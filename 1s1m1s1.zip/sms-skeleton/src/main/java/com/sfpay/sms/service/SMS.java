package com.sfpay.sms.service;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * 关于消息类型<br>
 * 香港短信接口中有个msgType.
 * 在资科的应用系统WebService中好像有一个MsgType的字段。
 * 顺银目前没有使用,统一使用的是SFPAY。如果需要用到，则可以使用JMS中的头字段：JMSType。所以暂时对JMSType保留使用。
 * <p>
 * 关于投递模式<br>
 * 暂时不提供投递模式。因为对于短信应用来说，性能并不是最重要的，只要服务不停。
 * 不管是何应用，如果没有必须的超高性能要求，则都应该是采用持久模式。
 * 一来是利于监控，二来持续订阅需要。
 * <p>
 * 
 * @author sfhq534 卢隆洲 CreateDate: 2014-7-29
 * @author 325336	梁亚保	CreateDate: 2014-7-29
 * @since 1.2.0
 */
public class SMS {

	private static Logger logger = LoggerFactory.getLogger(SMS.class);
	
	// 队列的命名规则？
	public static final String DESTINATION_CN="QUEUE_SMS_CN";
	public static final String DESTINATION_HK="QUEUE_SMS_HK";
	
	/**
	 * 对于中国移动的短信网关，可特别地写成<br>
	 * DESTINATION_CN_CMCC="QUEUE_SMS_CN_CMCC";
	 */
	public static final String DESTINATION_DEFAULT=DESTINATION_CN;
	
	/**
	 * 短信的默认存活时间,默认为0秒.即永不过期.
	 * JMSExpiration=timeToLiveInMilliseconds+GMT
	 */
	public static final long DEFAULT_TIME_TO_LIVE = 0L;
	
	
	/**
	 * 中国联通，一个短信批次，最多1000个手机号码。
	 */
	public static final int PHONE_MAX_NUM = 1000;
	
	/**
	 * 手机短信的长度是由编码决定的，根据国际标准，每条短信最多发送1120位。
	 * 合（1120÷8=140 一个字节占8位）140字节的内容。
	 * 如果发送纯英文字符，由于英文ASCII采用 7位编码，所以1120位的限额可以传送1120÷7=160个字符。
	 * 一旦传送的字符中包含中文、日文、韩文等双字节字符，不论中文还是西文，
	 * 不论全角还 是半角，都必须采用2个字节的8位编码，因此1120÷8÷2=70个字符，即最多传送70个字。
	 * 考虑到可能有的服务提供商会将一条长短信拆分成多条短信发送到用户手机。
	 * 
	 * 中国联通一般要求内容长度最大为402个汉字
	 * 中国移动一般要求内容长度最大为140个汉字
	 * 所以此处限制为700个汉字。足以表达10条最大长度的纯汉字短信。或者4条最大长度的纯英文短信。
	 * 如果超出此长度，则应该考虑下列三个方案：
	 * 1）业务系统缩减短信内容；
	 * 2）业务系统主动拆分短信内容；
	 * 3）主要内容以邮件发出，短信只作提醒；
	 */
	public static final int CONTENT_MAX_LENGTH=700;
	
	public static final String SMS_SOURCE="SMS-SOURCE";

	/**
	 * ShortMessageSource表示消息的源头。
	 * 可以表示发送消息的主机(名字或IP地址)、系统或应用的标识。
	 * ShortMessageSource可用于消息选择器；有利于服务器对短信的选择处理。 因此应该存在于消息头属性中。
	 * 
	 * @return 默认返回主机名字
	 */
	public static final String getShortMessageSource(){
		 try {
			return InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			logger.warn("InetAddress.getLocalHost().getHostName()无法获得本机名字！将使用UnknownHost表示。");
			return "UnknownHost";
		}
	}

}
