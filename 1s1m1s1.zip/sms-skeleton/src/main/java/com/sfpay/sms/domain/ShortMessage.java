/**
 * 包名：com.sfpay.sms.domain
 * 文件名：SmsMsg.java
 * 版本信息：
 * 日期：2014-7-28-上午9:32:48
 * 
 */
package com.sfpay.sms.domain;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.sms.service.SMS;
import com.sfpay.sms.service.ShortMessageService;

/**
 * 类名称：ShortMessage
 * 类描述：短信。表示域对象短信。包含手机号，内容等。
 * 修改时间：2014-7-28 上午9:32:48
 * 
 * <p>
 * 短信大小<br>
 * 按中国移动与中国联通的通信要求，进行评估。<br>
 * 批量手机号码的大小为1000*11=11KB,短信内容700汉字*2B=1400B，加额外信息总计是13KB。<br>
 * 这个大小的消息非常适合于MQ的处理。
 * <p>
 * 定时短信<br>
 * 定时时间是服务商需要的信息，如果以后需要扩展此信息，则应该设置在ShortMessage实体BEAN中。<br>
 * MQ定时而服务商不定时没有多少作用，服务商定时而MQ不定时，更有作用。<br>
 * <p>
 * 
 * @author sfhq534 卢隆洲
 * @author 325336 梁亚保
 * @since 1.2.0
 * 
 * @see ShortMessageService
 * @see	SMS
 * 
 */
public class ShortMessage implements Cloneable,Serializable{
	
	private static Logger logger = LoggerFactory.getLogger(ShortMessage.class);
	private static final long serialVersionUID = 1L;

	private String[] phoneNumber;
	
	/**
	 * 消息内容（必填）
	 */
	private String content;
	
	/**
	 * 开始发送时间段(如：08:00)(大陆短信不起效)
	 */
	private String periodBegin;
	
	/**
	 * 结束发送时间段(如：20:00)(大陆短信不起效)
	 */
	private String periodEnd;
	

	/**
	 * 
	 * 短信构造方法。其中手机号码与短信内容为必填内容
	 * @param phoneNumber	手机号码
	 * @param content		短信内容
	 */
	public ShortMessage(String phoneNumber, String content) {
		this.setPhoneNumber(phoneNumber);
		this.setContent(content);
	}
	
	/**
	 * 短信构造方法。其中手机号码与短信内容为必填内容
	 * @param phoneNumber	手机号码
	 * @param content		短信内容
	 */
	public ShortMessage(String[] phoneNumber, String content) {
		this.setPhoneNumber(phoneNumber);
		this.setContent(content);
	}
	
	/**
	 * 短信构造方法。其中手机号码与短信内容为必填内容
	 * @param phoneNumber	手机号码
	 * @param content		短信内容
	 */
	public ShortMessage(List<String> phoneNumber, String content) {
		this.setPhoneNumber(phoneNumber);
		this.setContent(content);
	}
	
	/**
	 * 
	 * @return	手机号码
	 */
	public String[] getPhoneNumber() {
		return phoneNumber;
	}
	
	/**
	 * @param phoneNumber	手机号码（必填）
	 */
	public void setPhoneNumber(String phoneNumber) {
		if(StringUtils.isEmpty(phoneNumber)){
			throw new IllegalArgumentException("手机号不能为空！");
		}
		this.phoneNumber = new String[]{phoneNumber};
	}
	
	/**
	 * @param phoneNumber	手机号码（必填）
	 * 
	 * <p>
	 * 国内运营商，多个手机号码时，以逗号分隔。
	 * 香港短信服务提供商，多个手机号码时，以分号分隔。
	 * <p>
	 * 手机号码的传参来源通常是两种方式，一是从数据库读取，二是从页面输入。
	 * 实体类的手机号码属性设计成数组形式，有利于:
	 * 1)有效性检查，
	 * 2)有利于参数传递;
	 * 3)有利于客户端的批量短信拆分;
	 * 4)有利于服务端组装报文。
	 * 
	 */
	public void setPhoneNumber(String[] phoneNumber) {
		if (phoneNumber == null || phoneNumber.length == 0) {
			throw new IllegalArgumentException("手机号码不能为空！");
		}
		for (String pn : phoneNumber) {
			if (StringUtils.isEmpty(pn)) {
				throw new IllegalArgumentException("手机号码不能为空！");
			}
		}
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @param phoneNumber 手机号码
	 */
	public void setPhoneNumber(List<String> phoneNumber) {
		
		if (phoneNumber == null || phoneNumber.isEmpty()) {
			throw new IllegalArgumentException("手机号码不能为空！");
		}
		for (String pn : phoneNumber) {
			if (StringUtils.isEmpty(pn)) {
				throw new IllegalArgumentException("手机号码不能为空！");
			}
		}
		
		this.phoneNumber = new String[phoneNumber.size()];
		phoneNumber.toArray(this.phoneNumber);
	}
	
	/**
	 * @return	短信内容
	 */
	public String getContent() {
		return content;
	}
	
	
	/**
	 * @param content	短信内容
	 * @see	SMS
	 * 短信内容不能超过{@link SMS#CONTENT_MAX_LENGTH}指定的最大长度
	 * 
	 */
	public void setContent(String content) {
		if(StringUtils.isEmpty(content)){
			throw new IllegalArgumentException("短信内容不能为空！");
		}
		if(content.length() > SMS.CONTENT_MAX_LENGTH){
			logger.error("短信内容不能超过"+SMS.CONTENT_MAX_LENGTH+"个字符！");
			throw new IllegalArgumentException("短信内容不能超过"+SMS.CONTENT_MAX_LENGTH+"个字符！");
		}
		this.content = content;
	}
	
	/**
	 * 
	 * @return	开始发送时间段(如：08:00)(大陆短信不起效)
	 */
	public String getPeriodBegin() {
		return periodBegin;
	}
	/**
	 * 
	 * @param periodBegin	开始发送时间段(如：08:00)(大陆短信不起效)
	 */
	public void setPeriodBegin(String periodBegin) {
		//TODO 正则表达式校验
		this.periodBegin = periodBegin;
	}
	
	/**
	 * 
	 * @return	结束发送时间段(如：20:00)(大陆短信不起效)
	 */
	public String getPeriodEnd() {
		return periodEnd;
	}
	/**
	 * 
	 * @param periodEnd	结束发送时间段(如：20:00)(大陆短信不起效)
	 */
	public void setPeriodEnd(String periodEnd) {
		//TODO 正则表达式校验
		this.periodEnd = periodEnd;
	}

	@Override
    public ShortMessage clone() {
        try {
			return (ShortMessage) super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((content == null) ? 0 : content.hashCode());
		result = prime * result
				+ ((periodBegin == null) ? 0 : periodBegin.hashCode());
		result = prime * result
				+ ((periodEnd == null) ? 0 : periodEnd.hashCode());
		result = prime * result + Arrays.hashCode(phoneNumber);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ShortMessage other = (ShortMessage) obj;
		if (content == null) {
			if (other.content != null)
				return false;
		} else if (!content.equals(other.content))
			return false;
		if (periodBegin == null) {
			if (other.periodBegin != null)
				return false;
		} else if (!periodBegin.equals(other.periodBegin))
			return false;
		if (periodEnd == null) {
			if (other.periodEnd != null)
				return false;
		} else if (!periodEnd.equals(other.periodEnd))
			return false;
		if (!Arrays.equals(phoneNumber, other.phoneNumber))
			return false;
		return true;
	}
}
