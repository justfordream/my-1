package com.sfpay.sms.service.test;

import java.util.Arrays;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;

import com.sfpay.sms.domain.ShortMessage;

public class ShortMessageReceiver4Test implements MessageListener {

	public static void main(String[] args) throws JMSException {
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
				"failover:(tcp://10.79.11.171:61619,tcp://10.79.11.172:61619)");
		Connection connection = connectionFactory.createConnection();
		connection.start();
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		MessageConsumer consumer = session.createConsumer(session
				.createQueue("QUEUE_SMS_HK1"));
		consumer.setMessageListener(new ShortMessageReceiver4Test());
	}

	public void onMessage(Message message) {
		if (message instanceof ObjectMessage) {
			ObjectMessage m = (ObjectMessage) message;
			try {
				ShortMessage s = (ShortMessage) m.getObject();
				System.out.println(Arrays.asList(s.getPhoneNumber()) + "   " + s.getContent());
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
