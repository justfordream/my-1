package com.sfpay.sms.service;

import java.util.Arrays;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.sms.domain.ShortMessage;

/**
 * 以ActiveMQ方式实现的短信服务
 * <p>
 * 与MQ相关的信息放在接口参数中，与MQ不相关的却属于短信的信息放在实体bean中。
 * 系统来源是我们业务跟踪需要，但服务商并不需要。因此系统源属于此服务实现类的属性参数。
 * <p>
 * 每一次发送方法的调用都是一次事务，默认以持久化模式投递。
 * 
 * @author 325336	梁亚保
 * @see	SMS
 * @see	ShortMessage
 * @see	ShortMessageService
 * @since 1.2.0
 *
 */
public class ShortMessageServiceWithQueue implements ShortMessageService {
	private static Logger logger = LoggerFactory.getLogger(ShortMessageServiceWithQueue.class);
	
	private ConnectionFactory connectionFactory;
	private String name="";
	
	
	/**
	 * 构造方法，以ActiveMQ方式实现的短信服务
	 * @param connectionUrl	ActiveMQ的连接字符串<br>
	 * 通常的ActiveMQ的连接字符串的参考写法如下：<br>
	 * failover:tcp://10.79.11.171:61619,tcp://10.79.11.172:61619
	 * <br>
	 * 内部默认使用{@link SMS#getShortMessageSource()}
	 */
	public ShortMessageServiceWithQueue(String connectionUrl){
		this(connectionUrl,SMS.getShortMessageSource());
	}
	
	/**
	 * 构造方法，以ActiveMQ方式实现的短信服务
	 * @param connectionUrl	ActiveMQ的连接字符串<br>
	 * 通常的ActiveMQ的连接字符串的参考写法如下：<br>
	 * failover:tcp://10.79.11.171:61619,tcp://10.79.11.172:61619
	 * @param	name	可以表示发送消息的主机(名字或IP地址)、系统或应用的标识。
	 * 参考{@link SMS#getShortMessageSource()}
	 */
	public ShortMessageServiceWithQueue(String connectionUrl,String name){
		connectionFactory = new org.apache.activemq.pool.PooledConnectionFactory(connectionUrl);  
		this.name = name;
	}

	/**
	 * 构造方法，以ActiveMQ方式实现的短信服务
	 * @param connectionFactory	ActiveMQ的连接工厂（或连接池）<br>
	 * 在既有短信发送又有短信情况查询或短信接收的情况下，可共用同一个连接池，不必为不同的情况使用不同的连接池。
	 * 内部默认使用{@link SMS#getShortMessageSource()}
	 * 参考{@link SMS#getShortMessageSource()}
	 */
	public ShortMessageServiceWithQueue(ConnectionFactory connectionFactory){
		this(connectionFactory,SMS.getShortMessageSource());
	}
	
	/**
	 * 构造方法，以ActiveMQ方式实现的短信服务
	 * @param connectionFactory	ActiveMQ的连接工厂（或连接池）<br>
	 * 在既有短信发送又有短信情况查询或短信接收的情况下，可共用同一个连接池，不必为不同的情况使用不同的连接池。
	 * @param	name	可以表示发送消息的主机(名字或IP地址)、系统或应用的标识。
	 * 参考{@link SMS#getShortMessageSource()}
	 */
	public ShortMessageServiceWithQueue(ConnectionFactory connectionFactory,String name){
		this.connectionFactory = connectionFactory;
		this.name = name;
	}
	
	@Override
	public void send(ShortMessage msg) {
		this.send(msg, SMS.DESTINATION_DEFAULT, SMS.DEFAULT_TIME_TO_LIVE);
	}

	@Override
	public void send(ShortMessage msg, long timeToLive) {
		this.send(msg, SMS.DESTINATION_DEFAULT, timeToLive);
	}
	
	@Override
	public void send(ShortMessage msg, String destination) {
		this.send(msg, destination, SMS.DEFAULT_TIME_TO_LIVE);
	}

	@Override
	public void send(ShortMessage msg, String destination, long timeToLiveInMilliseconds) {
		if (msg==null || destination ==null ) {
			throw new IllegalArgumentException("短信为空或目的地不明确！");
		}
		
		
		Connection connection = null;
		Session session =null;
		MessageProducer producer = null;
		try {

			connection = (Connection) connectionFactory.createConnection();
			connection.start();
			//通过事务的方法，确保分段发送的消息在一个事务中，要么一起完成，要么一起失败。
			//短信应用，并非业务关键型的，所以不需要XA事务。
			session = (Session) connection.createSession(true,
					Session.AUTO_ACKNOWLEDGE);
			
			producer = session.createProducer(new org.apache.activemq.command.ActiveMQQueue(destination));
			
			//JMSExpiration=timeToLiveInMilliseconds+GMT
			producer.setTimeToLive(timeToLiveInMilliseconds);
			
			//经考虑后，暂不使用ActiveMQ的消息组的特性。
			//批量手机号码被分段后，没有必要是同一个消费者进行发送。负载均衡后会有更好的性能表现。
			send(session, producer,msg);
			//以事务方式完成时，应该提交该事务
			session.commit();
			
		}catch(JMSException jmse){
			logger.error("消息发送异常", jmse);
		} catch (Exception e) {
			logger.error("消息发送异常", e);
		} finally {
			close(connection, session, producer);
		}
		
	}

	/**
	 * 当手机号码个数超过指定阀值时，通过递归二分法，拆分成多个消息发送到消息队列。<br>
	 * 假设手机号码超过指定阀值的1000个,为1002个。则一般有两种拆分方式：<br>
	 * 1）1000+2<br>
	 * 2）501+501<br>
	 * 考虑到：<br>
	 * 1）消息中间件的队列特性，消息是排队处理的，一般有先后顺序。<br>
	 * 2）短信服务的实际处理逻辑。部分服务提供商提供的接口只有逐个手机号码发送短信的功能，没有批量接口。<br>
	 * 所以：本类实现，使用的是第二种拆分策略。对于服务时间，会有更好的线性表现。<br>
	 * 
	 * @param session	会话
	 * @param producer	生产者
	 * @param msg		消息
	 * @throws JMSException	JMS异常
	 */
	private void send( Session session,
			MessageProducer producer,ShortMessage msg) throws JMSException {
		if (msg.getPhoneNumber() == null) {
			throw new IllegalArgumentException("手机号不能为空！");
		}
		
		int length = msg.getPhoneNumber().length;
		//校验检查逻辑 二分法的设计思路
		if (length>SMS.PHONE_MAX_NUM) {
			ShortMessage left = msg.clone();
			left.setPhoneNumber(Arrays.copyOfRange(msg.getPhoneNumber(), 0, length/2));
			send( session, producer,left);
			
			ShortMessage right = msg.clone();
			right.setPhoneNumber(Arrays.copyOfRange(msg.getPhoneNumber(), length/2, length));
			send(session, producer,right);
		} else {
			//创建并发送JMS消息
			ObjectMessage message = session.createObjectMessage(msg);
			message.setStringProperty(SMS.SMS_SOURCE, name);			
			producer.send(message);
		}
		
	}
	
	/**
	 * 关闭资源，实际是向连接池归还资源。
	 * @param connection
	 * @param session
	 * @param producer
	 */
	private void close(Connection connection, Session session,
			MessageProducer producer) {
		if (producer != null) {
			try {
				producer.close();
			} catch (JMSException e) {
				logger.error("消息生产者关闭异常",e );
			}
		}
		if(session!=null){
			try {
				session.close();
			} catch (JMSException e) {
				logger.error("消息会话关闭异常", e);
			}
		}
		if (connection != null) {
			try {
				connection.close();
			} catch (JMSException e) {
				logger.error("消息连接关闭异常", e);
			}
		}
	}

	
}
