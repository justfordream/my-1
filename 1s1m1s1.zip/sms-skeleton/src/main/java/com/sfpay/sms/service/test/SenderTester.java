package com.sfpay.sms.service.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.sfpay.sms.domain.ShortMessage;
import com.sfpay.sms.service.ShortMessageService;
import com.sfpay.sms.service.ShortMessageServiceWithQueue;

public class SenderTester {
	public static void main(String[] args) throws InterruptedException{
		
		final ShortMessageService sms = new ShortMessageServiceWithQueue("failover:(tcp://10.79.11.171:61619,tcp://10.79.11.172:61619)");
		
		class SendTask implements Runnable{

			@Override
			public void run() {
				System.out.println(Thread.currentThread().getId());
				for(int i=0;i<10000;i++){
					sms.send(new ShortMessage("18718868355","just for test my short message service!"), 10000);
				}
			}
			
		};
		ExecutorService es = Executors.newFixedThreadPool(20);
		for(int i=0;i<20;i++){
			es.submit(new SendTask());
		}
		es.awaitTermination(120, TimeUnit.SECONDS);
		//es.shutdownNow();
	}

}
