package com.sfpay.sms.service;

import com.sfpay.sms.domain.ShortMessage;

/**
 * <p>
 * 短信服务接口
 * 
 * @see	SMS
 * @see ShortMessage
 * @see ShortMessageServiceWithQueue
 * @author 325336	梁亚保
 * @since 1.2.0
 *
 */
public interface ShortMessageService {
	
	/**
	 * 重载{@link #send(ShortMessage, String, long)}
	 * 使用{@link SMS#DESTINATION_DEFAULT}
	 * 短信不作存活时间限制，直到发送给运营商
	 * @param msg	短信
	 * @exception	IllegalArgumentException	当输入参数为空值时，抛出运行时非法参数异常。
	 */
	public void send(ShortMessage msg);
	
	/**
	 * 重载{@link #send(ShortMessage, String, long)}<br>
	 * 使用{@link SMS#DESTINATION_DEFAULT}<br>
	 * 注意JMSExpiration与MessageProducer中的timeToLive是不同的。但0都是表示不过期。<br>
	 * 短信设计中使用了timeToLive，因为短信验证码有效期用得特多。<br>
	 * 
	 * @param msg	短信
	 * @param timeToLive	短信在消息系统中存活指定的毫秒数
	 * @exception	IllegalArgumentException	当输入参数为空值时，抛出运行时非法参数异常。
	 */
	public void send(ShortMessage msg,long timeToLive);
	
	/**
	 * 重载{@link #send(ShortMessage, String, long)}
	 * 短信不作存活时间限制，直到发送给运营商
	 * @param msg
	 * @param destination	目的（地区运营商），通常表示某个地区或某个移动运营商或某个短信服务提供商。
	 * @exception	IllegalArgumentException	当输入参数为空值时，抛出运行时非法参数异常。
	 */
	public void send(ShortMessage msg,String destination);
	
	/**
	 * 发送短信到指定的目的地区，短信在消息系统中存活指定的毫秒数。
	 * 当手机号码个数大于{@link SMS#PHONE_MAX_NUM}时，此方法将会通过递归二分法，拆分成多个消息发送。
	 * 确保所发送的每条消息的手机号码个数在{@link SMS#PHONE_MAX_NUM}限制内。
	 * @param msg			短信
	 * @param destination	目的地。香港、中国大陆或其它地区。
	 * 可参考{@link SMS#DESTINATION_DEFAULT},
	 * {@link SMS#DESTINATION_CN},
	 * {@link SMS#DESTINATION_HK}.
	 * @param timeToLiveInMilliseconds	短信在消息系统中存活指定的毫秒数
	 * @exception	IllegalArgumentException	当输入参数为空值时，抛出运行时非法参数异常。
	 */
	public void send(ShortMessage msg,String destination,long timeToLiveInMilliseconds);
	
}
