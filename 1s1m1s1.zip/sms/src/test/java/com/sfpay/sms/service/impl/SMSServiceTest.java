package com.sfpay.sms.service.impl;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;
import java.util.Set;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.framework.web.test.SpringTestCase;
import com.sfpay.sms.domain.ShortMessage;

public class SMSServiceTest extends SpringTestCase {

	@Resource
	private SMSService smsService;
	
	@Test
	public void testSend() {
		smsService.send("test", "18718868351");
	}
		
	@Test
	public void testCheckMssage()
	{
		ShortMessage smsMsg = new ShortMessage("18617099712", "test123");
		ShortMessage smsMsg2 = new ShortMessage("18617099712", "test123");
		
		Set<ShortMessage> set = new HashSet<ShortMessage>();
		set.add(smsMsg);
		set.add(smsMsg2);
		
		assertEquals(smsMsg, smsMsg2);
		assertEquals(set.size(), 1);
	}
	
}
