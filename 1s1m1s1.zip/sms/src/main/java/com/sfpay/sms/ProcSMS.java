/**
 * ProcSMS_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sfpay.sms;

public interface ProcSMS extends java.rmi.Remote {
    public java.lang.String sendSMS(com.sfpay.sms.dao.bean.SMS sms) throws java.rmi.RemoteException;
    public java.lang.String sendSMSEX(com.sfpay.sms.dao.bean.SMSEX sms) throws java.rmi.RemoteException;
    public java.lang.String sendAdvertisement(com.sfpay.sms.dao.bean.SMS sms) throws java.rmi.RemoteException;
}
