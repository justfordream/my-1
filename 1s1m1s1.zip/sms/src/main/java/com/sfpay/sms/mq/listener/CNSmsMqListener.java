/**
 * 包名：com.sfpay.sms.mq.listener
 * 文件名：CNSmsMqListener.java
 * 版本信息：
 * 日期：2014-7-10-下午4:02:29
 * 
 */
package com.sfpay.sms.mq.listener;

import javax.annotation.Resource;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.base.utils.StringUtils;
import com.sfpay.sms.domain.ShortMessage;
import com.sfpay.sms.service.SMS;
import com.sfpay.sms.service.impl.SMSService;

/**
 * 类名称：CNSmsMqListener 
 * @author	313920 	熊伟 
 * @author	sfhq534 	卢隆洲 
 * 修改时间：2014-7-10 下午4:02:29
 * 修改备注：大陆短信监听器
 * 
 * @version 2.0.1
 * 
 */
public class CNSmsMqListener implements MessageListener {

	private static Logger logger = LoggerFactory.getLogger(CNSmsMqListener.class);

	@Resource
	private SMSService smsService;

	@Override
	public void onMessage(Message message) {

		if (!(message instanceof ObjectMessage)) {
			logger.info("接收的消息类型不匹配！");
			return;
		}
		try {
			ObjectMessage objectMessage = (ObjectMessage) message;
			ShortMessage smsMsg = (ShortMessage)objectMessage.getObject();
			logger.info("短信来源:【{}】",message.getStringProperty(SMS.SMS_SOURCE));
			logger.info("短信内容:【{}】",smsMsg.getContent());
			if (smsMsg.getPhoneNumber() == null || smsMsg.getPhoneNumber().length == 0) {
				logger.info("手机号为空，不处理！");
				return;
			}
			
			if(StringUtils.isEmpty(smsMsg.getContent())){
				logger.info("短信内容为空，不处理！");
				return;
			}
			
			for (int i = 0; i < smsMsg.getPhoneNumber().length; i++)	
			{
				smsService.send(smsMsg.getContent(), smsMsg.getPhoneNumber()[i]);
			}
			
		} catch (JMSException e) {
			logger.error("jms异常", e);
		}

	}

}
