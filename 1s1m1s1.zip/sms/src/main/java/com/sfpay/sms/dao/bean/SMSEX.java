
package com.sfpay.sms.dao.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SMSEX complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SMSEX">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SP" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="checkword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="mobileno" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="msgId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="msgtype" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="resno" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SMSEX", propOrder = {
    "sp",
    "checkword",
    "mobileno",
    "msg",
    "msgId",
    "msgtype",
    "resno",
    "systemId"
})
public class SMSEX {

    @XmlElement(name = "SP", required = true, nillable = true)
    protected String sp;
    @XmlElement(required = true, nillable = true)
    protected String checkword;
    @XmlElement(required = true, nillable = true)
    protected String mobileno;
    @XmlElement(required = true, nillable = true)
    protected String msg;
    @XmlElement(required = true, nillable = true)
    protected String msgId;
    @XmlElement(required = true, nillable = true)
    protected String msgtype;
    @XmlElement(required = true, nillable = true)
    protected String resno;
    @XmlElement(required = true, nillable = true)
    protected String systemId;

    /**
     * Gets the value of the sp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSP() {
        return sp;
    }

    /**
     * Sets the value of the sp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSP(String value) {
        this.sp = value;
    }

    /**
     * Gets the value of the checkword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckword() {
        return checkword;
    }

    /**
     * Sets the value of the checkword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckword(String value) {
        this.checkword = value;
    }

    /**
     * Gets the value of the mobileno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileno() {
        return mobileno;
    }

    /**
     * Sets the value of the mobileno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileno(String value) {
        this.mobileno = value;
    }

    /**
     * Gets the value of the msg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsg() {
        return msg;
    }

    /**
     * Sets the value of the msg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsg(String value) {
        this.msg = value;
    }

    /**
     * Gets the value of the msgId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgId() {
        return msgId;
    }

    /**
     * Sets the value of the msgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgId(String value) {
        this.msgId = value;
    }

    /**
     * Gets the value of the msgtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgtype() {
        return msgtype;
    }

    /**
     * Sets the value of the msgtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgtype(String value) {
        this.msgtype = value;
    }

    /**
     * Gets the value of the resno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResno() {
        return resno;
    }

    /**
     * Sets the value of the resno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResno(String value) {
        this.resno = value;
    }

    /**
     * Gets the value of the systemId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemId() {
        return systemId;
    }

    /**
     * Sets the value of the systemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemId(String value) {
        this.systemId = value;
    }

}
