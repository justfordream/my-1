/**
 * ProcSMSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sfpay.sms;

public interface ProcSMSService extends javax.xml.rpc.Service {
    public java.lang.String getprocSMSAddress();

    public com.sfpay.sms.ProcSMS getprocSMS() throws javax.xml.rpc.ServiceException;

    public com.sfpay.sms.ProcSMS getprocSMS(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
