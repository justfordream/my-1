package com.sfpay.sms.service.impl;


import java.util.Arrays;

import javax.annotation.Resource;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework.config.properties.Property;
import com.sfpay.pubcenter.sms.ISMSService;
import com.sfpay.pubcenter.sms.exception.SMSException;
import com.sfpay.sms.ProcSMSServiceLocator;
import com.sfpay.sms.ProcSMS;
import com.sfpay.sms.dao.bean.SMS;

/**
 * 
 * 
 * 类说明：短信发送服务
 * 
 * 
 * <p>
 * 详细描述：
 * 
 * 
 * @author 313920
 * 
 *         CreateDate: 2012-2-7
 */
@Service
public class SMSService implements ISMSService{
	private static Logger logger = LoggerFactory.getLogger(SMSService.class);

	private static ProcSMSServiceLocator client = new ProcSMSServiceLocator();
	private static final String msgType = Property.getProperty("MSG_TYPE");
	//香港短信地址
	private static final String HK_SMS_URL = Property.getProperty("HK_SMS_URL");
	private static final String wsdl = Property.getProperty("SF_SMS_WSDL");
	
	private static final int HK_MOBILE_LENGTH = 8;
	
	private static final String HK_MOBILE_DIVCODE = "852";
	@Resource
	private HttpClient httpClient;
	
	@Override
	public String send(String message, String mobileNo) {
		try {
			client.setprocSMSEndpointAddress(wsdl);
			ProcSMS service = client.getprocSMS();
			String result = "";
			logger.debug("msgType:" + msgType + ",service:"+service);
			logger.info("start send, mobile:[" + mobileNo + "],message:[" + message + "]");
			int length = 500;
			for (int i = 0; i <= message.length() / length; i++) {
				SMS sms = new SMS();
				sms.setCheckword("");
				sms.setMobileno(mobileNo);
				if ((i + 1) * length > message.length()) {
					sms.setMsg(message.substring(i * length, message.length()));
				} else {
					sms.setMsg(message.substring(i * length, (i + 1) * length));
				}
				sms.setMsgtype(msgType);
//				sms.setResno("SFPAY");
				//2013年11月13日16:39:00修改调用方式，改为sendSMS
				//result = service.sendAdvertisement(sms);
				result = service.sendSMS(sms);
				if(result.charAt(0) == '0'){
					logger.error("send error, mobile:[" + mobileNo + "],message:[" + message + "],result:["+result+"]");
				}else{
					logger.info("send success, mobile:[" + mobileNo + "],message:[" + message + "],result:["+result+"]");
				}
			}
			return result;
		} catch (Exception e) {
			logger.error("send message error ", e);
			throw new SMSException(e.getMessage());
		}
	}
	
	/**
	 * 
	 * 方法说明：sendHK 发送香港
	 * @param smsMsg
	 * @return 
	 * @exception 
	 * @since  2.0.1
	 */
	public String sendHK(com.sfpay.sms.domain.ShortMessage smsMsg) {
		PostMethod postMethod = new PostMethod(HK_SMS_URL); 
		postMethod.addRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		postMethod.addParameter("msgType", msgType);
		postMethod.addParameter("msg", smsMsg.getContent());
		postMethod.addParameter("destphone", buildPhoneNumberForHK(smsMsg.getPhoneNumber()));
		
		if (smsMsg.getPeriodBegin() != null) {
			postMethod.addParameter("periodBegin", smsMsg.getPeriodBegin());
		}
		if (smsMsg.getPeriodEnd() != null) {
			postMethod.addParameter("periodEnd", smsMsg.getPeriodEnd());
		}
		String responseBody = null;
		try {
			logger.info(String.format("开始发送短息,内容:【%s】",smsMsg.getContent()));
			int status = httpClient.executeMethod(postMethod);
			responseBody = new String(postMethod.getResponseBody());
			logger.info(String.format("短信发送完成，号码:【%s】,返回状态码:【%s】，返回消息体:【%s】", Arrays.asList(smsMsg.getPhoneNumber()),status,responseBody));
			return responseBody;
		} catch (Exception e) {
			logger.error("【"+Arrays.asList(smsMsg.getPhoneNumber())+"】短信发送异常",e);
		} finally{
			postMethod.releaseConnection();
		}
		return responseBody;
	}

	private String buildPhoneNumberForHK(String[] phoneNumber){
		StringBuilder builder = new StringBuilder();
		for(String p:phoneNumber){
			builder.append(p.length() == HK_MOBILE_LENGTH?HK_MOBILE_DIVCODE+p:p).append(';');
		}
		builder.deleteCharAt(builder.length()-1);
		return builder.toString();
	}

}
