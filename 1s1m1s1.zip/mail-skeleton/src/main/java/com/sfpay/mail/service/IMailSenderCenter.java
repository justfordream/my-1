/**
 * 
 */
package com.sfpay.mail.service;

import com.sfpay.mail.domain.MailInfo;



/**
 * 类说明：邮件发送服务类
 *
 * 类描述：一般情况下，一个连接只需建立一个MailSenderServiceImpl对象，推荐由Spring容器管理该对象。
 * 本对象将使用PooledConnectionFactory提供的缓存Connection、Session和Producer的功能。
 * 
 * @author 625288 易振强
 * 2015-1-5
 */
public interface IMailSenderCenter {
	
	/**
	 * 发送一封邮件
	 * 消息生存时间无限
	 * @param mailInfo
	 * @param queueName
	 * @param timeToLive 以毫秒为单位
	 */
	public void sendMail(MailInfo mailInfo, String queueName);
	
	/**
	 * 发送一封邮件
	 * 消息有固定的生存时间
	 * @param mailInfo
	 * @param queueName
	 * @param timeToLive 以毫秒为单位
	 */
	public void sendMail(MailInfo mailInfo, String queueName, long timeToLive);
	
	/**
	 * 获取队列名称
	 */
	public void getQueueName();
	
}
