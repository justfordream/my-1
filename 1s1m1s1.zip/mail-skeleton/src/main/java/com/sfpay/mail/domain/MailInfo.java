/**
 * 
 */
package com.sfpay.mail.domain;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * 类说明：邮件对象
 * 
 * 类描述：邮件对象
 * 
 * @author 625288 易振强 2015-1-5
 */
public class MailInfo implements Serializable {
	private static final long serialVersionUID = 5902075564266010504L;

	// 发送人
	private String sender;
	// 收件人
	private String reciver;
	// 抄送人
	private String carbonCopy;
	// 主题
	private String subject;
	// 邮件内容
	private String content;
	// 发送日期
	private Date sendDate;
	// 0::发送不成功,1:发送成功
	private String flag;
	// 备注
	private String remarks;
	// 发送来源
	private String systemFrom;
	// SIMPL_EMAIL:简单邮件类型；HTML_EMAIL:HTML邮件类型
	private String mailType;

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getReciver() {
		return reciver;
	}

	public void setReciver(String reciver) {
		this.reciver = reciver;
	}

	public String getCarbonCopy() {
		return carbonCopy;
	}

	public void setCarbonCopy(String carbonCopy) {
		this.carbonCopy = carbonCopy;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getSendDate() {
		return sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSystemFrom() {
		return systemFrom;
	}

	public void setSystemFrom(String systemFrom) {
		this.systemFrom = systemFrom;
	}

	public String getMailType() {
		return mailType;
	}

	public void setMailType(String mailType) {
		this.mailType = mailType;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
