/**
 * 
 */
package com.sfpay.mail.domain;

/**
 * 类说明：邮件类型
 *
 * 类描述：SIMPL_EMAIL:简单邮件类型；HTML_EMAIL:HTML邮件类型
 * @author 625288 易振强
 * 2015-1-5
 */
public enum MailType {
	SIMPL_EMAIL("SIMPL_EMAIL"),
	HTML_EMAIL("HTML_EMAIL");
	
	private String value;
	
	MailType(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return value;
	}
}
