/**
 * 
 */
package com.sfpay.mail.service.impl;

import java.util.Arrays;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.mail.domain.MailInfo;
import com.sfpay.mail.domain.MailType;



/**
 * 类说明：邮件发送服务类
 *
 * 类描述：一般情况下，一个连接只需建立一个MailSenderServiceImpl对象，推荐由Spring容器管理该对象。
 * 本对象将使用PooledConnectionFactory提供的缓存Connection、Session和Producer的功能。
 * 
 * @author 625288 易振强
 * 2015-1-5
 */
public class MailSenderCenterImpl {
	private ConnectionFactory connectionFactory;
	private String queueName;
	
	private static Logger logger = LoggerFactory.getLogger(MailSenderCenterImpl.class);
	
	/**
	 * 新建一个连接器中心
	 * @param connectionUrl
	 */
	public MailSenderCenterImpl(String connectionUrl, String queueName) {
		if(StringUtils.isBlank(connectionUrl) || StringUtils.isBlank(queueName)) {
			throw new IllegalArgumentException("连接URL或队列名称不能为空！");
		}
		
		connectionFactory = new PooledConnectionFactory(connectionUrl);
		this.queueName = queueName;
	}
	
	/**
	 * 发送一封邮件
	 * 消息生存时间无限
	 * @param mailInfo
	 * @param queueName
	 * @param timeToLive 以毫秒为单位
	 */
	public void sendMail(MailInfo mailInfo) {
		sendMail(mailInfo, 0);
	}
	
	/**
	 * 发送一封邮件
	 * 消息有固定的生存时间
	 * @param mailInfo
	 * @param queueName
	 * @param timeToLive 以毫秒为单位
	 */
	public void sendMail(MailInfo mailInfo, long timeToLive) {
		logger.debug("sendMail start 【{}】 【{}】 【{}】", mailInfo, queueName, timeToLive);
		
		if (mailInfo == null || StringUtils.isBlank(queueName)) {
			throw new IllegalArgumentException("邮件对象或队列名称为空！");
		}
		
		timeToLive = timeToLive < 0 ? 0 : timeToLive;
		
		String type = mailInfo.getMailType();
		if(!Arrays.asList(MailType.values()).contains(type)) {
			logger.error("邮件类型非法【{}】！", mailInfo.getMailType());
			throw new IllegalArgumentException(String.format("邮件类型非法【%s】！", mailInfo.getMailType()));
		}
		
		if(StringUtils.isBlank(mailInfo.getSender()) || StringUtils.isBlank(mailInfo.getReciver()) 
				|| StringUtils.isBlank(mailInfo.getSubject()) || StringUtils.isBlank(mailInfo.getContent())) {
			logger.error("发件人、收件人、邮件标题和邮件正文不能为空【{}】！", mailInfo.getMailType());
			throw new IllegalArgumentException(String.format("发件人、收件人、邮件标题和邮件正文不能为空【%s】！", mailInfo.getMailType()));
		}
		
		Connection connection = null;
		Session session = null;
		MessageProducer producer = null;
		try {

			connection = connectionFactory.createConnection();
			
			session = (Session) connection.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			
			producer = session.createProducer(new ActiveMQQueue(queueName));
			
			producer.setTimeToLive(timeToLive);
			
			connection.start();
			
			//创建并发送JMS消息
			ObjectMessage message = session.createObjectMessage(mailInfo);
			producer.send(message);
			
			logger.info("邮件消息【{}】发送成功!", mailInfo.getSubject());
			
		} catch (Exception e) {
			logger.error("邮件消息【{}】发送异常{}", mailInfo.getSubject(), e);
		} finally {
			close(connection, session, producer);
		}
	}
	
	/**
	 * 关闭资源，实际是向连接池归还资源。
	 * @param connection
	 * @param session
	 * @param producer
	 */
	private void close(Connection connection, Session session,
			MessageProducer producer) {
		if (producer != null) {
			try {
				producer.close();
			} catch (JMSException e) {
				logger.error("消息生产者关闭异常",e );
			}
		}
		
		if(session != null){
			try {
				session.close();
			} catch (JMSException e) {
				logger.error("消息会话关闭异常", e);
			}
		}
		
		if (connection != null) {
			try {
				connection.close();
			} catch (JMSException e) {
				logger.error("消息连接关闭异常", e);
			}
		}
	}
	
	
	
	
}
