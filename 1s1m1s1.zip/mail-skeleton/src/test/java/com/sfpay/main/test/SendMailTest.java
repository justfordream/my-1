package com.sfpay.main.test;

import com.sfpay.mail.service.IMailSenderCenter;
import com.sfpay.mail.service.impl.MailSenderCenterImpl;

public class SendMailTest {
	public static void main(String[] args) {
		IMailSenderCenter center = new MailSenderCenterImpl("");
	}
}
