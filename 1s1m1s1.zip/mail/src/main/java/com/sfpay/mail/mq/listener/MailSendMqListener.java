/**
 * 
 */
package com.sfpay.mail.mq.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.mail.domain.MailInfo;


/**
 * 类说明：邮件发送消息监听器
 *
 * 类描述：邮件发送消息监听器
 * @author 625288 易振强
 * 2015-1-5
 */
public class MailSendMqListener implements MessageListener {
	private static Logger logger = LoggerFactory.getLogger(MailSendMqListener.class);

	@Override
	public void onMessage(Message message) {
		if (!(message instanceof ObjectMessage)) {
			logger.info("接收的消息类型不匹配:" + message.getClass());
			return;
		}
		
		try {
			ObjectMessage objectMessage = (ObjectMessage) message;
			MailInfo mailInfo = (MailInfo)objectMessage.getObject();
			logger.info("接收到发送邮件消息类:【{}】", message);
			
			// TODO: 发送邮件的服务调用
			
			
		} catch (JMSException e) {
			logger.error("jms异常", e);
		}

	}

}
