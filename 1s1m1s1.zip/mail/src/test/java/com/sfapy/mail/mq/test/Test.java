/**
 * 
 */
package com.sfapy.mail.mq.test;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;

import com.sfpay.mail.domain.MailInfo;
import com.sfpay.mail.domain.MailType;


/**
 * 类说明：
 *
 * 类描述：
 * @author 625288 易振强
 * 2015-1-5
 */
public class Test {
	public static void main(String[] args) {
		ConnectionFactory factory = new ActiveMQConnectionFactory("failover:tcp://10.79.6.181:61616," +
				"tcp://10.79.6.181:61617,tcp://10.79.6.181:61618");
		try {
			Connection connection = factory.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageProducer producer = session.createProducer(new ActiveMQQueue("MAIL_SEND_QUEUE"));
			
			MailInfo mailInfo = new MailInfo();
			mailInfo.setSubject("永远的海贼王");
			mailInfo.setContent("zdfsfsdfzdxfsdfsaf士大夫士大夫士大夫123123213");
			mailInfo.setMailType(MailType.SIMPL_EMAIL.toString());
			mailInfo.setSender("yizhenqiang@sf-express.com");
			mailInfo.setReciver("fengxiaopeng@sf-express.com");
			
			for(int i = 0; i < 10; i++) {
				producer.send(session.createObjectMessage(mailInfo));
			}
			
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
}
