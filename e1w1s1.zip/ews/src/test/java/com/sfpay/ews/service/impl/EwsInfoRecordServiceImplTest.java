package com.sfpay.ews.service.impl;


import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.ews.dao.IEwsInfoRecordDao;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsInfoRecord;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsInfoRecordService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsInfoRecordServiceImplTest extends ClassTransactionalTestCase {

	@Resource
	private IEwsInfoRecordService ewsInfoRecordService;
	
	@Resource
	private IEwsInfoRecordDao ewsInfoRecordDao;
	
	@Resource
	private IEwsIndexDefService ewsIndexDefService;
	
	@Test
	public void testUpdateEwsInfoRecord() {
		
	}

	@Test
	public void testDelEwsInfoRecord() {
		ewsInfoRecordService.delEwsInfoRecord("TEST0013201504081824310112");
		try {
			ewsInfoRecordService.delEwsInfoRecord(null);
		} catch (Exception e) {
		}
		
		try {
			ewsInfoRecordService.delEwsInfoRecord("123");
		} catch (Exception e) {
		}
	}

	@Test
	public void testQueryById() {
		EwsInfoRecord ewsInfoRecord=ewsInfoRecordService.queryById("SFPR0036201504141434000131");
		
		try {
			ewsInfoRecordService.queryById("");
		} catch (Exception e) {
		}
		
		System.out.println(ewsInfoRecord);
	}

	@Test
	public void testQueryAll() {
		ewsInfoRecordService.queryAll();
	}

	@Test
	public void testQueryEwsInfoRecordByParam() {
		EwsInfoRecord ewsInfoRecord=new EwsInfoRecord();
		ewsInfoRecord.setWarnClassCode("CHANNEL");
		ewsInfoRecordService.queryEwsInfoRecordByParam(ewsInfoRecord);
	}

	@Test
	public void testQueryEwsHandleInfoByOrderPage() {
		EwsInfoRecord ewsInfoRecord=new EwsInfoRecord();
		ewsInfoRecord.setWarnClassCode("CHANNEL");
		ewsInfoRecordService.queryEwsHandleInfoByOrderPage(ewsInfoRecord, 1, Integer.MAX_VALUE);
	}

	@Test
	public void testAddEwsInfoRecord() {
		EwsIndexDef ewsIndexDef=new EwsIndexDef();
//		ewsIndexDef=ewsIndexDefService.queryEwsIndexDefByIndexNo("TEST0003");
		ewsIndexDef=ewsIndexDefService.queryByWarnIndexNo("TEST0003");
		String id=ewsInfoRecordService.addEwsInfoRecord(ewsIndexDef, "预警记录测试", new Date(), new Date());
/*		Long ewsInfoRecordSeq=ewsInfoRecordDao.getEwsInfoRecordSeqValue();
		String id=DateUtils.formatDate(new Date(),"yyyyMMddHHmmss")+String.format("%04d", ewsInfoRecordSeq);*/
		System.out.println(id);
	}
	
	@Test
	public void testUpateEwsInfoRecord(){
		EwsInfoRecord ewsInfoRecord=new EwsInfoRecord();
		try {
			ewsInfoRecordService.updateEwsInfoRecord(null);
		} catch (Exception e) {
		}
		
		try {
			ewsInfoRecord.setId("TEST0013201504020204470065");
			ewsInfoRecordService.updateEwsInfoRecord(ewsInfoRecord);
		} catch (Exception e) {
		}
		
		try {
			ewsInfoRecord.setId("");
			ewsInfoRecord.setInfoContext("测试");
			ewsInfoRecordService.updateEwsInfoRecord(ewsInfoRecord);
		} catch (Exception e) {
		}
		
		
	}
	
	@Test
	public void testQueryEwsDetailInfoByEwsInfoId() {
//		ArrayList<String[]> exportExcel = new ArrayList<String[]>();
		String ewsInfoRecordId="TEST0013201504020204470065";
		Map<String, List<Map<String, Object>>> resultMap=ewsInfoRecordService.queryEwsDetailInfoByEwsInfoId(ewsInfoRecordId);
		
//		for (Map.Entry<String, List<Map<String, Object>>> result : resultMap.entrySet()) {
//			String sheetName = result.getKey();
//			List<Map<String, Object>> singleResultList = result.getValue();
//			// 获取第一行Map的Size为标题的长度
//			String[] contenCells = new String[singleResultList.get(0).size()];
//			String[] cellsTitle = new String[singleResultList.get(0).size()];
//
//			for (Map<String, Object> map : singleResultList) {
//				cellsTitle=map.keySet().toArray(new String[0]);
//				List<String> content=new ArrayList(map.values());
//				contenCells=content.toArray(new String[0]);
//				exportExcel.add(contenCells);
//			}
//		}
		
		System.out.println(resultMap.size());
	}

}
