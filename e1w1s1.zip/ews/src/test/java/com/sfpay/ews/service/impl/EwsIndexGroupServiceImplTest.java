package com.sfpay.ews.service.impl;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.service.IEwsIndexGroupService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsIndexGroupServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private IEwsIndexGroupService ewsIndexGroupService;
	
	@Test
	public void testQueryAllEwsIndexGroup() {
		ewsIndexGroupService.queryAllEwsIndexGroup();
	}

	@Test
	public void testQueryEwsIndexGroupByGroupNo() {
		ewsIndexGroupService.queryEwsIndexGroupByGroupNo("TEST_GROUP");
		try {
			ewsIndexGroupService.queryEwsIndexGroupByGroupNo("");
		} catch (Exception e) {
		}
	}

}
