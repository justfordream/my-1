/**
 * 
 */
package com.sfpay.ews.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.service.IBeanShellService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-27
 */
public class BeanShellServiceImplTest extends ClassTransactionalTestCase {
	
	@Autowired
	private IBeanShellService beanShellService;
	
	@Test
	public void executeShellTest() {
		beanShellService.executeShell("SFPR0001");
		
		
	}
}
