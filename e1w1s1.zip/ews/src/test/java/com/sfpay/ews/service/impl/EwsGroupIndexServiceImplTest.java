package com.sfpay.ews.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsGroupIndex;
import com.sfpay.ews.platform.service.IEwsGroupIndexService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsGroupIndexServiceImplTest extends ClassTransactionalTestCase{

	@Autowired
	private IEwsGroupIndexService ewsGroupIndexService;
	
	@Test
	public void testAddEwsGroupIndex() {
		EwsGroupIndex ewsGroupIndex=new EwsGroupIndex();
		try {
			ewsGroupIndexService.addEwsGroupIndex(ewsGroupIndex);
		} catch (Exception e) {
		}
		ewsGroupIndex.setGroupNo("TEST");
		ewsGroupIndex.setWarnIndexNo("testIndex");
		try {
			ewsGroupIndexService.addEwsGroupIndex(ewsGroupIndex);
		} catch (Exception e) {
		}
	}

	@Test
	public void testQueryEwsGroupIndex() {
		try {
			ewsGroupIndexService.queryEwsGroupIndex("TEST_GROUP", "TEST0001");
		} catch (Exception e) {
		}
		
		try {
			ewsGroupIndexService.queryEwsGroupIndex("TEST_GROUP", "");
		} catch (Exception e) {
		}
		
		try {
			ewsGroupIndexService.queryEwsGroupIndex("", "TEST0001");
		} catch (Exception e) {
		}
	}

}
