/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsIndexGroup;
import com.sfpay.ews.platform.domain.EwsIndexParam;
import com.sfpay.ews.platform.sch.service.IEwsGroupTaskService;
import com.sfpay.ews.platform.sch.service.IEwsTaskService;
import com.sfpay.ews.platform.service.IEwsEmpGroupReferService;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsIndexGroupReferService;
import com.sfpay.ews.platform.service.IEwsIndexGroupService;
import com.sfpay.ews.platform.service.IEwsIndexParamService;
import com.sfpay.ews.service.IEwsSendMailAndSmsService;
import com.sfpay.ews.util.ParamStrUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：指标组调度任务服务实现类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
//@HessianExporter
//@Service("ewsGroupTaskService")
public class EwsGroupTaskServiceImpl_bak implements IEwsGroupTaskService {
	@Autowired
	private IEwsIndexGroupService ewsIndexGroupService;
	@Autowired
	private IEwsTaskService ewsTaskService;
	@Autowired
	private IEwsIndexGroupReferService ewsIndexGroupReferService;
	@Autowired
	private IEwsIndexParamService ewsIndexParamService;
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	@Autowired
	private IEwsSendMailAndSmsService warnSendMailAndSmsService;
	@Autowired
	private IEwsEmpGroupReferService ewsEmpGroupReferService;
	
	private Logger logger = LoggerFactory.getLogger(EwsGroupTaskServiceImpl_bak.class);
	
	@Override
	@Async
	public void doTask(String ewsIndexGroupNo) {
	/*	logger.info("开始执行指标组调度：{}", ewsIndexGroupNo);
		
		try {
			if(StringUtils.isBlank(ewsIndexGroupNo)) {
				logger.error("指标组编号不能为空！");
				throw new ServiceException("指标组编号不能为空！");
			}
			
			EwsIndexGroup ewsIndexGroup = ewsIndexGroupService.queryEwsIndexGroupByGroupNo(ewsIndexGroupNo);
			if(ewsIndexGroup == null) {
				logger.error("指标组编号【{}】不存在，调度任务执行失败！", ewsIndexGroupNo);
				throw new ServiceException(String.format("指标组编号【%s】不存在，调度任务执行失败！", ewsIndexGroupNo));
			}
			
			// 查询出该指标组对应的所有参数
			Map<String, Object> ewsIndexGroupParamMap = new HashMap<String, Object>();
			List<EwsIndexParam> indexParamList = ewsIndexParamService.queryIndexNoParamsByWarnIndexNo(ewsIndexGroup.getWarnIndexGroupNo());
			Map<String, String> queryMap = new HashMap<String, String>();
			if(indexParamList != null) {
				for(EwsIndexParam param : indexParamList) {
					queryMap.put(param.getParamName(), param.getParamVal());
				}
			}
			
			ewsIndexGroupParamMap.putAll(queryMap);
			
			// 查询出该预警指标组下面的所有预警指标
			List<String> warnIndexNoList = ewsIndexGroupReferService.queryWarnIndexByGroupNo(
					ewsIndexGroup.getWarnIndexGroupNo());
			if(warnIndexNoList == null || warnIndexNoList.isEmpty()) {
				logger.error("预警指标组【{}】下没有预警指标，调度结束。", ewsIndexGroup.getWarnIndexGroupNo());
				return ;
			}
			
			logger.info("预警指标组【{}】下一共有【{}】条预警指标。", ewsIndexGroup.getWarnIndexGroupNo(), 
					warnIndexNoList.size());
			
			List<EwsIndexDef> warnIndexList = new ArrayList<EwsIndexDef>();
			EwsIndexDef warnIndexDefTemp = null;
			for(String warnIndexNo : warnIndexNoList) {
				warnIndexDefTemp = ewsIndexDefService.queryEwsIndexDefByIndexNo(warnIndexNo);
				if(warnIndexDefTemp == null) {
					logger.error("预警指标组【{}】下预警指标【{}】不存在，调度结束。", ewsIndexGroup.
							getWarnIndexGroupNo(), warnIndexNo);
					return ;
				}
				
				warnIndexList.add(warnIndexDefTemp);
			}
			
			// 开始执行预警指标组下面的各个预警指标调度任务
			// 需要发送邮件结果集的Map
			Map<String, List<Map<String, Object>>> totalDataMap = new HashMap<String, List<Map<String, Object>>>();
			// 所有预警指标调用drools的返回
			List<String> warnMsgList = new ArrayList<String>();
			
			for(EwsIndexDef warnIndexDef : warnIndexList) {
				// 执行sql
				Map<String, List<Map<String, Object>>> dataMap = ewsTaskService.executorSql(warnIndexDef, ewsIndexGroupParamMap);
				
				String warnMsg = null;
				
				if(dataMap != null && !dataMap.isEmpty()) {
					totalDataMap.putAll(dataMap);
					// 调用drools服务
					warnMsg = ewsTaskService.executorDrools(warnIndexDef, dataMap);
				} else {
					logger.info("预警指标组【{}】中指标【{}】将要发送到drools服务的数据为空！", warnIndexDef.getWarnIndexNo(), 
							warnIndexDef.getWarnIndexNo());
				}
				
				if(StringUtils.isNotBlank(warnMsg.toString())) {
					warnMsgList.add(warnMsg.toString());
				}
			}
			
			if(!warnMsgList.isEmpty()) {
				logger.info("预警指标组【{}】drools返回结果数为：【{}】，准备发送邮件... ...", ewsIndexGroup.getWarnIndexGroupNo(), 
						warnMsgList.size());
				
				// 预先获取发邮件的行数
				int row = 200;
				if(ewsIndexGroupParamMap.containsKey(EwsTaskServiceImpl.MAILROWNUM)) {
					try {
						row = Integer.valueOf((String) ewsIndexGroupParamMap.get(EwsTaskServiceImpl.MAILROWNUM));
					} catch (Exception e) {
						logger.error("预警指标组【{}】发送邮件获取MAILROWNUM行数异常，默认采用200：", ewsIndexGroupNo, e);
					}
				}
				sendMail(ewsIndexGroup, totalDataMap, warnMsgList, row);
			} else {
				logger.info("预警指标组【{}】drools返回结果空！", ewsIndexGroup.getWarnIndexGroupNo());
			}
			
			logger.info("指标组调度任务结束：{}", ewsIndexGroup);
		} catch (ServiceException e) {
			logger.error("指标组【{}】调度异常结束：", ewsIndexGroupNo, e);
		}*/
	}
	
	/**
	 * 发送邮件
	 * @param ewsIndexGroup 	告警指标组
	 * @param sendMailDataMap	发送邮件SQL结果Map
	 * @param warnMsgList		drools返回信息列表
	 * @param rowSeparator		发送每封邮件的行号
	 */
	private void sendMail(EwsIndexGroup ewsIndexGroup, Map<String, List<Map<String, Object>>> sendMailDataMap, 
			List<String> warnMsgList, int rowSeparator) {
		logger.info("预警指标组【{}】sendMailAndSms开始... ...", ewsIndexGroup.getWarnIndexGroupNo());
		
		try {
			StringBuilder context = new StringBuilder();
			// 添加drools返回结果
			for(String warnMsg : warnMsgList) {
				context.append(warnMsg);
			}
			context.append("<br />");
			
			// 组装邮件正文和标题
			List<String> contextList = ParamStrUtil.translationContext(context.toString() + ewsIndexGroup.
					getMailContextTemplate(), sendMailDataMap, rowSeparator);
			String title = ParamStrUtil.translationContext(ewsIndexGroup.getMailTitleTemplate(), sendMailDataMap, -1).get(0);
			
			logger.info("预警指标组【{}】发送邮件开始... ...", ewsIndexGroup.getWarnIndexGroupNo());
			List<EwsEmpGroupRefer> ewsEmpGroupReferList = ewsEmpGroupReferService.queryEmpGroupInfoByIndexNo(ewsIndexGroup.getWarnIndexGroupNo());
			if(ewsEmpGroupReferList != null && !ewsEmpGroupReferList.isEmpty()) {
				warnSendMailAndSmsService.sendWarnIndexMail(ewsEmpGroupReferList, title, contextList);
			} else {
				logger.info("预警指标组【{}】发送邮件的人员列表为空，不需要发邮件.", ewsIndexGroup.getWarnIndexGroupNo());
			}
			logger.info("预警指标组【{}】邮件发送结束.", ewsIndexGroup.getWarnIndexGroupNo());
			
		} catch (Exception e) {
			logger.error("预警指标组【{}】邮件调用sendMailAndSms异常:", ewsIndexGroup.getWarnIndexGroupNo(), e);
		}
		
		logger.info("预警指标组【{}】sendMailAndSms结束.", ewsIndexGroup.getWarnIndexGroupNo());
	}

}
