package com.sfpay.ews.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsGroupDef;
import com.sfpay.ews.platform.service.IEwsGroupDefService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsGroupDefServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IEwsGroupDefService ewsGroupDefService;

	@Test
	public void testAddEwsGroupDef() {
		EwsGroupDef ewsGroupDef=new EwsGroupDef();
		try {
			ewsGroupDefService.addEwsGroupDef(null);
		} catch (Exception e) {
		}
		try {
			ewsGroupDefService.addEwsGroupDef(ewsGroupDef);
		} catch (Exception e) {
		}
		ewsGroupDef.setGroupNo("test");
		try {
			ewsGroupDefService.addEwsGroupDef(ewsGroupDef);
		} catch (Exception e) {
		}
		ewsGroupDef.setGroupName("测试小组");
		try {
			ewsGroupDefService.addEwsGroupDef(ewsGroupDef);
		} catch (Exception e) {
		}
		ewsGroupDef.setIsValid("Y");
		ewsGroupDefService.addEwsGroupDef(ewsGroupDef);
	}

	@Test
	public void testUpdateEwsGroupDef() {
		EwsGroupDef ewsGroupDef=new EwsGroupDef();
		try {
			ewsGroupDefService.updateEwsGroupDef(ewsGroupDef);
		} catch (Exception e) {
		}
		ewsGroupDef.setGroupNo("test");
		try {
			ewsGroupDefService.updateEwsGroupDef(ewsGroupDef);
		} catch (Exception e) {
		}
		ewsGroupDef.setGroupName("测试小组");
		try {
			ewsGroupDefService.updateEwsGroupDef(ewsGroupDef);
		} catch (Exception e) {
		}
		ewsGroupDef.setIsValid("Y");
		ewsGroupDefService.updateEwsGroupDef(ewsGroupDef);
	}

	@Test
	public void testQuerytAllEwsGroupDef() {
		ewsGroupDefService.querytAllEwsGroupDef();
	}

	@Test
	public void testDelEwsGroupDef() {
		try {
			ewsGroupDefService.delEwsGroupDef("123");
		} catch (Exception e) {
		}
		ewsGroupDefService.delEwsGroupDef("test");
	}

	@Test
	public void testQueryByGroupNo() {
		try {
			ewsGroupDefService.queryByGroupNo(null);
		} catch (Exception e) {
		}
		ewsGroupDefService.queryByGroupNo("TEST_GROUP");
	}

	@Test
	public void testQueryEwsGroupDefByParam() {
		EwsGroupDef ewsGroupDef=new EwsGroupDef();
		ewsGroupDef.setGroupNo("test");
		ewsGroupDef.setGroupName("测试小组");
		ewsGroupDef.setIsValid("Y");
		ewsGroupDefService.queryEwsGroupDefByParam(ewsGroupDef);
	}

	@Test
	public void testQueryEwsGroupDefByOrderPage() {
		EwsGroupDef group = new EwsGroupDef();
		try {
			ewsGroupDefService.queryEwsGroupDefByOrderPage(null,0,0);
		} catch (Exception e) {
		}
		try {
			ewsGroupDefService.queryEwsGroupDefByOrderPage(group,0,2);
		} catch (Exception e) {
		}
		try {
			ewsGroupDefService.queryEwsGroupDefByOrderPage(group,1,0);
		} catch (Exception e) {
		}
		try {
			ewsGroupDefService.queryEwsGroupDefByOrderPage(group,1,2);
		} catch (Exception e) {
		}
		group.setGroupNo("TEST_GROUP");
		group.setGroupName("");
		IPage<EwsGroupDef> test= ewsGroupDefService.queryEwsGroupDefByOrderPage(group, 1, 20);
		System.out.println(test.getSize());
	}

}
