package com.sfpay.ews.service.impl;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.service.ISendSMSService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class SendSMSServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private ISendSMSService sendSMSService;
	
	@Test
	public void testSendMessage() {
		sendSMSService.sendMessage("123456789", "tset sms");
	}
	
	@Test
	public void testStopPool(){
		SendSMSServiceImpl sendSMSServiceImpl=new SendSMSServiceImpl();
		sendSMSServiceImpl.stopPool();
	}

}
