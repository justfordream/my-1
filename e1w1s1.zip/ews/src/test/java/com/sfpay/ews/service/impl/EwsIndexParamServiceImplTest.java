package com.sfpay.ews.service.impl;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsIndexParam;
import com.sfpay.ews.platform.service.IEwsIndexParamService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsIndexParamServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private IEwsIndexParamService ewsIndexParamService;

	@Test
	public void testAddEwsIndexParam() {
		EwsIndexParam ewsIndexParam = new EwsIndexParam();
		try {
			ewsIndexParamService.addEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}

		ewsIndexParam.setParamName("测试");
		try {
			ewsIndexParamService.addEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		ewsIndexParam.setParamVal("123");
		try {
			ewsIndexParamService.addEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		ewsIndexParam.setWarnIndexNo("TEST0001");
		try {
			ewsIndexParamService.addEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		ewsIndexParam.setParamUnit("元");
		try {
			ewsIndexParamService.addEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
	}

	@Test
	public void testUpdateEwsIndexParam() {
		EwsIndexParam ewsIndexParam = new EwsIndexParam();
		try {
			ewsIndexParamService.updateEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		ewsIndexParam.setParamName("测试");
		try {
			ewsIndexParamService.updateEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		ewsIndexParam.setParamVal("123");
		try {
			ewsIndexParamService.updateEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		ewsIndexParam.setWarnIndexNo("TEST0001");
		try {
			ewsIndexParamService.updateEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		ewsIndexParam.setParamUnit("元");
		try {
			ewsIndexParamService.updateEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
		
		ewsIndexParam.setId(123);
		try {
			ewsIndexParamService.updateEwsIndexParam(ewsIndexParam);
		} catch (Exception e) {
		}
	}

	@Test
	public void testQueryIndexParamByPage() {
		EwsIndexParam ewsIndexParam = new EwsIndexParam();
		try {
			ewsIndexParamService.queryIndexParamByPage(ewsIndexParam, 1, 200);
		} catch (Exception e) {
		}
		ewsIndexParam.setWarnIndexNo("TEST");;
		try {
			ewsIndexParamService.queryIndexParamByPage(ewsIndexParam, -1, 200);
		} catch (Exception e) {
		}
		
		try {
			ewsIndexParamService.queryIndexParamByPage(ewsIndexParam, -1, 200);
		} catch (Exception e) {
		}
	}

	@Test
	public void testQueryWarnIndexParamById() {
		ewsIndexParamService.queryWarnIndexParamById(1302);
	}

	@Test
	public void testQueryIndexNoParamsByWarnIndexNo() {
		try {
			ewsIndexParamService.queryIndexNoParamsByWarnIndexNo("TEST0001");
		} catch (Exception e) {
		}
		
		try {
			ewsIndexParamService.queryIndexNoParamsByWarnIndexNo("");
		} catch (Exception e) {
		}
		
	}

	@Test
	public void testDeleteEwsIndexParamById() {
		try {
			ewsIndexParamService.deleteEwsIndexParamById(0);
		} catch (Exception e) {
		}

		try {
			ewsIndexParamService.deleteEwsIndexParamById(1137);
		} catch (Exception e) {
		}
	}

}
