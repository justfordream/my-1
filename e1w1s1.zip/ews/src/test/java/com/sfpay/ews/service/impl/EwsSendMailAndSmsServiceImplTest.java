package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.ews.platform.service.IEwsEmpGroupReferService;
import com.sfpay.ews.service.IEwsSendMailAndSmsService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsSendMailAndSmsServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private IEwsSendMailAndSmsService ewsSendMailAndSmsService;
	
	@Autowired
	private IEwsEmpGroupReferService ewsEmpGroupReferService;
	
	
	@Test
	public void testSendWarnIndexMail() {
		List<EwsEmpGroupRefer> ewsEmpGroupReferList=ewsEmpGroupReferService.queryEmpGroupInfoByIndexNo("TEST0001");
		List<String> contentList=new ArrayList<String>();
		contentList.add("test");
		ewsSendMailAndSmsService.sendWarnIndexMail(ewsEmpGroupReferList, "title", contentList);
	}

	@Test
	public void testSendWarnIndexSms() {
		List<EwsEmpGroupRefer> ewsEmpGroupReferList=ewsEmpGroupReferService.queryEmpGroupInfoByIndexNo("TEST0001");
		ewsSendMailAndSmsService.sendWarnIndexSms(ewsEmpGroupReferList, "SMS CONTENT");
	}

}
