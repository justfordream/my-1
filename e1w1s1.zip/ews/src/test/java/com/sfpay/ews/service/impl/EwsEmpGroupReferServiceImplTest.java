package com.sfpay.ews.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.ews.platform.service.IEwsEmpGroupReferService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsEmpGroupReferServiceImplTest extends ClassTransactionalTestCase{

	@Autowired
	private IEwsEmpGroupReferService ewsEmpGroupReferService;
	
	@Test
	public void testAddEwsEmpGroupRefer() {
		EwsEmpGroupRefer ewsEmpGroupRefer=new EwsEmpGroupRefer();
		try {
			ewsEmpGroupReferService.addEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		ewsEmpGroupRefer.setEmpId("544771");
		try {
			ewsEmpGroupReferService.addEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		
		ewsEmpGroupRefer.setGroupNo("234");
		try {
			ewsEmpGroupReferService.addEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		
		ewsEmpGroupRefer.setIsMailNotify("Y");
		try {
			ewsEmpGroupReferService.addEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		
		ewsEmpGroupRefer.setIsSmsNotify("Y");
		try {
			ewsEmpGroupReferService.addEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
	}

	@Test
	public void testUpdateEwsEmpGroupRefer() {
		EwsEmpGroupRefer ewsEmpGroupRefer=new EwsEmpGroupRefer();
		try {
			ewsEmpGroupReferService.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		ewsEmpGroupRefer.setEmpId("544771");
		try {
			ewsEmpGroupReferService.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		
		ewsEmpGroupRefer.setGroupNo("234");
		try {
			ewsEmpGroupReferService.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		
		ewsEmpGroupRefer.setIsMailNotify("Y");
		try {
			ewsEmpGroupReferService.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		
		ewsEmpGroupRefer.setIsSmsNotify("Y");
		try {
			ewsEmpGroupReferService.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		ewsEmpGroupRefer.setId(201);
		try {
			ewsEmpGroupReferService.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
		
	}

	@Test
	public void testDelEwsEmpGroupRefer() {
		try {
			ewsEmpGroupReferService.delEwsEmpGroupRefer("123");
		} catch (Exception e) {
		}
		try {
			ewsEmpGroupReferService.delEwsEmpGroupRefer("201");
		} catch (Exception e) {
		}
		
		
	}

	@Test
	public void testQueryEwsEmpGroupReferByParam() {
		EwsEmpGroupRefer ewsEmpGroupRefer=new EwsEmpGroupRefer();
		try {
			ewsEmpGroupReferService.queryEwsEmpGroupReferByParam(ewsEmpGroupRefer);
		} catch (Exception e) {
		}
	}

	@Test
	public void testQueryEmpGroupInfoByIndexNo() {
		try {
			ewsEmpGroupReferService.queryEmpGroupInfoByIndexNo("TEST0001");
		} catch (Exception e) {
		}
		
		try {
			ewsEmpGroupReferService.queryEmpGroupInfoByIndexNo("123");
		} catch (Exception e) {
		}
	}

}
