/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.service.IEwsOpenService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-13
 */
public class EwsOpenServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IEwsOpenService ewsOpenService;
	
	@Test
	public void updateDataTest() {
		Map<String, Object> updateMap = new HashMap<String, Object>();
		Map<String, Object> whereMap = new HashMap<String, Object>();
		whereMap.put("info_record_id", "TEST0013201504020204470065");
		updateMap.put("status", "Y");
		
		try {
			ewsOpenService.updateData(null, null, null);
		} catch (ServiceException e) {
			System.out.println(e);
		}
		
		try {
			ewsOpenService.updateData("TEST_TABLE", null, null);
		} catch (ServiceException e) {
			System.out.println(e);
		}
		
		try {
			ewsOpenService.updateData("TEST_TABLE", updateMap, null);
		} catch (ServiceException e) {
			System.out.println(e);
		}
		
		try {
			ewsOpenService.updateData("TEST_TABLE", updateMap, whereMap);
		} catch (ServiceException e) {
			System.out.println(e);
		}
		
		
	}
	
	@Test
	public void updateMultiData() {
		Map<String, Object> updateMap = new HashMap<String, Object>();
		Map<String, Object> whereMap = new HashMap<String, Object>();
		List<Map<String, Object>> whereList = new ArrayList<Map<String, Object>>();
		whereList.add(whereMap);
		whereMap.put("info_record_id", "TEST0013201504020204470065");
		updateMap.put("status", "Y");
		
		try {
			ewsOpenService.updateMultiData(null, null, null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		ewsOpenService.updateMultiData("TEST_TABLE", updateMap, whereList);
		try {
			ewsOpenService.updateMultiData("TEST_TABLE", updateMap, whereList);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsOpenService.updateMultiData("Test_TABLE", updateMap, whereList);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
	}
}
