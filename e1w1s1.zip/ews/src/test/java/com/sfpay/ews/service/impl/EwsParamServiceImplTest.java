package com.sfpay.ews.service.impl;

import java.util.List;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import com.sfpay.ews.platform.domain.EwsParam;
import com.sfpay.ews.platform.service.IEwsParamService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsParamServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private IEwsParamService ewsParamService;
	@Test
	public void testAddEwsParam() {
		EwsParam ewsParam=new EwsParam();
		try {
			ewsParamService.addEwsParam(ewsParam);
		} catch (Exception e) {
		}
		ewsParam.setParamCode("TEST");
		try {
			ewsParamService.addEwsParam(ewsParam);
		} catch (Exception e) {
		}
		ewsParam.setParamTypeCode("TYPE_CODE");
		ewsParamService.addEwsParam(ewsParam);
	}

	@Test
	public void testUpdateEwsParam() {
		EwsParam ewsParam=new EwsParam();
		try {
			ewsParamService.updateEwsParam(ewsParam);
		} catch (Exception e) {
		}
		ewsParam.setParamCode("UNPROCESSED");
		try {
			ewsParamService.updateEwsParam(ewsParam);
		} catch (Exception e) {
		}
		ewsParam.setParamTypeCode("OPR_STATUS");
		try {
			ewsParamService.updateEwsParam(ewsParam);
		} catch (Exception e) {
		}
		ewsParam.setId(58);
		ewsParamService.updateEwsParam(ewsParam);
	}

	@Test
	public void testDelEwsParam() {
		try {
			ewsParamService.delEwsParam("");
		} catch (Exception e) {
		}
		ewsParamService.delEwsParam("58");
	}

	@Test
	public void testQueryById() {
		try {
			ewsParamService.queryById("");
		} catch (Exception e) {
		}
		ewsParamService.queryById("58");
	}

	@Test
	public void testQueryAll() {
		ewsParamService.queryAll();
	}

	@Test
	public void testQueryEwsParamByParam() {
		EwsParam ewsParam=new EwsParam();
		ewsParam.setParamCode("UNPROCESSED");
		ewsParam.setParamTypeCode("OPR_STATUS");
		ewsParam.setId(58);
		ewsParamService.queryEwsParamByParam(ewsParam);
	}

	@Test
	public void testQueryEwsParamByPage() {
		try {
			ewsParamService.queryEwsParamByPage(100,1);
		} catch (Exception e) {
		}
		try {
			ewsParamService.queryEwsParamByPage(-1,1);
		} catch (Exception e) {
		}
		ewsParamService.queryEwsParamByPage(1, 100);
	}

	@Test
	public void testQueryEwsParamByOrderPage() {
		try {
			ewsParamService.queryEwsParamByOrderPage(100,1);
		} catch (Exception e) {
		}
		try {
			ewsParamService.queryEwsParamByOrderPage(-1,1);
		} catch (Exception e) {
		}
		ewsParamService.queryEwsParamByOrderPage(1, 100);
	}

	@Test
	public void testQueryAllTypesByParamTypeCode() {
		try {
			ewsParamService.queryAllTypesByParamTypeCode(null);
		} catch (Exception e) {
		}
		List<EwsParam> warnClassList = ewsParamService.queryAllTypesByParamTypeCode("WARN_CLASS_CODE");
		System.out.println(warnClassList.size());
	}

	@Test
	public void testQueryEwsParamByParamCodeAndTypeCode() {
		try {
			ewsParamService.queryEwsParamByParamCodeAndTypeCode(null, "WARN_SOURCE");
		} catch (Exception e) {
		}
		
		try {
			ewsParamService.queryEwsParamByParamCodeAndTypeCode("DEBIT", null);
		} catch (Exception e) {
		}
		
		try {
			ewsParamService.queryEwsParamByParamCodeAndTypeCode(null, null);
		} catch (Exception e) {
		}
		
		ewsParamService.queryEwsParamByParamCodeAndTypeCode("DEBIT", "WARN_SOURCE");
	}

}
