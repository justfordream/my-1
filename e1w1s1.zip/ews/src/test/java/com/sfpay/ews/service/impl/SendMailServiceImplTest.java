package com.sfpay.ews.service.impl;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.service.ISenderMailService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class SendMailServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private ISenderMailService senderMailService;
	
	@Test
	public void testSendMail() {
		senderMailService.sendMail("test", "tset.@sf-express.com", "123456");
	}

	@Test
	public void testSendOutMail() {
		senderMailService.sendOutMail("测试", "code", "head");
	}

	@Test
	public void testSendHTMLMail() {
		senderMailService.sendHTMLMail("测试", "subject", "text");
	}

}
