package com.sfpay.ews.service.impl;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.service.IEwsIndexGroupReferService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsIndexGroupReferServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private IEwsIndexGroupReferService ewsIndexGroupReferService;
	
	@Test
	public void testQueryAllRefer() {
		ewsIndexGroupReferService.queryAllRefer();
	}

	@Test
	public void testQueryWarnIndexByGroupNo() {
		try {
			ewsIndexGroupReferService.queryWarnIndexByGroupNo("123");
		} catch (Exception e) {
		}
		
		try {
			ewsIndexGroupReferService.queryWarnIndexByGroupNo("WARN_TEST_GROUP");
		} catch (Exception e) {
		}
	}

}
