/**
 * 
 */
package com.sfpay.ews.service.impl;

import org.junit.Test;
import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-3
 */
public class EwsIndexDefServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	
	@Test
	public void queryByWarnIndexNoTest() {
		try {
			ewsIndexDefService.queryByWarnIndexNo("");
		} catch (Exception e) {
		}
		System.out.println("查询结果:" + ewsIndexDefService.queryByWarnIndexNo("TEST0013"));
	}
	
	@Test
	public void addEwsIndexDefTest() {
		try {
			ewsIndexDefService.addEwsIndexDef(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexDefService.addEwsIndexDef(new EwsIndexDef());
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsIndexDef ewsIndexDef = new EwsIndexDef();
		ewsIndexDef.setWarnIndexNo("TEST0099");
		ewsIndexDef.setWarnIndexName("这是测试指标");
		ewsIndexDef.setEffectCode("TEST1");
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setCronExpress("0 */? * * * ?");
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnSource("TEST");
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnLevel("L1");
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnStage("BEFORE");
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setIsValid("Y");
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnProperty("WARNING");
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnIndexNo("TEST0001");
		
		try {
			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateEwsIndexDefTest() {
		try {
			ewsIndexDefService.updateEwsIndexDef(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexDefService.updateEwsIndexDef(new EwsIndexDef());
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsIndexDef ewsIndexDef = new EwsIndexDef();
		ewsIndexDef.setWarnIndexNo("TEST");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnIndexNo("TEST0001");
		
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnIndexName("新名称");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setCronExpress("0 */1 * * * ?");
		ewsIndexDef.setEffectCode("TEST900");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setEffectCode("TEST2");
		ewsIndexDef.setWarnSource("TEST2");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnSource("TEST");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnProperty("123123");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnProperty("ERROR");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnStage("AFTER1");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexDef.setWarnStage("AFTER");
		try {
			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsIndexDef def = ewsIndexDefService.queryByWarnIndexNo("SYPAY0008");
		def.setOprFlag("");
		try {
			ewsIndexDefService.updateEwsIndexDef(def);
			def = ewsIndexDefService.queryByWarnIndexNo("SYPAY0008");
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryEwsIndexDefByPageTest() {
		try {
			ewsIndexDefService.queryEwsIndexDefByPage(null, 1, 20);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexDefService.queryEwsIndexDefByPage(new EwsIndexDef(), 1, 20);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsIndexDef ewsIndexDef = new EwsIndexDef();
		ewsIndexDef.setWarnStage("AFTER");
		try {
			ewsIndexDefService.queryEwsIndexDefByPage(ewsIndexDef, 1, 20);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryByWarnSourceTest() {
		try {
			ewsIndexDefService.queryByWarnSource(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexDefService.queryByWarnSource("");
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexDefService.queryByWarnSource("TEST");
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryAllIndexDefTest() {
		try {
			ewsIndexDefService.queryAllIndexDef();
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateIndexSchStatusTest(){
		try {
			ewsIndexDefService.updateIndexSchRunStatus("TEST0001", "RUNNING");
		} catch (Exception e) {
		}
		
		try {
			ewsIndexDefService.updateIndexSchRunStatus("TEST0001", "test");
		} catch (Exception e) {
		}
		
		try {
			ewsIndexDefService.updateIndexSchRunStatus("TEST1", "test");
		} catch (Exception e) {
		}
	}
	
	@Test
	public void updateIndexSchRunStatusTest(){
		try {
			ewsIndexDefService.updateIndexSchStatus("TEST1", "test");
		} catch (Exception e) {
		}
		
		try {
			ewsIndexDefService.updateIndexSchStatus("TEST0001", "RUNNING");
		} catch (Exception e) {
		}
		
		try {
			ewsIndexDefService.updateIndexSchStatus("TEST0001", "test");
		} catch (Exception e) {
		}
	}
}
