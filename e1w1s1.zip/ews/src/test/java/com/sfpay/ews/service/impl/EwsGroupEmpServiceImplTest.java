package com.sfpay.ews.service.impl;

import javax.annotation.Resource;
import org.junit.Test;

import com.sfpay.ews.platform.domain.EwsGroupEmp;
import com.sfpay.ews.platform.service.IEwsGroupEmpService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsGroupEmpServiceImplTest extends ClassTransactionalTestCase {

	@Resource
	private IEwsGroupEmpService ewsGroupEmpService;
	@Test
	public void testAddEwsGroupEmp() {
		EwsGroupEmp ewsGroupEmp=new EwsGroupEmp();
		try {
			ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpId("544772");
		try {
			ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpName("test");
		try {
			ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpMail("1234565");
		try {
			ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpMobile("123456");
		try {
			ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setIsMailNotify("Y");
		try {
			ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setIsSmsNotify("Y");
		try {
			ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setIsValid("N");
		ewsGroupEmpService.addEwsGroupEmp(ewsGroupEmp);
	}

	@Test
	public void testUpdateEwsGroupEmp() {
		EwsGroupEmp ewsGroupEmp=new EwsGroupEmp();
		try {
			ewsGroupEmpService.updateEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpMail("1234565");
		try {
			ewsGroupEmpService.updateEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpId("544772");
		try {
			ewsGroupEmpService.updateEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpName("test");
		try {
			ewsGroupEmpService.updateEwsGroupEmp(ewsGroupEmp);
		} catch (Exception e) {
		}
		ewsGroupEmp.setEmpMobile("123456");
		ewsGroupEmp.setIsMailNotify("Y");
		ewsGroupEmp.setIsSmsNotify("Y");
		ewsGroupEmp.setIsValid("N");
		ewsGroupEmpService.updateEwsGroupEmp(ewsGroupEmp);
	}

	@Test
	public void testQueryEwsGroupEmpByPage() {
		EwsGroupEmp ewsGroupEmp=new EwsGroupEmp();
		try {
			ewsGroupEmpService.queryEwsGroupEmpByPage(null,1,1000);
		} catch (Exception e) {
		}
		
		try {
			ewsGroupEmpService.queryEwsGroupEmpByPage(null,-1,1000);
		} catch (Exception e) {
		}
		
		IPage<EwsGroupEmp> list=ewsGroupEmpService.queryEwsGroupEmpByPage(ewsGroupEmp,1,1000);
		System.out.println(list.getSize());
	}

	@Test
	public void testQueryEwsGroupEmpByEmpId() {
		ewsGroupEmpService.queryEwsGroupEmpByEmpId("544772");
	}

	@Test
	public void testQueryNotifyEmpByIndexNo() {
		ewsGroupEmpService.queryNotifyEmpByIndexNo("MARKET0006");
	}

}
