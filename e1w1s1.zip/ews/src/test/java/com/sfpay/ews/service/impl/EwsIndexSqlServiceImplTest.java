/**
 * 
 */
package com.sfpay.ews.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsIndexSql;
import com.sfpay.ews.platform.service.IEwsIndexSqlService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-7
 */
public class EwsIndexSqlServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IEwsIndexSqlService ewsIndexSqlService;
	
	@Test
	public void queryEwsIndexSqlByWarnNoTest() {
		try {
			ewsIndexSqlService.queryEwsIndexSqlByWarnNo(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexSqlService.queryEwsIndexSqlByWarnNo("");
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexSqlService.queryEwsIndexSqlByWarnNo("TEST0001");
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void addEwsIndexSqlTest() {
		try {
			ewsIndexSqlService.addEwsIndexSql(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexSqlService.addEwsIndexSql(new EwsIndexSql());
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsIndexSql ewsIndexSql = new EwsIndexSql();
		ewsIndexSql.setWarnIndexNo("TEST00000");
		try {
			ewsIndexSqlService.addEwsIndexSql(ewsIndexSql);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexSql.setWarnIndexNo("TEST0001");
		ewsIndexSql.setSqlKey("SQLKEY1");
		try {
			ewsIndexSqlService.addEwsIndexSql(ewsIndexSql);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexSql.setWarnIndexSql("sdfsdfsd sdfsdfsssfdsd sdfsdfsdfdsf");
		try {
			ewsIndexSqlService.addEwsIndexSql(ewsIndexSql);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void deleteEwsIndexSqlTest() {
		try {
			ewsIndexSqlService.deleteEwsIndexSql(0);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexSqlService.deleteEwsIndexSql(5);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateEwsIndexSqlTest() {
		try {
			ewsIndexSqlService.updateEwsIndexSql(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsIndexSqlService.updateEwsIndexSql(new EwsIndexSql());
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsIndexSql ewsIndexSql = new EwsIndexSql();
		ewsIndexSql.setId(5);
		try {
			ewsIndexSqlService.updateEwsIndexSql(ewsIndexSql);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexSql.setWarnIndexNo("TEST0003");
		ewsIndexSql.setSqlKey("TRADEUNSUCNUM");
		try {
			ewsIndexSqlService.updateEwsIndexSql(ewsIndexSql);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsIndexSql.setSqlKey("TRADEALLNUM");
		try {
			ewsIndexSqlService.updateEwsIndexSql(ewsIndexSql);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryByWarnIndexNoAndSqlKeyTest() {
		try {
			ewsIndexSqlService.queryByWarnIndexNoAndSqlKey("TEST0003", "TRADEALLNUM");
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryByIdTest() {
		ewsIndexSqlService.queryById(5);
		
	}
	
	@Test
	public void queryAllTableNameTest() {
		ewsIndexSqlService.queryAllTableName();
	}
	
	@Test
	public void queryByPageTest() {
		ewsIndexSqlService.queryByPage(new EwsIndexSql(), 1, 10);
	}
}
