package com.sfpay.ews.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsOprRecord;
import com.sfpay.ews.platform.service.IEwsOprRecordService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsOprRecordServiceImplTest extends ClassTransactionalTestCase {

	@Autowired
	private IEwsOprRecordService ewsOprRecordService;
	
	
	@Test
	public void testAddEwsOprRecord() {
		EwsOprRecord ewsOprRecord=new EwsOprRecord();
		try {
			ewsOprRecordService.addEwsOprRecord(ewsOprRecord);
		} catch (Exception e) {
		}
		
		ewsOprRecord.setOperDesc("测试");
		ewsOprRecord.setWarnInfoRecordId("TEST0013201504020204470078");
		try {
			ewsOprRecordService.addEwsOprRecord(ewsOprRecord);
		} catch (Exception e) {
		}
		
	}

	@Test
	public void testUpdateEwsOprRecord() {
		EwsOprRecord ewsOprRecord=new EwsOprRecord();
		try {
			ewsOprRecordService.updateEwsOprRecord(ewsOprRecord);
		} catch (Exception e) {
		}
		
		ewsOprRecord.setOperDesc("测试");
		ewsOprRecord.setWarnInfoRecordId("TEST0013201504020204470078");
		ewsOprRecord.setId(51);
		try {
			ewsOprRecordService.updateEwsOprRecord(ewsOprRecord);
		} catch (Exception e) {
		}
	}

	@Test
	public void testDelEwsOprRecord() {
		try {
			ewsOprRecordService.delEwsOprRecord("");
		} catch (Exception e) {
		}
		try {
			ewsOprRecordService.delEwsOprRecord("50");
		} catch (Exception e) {
		}
	}

	@Test
	public void testQueryById() {
		try {
			ewsOprRecordService.queryById("");
		} catch (Exception e) {
		}
		try {
			ewsOprRecordService.queryById("50");
		} catch (Exception e) {
		}
	}

	@Test
	public void testQueryEwsOprRecordByWarnInfoRecordId() {
		try {
			ewsOprRecordService.queryEwsOprRecordByWarnInfoRecordId("");
		} catch (Exception e) {
		}
		
		try {
			ewsOprRecordService.queryEwsOprRecordByWarnInfoRecordId("TEST0013201504020204470084");
		} catch (Exception e) {
		}
		
	}

}
