/**
 * 
 */
package com.sfpay.ews.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsRule;
import com.sfpay.ews.platform.service.IEwsRuleService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-7
 */
public class EwsRuleServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IEwsRuleService ewsRuleService;
	
	@Test
	public void queryByEwsIndexNoTest() {
		System.out.println(ewsRuleService.queryByEwsIndexNo("TEST0013"));
	}
	
	@Test
	public void addEwsRule() {
		try {
			ewsRuleService.addEwsRule(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsRuleService.addEwsRule(new EwsRule());
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsRule ewsRule = new EwsRule();
		ewsRule.setParamName("name1");
		try {
			ewsRuleService.addEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsRule.setParamExpress("#{A} + #{B} > 10");
		try {
			ewsRuleService.addEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsRule.setFormatStr("sdfsdfsdf");
		try {
			ewsRuleService.addEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsRule.setWarnIndexNo("TEST0013EE");
		try {
			ewsRuleService.addEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsRule.setWarnIndexNo("TEST0013");
		try {
			ewsRuleService.addEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateEwsRule() {
		try {
			ewsRuleService.updateEwsRule(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			ewsRuleService.updateEwsRule(new EwsRule());
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		EwsRule ewsRule = new EwsRule();
		ewsRule.setId(10);
		try {
			ewsRuleService.updateEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsRule.setId(1);
		ewsRule.setParamName("B");
		try {
			ewsRuleService.updateEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		ewsRule.setParamName("A");
		ewsRule.setParamExpress("123123123");
		try {
			ewsRuleService.updateEwsRule(ewsRule);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryByPageTest() {
		try {
			ewsRuleService.queryByPage(new EwsRule(), 1, 10);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void deleteEwsRuleTest(){
		try {
			ewsRuleService.deleteEwsRule(3);
		} catch (Exception e) {
		}
		
		try {
			ewsRuleService.deleteEwsRule(-1);
		} catch (Exception e) {
		}
	}
	
	@Test
	public void queryResultEwsRuleTest(){
		try {
			ewsRuleService.queryResultEwsRule("TEST0013");
		} catch (Exception e) {
		}
		
		try {
			ewsRuleService.queryResultEwsRule("");
		} catch (Exception e) {
		}
	}
	
	
	
}
