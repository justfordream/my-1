package com.sfpay.ews.service.impl;

import javax.annotation.Resource;

import org.junit.Test;
import com.sfpay.ews.platform.domain.EwsEffect;
import com.sfpay.ews.platform.service.IEwsEffectService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class EwsEffectServiceImplTest extends ClassTransactionalTestCase {
	@Resource
	private IEwsEffectService ewsEffectService;

	@Test
	public void testQueryByEffectCode() {
		try {
			ewsEffectService.queryByEffectCode("");
		} catch (Exception e) {
		}

		try {
			ewsEffectService.queryByEffectCode("TEST1");
		} catch (Exception e) {
		}

	}

	@Test
	public void testQueryByWarnClassAndWarnLevel() {
		ewsEffectService.queryByWarnClassAndWarnLevel("FUND", "L1");
		try {
			ewsEffectService.queryByWarnClassAndWarnLevel("FUND", "");
		} catch (Exception e) {
		}
		try {
			ewsEffectService.queryByWarnClassAndWarnLevel("", "L1");
		} catch (Exception e) {
		}
		try {
			ewsEffectService.queryByWarnClassAndWarnLevel("", "");
		} catch (Exception e) {
		}
	}

	@Test
	public void testAddEwsEffect() {
		try {
			EwsEffect ewsEffect = new EwsEffect();
			ewsEffect.setEffectCode("TESTN");
			ewsEffect.setEffectName("test");
			ewsEffect.setWarnClassCode("123");
			ewsEffect.setWarnLevel("ee");
			ewsEffect.setEffectTime(Long.valueOf("1000"));
			ewsEffect.setOverEffectTime(Long.valueOf("2000"));
			ewsEffectService.addEwsEffect(ewsEffect);
		} catch (Exception e) {
		}
		try {
			EwsEffect ewsEffect = new EwsEffect();
			ewsEffect.setEffectCode("");
			ewsEffectService.addEwsEffect(ewsEffect);
		} catch (Exception e) {
		}
		try {
			EwsEffect ewsEffect = new EwsEffect();
			ewsEffect.setEffectCode("TESTN");
			ewsEffect.setWarnClassCode("123");
			ewsEffect.setWarnLevel("ee");
			ewsEffectService.addEwsEffect(ewsEffect);
		} catch (Exception e) {
		}

		EwsEffect ewsEffect = new EwsEffect();
		ewsEffect.setEffectCode("TESTN");
		ewsEffect.setEffectName("test");
		ewsEffect.setEffectTime(Long.valueOf("1000"));
		ewsEffect.setOverEffectTime(Long.valueOf("2000"));
		ewsEffectService.addEwsEffect(ewsEffect);
	}

	@Test
	public void testUpdateEwsEffect() {
		EwsEffect ewsEffect = new EwsEffect();
		ewsEffect.setEffectCode("TESTN");
		ewsEffect.setEffectName("test");
		ewsEffect.setEffectTime(Long.valueOf("1000"));
		ewsEffect.setOverEffectTime(Long.valueOf("2000"));
		ewsEffectService.updateEwsEffect(ewsEffect);
	}

	@Test
	public void testDeleteEwsEffect() {
		try {
			ewsEffectService.deleteEwsEffect(1);
		} catch (Exception e) {
		}
		try {
			ewsEffectService.deleteEwsEffect(-2);
		} catch (Exception e) {
		}

	}

	@Test
	public void testQueryById() {
		ewsEffectService.queryById(1);
	}

	@Test
	public void testSelectEwsEffectByPage() {
		EwsEffect ewsEffect = new EwsEffect();
		try {
			ewsEffectService.selectEwsEffectByPage(ewsEffect, 1, 20);
		} catch (Exception e) {
		}

		try {
			ewsEffectService.selectEwsEffectByPage(ewsEffect, -1, 20);
		} catch (Exception e) {
		}

		try {
			ewsEffectService.selectEwsEffectByPage(ewsEffect, 1, -20);
		} catch (Exception e) {
		}

		try {
			ewsEffect.setId(99999);
			ewsEffectService.selectEwsEffectByPage(ewsEffect, 1, 20);
		} catch (Exception e) {
		}

	}

}
