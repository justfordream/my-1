package com.sfpay.ews.common;

public class SOAPConstants {
    
    
 
    
    public static final String DEFAULT_ENCODING                     = "UTF-8";
    
    public static final String DEFAULT_XMLNS                        = "RuleRequest";
    
    public static final String DEFAULT_CHILD_XMLNS                    = "ruleRequest"; 
    
    public static final String DEFAULT_XMLNS_PARAM                    = "param";
    
    public static final String NAME_SPACE_XML_SCHEMA_PREFIX         = "dto";
    
    public static final String NAME_SPACE_XML_SCHEMA                = "http://dto.valueobject.rule.ews.sfpay.com";

}
