package com.sfpay.ews.service;

import com.sfpay.ews.domain.EwsWarningCalrltlog;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 记录产生每个指标调用的开始时间和结束时间，记录到资料库中;
 * @author 575740
 *
 */
public interface IEwsWarningCalrltlogService {
	/**
	 * 
	 * 方法说明：创建一条日志记录
	 * @param logLevel
	 * @param logContent
	 */
	public void createCalRltLog(EwsWarningCalrltlog warnCalRltLog) throws ServiceException;
	
}