package com.sfpay.ews.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.sfpay.ews.platform.domain.EwsParam;

public interface IEwsParamDao {
	
	/**
	 * 新增预警参数数据
	 * 
	 * @param ewsParam
	 */
	public void addEwsParam(EwsParam ewsParam);
	
	/**
	 * 更新预警参数数据
	 * 
	 * @param ewsParam
	 */
	public void updateEwsParam(EwsParam ewsParam);
	
	/**
	 * 删除预警参数记录
	 * 
	 * @param id
	 */
	public void delEwsParam(@Param("id")String id);
	
	/**
	 * 通过主键查询预警参数记录
	 * 
	 * @param id
	 */
	public EwsParam queryById(@Param("id")String id);
	
	/**
	 * 查询所有预警参数记录
	 * 
	 * @return
	 */
	public List<EwsParam> queryAll();
	
	/**
	 * 通过参数对象查询预警参数记录
	 * 
	 * @param ewsParam
	 * @return
	 */
	public List<EwsParam> queryEwsParamByParam(EwsParam ewsParam);
	
	/**
	 * 通过参数参数代码和参数类型代码查询预警参数记录
	 * 
	 * @param ewsParam
	 * @return
	 */
	public EwsParam queryEwsParamByParamCodeAndTypeCode(@Param("paramCode")String paramCode,@Param("paramTypeCode")String paramTypeCode);
	
	/**
	 * 不排序直接分页
	 * 
	 * @param start
	 * @param end
	 * @return
	 */
	public List<EwsParam> queryEwsParamByPage(int start,int end);
	
	/**
	 *  排序+分页
	 * 
	 * @param start
	 * @param end
	 * @return
	 */
	public List<EwsParam> queryEwsParamByOrderPage(int start,int end);

}
