/**
 * 
 */
package com.sfpay.ews.dao;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsGroupIndex;

/**
 * 预警群组与指标映射Dao
 * 
 * @author 625288
 *
 */
public interface IEwsGroupIndexDao {

	/**
	 * 新增预警群组与指标映射
	 * @param ewsGroupIndex
	 */
	public void addEwsGroupIndex(EwsGroupIndex ewsGroupIndex);
	
	/**
	 * 查询一个群组指标映射
	 * @param groupNo
	 * @param warnIndexNo
	 * @return
	 */
	public EwsGroupIndex queryEwsGroupIndex(@Param("groupNo")String groupNo, 
			@Param("warnIndexNo")String warnIndexNo);
	
	/**
	 * 
	 * 方法：根据群组编号删除对应关系
	 * 方法说明：
	 *
	 * @param groupNo 群组编号
	 */
	public void deleteEwsGroupIndexByGroupNo(String groupNo);
}
