/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sfpay.ews.dao.IEwsGroupDefDao;
import com.sfpay.ews.platform.domain.EwsGroupDef;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.service.IEwsGroupDefService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月8日 下午1:34:22
 */
@HessianExporter
@Service("ewsGroupDefService")
public class EwsGroupDefServiceImpl implements IEwsGroupDefService {
	
	private Log logger = LogFactory.getLog(EwsGroupDefServiceImpl.class);
	
	@Autowired
	private IEwsGroupDefDao ewsGroupDefDao;

	@Override
	public void addEwsGroupDef(EwsGroupDef defDTO)
			throws ServiceException {
		logger.info("群组参数对象 = " + defDTO);
		
		if(defDTO == null){
			throw new ServiceException("群组参数对象为空");
		}
		
		EwsGroupDef groupDef = new EwsGroupDef();
		BeanUtils.copyProperties(defDTO, groupDef);
		logger.info("转化后的群组对象 = " + groupDef);
		
		if(StringUtils.isBlank(groupDef.getGroupNo())){
			throw new ServiceException("群组编号为空");
		}
		
		if(StringUtils.isBlank(groupDef.getGroupName())){
			throw new ServiceException("群组名称为空");
		}
		
		if(StringUtils.isBlank(groupDef.getIsValid())){
			throw new ServiceException("群组的有效标志为空");
		}
		
		logger.info("群组编号 = " + groupDef.getGroupNo());
		EwsGroupDef tmpDto = ewsGroupDefDao.queryByGroupNo(groupDef.getGroupNo());
		try{

			//新增群组
				groupDef.setCreateTime(new Date());
				if(tmpDto != null){
					throw new ServiceException("该群组编号已经存在");
				}
				
				ewsGroupDefDao.addEwsGroupDef(groupDef);
			
		}catch (ServiceException e) {
			throw new ServiceException(e.getMessage(),e);
		}catch (Exception e) {
			logger.error("新增群组记录错误",e);
			throw new ServiceException("新增群组记录错误",e);
		}
	}
	
	@Override
	public void updateEwsGroupDef(EwsGroupDef ewsGroupDef)
			throws ServiceException {
		logger.info("群组参数对象 = " + ewsGroupDef);
		
		if(ewsGroupDef == null){
			throw new ServiceException("群组参数对象为空");
		}
		
		EwsGroupDef groupDef = new EwsGroupDef();
		BeanUtils.copyProperties(ewsGroupDef, groupDef);
		logger.info("转化后的群组对象 = " + groupDef);
		
		if(StringUtils.isBlank(groupDef.getGroupNo())){
			throw new ServiceException("群组编号为空");
		}
		
		if(StringUtils.isBlank(groupDef.getGroupName())){
			throw new ServiceException("群组名称为空");
		}
		
		if(StringUtils.isBlank(groupDef.getIsValid())){
			throw new ServiceException("群组的有效标志为空");
		}
		
		logger.info("群组编号 = " + groupDef.getGroupNo());
		EwsGroupDef tmpDto = ewsGroupDefDao.queryByGroupNo(groupDef.getGroupNo());
		try{
			//修改群组
				groupDef.setUpdateTime(new Date());
				if(tmpDto == null){
					throw new ServiceException("找不到要修改的群组记录");
				}
				
				ewsGroupDefDao.updateEwsGroupDef(groupDef);
			
		}catch (ServiceException e) {
			throw new ServiceException(e.getMessage(),e);
		}catch (Exception e) {
			logger.error("修改群组记录错误",e);
			throw new ServiceException("修改群组记录错误",e);
		}
	}

	@Override
	public List<EwsGroupDef> querytAllEwsGroupDef() {
		EwsGroupDef ewsGroupDef=new EwsGroupDef();
		return ewsGroupDefDao.queryEwsGroupDefByParam(ewsGroupDef);
	}

	@Override
	public void delEwsGroupDef(String groupNo) {
		logger.info("群组编号 = " + groupNo);
		EwsGroupDef tmpDto = ewsGroupDefDao.queryByGroupNo(groupNo);
		if (tmpDto==null) {
			throw new ServiceException("找不到要删除的群组记录");
		}
		ewsGroupDefDao.delEwsGroupDef(groupNo);
	}

	@Override
	public EwsGroupDef queryByGroupNo(String groupNo) {
		if (StringUtils.isEmpty(groupNo)) {
			logger.info("群组编号为空");
			return null;
		}
		return ewsGroupDefDao.queryByGroupNo(groupNo);
	}

	@Override
	public List<EwsGroupDef> queryEwsGroupDefByParam(EwsGroupDef ewsGroupDef) {
		return ewsGroupDefDao.queryEwsGroupDefByParam(ewsGroupDef);
	}

	@Override
	public IPage<EwsGroupDef> queryEwsGroupDefByOrderPage(EwsGroupDef ewsGroupDef, int index, int size) {
		logger.info("分页查询预警群组,参数 = " + ewsGroupDef);
		if (ewsGroupDef == null) {
			throw new ServiceException("查询预警群组参数对象为空");
		}

		if (index <= 0 || size <= 0) {
			throw new ServiceException("查询预警通知的index,size为空");
		}
		
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("ewsGroupDef", ewsGroupDef);
			map.put("start", (index - 1) * size + 1);
			map.put("end", index * size);
			
			Long row = ewsGroupDefDao.queryEwsGroupDefCntByParam(ewsGroupDef);
			logger.info("分页查询行数 row = " + row);
			List<EwsGroupDef> groups = new ArrayList<EwsGroupDef>();
			if (row > 0) {
				groups = ewsGroupDefDao.queryEwsGroupDefByOrderPage(map);
			}
			return new Page<EwsGroupDef>(groups, row, index, size);
		} catch (Exception e) {
			logger.error("分页查询预警群组错误", e);
			throw new ServiceException("分页查询预警群组错误 ", e);
		}
	}

	@Override
	public List<EwsIndexDef> queryAuthIndexByGroupNo(String groupNo) throws ServiceException {
		if (StringUtils.isEmpty(groupNo)) {
			logger.info("群组编号为空");
			return null;
		}
		List<EwsIndexDef> list=new ArrayList<EwsIndexDef>();
		try {
			list=ewsGroupDefDao.queryAuthIndexByGroupNo(groupNo);
		} catch (Exception e) {
			logger.error("查询群组授权指标出错", e);
			throw new ServiceException("查询群组授权指标出错 ", e);
		}
		return list;
	}

	@Override
	public List<EwsIndexDef> queryUnAuthIndexByGroupNo(String groupNo) throws ServiceException {
		if (StringUtils.isEmpty(groupNo)) {
			logger.info("群组编号为空");
			return null;
		}
		List<EwsIndexDef> list=new ArrayList<EwsIndexDef>();
		try {
			list=ewsGroupDefDao.queryUnAuthIndexByGroupNo(groupNo);
		} catch (Exception e) {
			logger.error("查询群组未授权指标出错", e);
			throw new ServiceException("查询群组未授权指标出错 ", e);
		}
		return list;
	}

}
