/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsEffectDao;
import com.sfpay.ews.platform.domain.EwsEffect;
import com.sfpay.ews.platform.service.IEwsEffectService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：预警实效服务实现类
 * 
 * 类描述：
 * 
 * @author 625288
 * 
 *         2015-3-27
 */
@HessianExporter
@Service("ewsEffectService")
public class EwsEffectServiceImpl implements IEwsEffectService {
	@Autowired
	private IEwsEffectDao ewsEffectDao;

	private Logger logger = LoggerFactory.getLogger(EwsEffectServiceImpl.class);

	@Override
	public EwsEffect queryByEffectCode(String effectCode) {
		if (StringUtils.isBlank(effectCode)) {
			throw new ServiceException("实效编码不能为空！");
		}

		return ewsEffectDao.queryByEffectCode(effectCode);
	}

	@Override
	public EwsEffect queryByWarnClassAndWarnLevel(String warnClassCode, String warnLevel) {
		if (StringUtils.isBlank(warnClassCode)) {
			throw new ServiceException("预警类别代码不能为空！");
		}

		if (StringUtils.isBlank(warnLevel)) {
			throw new ServiceException("风险等级不能为空！");
		}

		return ewsEffectDao.queryByWarnClassAndWarnLevel(warnClassCode, warnLevel);
	}

	@Override
	public void addEwsEffect(EwsEffect ewsEffect) {
		logger.info("addEwsEffect 【{}】", ewsEffect);
		checkEwsEffect(ewsEffect);

		if (queryByEffectCode(ewsEffect.getEffectCode()) != null) {
			logger.error("实效代码【{}】已存在！", ewsEffect.getEffectCode());
			throw new ServiceException(String.format("实效代码【%s】已存在！", ewsEffect.getEffectCode()));
		}

		if (queryByWarnClassAndWarnLevel(ewsEffect.getWarnClassCode(), ewsEffect.getWarnLevel()) != null) {
			logger.error("预警类别和风险等级映射【{}-{}】已存在！", ewsEffect.getWarnClassCode(), ewsEffect.getWarnLevel());
			throw new ServiceException(String.format("预警类别和风险等级映射【%s-%s】已存在！",
					new Object[] { ewsEffect.getWarnClassCode(), ewsEffect.getWarnLevel() }));
		}

		ewsEffectDao.addEwsEffect(ewsEffect);
		logger.info("addEwsEffect 新增实效成功【{}】", ewsEffect);
	}

	@Override
	public void updateEwsEffect(EwsEffect ewsEffect) {
		logger.info("updateEwsEffect 【{}】", ewsEffect);
		checkEwsEffect(ewsEffect);

		EwsEffect oldEwsEffect = queryById(ewsEffect.getId());
		if (oldEwsEffect == null) {
			logger.error("预警实效ID【{}】不存在！", ewsEffect.getId());
			throw new ServiceException(String.format("预警实效ID【%s】不存在！", ewsEffect.getId()));
		}

		if (!StringUtils.equals(ewsEffect.getEffectCode(), oldEwsEffect.getEffectCode())
				&& queryByEffectCode(ewsEffect.getEffectCode()) != null) {
			logger.error("实效代码【{}】已存在！", ewsEffect.getEffectCode());
			throw new ServiceException(String.format("实效代码【%s】已存在！", ewsEffect.getEffectCode()));
		}

		if ((!StringUtils.equals(ewsEffect.getWarnClassCode(), oldEwsEffect.getWarnClassCode())
				|| !StringUtils.equals(ewsEffect.getWarnLevel(), oldEwsEffect.getWarnLevel()))&&
				(queryByWarnClassAndWarnLevel(ewsEffect.getWarnClassCode(), ewsEffect.getWarnLevel()) != null)) {
				logger.error("预警类别和风险等级映射【{}-{}】已存在！", ewsEffect.getWarnClassCode(), ewsEffect.getWarnLevel());
				throw new ServiceException(String.format("预警类别和风险等级映射【%s-%s】已存在！",
						new Object[] { ewsEffect.getWarnClassCode(), ewsEffect.getWarnLevel() }));
		}

		ewsEffectDao.updateEwsEffect(ewsEffect);

		logger.info("updateEwsEffect 更新实效对象成功【{}】", ewsEffect);
	}

	@Override
	public void deleteEwsEffect(long id) {
		logger.info("deleteEwsEffect 【{}】", id);
		if (queryById(id) == null) {
			logger.error("预警实效ID【{}】不存在！", id);
			throw new ServiceException(String.format("预警实效ID【%s】不存在！", id));
		}

		ewsEffectDao.deleteEwsEffect(id);

		logger.info("deleteEwsEffect 删除实效成功【{}】", id);
	}

	/**
	 * 检查实效类数据是否正确
	 * 
	 * @param ewsEffect
	 */
	private void checkEwsEffect(EwsEffect ewsEffect) {
		if (ewsEffect == null) {
			throw new ServiceException("实效对象不能为空！");
		}

		if (StringUtils.isBlank(ewsEffect.getEffectCode())) {
			throw new ServiceException("实效代码不能为空！");
		}

		if (StringUtils.isBlank(ewsEffect.getEffectName())) {
			throw new ServiceException("实效名称不能为空！");
		}

		if (StringUtils.isBlank(ewsEffect.getWarnClassCode())) {
			throw new ServiceException("预警类别代码不能为空！");
		}

		if (StringUtils.isBlank(ewsEffect.getWarnLevel())) {
			throw new ServiceException("风险等级不能为空！");
		}
	}

	@Override
	public EwsEffect queryById(long id) {
		return ewsEffectDao.queryById(id);
	}

	/**
	 * 预警时效分页查询
	 * 
	 */
	@Override
	public IPage<EwsEffect> selectEwsEffectByPage(EwsEffect ewsEffect, int index, int size) {
		try {
			if (index <= 0 || size <= 0) {
				logger.error("预警时效分页查询index,size不能为空");
				throw new ServiceException("预警时效分页查询index,size不能为空");
			}

			long cnt = ewsEffectDao.selectEwsEffectCount(ewsEffect);
			if (cnt <= 0) {
				logger.error("预警时效分页查询结果为零");
			}

			List<EwsEffect> list = ewsEffectDao.selectEwsEffectByPage(ewsEffect, index, size);
			
			return new Page<EwsEffect>(list, cnt, index, size);
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("预警时效分页查询时出错", e);
			throw new ServiceException("预警时效分页查询时出错", e);
		}

	}
}
