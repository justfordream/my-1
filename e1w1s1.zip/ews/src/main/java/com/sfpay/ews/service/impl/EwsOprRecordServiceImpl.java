package com.sfpay.ews.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsOprRecordDao;
import com.sfpay.ews.platform.domain.EwsOprRecord;
import com.sfpay.ews.platform.service.IEwsOprRecordService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

@HessianExporter
@Service("ewsOprRecordService")
public class EwsOprRecordServiceImpl implements IEwsOprRecordService {

	private static Logger logger = LoggerFactory.getLogger(EwsOprRecordServiceImpl.class);

	@Resource
	private IEwsOprRecordDao ewsOprRecordDao;

	@Override
	public void addEwsOprRecord(EwsOprRecord ewsOprRecord) {
		try {
			if (ewsOprRecord == null) {
				logger.error("不可以将空对象新增到预警操作记录中");
				throw new ServiceException("不可以将空对象新增到预警操作记录中");
			}
			if (StringUtils.isBlank(ewsOprRecord.getOperDesc())) {
				logger.error("新增预警操作记录的处理说明不可以为空");
				throw new ServiceException("新增预警操作记录的处理说明不可以为空");
			}
			ewsOprRecordDao.addEwsOprRecord(ewsOprRecord);

		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("新增预警操作记录错误", e);
			throw new ServiceException("新增预警操作记录错误", e);
		}

	}

	@Override
	public void updateEwsOprRecord(EwsOprRecord ewsOprRecord) {
		try {
			if (ewsOprRecord == null) {
				logger.error("不可以将空对象更新到预警操作记录中");
				throw new ServiceException("不可以将空对象更新到预警操作记录中");
			}
			if (StringUtils.isBlank(ewsOprRecord.getOperDesc())) {
				logger.error("更新预警操作记录的处理说明不可以为空");
				throw new ServiceException("更新预警操作记录的处理说明不可以为空");
			}
			ewsOprRecordDao.updateEwsOprRecord(ewsOprRecord);

		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("更新预警操作记录错误", e);
			throw new ServiceException("更新预警操作记录错误", e);
		}
	}

	@Override
	public void delEwsOprRecord(String id) {
		try {
			if (StringUtils.isBlank(id)) {
				logger.error("根据ID删除预警操作记录时主键ID不可以为空");
				throw new ServiceException("根据ID删除预警操作记录时主键ID不可以为空");
			}
			ewsOprRecordDao.delEwsOprRecord(id);
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("删除预警操作记录错误", e);
			throw new ServiceException("删除预警操作记录错误", e);
		}

	}

	@Override
	public EwsOprRecord queryById(String id) {
		try {
			if (StringUtils.isBlank(id)) {
				logger.error("根据ID查询预警操作记录时主键ID不可以为空");
				throw new ServiceException("根据ID查询预警操作记录时主键ID不可以为空");
			}
			return ewsOprRecordDao.queryById(id);
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("根据ID查询预警操作记录错误", e);
			throw new ServiceException("根据ID查询预警操作记录错误", e);
		}
	}

	@Override
	public List<EwsOprRecord> queryEwsOprRecordByWarnInfoRecordId(String warnInfoRecordId) {
		try {
			if (StringUtils.isBlank(warnInfoRecordId)) {
				logger.error("根据指标预警编号查询预警操作记录时指标预警编号不可以为空");
				throw new ServiceException("根据指标预警编号查询预警操作记录时指标预警编号不可以为空");
			}
			return ewsOprRecordDao.queryEwsOprRecordByWarnInfoRecordId(warnInfoRecordId);
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("根据指标预警记录编号查询预警操作记录错误", e);
			throw new ServiceException("根据指标预警记录编号查询预警操作记录错误", e);
		}
	}

}
