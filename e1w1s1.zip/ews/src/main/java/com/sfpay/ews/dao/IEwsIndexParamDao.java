package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsIndexParam;

/**
 * 指标参数dao
 * 
 * @author 321566 张泽豪
 * 
 *         2014-5-9 上午9:26:24
 */
public interface IEwsIndexParamDao {

	/**
	 * 新增指标参数
	 * 
	 * @param EwsIndexParam
	 * @return
	 */
	public int saveEwsIndexParam(EwsIndexParam ewsIndexParam);

	/**
	 * 修改指标参数
	 * 
	 * @param EwsIndexParam
	 * @return
	 */
	public int updateEwsIndexParam(EwsIndexParam ewsIndexParam);

	/**
	 * 查询所有指标参数记录数
	 * 
	 * @param param
	 * @return
	 */
	public int selectEwsIndexParamCount(@Param("param") EwsIndexParam param);

	/**
	 * 分页查询指标参数
	 * 
	 * @param param
	 * @param index
	 * @param size
	 * @return
	 */
	public List<EwsIndexParam> selectEwsIndexParamByPage(
			@Param("param") EwsIndexParam param, @Param("index") int index,
			@Param("size") int size);

	/**
	 * 根据ID查询指标参数
	 * 
	 * @param id
	 * @return
	 */
	public EwsIndexParam selectEwsIndexParamById(long id);
	
	/**
	 * 
	 * 方法：根据ID删除指标参数
	 * 方法说明：
	 *
	 * @param id
	 */
	public void deleteEwsIndexParamById(long id);

	/**
	 * 根据预警编号和指标编号查询指标参数
	 * 
	 * @param paramName
	 * @param warnIndexNo
	 * @return
	 */
	public EwsIndexParam selectEwsIndexParamByParamNameAndIndexNo(
			@Param("paramName") String paramName,
			@Param("warnIndexNo") String warnIndexNo);

	/**
	 * 根据指标编号来获取某指标的全部参数
	 * 
	 * @param warnIndexNo
	 * 
	 * @return
	 */
	public List<EwsIndexParam> queryEwsIndexParamsByWarnIndexNo(
			@Param("warnIndexNo") String warnIndexNo);
	
	/**
	 * 
	 * 方法：根据指标编号和参数名称查询参数
	 * 方法说明：
	 *
	 * @param warnIndexNo 指标编号
	 * @param paramName 参数名称
	 * @return 参数对象
	 */
	public EwsIndexParam queryByIndexNoAndParamName(@Param("warnIndexNo") String warnIndexNo, 
			@Param("paramName")String paramName);

}
