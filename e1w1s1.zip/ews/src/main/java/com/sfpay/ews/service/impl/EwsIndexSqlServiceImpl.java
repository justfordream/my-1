/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsIndexSqlDao;
import com.sfpay.ews.platform.domain.EwsIndexSql;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsIndexSqlService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：告警指标SQL的服务实现类
 *
 * 类描述：告警指标SQL的服务实现类
 * @author 625288
 *
 * 2015-3-3
 */
@HessianExporter
@Service("ewsIndexSqlService")
public class EwsIndexSqlServiceImpl implements IEwsIndexSqlService{
	@Autowired
	private IEwsIndexSqlDao ewsIndexSqlDao;
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	
	private Logger logger = LoggerFactory.getLogger(EwsIndexSqlServiceImpl.class);
	
	@Override
	public List<EwsIndexSql> queryEwsIndexSqlByWarnNo(String warnIndexNo) {
		if(StringUtils.isBlank(warnIndexNo)) {
			throw new ServiceException("指标编号不能为空！");
		}
		
		return ewsIndexSqlDao.queryEwsIndexSqlByWarnNo(warnIndexNo);
	}

	@Override
	public void addEwsIndexSql(EwsIndexSql ewsIndexSql) {
		logger.info("addEwsIndexSql 【{}】", ewsIndexSql);
		
		checkEwsIndexSql(ewsIndexSql);
		
		// 指标编号是否存在
		checkWarnIndexNo(ewsIndexSql);
		
		// 是否违反唯一约束
		if(queryByWarnIndexNoAndSqlKey(ewsIndexSql.getWarnIndexNo(), 
				ewsIndexSql.getSqlKey()) != null) {
			logger.error("预警指标【{}】sql键【{}】已存在！", ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey());
			throw new ServiceException(String.format("预警指标【%s】sql键【%s】已存在！", 
					new Object[]{ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
		}
		
		ewsIndexSqlDao.addEwsIndexSql(ewsIndexSql);
		logger.info("addEwsIndexSql 新增指标SQL【{}】成功！", ewsIndexSql);
	}

	@Override
	public void deleteEwsIndexSql(long id) {
		logger.info("deleteEwsIndexSql 【{}】", id);
		
		EwsIndexSql ewsIndexSql = queryById(id);
		if(ewsIndexSql == null) {
			logger.error("删除删除预警指标SQL失败，ID【{}】不存在！", 
					id);
			throw new ServiceException(String.format("删除预警指标SQL失败，ID【%s】不存在！", id));
		}
		
		ewsIndexSqlDao.deleteEwsIndexSql(id);
		
		logger.info("deleteEwsIndexSql 删除预警指标SQL【{}】成功！", id);
		
	}

	@Override
	public void updateEwsIndexSql(EwsIndexSql ewsIndexSql) {
	logger.info("updateEwsIndexSql 【{}】", ewsIndexSql);
		
	if (ewsIndexSql == null) {
		throw new ServiceException("预警指标SQL对象不能为空");
	}
		
		EwsIndexSql oldSql = queryById(ewsIndexSql.getId());
		if(oldSql == null) {
			logger.error("预警指标SQL【{}】ID不存在，更新失败！", ewsIndexSql);
			throw new ServiceException(String.format("预警指标SQL的ID【%s】不存在，更新失败！", 
					ewsIndexSql.getId()));
		}
		
		// 指标编号是否存在
		checkWarnIndexNo(ewsIndexSql);
		
		// 是否违反唯一约束
		if(StringUtils.isNotBlank(ewsIndexSql.getSqlKey()) && 
				!StringUtils.equals(oldSql.getSqlKey(), ewsIndexSql.getSqlKey()) || 
				!StringUtils.equals(oldSql.getWarnIndexNo(), ewsIndexSql.getWarnIndexNo())) {
			if(queryByWarnIndexNoAndSqlKey(ewsIndexSql.getWarnIndexNo(), 
					ewsIndexSql.getSqlKey()) != null) {
				logger.error("预警指标【{}】sql键【{}】已存在！", ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey());
				throw new ServiceException(String.format("预警指标【%s】sql键【%s】已存在！", 
						new Object[]{ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
			}
		}
		
		ewsIndexSqlDao.updateEwsIndexSql(ewsIndexSql);
		logger.info("updateEwsIndexSql 更新指标SQL【{}】成功！", ewsIndexSql);
	}
	
	@Override
	public EwsIndexSql queryByWarnIndexNoAndSqlKey(String warnIndexNo,
			String sqlKey) {
		if(StringUtils.isBlank(warnIndexNo)) {
			throw new ServiceException("指标编号不能为空！");
		}
		
		if(StringUtils.isBlank(sqlKey)) {
			throw new ServiceException("SQL键不能为空！");
		}
		
		return ewsIndexSqlDao.queryByWarnIndexNoAndSqlKey(warnIndexNo, sqlKey);
	}
	
	/**
	 * 检查预警指标SQL对象正确性
	 * @param ewsIndexSql
	 */
	private void checkEwsIndexSql(EwsIndexSql ewsIndexSql) {
		if (ewsIndexSql == null) {
			throw new ServiceException("预警指标SQL对象不能为空");
		}

		if (StringUtils.isBlank(ewsIndexSql.getSqlKey())) {
			throw new ServiceException("SQL键不能为空");
		}

		if (StringUtils.isBlank(ewsIndexSql.getWarnIndexSql())) {
			throw new ServiceException("SQL语句不能为空");
		}

		if (StringUtils.isBlank(ewsIndexSql.getWarnIndexNo())) {
			throw new ServiceException("指标编号不能为空");
		}
		
		if(ewsIndexDefService.queryByWarnIndexNo(ewsIndexSql.getWarnIndexNo()) == null) {
			throw new ServiceException(String.format("指标编号【%s】不存在！", ewsIndexSql.getWarnIndexNo()));
		}
	}

	@Override
	public EwsIndexSql queryById(long id) {
		return ewsIndexSqlDao.queryById(id);
	}

	@Override
	public Set<String> queryAllTableName() {
		Set<String> tableSet = new HashSet<String>();
		List<String> result = ewsIndexSqlDao.queryAllTableName();
		if(result != null && !result.isEmpty()) {
			tableSet.addAll(ewsIndexSqlDao.queryAllTableName());
		}
		
		return tableSet;
	}
	
	/**
	 * 检查指标编号是否存在
	 * @param ewsIndexSql
	 */
	private void checkWarnIndexNo(EwsIndexSql ewsIndexSql) {
		if(ewsIndexSql != null && StringUtils.isNotBlank(ewsIndexSql.getWarnIndexNo())) {
			// 指标编号是否存在
			if(ewsIndexDefService.queryByWarnIndexNo(ewsIndexSql.getWarnIndexNo()) == null) {
				logger.error(String.format("指标编号【%s】不存在！",  ewsIndexSql.getWarnIndexNo()));
				throw new ServiceException(String.format("指标编号【%s】不存在！", ewsIndexSql.getWarnIndexNo()));
			}
		}
	}

	@Override
	public IPage<EwsIndexSql> queryByPage(EwsIndexSql ewsIndexSql, int index, int size)
			throws ServiceException {
		logger.info("指标SQL分页查询参数对象 = " + ewsIndexSql);
		if (ewsIndexSql == null) {
			throw new ServiceException("查询参数为空");
		}

		if (index <= 0 || size <= 0) {
			throw new ServiceException("分页参数index,size为空");
		}

		try {
			int row = ewsIndexSqlDao.queryEwsIndexSqlCount(ewsIndexSql);
			
			List<EwsIndexSql> result = null;
			if (row == 0) {
				result = new ArrayList<EwsIndexSql>();
				
			} else {
				int start = (index - 1) * size;
				int end = index * size;
				result = ewsIndexSqlDao.queryByPage(ewsIndexSql, start, end);
			}
			
			return new Page<EwsIndexSql>(result, row, index, size);
			
		} catch (Exception e) {
			logger.error("指标SQL分页查询错误", e);
			throw new ServiceException("指标SQL分页查询错误", e);
		}
	}
}
