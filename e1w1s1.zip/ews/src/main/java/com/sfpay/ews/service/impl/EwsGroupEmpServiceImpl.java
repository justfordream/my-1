package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsGroupEmpDao;
import com.sfpay.ews.platform.domain.EwsGroupEmp;
import com.sfpay.ews.platform.service.IEwsGroupEmpService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

@HessianExporter
@Service("ewsGroupEmpService")
public class EwsGroupEmpServiceImpl implements IEwsGroupEmpService {

	private Log logger = LogFactory.getLog(EwsGroupEmpServiceImpl.class);

	@Resource
	private IEwsGroupEmpDao groupEmpDao;

	@Override
	public void addEwsGroupEmp(EwsGroupEmp emp) throws ServiceException {
		logger.info("预警通知对象 = " + emp);
		if (emp == null) {
			throw new ServiceException("预警通知参数对象为空");
		}
		EwsGroupEmp groupEmp = new EwsGroupEmp();
		BeanUtils.copyProperties(emp, groupEmp);

		if (StringUtils.isBlank(groupEmp.getEmpId())) {
			throw new ServiceException("预警工号不能为空");
		}

		if (StringUtils.isBlank(groupEmp.getEmpName())) {
			throw new ServiceException("员工姓名不能为空");
		}

		try {
			EwsGroupEmp empDTO = groupEmpDao.selectGroupEmpByEmpId(groupEmp
					.getEmpId());
			// 新增预警记录
			groupEmp.setCreateTime(new Date());
			if (empDTO != null) {
				throw new ServiceException("该工号已经配置了预警通知");
			}

			int row = groupEmpDao.insertEwsGroupEmp(groupEmp);
			logger.info("新增预警通知记录 row = " + row);
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("新增或修改预警记录错误 ", e);
			throw new ServiceException("新增或修改预警记录错误", e);
		}
	}

	@Override
	public void updateEwsGroupEmp(EwsGroupEmp emp) throws ServiceException {
		logger.info("预警通知对象 = " + emp);
		if (emp == null) {
			throw new ServiceException("预警通知参数对象为空");
		}
		EwsGroupEmp groupEmp = new EwsGroupEmp();
		BeanUtils.copyProperties(emp, groupEmp);

		if (StringUtils.isBlank(groupEmp.getEmpId())) {
			throw new ServiceException("预警工号不能为空");
		}

		if (StringUtils.isBlank(groupEmp.getEmpName())) {
			throw new ServiceException("员工姓名不能为空");
		}

		try {
			EwsGroupEmp empDTO = groupEmpDao.selectGroupEmpByEmpId(groupEmp
					.getEmpId());
			// 修改预警记录
			if (empDTO == null) {
				throw new ServiceException("找不到要修改的预警通知");
			}
			groupEmp.setUpdateTime(new Date());
			int row = groupEmpDao.updateWarnGroupEmp(groupEmp);
			logger.info("修改预警通知记录 row = " + row);
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("新增或修改预警记录错误 ", e);
			throw new ServiceException("新增或修改预警记录错误", e);
		}
	}

	@Override
	public IPage<EwsGroupEmp> queryEwsGroupEmpByPage(EwsGroupEmp emp, int index,
			int size) throws ServiceException {
		logger.info("分页查询预警通知,参数 = " + emp);
		if (emp == null) {
			throw new ServiceException("查询预警通知参数对象为空");
		}

		if (index <= 0 || size <= 0) {
			throw new ServiceException("查询预警通知的index,size为空");
		}

		try {
			int row = groupEmpDao.selectGroupEmpCount(emp);
			logger.info("分页查询行数 row = " + row);
			List<EwsGroupEmp> emps = new ArrayList<EwsGroupEmp>();
			if (row > 0) {
				emps = groupEmpDao.selectGroupEmpByPage(emp, index, size);
			}
			return new Page<EwsGroupEmp>(emps, row, index, size);
		} catch (Exception e) {
			logger.error("分页查询预警记录错误", e);
			throw new ServiceException("分页查询预警记录错误 ", e);
		}
	}

	@Override
	public EwsGroupEmp queryEwsGroupEmpByEmpId(String empId)
			throws ServiceException {
		try {
			logger.info("查询工号 = " + empId);
			return groupEmpDao.selectGroupEmpByEmpId(empId);
		} catch (Exception e) {
			logger.error("查询预警记录错误 empId = " + empId, e);
			throw new ServiceException("查询预警记录错误 empId = " + empId, e);
		}
	}

	/**
	 * 根据指标代码找出对应的有效人员;
	 * 
	 * @param indexNo
	 * @return
	 * @throws ServiceException
	 */
	@Override
	public List<EwsGroupEmp> queryNotifyEmpByIndexNo(String indexNo)
			throws ServiceException {
		List<EwsGroupEmp> EwsGroupEmpList = null;
		try {
			logger.info("查询的指标代码 = " + indexNo);
			EwsGroupEmpList = groupEmpDao.queryNotifyEmpByIndexNo(indexNo);
		} catch (Exception e) {
			logger.error("根据指标代码查询通知人员的记录错误 indexNo = " + indexNo, e);
			throw new ServiceException("根据指标代码查询通知人员的记录错误empId = " + indexNo, e);
		}
		return EwsGroupEmpList;
	}
}
