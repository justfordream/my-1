package com.sfpay.ews.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 记录产生每个指标调用的开始时间和结束时间，记录到资料库中
 *  对应的日志记录;
 * @author 575740
 *
 */
public class EwsWarningCalrltlog  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4176276924476336189L;
	
	/**
	 * 预警日期 YYYY-MM-DD;资料库后台Trunc
	 */
	private Date warnDate;
	/**
	 * 预警编号
	 */
	private String warnIndexNo;
	/**
	 * 预警指标说明
	 */
	private String warnIndexName;
	/**
	 * 指标计算开始时间
	 */
	private Date warnBeginTime;
	/**
	 * 指标计算结束时间
	 */
	private Date warnEndTime;
	/**
	 * 指标计算的秒 = 计算结束时间  - 计算开始时间
	 */
	private Long warnCalSecond;
	/**
	 * 备注
	 */
	private String remark;
	
	/**
	 * 创建时间
	 */
	private Date createTime;
	
	/**
	 * 预警来源;
	 */
	private String warnSource;
	
	

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public Date getWarnDate() {
		return (Date)warnDate.clone();
	}

	public void setWarnDate(Date warnDate) {
		this.warnDate = (Date)warnDate.clone();
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexName() {
		return warnIndexName;
	}

	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}

	public Date getWarnBeginTime() {
		return (Date)warnBeginTime.clone();
	}

	public void setWarnBeginTime(Date warnBeginTime) {
		this.warnBeginTime = (Date)warnBeginTime.clone();
	}

	public Date getWarnEndTime() {
		return (Date)warnEndTime.clone();
	}

	public void setWarnEndTime(Date warnEndTime) {
		this.warnEndTime = (Date)warnEndTime.clone();
	}

	public Long getWarnCalSecond() {
		return warnCalSecond;
	}

	public void setWarnCalSecond(Long warnCalSecond) {
		this.warnCalSecond = warnCalSecond;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return (Date)createTime.clone();
	}

	public void setCreateTime(Date createTime) {
		this.createTime = (Date)createTime.clone();
	}
}
