package com.sfpay.ews.service.impl;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.sfpay.ews.service.ISendSMSService;
import com.sfpay.pubcenter.sms.ISMSService;

public class SendSMSServiceImpl implements ISendSMSService {

	private static Logger logger = LoggerFactory
			.getLogger(SendSMSServiceImpl.class);
	private static ExecutorService threadPool;

	/** 线程池大小 **/
	@Value("${sms_threadpool_size}")
	public String THREAD_POOL_SIZE;
	public int threadPoolSize = 5;// 默认值

	@Resource
	private ISMSService smsService;

	/**
	 * 代码说明：<br>
	 * 初始线程池
	 * 
	 */
	/*
	 * 线程池改用延时加载方式实现（application.xml延时加载init()方法），避免后续升级到framework2后 使用public
	 * static final String THREAD_POOL_SIZE =
	 * Property.getProperty("sms_mail_threadpool_size");报错
	 * 使用构造函数会出现初始化两次，不使用构造方法来初始化
	 */
	public void init() {
		try {
			threadPoolSize = Integer.parseInt(THREAD_POOL_SIZE);
			threadPool = Executors.newFixedThreadPool(threadPoolSize);
			logger.info("短信服务线程池初始化，大小[{}]", THREAD_POOL_SIZE);
		} catch (Throwable e) {
			// 使用默认值20
			threadPool = Executors.newFixedThreadPool(threadPoolSize);
			logger.error("短信服务线程池初始化异常，使用默认值，大小为[{}]", threadPoolSize, e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 关闭线程池
	 * 
	 */
	public void stopPool() {
		threadPool.shutdown();
		logger.info("短信服务线程池停止服务");
	}

	@Override
	public void sendMessage(final String mobile, final String message) {
		threadPool.execute(new Runnable() {
			@Override
			public void run() {
				if (StringUtils.isNotBlank(mobile)) {
					try {
						smsService.send(message, mobile);
						logger.info("给手机号：" + mobile + "发短信通知成功");
					} catch (Exception e) {
						logger.error("给手机号：" + mobile + "发短信通知时发生异常", e);
					}
				}
			}
		});
	}

}
