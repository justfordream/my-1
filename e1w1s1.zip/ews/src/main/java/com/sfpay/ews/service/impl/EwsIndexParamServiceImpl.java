/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsIndexParamDao;
import com.sfpay.ews.platform.domain.EwsIndexParam;
import com.sfpay.ews.platform.service.IEwsIndexParamService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * @author 321566 张泽豪
 * 
 *         2014-5-9 上午10:44:15
 */
@HessianExporter
@Service("ewsIndexParamService")
public class EwsIndexParamServiceImpl implements IEwsIndexParamService {

	private Logger logger = LoggerFactory.getLogger(EwsIndexParamServiceImpl.class);

	@Resource
	IEwsIndexParamDao ewsIndexParamDao;

	@Override
	public void addEwsIndexParam(EwsIndexParam indexParam) throws ServiceException {
		logger.info("addEwsIndexParam 指标参数对象 = " + indexParam);

		checkEwsIndexParam(indexParam);
		
		EwsIndexParam oldEwsIndexParam = ewsIndexParamDao
				.selectEwsIndexParamByParamNameAndIndexNo(
						indexParam.getParamName(), indexParam.getWarnIndexNo());
		try {
			if (oldEwsIndexParam != null) {
				throw new ServiceException(String.format("指标参数【{%s}：{%s}】已经存在", 
						indexParam.getWarnIndexNo(), indexParam.getParamName()) );
			}
			// 新增指标参数
			indexParam.setCreateTime(new Date());
			ewsIndexParamDao.saveEwsIndexParam(indexParam);
			
			logger.info("addEwsIndexParam 新增指标参数对象成功 = " + indexParam);
		} catch (ServiceException e) {
			throw e;
			
		} catch (Exception e) {
			logger.error("新增指标参数记录错误", e);
			throw new ServiceException("新增指标参数记录错误", e);
		}
	}

	@Override
	public void updateEwsIndexParam(EwsIndexParam indexParam)
			throws ServiceException {
		logger.info("updateEwsIndexParam 指标参数对象 = " + indexParam);

		checkEwsIndexParam(indexParam);

		try {
			if (indexParam.getId() <= 0) {
				throw new ServiceException("更新指标参数记录，ID不能为空");
			}
			
			// 修改指标参数
			indexParam.setUpdateTime(new Date());
			ewsIndexParamDao.updateEwsIndexParam(indexParam);
			
			logger.info("updateEwsIndexParam 更新指标参数对象成功 = " + indexParam);
			
		} catch (ServiceException e) {
			throw e;
			
		} catch (Exception e) {
			logger.error("更新指标参数记录错误", e);
			throw new ServiceException("更新指标参数记录错误", e);
		}
	}

	@Override
	public IPage<EwsIndexParam> queryIndexParamByPage(EwsIndexParam param,
			int index, int size) throws ServiceException {
		logger.info("queryIndexParamByPage 指标参数分页查询参数对象 = " + param);
		if (param == null) {
			throw new ServiceException("查询参数为空");
		}

		if (index <= 0 || size <= 0) {
			throw new ServiceException("分页参数index,size为空");
		}

		try {
			int row = ewsIndexParamDao.selectEwsIndexParamCount(param);
			logger.info("指标参数分页总数量 = " + row);
			List<EwsIndexParam> result = new ArrayList<EwsIndexParam>();
			if (row > 0) {
				result = ewsIndexParamDao.selectEwsIndexParamByPage(param, index,
						size);
			}
			return new Page<EwsIndexParam>(result, row, index, size);
			
		} catch (Exception e) {
			logger.error("指标参数分页查询错误", e);
			throw new ServiceException("指标参数分页查询错误", e);
		}
	}

	@Override
	public EwsIndexParam queryWarnIndexParamById(long id)
			throws ServiceException {
		try {
			logger.info("id = " + id);
			return ewsIndexParamDao.selectEwsIndexParamById(id);
			
		} catch (Exception e) {
			logger.error("根据ID查询指标参数错误", e);
			throw new ServiceException("根据ID查询指标参数错误", e);
		}
	}

	@Override
	public List<EwsIndexParam> queryIndexNoParamsByWarnIndexNo(String warnIndexNo) {
		if (StringUtils.isBlank(warnIndexNo)) {
			throw new ServiceException("指标编号不能为空！");
		}
		
		return ewsIndexParamDao.queryEwsIndexParamsByWarnIndexNo(warnIndexNo);
	}
	
	/**
	 * 检查指标参数对象的正确性
	 * @param indexParam
	 */
	private void checkEwsIndexParam(EwsIndexParam indexParam) {
		if (indexParam == null) {
			throw new ServiceException("指标参数对象为空");
		}

		if (StringUtils.isBlank(indexParam.getParamName())) {
			throw new ServiceException("参数名称为空");
		}

		if (StringUtils.isBlank(indexParam.getParamVal())) {
			throw new ServiceException("参数设置值为空");
		}

		if (StringUtils.isBlank(indexParam.getParamUnit())) {
			throw new ServiceException("参数值的单位为空");
		}

		if (StringUtils.isBlank(indexParam.getWarnIndexNo())) {
			throw new ServiceException("预警指标代码为空");
		}

	}

	@Override
	public void deleteEwsIndexParamById(long id) {
		logger.info(String.format("删除指标参数ID为%s的记录",id));
		if (id<=0) {
			throw new ServiceException("指标参数编号不存在");
		}
		ewsIndexParamDao.deleteEwsIndexParamById(id);
		logger.info(String.format("删除指标参数ID为%s的记录结束",id));
	}

	@Override
	public EwsIndexParam queryByIndexNoAndParamName(String warnIndexNo, String paramName) {
		if(StringUtils.isBlank(warnIndexNo) || StringUtils.isBlank(paramName)) {
			logger.error("指标编号和参数名称不能为空！");
			throw new ServiceException("指标编号和参数名称不能为空！");
		}
		
		return ewsIndexParamDao.queryByIndexNoAndParamName(warnIndexNo, paramName);
	}

}
