/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsRuleDao;
import com.sfpay.ews.platform.domain.EwsRule;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsRuleService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：预警规则服务实现类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-25
 */
@HessianExporter
@Service("ewsRuleService")
public class EwsRuleServiceImpl implements IEwsRuleService{
	@Autowired
	private IEwsRuleDao ewsRuleDao;
	
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	
	private Logger logger = LoggerFactory.getLogger(EwsRuleServiceImpl.class);
	
	@Override
	public List<EwsRule> queryByEwsIndexNo(String ewsIndexNo) {
		if(StringUtils.isBlank(ewsIndexNo)) {
			throw new ServiceException("指标编号不能为空！");
		}
		
		return ewsRuleDao.queryByEwsIndexNo(ewsIndexNo);
	}

	@Override
	public void addEwsRule(EwsRule ewsRule) {
		logger.info("addEwsRule 【{}】", ewsRule);
		
		checkEwsRule(ewsRule);
		
		// 指标编号是否存在
		checkWarnIndexNo(ewsRule);
		
		if(queryByIndexNoAndParamName(ewsRule.getWarnIndexNo(), ewsRule.getParamName()) != null) {
			logger.error(String.format("预警指标【%s】下规则参数名称【%s】已存在！", 
					new Object[]{ewsRule.getWarnIndexNo(), ewsRule.getParamName()}));
			throw new ServiceException(String.format("预警指标【%s】下规则参数名称【%s】已存在！", 
					new Object[]{ewsRule.getWarnIndexNo(), ewsRule.getParamName()}));
		}
		
		// 一个指标的预警规则参数中只有一个输出结果
		if("Y".equals(ewsRule.getIsResult())) {

			if(queryResultEwsRule(ewsRule.getWarnIndexNo()) != null) {
				logger.error("预警指标【{}】结果规则只能有一个,新增预警规则【{}】失败！", 
						ewsRule.getWarnIndexNo(), ewsRule);
				throw new ServiceException(String.format("预警指标【%s】结果规则只能有一个！", 
						ewsRule.getWarnIndexNo()));
			}
			
		}
		
		ewsRuleDao.addEwsRule(ewsRule);
		logger.info("addEwsRule 新增【{}】成功！", ewsRule);
	}

	@Override
	public void updateEwsRule(EwsRule ewsRule) {
		logger.info("updateEwsRule 【{}】", ewsRule);
		
		if(ewsRule == null) {
			logger.error("预警规则对象不能为空！");
			throw new ServiceException("预警规则对象不能为空！");
		}
		
		EwsRule oldEwsRule = queryById(ewsRule.getId());
		if(oldEwsRule == null) {
			logger.info("updateEwsRule 更新预警规则【{}】失败，ID不存在！", ewsRule);
			throw new ServiceException(String.format("预警规则ID【%s】不存在！", 
					ewsRule.getId()));
		}
		
		// 指标编号是否存在
		checkWarnIndexNo(ewsRule);
		
		if((StringUtils.isNotBlank(ewsRule.getWarnIndexNo()) && !StringUtils.equals(ewsRule.getWarnIndexNo(), oldEwsRule.getWarnIndexNo())) || 
				(StringUtils.isNotBlank(ewsRule.getParamName()) && !StringUtils.equals(ewsRule.getParamName(), oldEwsRule.getParamName()))	) {
			String indexNo = StringUtils.isBlank(ewsRule.getWarnIndexNo()) ? oldEwsRule.getWarnIndexNo() : ewsRule.getWarnIndexNo();
			String paramName = StringUtils.isBlank(ewsRule.getParamName()) ? oldEwsRule.getParamName() : ewsRule.getParamName();
			
			if(queryByIndexNoAndParamName(indexNo, paramName) != null) {
				logger.error(String.format("预警指标下规则参数名称【%s】已存在！", 
						ewsRule.getParamName()));
				throw new ServiceException(String.format("预警指标下规则参数名称【%s】已存在！", 
						 ewsRule.getParamName()));
			}
		}
		
		// 一个指标下只有一个规则可以配置成输出结果
		if(!StringUtils.equals(ewsRule.getIsResult(), oldEwsRule.getIsResult()) && 
				"Y".equals(ewsRule.getIsResult())) {
			EwsRule resultEwsRule = queryResultEwsRule(ewsRule.getWarnIndexNo());
			if(resultEwsRule != null && resultEwsRule.getId() != ewsRule.getId()) {
				logger.error("结果规则只能有一个,更新预警规则【{}】失败！", ewsRule.getId());
				throw new ServiceException(String.format("结果规则只能有一个,更新预警规则【%s】失败！", 
						ewsRule.getId()));
			}
		}
		
		ewsRuleDao.updateEwsRule(ewsRule);
		logger.info("updateEwsRule 更新【{}】成功！", ewsRule);
	}

	@Override
	public void deleteEwsRule(long id) {
		logger.info("deleteEwsRule 【{}】", id);
		
		EwsRule ewsRule = queryById(id);
		if(ewsRule == null) {
			logger.error("删除预警规则失败，ID【{}】不存在！", 
					id);
			throw new ServiceException(String.format("删除预警规则失败，ID【%s】不存在！", id));
		}
		
		ewsRuleDao.deleteEwsRule(id);
		
		logger.info("deleteEwsRule 删除预警规则【{}】成功！", id);
	}
	
	@Override
	public EwsRule queryResultEwsRule(String ewsIndexNo) {
		if(StringUtils.isBlank(ewsIndexNo)) {
			throw new ServiceException("指标编号不能为空！");
		}
		
		return ewsRuleDao.queryResultEwsRule(ewsIndexNo);
	}
	
	@Override
	public EwsRule queryById(long id) {
		return ewsRuleDao.queryById(id);
	}
	
	/**
	 * 检查预警规则正确性
	 * @param ewsRule
	 */
	private void checkEwsRule(EwsRule ewsRule) {
		if(ewsRule == null) {
			logger.error("预警规则对象不能为空！");
			throw new ServiceException("预警规则对象不能为空！");
		}
		
		if(StringUtils.isBlank(ewsRule.getParamName())) {
			logger.error("预警规则参数名称不能为空！");
			throw new ServiceException("预警规则参数名称不能为空！");
		}
		
		if(StringUtils.isBlank(ewsRule.getParamExpress())) {
			logger.error("预警规则参数表达式不能为空！");
			throw new ServiceException("预警规则参数表达式不能为空！");
		}
		
		if(StringUtils.isBlank(ewsRule.getParamExpress())) {
			logger.error("预警规则参数表达式不能为空！");
			throw new ServiceException("预警规则参数表达式不能为空！");
		}
		
		if(StringUtils.isBlank(ewsRule.getWarnIndexNo())) {
			logger.error("预警规则指标编号不能为空！");
			throw new ServiceException("预警规则指标编号不能为空！");
		}
	}

	/**
	 * 检查指标编号是否存在
	 * @param ewsIndexSql
	 */
	private void checkWarnIndexNo(EwsRule ewsRule) {
		if(ewsRule != null && StringUtils.isNotBlank(ewsRule.getWarnIndexNo())) {
			// 指标编号是否存在
			if(ewsIndexDefService.queryByWarnIndexNo(ewsRule.getWarnIndexNo()) == null) {
				logger.error(String.format("指标编号【%s】不存在！", ewsRule.getWarnIndexNo()));
				throw new ServiceException(String.format("指标编号【%s】不存在！", ewsRule.getWarnIndexNo()));
			}
		}
	}

	@Override
	public EwsRule queryByIndexNoAndParamName(String warnIndexNo, String paramName) {
		if(StringUtils.isBlank(warnIndexNo)) {
			logger.error("指标编号不能为空!");
			throw new ServiceException("指标编号不能为空!");
		}
		
		if(StringUtils.isBlank(paramName)) {
			logger.error("参数名称不能为空!");
			throw new ServiceException("参数名称不能为空!");
		}
		
		return ewsRuleDao.queryByIndexNoAndParamName(warnIndexNo, paramName);
	}
	
	@Override
	public IPage<EwsRule> queryByPage(EwsRule ewsRule, int index, int size)
			throws ServiceException {
		logger.info("指标规则分页查询参数对象 = " + ewsRule);
		if (ewsRule == null) {
			throw new ServiceException("查询参数为空");
		}

		if (index <= 0 || size <= 0) {
			throw new ServiceException("分页参数index,size为空");
		}

		try {
			int row = ewsRuleDao.queryEwsRuleCount(ewsRule);
			
			List<EwsRule> result = null;
			if (row == 0) {
				result = new ArrayList<EwsRule>();
				
			} else {
				int start = (index - 1) * size;
				int end = index * size;
				result = ewsRuleDao.queryByPage(ewsRule, start, end);
			}
			
			return new Page<EwsRule>(result, row, index, size);
			
		} catch (Exception e) {
			logger.error("指标规则分页查询错误", e);
			throw new ServiceException("指标规则分页查询错误", e);
		}
	}
}
