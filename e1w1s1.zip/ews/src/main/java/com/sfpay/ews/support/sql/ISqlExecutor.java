/**
 * 
 */
package com.sfpay.ews.support.sql;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * 类说明：SQL执行器接口
 *
 * 类描述：
 * @author manzhizhen
 *
 * 2015年2月20日
 */
public interface ISqlExecutor {
	/**
	 * 通过Statement执行select的静态sql
	 * @param sql
	 * @return
	 */
	public ObjectResult executorQuerySql(String sql) throws SQLException ;
	
	/**
	 * 带参数的动态sql
	 * argMap将填充对应key的占位符，像MyBatis
	 * @param sql
	 * @param argMap
	 * @return
	 */
	public ObjectResult executorQuerySql(String sql, Map<String, Object> argMap) throws SQLException;
	
	/**
	 * 执行单条insert和update的静态sql
	 * @param sql
	 * @return
	 */
	public int executorUpdateSql(String sql) throws SQLException ;
	
	/**
	 * 执行多条insert和update的静态sql
	 * @param sqlList
	 * @return
	 */
	public int executorUpdateSql(List<String> sqlList) throws SQLException ;
	
	/**
	 * 执行单行的insert和update的动态sql
	 * @param sql 带#{}或${}的SQL语句
	 * @return
	 */
	public int executorUpdateSql(String sql, Map<String, Object> dataMap) throws SQLException ;
	
	/**
	 * 执行多行的insert和update的动态sql
	 * @param sql 带#{}或${}的SQL语句
	 * @return
	 */
	public int executorUpdateSql(String sql, List<Map<String, Object>> dataMapList) throws SQLException ;
	
	/**
	 * 获得数据库日期的字符串
	 * 只支持oracle
	 * @param dateFormat
	 * @return
	 */
	public String getDatabaseDate(String dateFormat) throws SQLException;
	
	/**
	 * 将给定的多行数据插入到指定的表中
	 * @param tableName 要插入的表名称
	 * @param dataMapList 要插入的多行数据
	 * @param constantColumnMap 常量列Map，如果需要某些列的行都显示固定值，则可使用此Map，此Map的优先级低于totalDataMap，不需要常量列可以传空
	 * @return
	 */
	public int insertData(String tableName, List<Map<String, Object>> dataMapList,  
			Map<String, Object> constantColumnMap) throws SQLException;
	
	/**
	 * 通过给定的表名、参数（where条件）和排序条件来查询所有列
	 * @param tableName 要插入的表名称
	 * @param whereMap where条件的数据，key为列明，value为匹配值。不需要where条件时可以为空。
	 * @param orderMap 排序的Map，key为排序列，value为asc或desc，value为空表示数据库默认的排序方式。不需要排序可以为空。
	 * @return
	 */
	public List<Map<String, Object>> queryByParam(String tableName, Map<String, Object> whereMap,  
			Map<String, String> orderMap) throws SQLException;
	
	/**
	 * 更新表数据
	 * @param tableName 表名，不能为空
	 * @param updateColumnMap 更新的列字段的Map，key为列名，value为要更新的值，不可为空
	 * @param whereMap 更新条件，可以为空
	 * @return
	 */
	public int updateData(String tableName, Map<String, Object> updateColumnMap, 
			Map<String, Object> whereMap) throws SQLException;
	
	/**
	 * 批量更新表数据
	 * @param tableName 表名，不能为空
	 * @param updateColumnMap 更新的列字段的Map，key为列名，value为要更新的值，不可为空
	 * @param whereMapList 更新条件列表，即多个更新条件，可以为空
	 * @return
	 */
	public int updateMultiData(String tableName, Map<String, Object> updateColumnMap, 
			List<Map<String, Object>> whereMapList) throws SQLException;
}
