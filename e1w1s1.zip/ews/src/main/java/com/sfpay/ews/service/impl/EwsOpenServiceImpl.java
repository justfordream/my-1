/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.platform.service.IEwsIndexSqlService;
import com.sfpay.ews.platform.service.IEwsOpenService;
import com.sfpay.ews.support.sql.ISqlExecutor;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：监控预警提供给外部的数据库表操作服务实现类
 *
 * 类描述：这些表必须在EWS_INDEX_SQL表中TABLE_NAME有定义。
 * @author 625288
 *
 * 2015-4-3
 */
@HessianExporter
@Service("ewsOpenService")
public class EwsOpenServiceImpl implements IEwsOpenService {
	private Logger logger = LoggerFactory.getLogger(EwsOpenServiceImpl.class);
	
	@Autowired
	private IEwsIndexSqlService ewsIndexSqlService;
	
	@Autowired
	private ISqlExecutor executor;
	
	@Override
	public int updateData(String tableName, Map<String, Object> updateColumnMap, Map<String, Object> whereMap) {
		logger.info("updateData 【{}】", tableName);
		if(StringUtils.isBlank(tableName)) {
			logger.error("更新数据失败，表名不能为空！");
			throw new ServiceException("更新数据失败，表名不能为空！");
		}
		
		if(updateColumnMap == null || updateColumnMap.isEmpty()) {
			logger.error("更新数据失败，更新列Map不能为空！");
			throw new ServiceException("更新数据失败，更新列Map不能为空！");
		}
		
		// 这些表必须在EWS_INDEX_SQL表中TABLE_NAME有定义。
		checkTableName(tableName);
		
		int updateNum = 0;
		try {
			updateNum = executor.updateData(tableName, updateColumnMap, whereMap);
			
		} catch (SQLException e) {
			logger.error("更新表【{}】数据异常：", tableName, e);
			throw new ServiceException(String.format("更新表【%s】数据异常:【%s】", tableName, e));
		}
		
		
		return updateNum;
	}

	@Override
	public int updateMultiData(String tableName, Map<String, Object> updateColumnMap,
			List<Map<String, Object>> whereMapList) throws ServiceException {
		logger.info("updateMultiData 【{}】", tableName);
		if(StringUtils.isBlank(tableName)) {
			logger.error("批量更新数据失败，表名不能为空！");
			throw new ServiceException("批量更新数据失败，表名不能为空！");
		}
		
		if(updateColumnMap == null || updateColumnMap.isEmpty()) {
			logger.error("批量更新数据失败，更新列Map不能为空！");
			throw new ServiceException("批量更新数据失败，更新列Map不能为空！");
		}
		
		// 这些表必须在EWS_INDEX_SQL表中TABLE_NAME有定义。
		checkTableName(tableName);
		
		int updateNum = 0;
		try {
			updateNum = executor.updateMultiData(tableName, updateColumnMap, whereMapList);
			
		} catch (SQLException e) {
			logger.error("批量更新表【{}】数据异常：", tableName, e);
			throw new ServiceException(String.format("批量更新表【%s】数据异常:【%s】", tableName, e));
		}
		
		
		return updateNum;
	}
	
	/**
	 * 检查表名是否在EWS_INDEX_SQL中出现过
	 * @param tableName
	 */
	private void checkTableName(String tableName) {
		Set<String> tableNameSet = ewsIndexSqlService.queryAllTableName();
		if(tableNameSet == null || tableNameSet.isEmpty() || !tableNameSet.contains(tableName)) {
			logger.error("指标SQL定义中不存在表【{}】", tableName);
			throw new ServiceException(String.format("指标SQL定义中不存在表【%s】", tableName));
		}
	}

}
