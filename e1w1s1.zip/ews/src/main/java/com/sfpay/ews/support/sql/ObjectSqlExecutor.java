/**
 * 
 */
package com.sfpay.ews.support.sql;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.support.spring.SfpaySqlFactoryBean;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：SQL语句执行器
 * 
 * 类描述：线程安全
 * 
 * @author manzhizhen
 * 
 *         2015年2月20日
 */
@Service("sqlExecutor")
public class ObjectSqlExecutor implements ISqlExecutor {
	Logger logger = LoggerFactory.getLogger(ObjectSqlExecutor.class);

	@Autowired
	private SfpaySqlFactoryBean sfpaySqlFactoryBean;
	
	@Override
	public ObjectResult executorQuerySql(String sql) throws SQLException {
		if (StringUtils.isBlank(sql)) {
			throw new IllegalArgumentException("Sql语句不能为空！");
		}

		logger.debug(String.format("将要执行的SQL：【%s】", sql));
		

		// 将SQL语句变成大写
		// sql = sqlToUpper(sql);
		// logger.info(String.format("格式化后的SQL：%s", sql));
		sql = sql.trim();

		Statement statement = null;
		ResultSet resultSet = null;
		Connection connection = null;
		ObjectResult resultObject = null;
		try {
			connection = sfpaySqlFactoryBean.getConnection();
			statement = connection.createStatement();
			resultObject = new ObjectResult();

			// 查询语句
			if ("select".equalsIgnoreCase(sql.split("\\s")[0])) {
				long start = System.currentTimeMillis();
				resultSet = statement.executeQuery(sql);
				logger.info(String.format("SQL执行时间为：%s(秒)",
						(System.currentTimeMillis() - start + 0.0d) / 1000));
				ResultSetMetaData rsmd = resultSet.getMetaData();
				int numberOfColumns = rsmd.getColumnCount();

				List<Map<String, Object>> objectMap = new ArrayList<Map<String, Object>>();
				Map<String, Object> map = null;
				while (resultSet.next()) {
					map = new LinkedHashMap<String, Object>();
					for (int i = 1; i <= numberOfColumns; i++) {
						// map.put(getClazzStr(rsmd.getColumnLabel(i)),
						// getJavaObject(resultSet, rsmd, i));
						map.put(rsmd.getColumnLabel(i), getJavaObject(resultSet, rsmd, i));
					}

					objectMap.add(map);
				}

				// 设置结果集对象
				if (!objectMap.isEmpty()) {
					resultObject.setObjectMapList(objectMap);
				}
				
			} else {
				logger.error(String.format("SQL语句【%s】不是以select开头！", sql));
				throw new ServiceException(String.format("SQL语句【%s】不是以select开头！", sql));
			}
		} finally {
			if(resultSet != null) {
				try {
					resultSet.close();
				} catch (Exception e) {
				}
			}
			
			if (statement != null) {
				try {
					statement.close();
				} catch (Exception e) {
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
				}
			}
		}

		return resultObject;
	}

	@Override
	public ObjectResult executorQuerySql(String sql, Map<String, Object> argsMap)
			throws SQLException {
		if (StringUtils.isBlank(sql)) {
			throw new IllegalArgumentException("Sql语句为空！");
		}

		if (argsMap != null) {
			sql = sqlBuilder(sql, argsMap);
		}

		return executorQuerySql(sql);
	}

	@Override
	public int executorUpdateSql(String sql) throws SQLException {
		if (StringUtils.isBlank(sql)) {
			throw new IllegalArgumentException("要执行的Sql语句不能为空！");
		}
		
		logger.debug(String.format("将要执行的SQL：【%s】", sql));

		sql = sql.trim();

		Statement statement = null;
		Connection connection = null;
		int resultNum = 0;
		try {
			connection = sfpaySqlFactoryBean.getConnection();
			statement = connection.createStatement();

			String startStr = sql.split("\\s")[0];
			if ("insert".equalsIgnoreCase(startStr) || "update".equalsIgnoreCase(startStr)) {
				long start = System.currentTimeMillis();
				resultNum = statement.executeUpdate(sql);
				
				connection.commit();
	
				logger.info(String.format("SQL执行时间为：%s(秒)",
						(System.currentTimeMillis() - start + 0.0d) / 1000));
			}
			
		} catch (SQLException e) {
			if(connection != null) {
				try {
					connection.rollback();
				} catch (Exception e1) {
				}
			}
			throw e;
			
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (Exception e) {
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
				}
			}
		}

		return resultNum;
	}

	@Override
	public int executorUpdateSql(List<String> sqlList) throws SQLException {
		if (sqlList == null || sqlList.isEmpty()) {
			throw new IllegalArgumentException("要执行的Sql语句不能为空！");
		}

		int resultNum = 0;
		Statement statement = null;
		long start = System.currentTimeMillis();
		Connection connection = sfpaySqlFactoryBean.getConnection();
		statement = connection.createStatement();
		try {
			for (String sql : sqlList) {
				sql = sql.trim();
	
				String startStr = sql.split("\\s")[0];
				if ("insert".equalsIgnoreCase(startStr) || "update".equalsIgnoreCase(startStr)) {
					statement.addBatch(sql);
				} else {
					logger.error("SQL语句非更新或新增语句：【{}】", sql);
				}
			}
			
			int[] results = statement.executeBatch();
			if(results != null) {
				for(int i : results) {
					resultNum += i;
				}
			}
			
			logger.info(String.format("SQL执行时间为：%s(秒)",
					(System.currentTimeMillis() - start + 0.0d) / 1000));
			
			connection.commit();
		} catch (SQLException e) {
			if(connection != null) {
				try {
					connection.rollback();
				} catch (Exception e1) {
				}
			}
			throw e;
			
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (Exception e) {
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
				}
			}
		}
		
		return resultNum;
	}

	@Override
	public int executorUpdateSql(String sql, Map<String, Object> dataMap) throws SQLException {
		if (StringUtils.isBlank(sql)) {
			throw new IllegalArgumentException("要执行的Sql语句为空！");
		}

		if (dataMap != null) {
			sql = sqlBuilder(sql, dataMap);
		}

		return executorUpdateSql(sql);
	}

	@Override
	public int executorUpdateSql(String sql,
			List<Map<String, Object>> dataMapList) throws SQLException {
		if (StringUtils.isBlank(sql)) {
			throw new IllegalArgumentException("要执行的Sql语句为空！");
		}
		
		Connection connection = null;
		Statement statement = null;
		if(dataMapList != null && !dataMapList.isEmpty()) {
			try {
				connection = sfpaySqlFactoryBean.getConnection();
				statement = connection.createStatement();
				int resultNum = 0;
				for(Map<String, Object> map : dataMapList) {
					statement.addBatch(sqlBuilder(sql, map));
				}
				
				int[] totals = statement.executeBatch();
				if(totals != null) {
					for(int i : totals) {
						resultNum += i;
					}
				}
				
				if (!connection.getAutoCommit()) {
					connection.commit();
				}
				
				return resultNum;
				
			} catch (SQLException e) {
				if(connection != null) {
					try {
						connection.rollback();
					} catch (Exception e1) {
					}
				}
				
				throw e;
				
			} finally {
				if(statement != null) {
					try {
						statement.close();
					} catch (Exception e) {
					}
				}
				
				if(connection != null) {
					try {
						connection.close();
					} catch (Exception e) {
					}
				}
			}
			
		} else {
			return executorUpdateSql(sql);
		}
	}

	/**
	 * 构建Sql
	 * @param sql
	 * @param argsMap
	 * @return
	 */
	private String sqlBuilder(String sql, Map<String, Object> argsMap) {
		// 先处理#{}
		int index = 0;
		String label = null, key = null;
		Object value = null;

		while (true) {
			index = sql.indexOf("#{", index);
			if (index < 0) {
				break;
			}

			// 获取${}中的值
			try {
				label = sql.substring(index, sql.indexOf("}", index + 1) + 1);
				key = label.substring(2, label.length() - 1);
				if (StringUtils.isBlank(key)) {
					throw new Exception("占位符为空！");
				}
			} catch (Exception e) {
				throw new IllegalArgumentException("Sql语句参数占位符格式错误！");
			}

			key = key.trim();
			value = argsMap.get(key);
			if (value == null) {
				throw new IllegalArgumentException(String.format(
						"参数Map中不包含key：" + "【%s】,或value为空！", key));
			}

			sql = sql.replaceAll(label.replace("{", "\\{").replace("}", "\\}"), switchLabel(value));
			index++;
		}

		// 再处理${}
		index = 0;
		while (true) {
			index = sql.indexOf("${", index);
			if (index < 0) {
				break;
			}

			// 获取${}中的值
			try {
				label = sql.substring(index, sql.indexOf("}", index + 1) + 1);
				key = label.substring(2, label.length() - 1);
				if (StringUtils.isBlank(key)) {
					throw new Exception("占位符为空！");
				}
			} catch (Exception e) {
				throw new IllegalArgumentException("Sql语句参数占位符格式错误！");
			}

			key = key.trim();
			value = argsMap.get(key);
			if (value == null) {
				throw new IllegalArgumentException(String.format(
						"参数Map中不包含key：" + "【%s】,或value为空！", key));
			}

			sql = sql.replaceAll(
					label.replace("$", "\\$").replace("{", "\\{").replace("}", "\\}"),
					String.valueOf(value).replace("$", "\\$").replace("{", "\\{")
							.replace("}", "\\}"));
			index++;
		}

		return sql;
	}

	/**
	 * 把sql字段名称变成java的属性名称
	 * @param sqlName
	 * @return
	 */
	@SuppressWarnings("unused")
	private String getClazzStr(String sqlName) {
		if (StringUtils.isBlank(sqlName)) {
			return "";
		}

		if (!sqlName.contains("_")) {
			return sqlName.toLowerCase();
		}

		StringBuilder result = new StringBuilder();
		String[] arrayStr = sqlName.split("_");
		for (String str : arrayStr) {
			result.append(str.toUpperCase().charAt(0) + str.toLowerCase().substring(1));
		}

		return result.toString();
	}

	/**
	 * 根据数据库字段类型来获取java类型
	 * 
	 * @param resultSet
	 * @param rsmd
	 * @param columnIndex
	 * @return
	 * @throws SQLException
	 */
	private Object getJavaObject(ResultSet resultSet, ResultSetMetaData rsmd, int columnIndex)
			throws SQLException {
		String columnTypeName = rsmd.getColumnTypeName(columnIndex).toUpperCase();

		if (columnTypeName.contains("CHAR")) {
			return resultSet.getString(columnIndex);

		} else if (columnTypeName.contains("INT") && !columnTypeName.contains("BIG")) {
			return resultSet.getInt(columnIndex);

		} else if (columnTypeName.contains("BIG")) {
			return resultSet.getLong(columnIndex);

		} else if (columnTypeName.contains("NUMBER") && !columnTypeName.contains(",")) {
			int leftIndex = columnTypeName.indexOf("(");
			if (leftIndex < 0) {
				return resultSet.getLong(columnIndex);
			}

			int length = Integer.valueOf(columnTypeName.substring(leftIndex + 1,
					columnTypeName.indexOf(")")));
			if (length <= 9) {
				return resultSet.getInt(columnIndex);
			} else {
				return resultSet.getLong(columnIndex);
			}

		} else if ((columnTypeName.contains("NUMBER") && columnTypeName.contains(","))
				|| columnTypeName.contains("DECIMAL")) {
			return resultSet.getDouble(columnIndex);

		} else if (columnTypeName.contains("DATE") || columnTypeName.contains("TIMESTAMP")) {
			return new Date(resultSet.getTimestamp(columnIndex).getTime());
		}

		throw new IllegalArgumentException("无法转换的列类型名称：" + columnTypeName);
	}

	private String switchLabel(Object value) {
		if (value instanceof String || value instanceof Character || value.getClass() == char.class) {
			return String.format("'%s'", value);

		} else if (value.getClass() == short.class || value.getClass() == int.class
				|| value.getClass() == long.class || value.getClass() == float.class
				|| value.getClass() == double.class || value instanceof Short
				|| value instanceof Integer || value instanceof Long || value instanceof Float
				|| value instanceof Double) {
			return String.valueOf(value);

		} else {
			System.err.println("e ... ...");
		}

		return "";
	}

	@Override
	public String getDatabaseDate(String dateFormat) throws SQLException {
		if (StringUtils.isBlank(dateFormat)) {
			dateFormat = "yyyy-mm-dd hh24:mi:ss";
		}

		String sql = String.format("select to_char(sysdate, '%s') current_date from dual",
				dateFormat);

		return (String) executorQuerySql(sql).getOne();
	}

	@Override
	public int insertData(String tableName, List<Map<String, Object>> dataMapList, 
			Map<String, Object> constantColumnMap) throws SQLException {
		if(dataMapList == null || dataMapList.isEmpty() || StringUtils.isBlank(tableName)) {
			throw new IllegalArgumentException("要插入的数据或表名称不能为空！");
		}
		
		// 检查连接状态
//		checkConnection();
		
		Connection connection = null;
		try {
			connection = sfpaySqlFactoryBean.getConnection();
			
			// 获取数据库信息
			DatabaseMetaData dbmd = connection.getMetaData(); 
			// 获取表格所有列信息
			ResultSet resultSet = dbmd.getColumns(connection.getCatalog(), 
					null, tableName.toUpperCase(), null);
			Set<String> otherColumnSet = new HashSet<String>(); // 非主键列的所有可空列
			
			TableBean tableBean = new TableBean();
			tableBean.setTableName(tableName.toUpperCase());
			ColumnBean columnBean = null;
			while(resultSet.next()) {
				columnBean = new ColumnBean();
				columnBean.setColumnName(resultSet.getString("COLUMN_NAME"));
				columnBean.setTableName(tableName.toUpperCase());
				columnBean.setDataType(resultSet.getInt("DATA_TYPE"));
				columnBean.setTypeName(resultSet.getString("TYPE_NAME"));
				columnBean.setColumnDef(resultSet.getString("COLUMN_DEF"));
				columnBean.setColumnSize(resultSet.getInt("COLUMN_SIZE"));
				columnBean.setDecimalDigits(resultSet.getInt("DECIMAL_DIGITS"));
				columnBean.setCanNull(resultSet.getInt("NULLABLE") == 1 ? true : false);
//			columnBean.setAutoIncrement("YES".equals(resultSet.getString("IS_AUTOINCREMENT")) ? true : false);
				
				tableBean.getColumnMap().put(columnBean.getColumnName(), columnBean);
				// 将可以为空的或有默认值的放入该Map中
				if(!columnBean.isCanNull() && columnBean.getColumnDef() == null) {
					otherColumnSet.add(columnBean.getColumnName());
				}
			}
			
			if(tableBean.getColumnMap().isEmpty()) {
				logger.error("数据库表【{}】不存在！", tableBean.getTableName());
				throw new IllegalArgumentException(String.format("数据库表【%s】不存在！", tableBean.getTableName()));
			}
			
			try {
				resultSet.close();
			} catch (Exception e) {
			}
			
			// 获取主键列
			resultSet = dbmd.getPrimaryKeys(connection.getCatalog(), 
					null, tableName.toUpperCase());
			Map<Short, String> primaryKeySet = new TreeMap<Short, String>();
			while(resultSet.next()) {
				if(!tableBean.getColumnMap().containsKey(resultSet.getString("COLUMN_NAME"))) {
					throw new IllegalStateException(String.format("主键列【%s】在表【%s】的所有列中不存在！", 
							new Object[]{resultSet.getString("COLUMN_NAME"), tableBean.getTableName()}));
				}
				
				primaryKeySet.put(resultSet.getShort("KEY_SEQ"), resultSet.getString("COLUMN_NAME"));
				otherColumnSet.remove(resultSet.getString("COLUMN_NAME"));
			}
			
			try {
				resultSet.close();
			} catch (Exception e) {
			}
			
			tableBean.getPrimaryKeyColumnSet().addAll(primaryKeySet.values());
			
			if(constantColumnMap != null) {
				switchKeyToUpper(constantColumnMap);
			}
			
			// 遍历插入数据
			List<String> executorSqlList = new ArrayList<String>(dataMapList.size());
			Map<String, String> columnValueMap = new LinkedHashMap<String, String>();
			for(Map<String, Object> dataMap : dataMapList) {
				switchKeyToUpper(dataMap);
				
				// 将常量Map补充到数据Map中，但不覆盖
				if(constantColumnMap != null) {
					for(Entry<String, Object> entry : constantColumnMap.entrySet()) {
						if(!dataMap.containsKey(entry.getKey())) {
							dataMap.put(entry.getKey(), entry.getValue());
						}
//					dataMap.putAll(constantColumnMap);
					}
				}
				
				// 如果包含该表的最小可插入列集，则认为该Map是可插入的
				if(dataMap.keySet().containsAll(otherColumnSet)) {
					for(Map.Entry<String, ColumnBean> entry : tableBean.getColumnMap().entrySet()) {
						if(entry.getValue().isAutoIncrement()) {
							continue ;
							
						} else if(dataMap.containsKey(entry.getKey())) {
							columnValueMap.put(entry.getKey(), switchValueToStr(dataMap.get(entry.getKey()), 
									entry.getValue().getDataType()));
							
						} else if(entry.getValue().isCanNull() || entry.getValue().getColumnDef() != null) {
							continue ;
						// 这里默认是序列	
						} else if(entry.getKey().equalsIgnoreCase("ID")) {
							columnValueMap.put(entry.getKey(), "SEQ_" + tableBean.getTableName() + ".nextval");
							
						} else {
							logger.error("数据库表【{}】中列【{}】无法赋值，插入数据失败！", 
									new Object[]{tableBean.getTableName(), entry.getKey()});
							throw new IllegalArgumentException(String.format("数据库表【%s】中列【%s】无法赋值，插入数据失败！", 
									new Object[]{tableBean.getTableName(), entry.getKey()}));
						}
					}
					
					if(columnValueMap.isEmpty()) {
						logger.warn(String.format("数据【%s】没有获取到需要插入到表【%s】的值！", 
								new Object[]{dataMap, tableBean.getTableName()}));
						continue ;
					}
					
					// 构建insert语句
					StringBuilder sql = new StringBuilder();
					sql.append(String.format("insert into %s(", tableBean.getTableName()));
					for(int i = 0; i < columnValueMap.size(); i++) {
						sql.append("%s, ");
					}
					sql.delete(sql.lastIndexOf(", "), sql.length());
					sql.append(") values(");
					for(int i = 0; i < columnValueMap.size(); i++) {
						sql.append("%s, ");
					}
					sql.delete(sql.lastIndexOf(", "), sql.length());
					sql.append(")");
					
					Object[] objs = new Object[columnValueMap.size() * 2];
					int index = 0;
					for(String columnName : columnValueMap.keySet()) {
						objs[index++] = columnName;
					}
					for(String value : columnValueMap.values()) {
						objs[index++] = value;
					}
					executorSqlList.add(String.format(sql.toString(), objs));
				}
			}
			
			if(executorSqlList.isEmpty()) {
				logger.info("数据Map中没有符合表【{}】的数据！", tableBean.getTableName());
				return 0;
			}
			
			// 开始执行sql
			int insertNum = executorUpdateSql(executorSqlList);
			
			logger.info("成功向表【{}】插入【{}】条数据！", new Object[]{tableBean.getTableName(), insertNum});
			
			return insertNum;
			
		} catch (SQLException e) {
			if(connection != null) {
				try {
					connection.rollback();
				} catch (Exception e1) {
				}
			}
			
			throw e;
			
		} finally {
			if(connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
				}
			}
		}
	}
	
	/**
	 * 将Map中的Key值全变成大写
	 * @param map
	 */
	private void switchKeyToUpper(Map<String, Object> map) {
		if(map == null || map.isEmpty()) {
			return ;
		}
		
		List<String> removeList = new ArrayList<String>();
		Map<String, Object> addMap = new HashMap<String, Object>();
		for(Map.Entry<String, Object> entry : map.entrySet()) {
			if(!StringUtils.equals(entry.getKey().toUpperCase(), entry.getKey())) {
				removeList.add(entry.getKey());
				addMap.put(entry.getKey().toUpperCase(), entry.getValue());
			}
		}
		
		for(String key : removeList) {
			map.remove(key);
		}
		map.putAll(addMap);
	}
	
	/**
	 * 根据jdbc中的type类型将Object对象转化成在sql语句中的字符串形式（带单引号或不带单引号）
	 * @param value
	 * @param dataType java.sql.Types
	 * @return
	 */
	private String switchValueToStr(Object value, int dataType) {
		if(Types.BIGINT == dataType || Types.BLOB == dataType || Types.DECIMAL == dataType || 
				Types.DOUBLE == dataType || Types.FLOAT == dataType || Types.INTEGER == dataType || 
				Types.TINYINT == dataType || Types.SMALLINT == dataType || Types.NUMERIC == dataType) {
			return String.valueOf(value == null ? 0 : value);
			
		} else if(Types.VARCHAR == dataType || Types.NVARCHAR == dataType || Types.CHAR == dataType 
				|| Types.NCHAR == dataType || Types.LONGNVARCHAR == dataType || Types.LONGVARCHAR == dataType 
				|| Types.CLOB == dataType){
			return value == null ? "null" : String.format("'%s'", String.valueOf(value));
			
		} else if(Types.DATE == dataType || Types.TIME == dataType || Types.TIMESTAMP == dataType){
			return String.format("'%s'", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(value));
			
		} else {
			throw new IllegalArgumentException(String.format("不支持的java.sql.Types：【%s】", dataType));
		}
	}
	
	/**
	 * 根据Object类型来转化成sql语句中的字符串形式（带单引号或不带单引号）
	 * @param value
	 * @return
	 */
	private String switchValueToStr(Object value) {
		if(value == null) {
			return "null";
			
		} else if(value instanceof String || value instanceof Character) {
			return String.format("'%s'", value);
			
		} else if(value instanceof Short || value instanceof Integer || value instanceof Long
				|| value instanceof Float || value instanceof Double) {
			return String.valueOf(value);
			
		} else if(value instanceof Date || value instanceof java.sql.Date) {
			return String.format("'%s'", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(value));
			
		} else {
			throw new IllegalArgumentException(String.format("不支持的数据类型：【%s】", value.getClass().getName()));
		}
	}

	@Override
	public List<Map<String, Object>> queryByParam(String tableName, Map<String, Object> whereMap, 
			Map<String, String> orderMap) throws SQLException {
		if(StringUtils.isBlank(tableName)) {
			logger.error("表名不能为空！");
			throw new IllegalArgumentException("表名不能为空！");
		}
		
		StringBuilder querySql = new StringBuilder("select * from ");
		querySql.append(tableName);
		
		if(whereMap != null && !whereMap.isEmpty()) {
			// 组装where语句
			querySql.append(" where ");
			for(Map.Entry<String, Object> entry : whereMap.entrySet()) {
				querySql.append(entry.getKey() + " = ");
				
				querySql.append(switchValueToStr(entry.getValue()) + " ");
				
				querySql.append("and ");
			}
			
			// 去掉末尾的"and "
			querySql.delete(querySql.lastIndexOf("and "), querySql.length());
		}
		
		if(orderMap != null && !orderMap.isEmpty()) {
			// 组装order by语句
			querySql.append(" order by ");
			for(Map.Entry<String, String> entry : orderMap.entrySet()) {
				querySql.append(entry.getKey());
				
				if(StringUtils.isNotEmpty(entry.getValue())) {
					querySql.append(" " + entry.getValue());
				}
				querySql.append(", ");
			}
			
			// 去掉末尾的", "
			querySql.delete(querySql.lastIndexOf(", "), querySql.length());
		}
		
		
		return executorQuerySql(querySql.toString()).get();
	}

	/**
	 * 更新表数据
	 * @param tableName 表名，不能为空
	 * @param updateColumnMap 更新的列字段的Map，key为列名，value为要更新的值，不可为空
	 * @param whereMap 更新条件，可以为空
	 * @return
	 * @throws SQLException 
	 */
	@Override
	public int updateData(String tableName, Map<String, Object> updateColumnMap, Map<String, Object> whereMap) throws SQLException {
		String sql = builderUpdateSql(tableName, updateColumnMap, whereMap);
		
		return executorUpdateSql(sql.toString());
	}
	
	@Override
	public int updateMultiData(String tableName, Map<String, Object> updateColumnMap,
			List<Map<String, Object>> whereMapList) throws SQLException {
		if(whereMapList == null || whereMapList.isEmpty()) {
			return updateData(tableName, updateColumnMap, null);
			
		} else {
			int updateNum = 0;
			Connection connection = null;
			Statement statement = null;
			try {
				connection = sfpaySqlFactoryBean.getConnection();
				
				statement = connection.createStatement();
				for(Map<String, Object> map : whereMapList) {
					statement.addBatch(builderUpdateSql(tableName, updateColumnMap, map));
				}
				
				int[] totals = statement.executeBatch();
				
				for(int i : totals) {
					updateNum += i;
				}
				
				connection.commit();
				
				return updateNum;
			} catch (Exception e) {
				logger.error("更新表【{}】数据异常：", tableName, e);
				if(connection != null) {
					try {
						connection.rollback();
					} catch (Exception e1) {
					}
				}
				throw new SQLException(String.format("更新表【%s】数据异常：", tableName), e);
				
			} finally {
				if(statement != null) {
					try {
						statement.close();
					} catch (Exception e) {
					}
				}
				
				if(connection != null) {
					try {
						connection.close();
					} catch (Exception e) {
					}
				}
			}
		}
	}
	
	private String builderUpdateSql(String tableName, Map<String, Object> updateColumnMap, Map<String, Object> whereMap) {
		if(StringUtils.isBlank(tableName)) {
			logger.error("表名不能为空！");
			throw new IllegalArgumentException("表名不能为空！");
		}
		
		if(updateColumnMap == null || updateColumnMap.isEmpty()) {
			logger.error("需要更新的列数据Map不能为空！");
			throw new IllegalArgumentException("需要更新的列数据Map不能为空！");
		}
		
		// 构造成有占位符的SQL语句
		StringBuilder sql = new StringBuilder("update " );
		sql.append(tableName);
		sql.append(" set ");
		for(Map.Entry<String, Object> entry : updateColumnMap.entrySet()) {
			sql.append(String.format("%s = %s, ", entry.getKey(), switchValueToStr(entry.getValue())));
		}
		// 去掉末尾的", "
		sql.delete(sql.lastIndexOf(", "), sql.length());
		
		if(whereMap != null) {
			sql.append(" where ");
			for(Map.Entry<String, Object> entry : whereMap.entrySet()) {
				sql.append(String.format("%s = %s and ", entry.getKey(), switchValueToStr(entry.getValue())));
			}
			
			// 去掉末尾的" and "
			sql.delete(sql.lastIndexOf(" and "), sql.length());
		}
		
		return sql.toString();
	}
}
