/**
 * 
 */
package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsGroupEmp;

/**
 * 预警群组与通知人员映射DAO
 * 
 * @author 321566
 * 
 */
public interface IEwsGroupEmpDao {

	/**
	 * 插入预警通知记录
	 * 
	 * @param emp
	 * @return
	 */
	public int insertEwsGroupEmp(EwsGroupEmp emp);

	/**
	 * 查询预警通知总记录数
	 * 
	 * @param emp
	 * @param index
	 * @param size
	 * @return
	 */
	public int selectGroupEmpCount(@Param("param") EwsGroupEmp emp);

	/**
	 * 分页查询预警记录
	 * 
	 * @param emp
	 * @param index
	 * @param size
	 * @return
	 */
	public List<EwsGroupEmp> selectGroupEmpByPage(
			@Param("param") EwsGroupEmp emp, @Param("index") int index,
			@Param("size") int size);

	/**
	 * 根据工号查询预警通知
	 * 
	 * @param empId
	 * @return
	 */
	public EwsGroupEmp selectGroupEmpByEmpId(@Param("empId") String empId);

	/**
	 * 修改预警通知
	 * 
	 * @param emp
	 * @return
	 */
	public int updateWarnGroupEmp(EwsGroupEmp emp);

	/**
	 * 根据指标代码找出对应的有效人员;
	 * 
	 * @param indexNo
	 * @return
	 */
	public List<EwsGroupEmp> queryNotifyEmpByIndexNo(
			@Param("indexNo") String indexNo);

}
