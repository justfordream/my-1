package com.sfpay.ews.service.impl;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.sfpay.ews.service.ISenderMailService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 工具类，调用邮件的服务;日志记录在调用端
 * 
 * @author 575740
 * 
 */
@Service("sendMailService")
public class SendMailServiceImpl implements ISenderMailService {

	private static Logger logger = LoggerFactory
			.getLogger(SendMailServiceImpl.class);

	@Resource
	private MailSender mailSender;
	@Resource
	private SimpleMailMessage mail;

	private static ExecutorService threadPoolExecutor = Executors
			.newFixedThreadPool(10);

	/**
	 * 
	 * 
	 * 方法说明：发送文本邮件
	 * 
	 * @param mTo
	 *            收件人
	 * @throws MailException
	 */
	@Override
	public void sendMail(String eMail, String userName, String passWord)
			throws ServiceException {
		JavaMailSender sender = (JavaMailSender) mailSender;
		// 发送人从配置文件中读取
		mail.setFrom(mail.getFrom());
		// 接收人
		mail.setTo(eMail);
		mail.setSubject(mail.getSubject());
		mail.setText("账号：" + userName + "\n" + "密码：" + passWord);
		try {
			sender.send(mail);
		} catch (MailException e) {
			throw new ServiceException("Mail timeout!");
		}

	}

	@Override
	public void sendOutMail(String eMail, String code, String head) {
		// 运行任务
		threadPoolExecutor.execute(createTask(eMail, code, head));

	}

	@Override
	public void sendHTMLMail(final String to, final String subject,
			final String text) throws ServiceException {
		threadPoolExecutor.execute(new Runnable() {
			@Override
			public void run() {
				JavaMailSenderImpl senderImpl = (JavaMailSenderImpl) mailSender;
				MimeMessage mailMessage = senderImpl.createMimeMessage();
				MimeMessageHelper messageHelper;
				try {
					messageHelper = new MimeMessageHelper(mailMessage, true,
							"utf-8");
					messageHelper.setFrom(mail.getFrom());
					messageHelper.setTo(to);// 接受者
					messageHelper.setSubject(subject);// 主题
					messageHelper.setText(text, true);
					senderImpl.send(mailMessage);
					logger.info("发送邮件完毕, TO:" + to + ",subject:" + subject
							+ ",text:" + text + ",message:" + mailMessage);
				} catch (MessagingException e) {
					logger.error("发送邮件失败！");
				}
			}
		});
	}

	private Runnable createTask(final String eMail, final String code,
			final String head) {
		return new Runnable() {
			public void run() {
				JavaMailSender sender = (JavaMailSender) mailSender;
				// 发送人从配置文件中读取
				mail.setFrom(mail.getFrom());
				// 接收人
				mail.setTo(eMail);
				if (null != head) {
					mail.setSubject(head);
				} else {
					mail.setSubject(mail.getSubject());
				}
				mail.setText(code);
				sender.send(mail);
			}
		};
	}

}
