package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsOprRecord;

/**
 * 
 *	类：操作记录表DAO
 *	类描述：操作记录表DAO
 *
 * @author 544772
 * @version 2015年3月30日 下午5:25:47
 */
public interface IEwsOprRecordDao {
	
	/**
	 * 
	 * 方法：增加操作记录
	 * 方法说明：
	 *
	 * @param ewsOprRecord
	 */
	public void addEwsOprRecord(EwsOprRecord ewsOprRecord);
	
	/**
	 * 
	 * 方法：更新操作记录
	 * 方法说明：
	 *
	 * @param ewsOprRecord
	 */
	public void updateEwsOprRecord(EwsOprRecord ewsOprRecord);
	
	/**
	 * 
	 * 方法：通过主键ID删除操作记录
	 * 方法说明：
	 *
	 * @param id
	 */
	public void delEwsOprRecord(@Param("id")String id);
	
	/**
	 * 
	 * 方法：通过主键ID查询操作记录
	 * 方法说明：
	 *
	 * @param id
	 * @return
	 */
	public EwsOprRecord queryById(@Param("id")String id);
	
	/**
	 * 
	 * 方法：通过指标记录编号查询操作记录
	 * 方法说明：
	 *
	 * @param warnInfoRecordId
	 * @return
	 */
	public List<EwsOprRecord> queryEwsOprRecordByWarnInfoRecordId(@Param("warnInfoRecordId")String warnInfoRecordId);
	
}
