/**
 * 
 */
package com.sfpay.ews.support.service.impl;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.stereotype.Service;

import bsh.EvalError;
import bsh.Interpreter;

import com.sfpay.ews.service.IBeanShellService;

/**
 * 类说明：BeanShell服务实现类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-27
 */
@Service("beanShellService")
public class BeanShellServiceImpl implements IBeanShellService{
	
	public void executeShell(String warnIndexNo) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader("d://shell.txt"));
			StringBuilder shell = new StringBuilder();
			String line = null;
			while((line = reader.readLine()) != null) {
				shell.append(line + System.getProperty("line.separator"));
			}
			
			System.out.println(shell);
			
			Interpreter interpreter = new Interpreter();
			interpreter.set("warnIndexNo", warnIndexNo);
			interpreter.eval(shell.toString());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (EvalError e) {
			e.printStackTrace();
		}
	}
}
