package com.sfpay.ews.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsEmpGroupReferDao;
import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.ews.platform.service.IEwsEmpGroupReferService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

@HessianExporter
@Service("ewsEmpGroupReferService")
public class EwsEmpGroupReferServiceImpl implements IEwsEmpGroupReferService {

	private static Logger logger = LoggerFactory.getLogger(EwsEmpGroupReferServiceImpl.class);

	@Resource
	private IEwsEmpGroupReferDao ewsEmpGroupReferDao;

	@Override
	public void addEwsEmpGroupRefer(EwsEmpGroupRefer ewsEmpGroupRefer) throws ServiceException {
		try {
			logger.info("新增预警人员与指标组对应记录：" + ewsEmpGroupRefer);
			StringBuilder warnMsg = checkValue(ewsEmpGroupRefer);
			if (!StringUtils.isBlank(warnMsg)) {
				throw new ServiceException(warnMsg.toString());
			} else {
				ewsEmpGroupReferDao.addEwsEmpGroupRefer(ewsEmpGroupRefer);
				logger.info("新增预警人员与指标组对应记录结束");
			}
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("新增预警人员与指标组对应记录错误 ", e);
			throw new ServiceException("新增预警人员与指标组对应记录错误", e);
		}
	}

	@Override
	public void updateEwsEmpGroupRefer(EwsEmpGroupRefer ewsEmpGroupRefer) throws ServiceException {
		try {
			logger.info("更新预警人员与指标组对应记录：" + ewsEmpGroupRefer);
			StringBuilder warnMsg = checkValue(ewsEmpGroupRefer);
			if (!StringUtils.isBlank(warnMsg)) {
				throw new ServiceException(warnMsg.toString());
			}
			ewsEmpGroupReferDao.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
			logger.info("更新预警人员与指标组对应记录结束");
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("更新预警人员与指标组对应记录错误 ", e);
			throw new ServiceException("更新预警人员与指标组对应记录错误", e);
		}
	}

	@Override
	public void delEwsEmpGroupRefer(String id) throws ServiceException {
		try {
			ewsEmpGroupReferDao.delEwsEmpGroupRefer(id);
		} catch (Exception e) {
			logger.error("删除人员群组关系出错"+e.getMessage());
			throw new ServiceException("删除人员群组关系出错");
		}
	}

	@Override
	public List<EwsEmpGroupRefer> queryEwsEmpGroupReferByParam(EwsEmpGroupRefer ewsEmpGroupRefer)
			throws ServiceException {
		try {
			return ewsEmpGroupReferDao.queryEwsEmpGroupReferByParam(ewsEmpGroupRefer);
		} catch (Exception e) {
			logger.error("查询预警人员与指标组对应记录错误 ", e);
			throw new ServiceException("查询预警人员与指标组对应记录错误", e);
		}
	}

	@Override
	public List<EwsEmpGroupRefer> queryEmpGroupInfoByIndexNo(String warIndexNo) throws ServiceException {
		try {
			return ewsEmpGroupReferDao.queryEmpGroupInfoByIndexNo(warIndexNo);
		} catch (Exception e) {
			logger.error("根据指标编号查询预警人员的信息出错 ", e);
			throw new ServiceException("根据指标编号查询预警人员的信息出错", e);
		}
	}

	private StringBuilder checkValue(EwsEmpGroupRefer ewsEmpGroupRefer) {
		StringBuilder string = new StringBuilder();

		if (StringUtils.isBlank(ewsEmpGroupRefer.getEmpId())) {
			string.append("预警用户ID为空;");
		}

		if (StringUtils.isBlank(ewsEmpGroupRefer.getGroupNo())) {
			string.append("指标组ID为空;");
		}

		if (StringUtils.isBlank(ewsEmpGroupRefer.getIsSmsNotify())) {
			string.append("短信标志为空;");
		}

		if (StringUtils.isBlank(ewsEmpGroupRefer.getIsMailNotify())) {
			string.append("邮件标志为空");
		}
		return string;
	}
}
