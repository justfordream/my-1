package com.sfpay.ews.support.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsIndexParam;
import com.sfpay.ews.platform.domain.EwsIndexSql;
import com.sfpay.ews.platform.domain.EwsRule;
import com.sfpay.ews.platform.sch.service.IEwsTaskService;
import com.sfpay.ews.platform.service.IEwsEmpGroupReferService;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsIndexParamService;
import com.sfpay.ews.platform.service.IEwsIndexSqlService;
import com.sfpay.ews.platform.service.IEwsInfoRecordService;
import com.sfpay.ews.platform.service.IEwsRuleService;
import com.sfpay.ews.service.IEwsSendMailAndSmsService;
import com.sfpay.ews.support.sql.ISqlExecutor;
import com.sfpay.ews.support.sql.ObjectResult;
import com.sfpay.ews.util.ParamStrUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 监控预警主服务类
 * @author 625288
 *
 */
@HessianExporter
@Service("ewsTaskService")
public class EwsTaskServiceImpl implements IEwsTaskService{
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	@Autowired
	private IEwsIndexSqlService ewsIndexSqlService;
	@Autowired
	private IEwsIndexParamService ewsIndexParamService;
	@Autowired
	private IEwsEmpGroupReferService ewsEmpGroupReferService;
	@Autowired
	private IEwsRuleService ewsRuleService;
	@Autowired
	private IEwsInfoRecordService ewsInfoRecordService;

	@Autowired
	private IEwsSendMailAndSmsService warnSendMailAndSmsService;
	
	@Autowired
	private ISqlExecutor executor;
	
	// 指标参数键常量(包括SQL参数和规则参数等)
	private static final String PARAMKEY = "PARAMKEY";
	// 数据库当前系统日期的SQL参数常量，他在数据库中是Date类型
	private static final String SYSDATE = "SYSDATE";
	// 数据库当前系统日期的SQL参数常量，他在数据库中是String类型
	private static final String SYSDATESTR = "SYSDATESTR";
	// 数据库当前系统日期格式的SQL参数常量
	private static final String SYSDATEFORMAT = "SYSDATEFORMAT";
	// 规则模板输入SQL参数常量
	private static final String RULEINPUT = "RULEINPUT";
	// 匹配占位符${SYSDATE}的正则表达式，在SQL语句中是日期类型，，例如"${SYSDATE} - 1/24,yyyy-mm-dd hh24:mi"
	private static final String SYSDATE_REGEX = "[^\\$\\{]*(\\$\\{\\s*SYSDATE\\s*\\})[^,]*(,(.+)){0,1}+";
	// 匹配占位符${SYSDATESTR}的正则表达式，用来表示日期字符串，例如"${SYSDATESTR} - 1/24,yyyy-mm-dd hh24:mi"
	private static final String SYSDATESTR_REGEX = "[^\\$\\{]*(\\$\\{\\s*SYSDATESTR\\s*\\})[^,]*(,(.+)){0,1}+";
	// 每个指标可以设置邮件循环内容发送的行数，不设置则默认每封邮件表格内容200行
	public static final String MAILROWNUM = "MAILROWNUM";
	// 默认邮件表格每封最多200行
	public static final int DEFAULT_SEP_ROW_NUM = 200;
	
	
	private Logger logger = LoggerFactory.getLogger(EwsTaskServiceImpl.class);
	
	@Override
	@Async
	public void doTask(String warnIndexNo) {
		logger.info("开始执行指标调度：{}", warnIndexNo);
		
		try {
			if(StringUtils.isBlank(warnIndexNo)) {
				throw new ServiceException("指标编号不能为空！");
			}
			
			EwsIndexDef ewsIndexDef = ewsIndexDefService.queryByWarnIndexNo(warnIndexNo);
			if(ewsIndexDef == null) {
				logger.error("指标编号【{}】不存在，调度任务执行失败！", warnIndexNo);
				throw new ServiceException(String.format("指标编号【%s】不存在，调度任务执行失败！", warnIndexNo));
			}
			
			// 检查调度任务是否有效
			if(!"Y".equals(ewsIndexDef.getIsValid())) {
				logger.info("指标编号【{}】无效，调度任务执行结束！", warnIndexNo);
				return ;
//				throw new ServiceException(String.format("指标编号【%s】无效，调度任务执行失败！", warnIndexNo));
			}
			
			// 检查调度任务是否正在执行
/*			if("RUNNING".equals(ewsIndexDef.getRunStatus())) {
				logger.error("指标编号【{}】调度任务正在运行，调度任务执行失败！", warnIndexNo);
				throw new ServiceException(String.format("指标编号【%s】调度任务正在运行，调度任务执行失败！", warnIndexNo));
			} else {
			}*/
			
			
			try {
				ewsIndexDefService.updateIndexSchRunStatus(warnIndexNo, "RUNNING");
				logger.info("将指标【{}】调度任务运行状态修改成RUNNING", warnIndexNo);
			} catch (Exception e) {
				logger.warn("将指标【{}】调度任务运行状态修改成RUNNING异常：", warnIndexNo, e);
			}
			
			// 开始执行SQL脚本
			Map<String, List<Map<String, Object>>> totalDataMap = executorSql(ewsIndexDef, null);
			
			// 用来保存drools返回结果
//			String warnMsg = executorDrools(ewsIndexDef, totalDataMap);
			String warnMsg = executorRule(ewsIndexDef, totalDataMap);
			
			if(StringUtils.isNotBlank(warnMsg)) {
				logger.info("指标【{}】已中规则.", ewsIndexDef.getWarnIndexNo());
				// 保存告警记录
				Date dealDate = new Date();
				String detailId = ewsInfoRecordService.addEwsInfoRecord(ewsIndexDef, warnMsg, dealDate, dealDate);
				Map<String, Object> constantColumnMap = new HashMap<String, Object>();
				constantColumnMap.put("INFO_RECORD_ID", detailId);
				constantColumnMap.put("WARN_INDEX_NO", ewsIndexDef.getWarnIndexNo());
				constantColumnMap.put("WARN_INDEX_NAME", ewsIndexDef.getWarnIndexName());
				// 保存结果集到数据库
				saveToDatabase(ewsIndexDef, totalDataMap, constantColumnMap);
				
				// 发送邮件和短信
				try {
					sendMail(ewsIndexDef, totalDataMap, warnMsg);
				} catch (Exception e) {
					logger.error("指标【{}】发送邮件异常：", warnIndexNo, e);
				}
				try {
					sendSms(ewsIndexDef, totalDataMap, warnMsg);
				} catch (Exception e) {
					logger.error("指标【{}】发送短信异常：", warnIndexNo, e);
				}
				
				
			} else {
				logger.info("预警指标【{}】调用规则服务的结果为空,不发送邮件或短信.", ewsIndexDef.getWarnIndexNo());
			}
			
		} catch (Exception e) {
			logger.error("指标调度【{}】异常结束：", warnIndexNo, e);
			
		} finally {
			try {
				// 将指标调度运行状态更新成停止
				ewsIndexDefService.updateIndexSchRunStatus(warnIndexNo, "STOP");
			} catch (Exception e) {
				logger.error("更新指标【{}】调度运行状态失败：", warnIndexNo, e);
			}
			
			logger.info("指标调度任务结束：{}", warnIndexNo);
		}
		
	}
	
	/**
	 * 执行预警指标SQL
	 * 由预警指标组任务调用
	 * @param warnIndexDef
	 * @param warnIndexGroupParamMap 告警指标组参数Map，可以覆盖告警指标的参数
	 * @return
	 */
	@Override
	public Map<String, List<Map<String, Object>>> executorSql(EwsIndexDef warnIndexDef, 
			Map<String, Object> warnIndexGroupParamMap) {
		if(warnIndexDef == null) {
			throw new ServiceException("预警指标对象不能为空！");
		}
		
		logger.info("预警指标【{}】executorSql开始... ...", warnIndexDef.getWarnIndexNo());
		
		Map<String, List<Map<String, Object>>> totalDataMap = new HashMap<String, List<Map<String, Object>>>();
		
		// 查询出该指标的所有SQL语句
		List<EwsIndexSql> ewsIndexSqlList = ewsIndexSqlService.queryEwsIndexSqlByWarnNo(warnIndexDef.getWarnIndexNo());
		logger.info("告警指标{} {} SQL为：{}", new Object[]{ warnIndexDef.getWarnIndexNo(), 
				warnIndexDef.getWarnIndexName(), ewsIndexSqlList});
		if(ewsIndexSqlList == null || ewsIndexSqlList.isEmpty()) {
			logger.warn("告警指标SQL为空：{} {}", warnIndexDef.getWarnIndexNo(), 
					warnIndexDef.getWarnIndexName());
			
			return totalDataMap;
		}

		// 查询出该指标对应的所有参数
		Map<String, Object> warnIndexParamMap = new HashMap<String, Object>();
		
		List<EwsIndexParam> indexParamList = ewsIndexParamService.queryIndexNoParamsByWarnIndexNo(warnIndexDef.getWarnIndexNo());
		Map<String, String> queryMap = new HashMap<String, String>();
		if(indexParamList != null) {
			for(EwsIndexParam param : indexParamList) {
				queryMap.put(param.getParamName(), param.getParamVal());
			}
		}
		
		warnIndexParamMap.putAll(queryMap);
		
		// 放入指标组参数,这会覆盖掉指标参数
		if(warnIndexGroupParamMap != null) {
			warnIndexParamMap.putAll(warnIndexGroupParamMap);
		}
		
		List<Map<String, Object>> sqlKeyParamList = new ArrayList<Map<String,Object>>();
		// 将规则模板放入SQL参数中
		warnIndexParamMap.put(RULEINPUT, warnIndexDef.getRuleTemplate());
		sqlKeyParamList.add(warnIndexParamMap);
		// 将SQL参数放入总的数据Map中
		totalDataMap.put(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY, sqlKeyParamList);
		
		// 开始执行SQL语句
		try {
			// 来做系统时间处理
			String sysdate = warnIndexParamMap.containsKey(SYSDATESTR) ? (String) warnIndexParamMap.get(SYSDATESTR) : 
				executor.getDatabaseDate((String) warnIndexParamMap.get(SYSDATEFORMAT));
			// 如果指标组没有包含SYSDATE，则放入SYSDATE
			if(!warnIndexParamMap.containsKey(SYSDATESTR) || StringUtils.isBlank((String)warnIndexParamMap.get(SYSDATESTR))) {
				warnIndexParamMap.put(SYSDATESTR, sysdate);
			}
			if(!warnIndexParamMap.containsKey(SYSDATEFORMAT)) {
				warnIndexParamMap.put(SYSDATEFORMAT, "yyyy-mm-dd hh24:mi:ss");
			}
			if(!warnIndexParamMap.containsKey(SYSDATE) || StringUtils.isBlank((String)warnIndexParamMap.get(SYSDATE))) {
				warnIndexParamMap.put(SYSDATE, String.format("to_date('%s', '%s')", 
						new Object[]{warnIndexParamMap.get(SYSDATESTR), warnIndexParamMap.get(SYSDATEFORMAT)}));
			}	
			
			// 来对使用了${SYSDATE}和${SYSDATESTR}占位符的SQL参数进行处理
			Pattern sysdatePattern = Pattern.compile(SYSDATE_REGEX);
			Pattern sysdatestrPattern = Pattern.compile(SYSDATESTR_REGEX);
			Matcher matcher = null;
			for(Map.Entry<String, Object> entry : warnIndexParamMap.entrySet()) {
				String key = entry.getKey();
				String value = (String) entry.getValue();
				
				if(StringUtils.isBlank(value)) {
					continue ;
				}
				
				// 匹配${SYSDATE}
				matcher = sysdatePattern.matcher(value);
				if(matcher.matches()) {
					String sysDateLabel = matcher.group(1);
					String sysLabel = value.contains(",") ? value.substring(0, value.lastIndexOf(",")) : value;
					String formatLabel = matcher.group(3) != null ? matcher.group(3).trim() : null;
					String switchValue = sysLabel.replaceFirst(sysDateLabel.replace("$", "\\$").replace("{", "\\{").
							replace("}", "\\}"), (String)warnIndexParamMap.get(SYSDATE));
					
					switchValue = String.format("to_date(to_char(%s, '%s'), '%s')", new Object[]{switchValue, 
							StringUtils.isBlank(formatLabel) ? ((warnIndexParamMap.containsKey(SYSDATEFORMAT) ? warnIndexParamMap.get(SYSDATEFORMAT) : "yyyy-mm-dd hh24:mi:ss")) : formatLabel,
							StringUtils.isBlank(formatLabel) ? ((warnIndexParamMap.containsKey(SYSDATEFORMAT) ? warnIndexParamMap.get(SYSDATEFORMAT) : "yyyy-mm-dd hh24:mi:ss")) : formatLabel});
					
					if(StringUtils.isBlank(switchValue)) {
						logger.error("预警指标【{}】解析SQL参数【{}】出错：错误的占位符表达式【{}】",
								new Object[]{warnIndexDef.getWarnIndexNo(), key, value});
						throw new ServiceException(String.format("预警指标【%s】解析SQL参数【%s】出错：错误的占位符表达式【%s】", 
								new Object[]{warnIndexDef.getWarnIndexNo(), key, value}));
					}
					
					entry.setValue(switchValue);
					logger.info("预警指标【{}】将SQL参数【{}】值由【{}】转化成【{}】.", 
							new Object[]{warnIndexDef.getWarnIndexNo(), key, value, switchValue});
					
					continue ;
				}
				
				// 匹配${SYSDATESTR}
				matcher = sysdatestrPattern.matcher(value);
				if(matcher.matches()) {
					String sysDateLabel = matcher.group(1);
					String sysLabel = value.contains(",") ? value.substring(0, value.lastIndexOf(",")) : value;
					String formatLabel = matcher.group(3) != null ? matcher.group(3).trim() : null;
					String switchValue = sysLabel.replaceFirst(sysDateLabel.replace("$", "\\$").replace("{", "\\{").
							replace("}", "\\}"), (String)warnIndexParamMap.get(SYSDATE));
					
					// 组装查询SQL
					String querySql = String.format("select to_char(%s, '%s') from dual", 
							new Object[]{switchValue, StringUtils.isBlank(formatLabel) ? 
									(warnIndexParamMap.containsKey(SYSDATEFORMAT) ? warnIndexParamMap.get(SYSDATEFORMAT) : "yyyy-mm-dd hh24:mi:ss") : 
										formatLabel}); 
					
					switchValue = (String) executor.executorQuerySql(querySql, warnIndexParamMap).getOne();
					
					if(StringUtils.isBlank(switchValue)) {
						logger.error("预警指标【{}】解析SQL参数【{}】出错：错误的占位符表达式【{}】",
								new Object[]{warnIndexDef.getWarnIndexNo(), key, value});
						throw new ServiceException(String.format("预警指标【%s】解析SQL参数【%s】出错：错误的占位符表达式【%s】", 
								new Object[]{warnIndexDef.getWarnIndexNo(), key, value}));
					}
					
					entry.setValue(switchValue);
					logger.info("预警指标【{}】将SQL参数【{}】值由【{}】转化成【{}】.", 
							new Object[]{warnIndexDef.getWarnIndexNo(), key, value, switchValue});
				}
				
			}
			
					
			logger.info("告警指标{} {} 开始执行SQL... ...", warnIndexDef.getWarnIndexNo(), 
					warnIndexDef.getWarnIndexName());
			long start = System.currentTimeMillis();
			
			for(EwsIndexSql ewsIndexSql : ewsIndexSqlList) {
				ObjectResult result = executor.executorQuerySql(ewsIndexSql.getWarnIndexSql(), warnIndexParamMap);
				
				if(result == null || result.get() == null || result.get().isEmpty()) {
					logger.info("预警指标【{}】SQL【{}】执行结果为空！", warnIndexDef.getWarnIndexNo(), 
							ewsIndexSql.getSqlKey());
					continue ;
				}
				
				// 如果包含重复的SQLkey，说明数据库脚本错误
				if(totalDataMap.containsKey(ewsIndexSql.getSqlKey())) {
					logger.error("预警指标【{}】中发现SQLkey【{}】重复！", warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey());
					throw new ServiceException(String.format("预警指标【%s】中发现SQLkey【%s】重复！", 
							new Object[]{warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
				}
				
				totalDataMap.put(ewsIndexSql.getSqlKey(), result.get());
				// 如果是单行单列的结果，则该SQL键也可以引用该结果
				if(result.isOneResult()) {
					result.get().get(0).put(ewsIndexSql.getSqlKey(), result.getOne());
				}
			}
			
			logger.info("告警指标【{}】查询SQL结果集完毕,耗时：【{}】秒", new Object[]{warnIndexDef.getWarnIndexNo(),
					(System.currentTimeMillis() - start + 0.0) / 1000 });
			
			logger.info("预警指标【{}】executorSql结束.", warnIndexDef.getWarnIndexNo());
			
			return totalDataMap;
		} catch (ServiceException e) {
			throw e;
			
		} catch (Exception e) {
			logger.error("告警指标【{}】执行SQL出错：", new Object[]{warnIndexDef.getWarnIndexNo(), e});
			
			throw new ServiceException(String.format("告警指标【%s】 执行SQL出错：%s", new Object[]{warnIndexDef.getWarnIndexNo(), e.getMessage()}), e);
		}
		
	}
	
	/**
	 * 调用drools服务
	 * @param warnIndexDef
	 * @param totalDataMap	所有结果集
	 * @return
	 */
/*	@Deprecated
	@Override
	public String executorDrools(EwsIndexDef warnIndexDef, final Map<String, List<Map<String, Object>>> totalDataMap) {
		if(warnIndexDef == null) {
			throw new ServiceException("预警指标对象不能为空！");
		}
		
		logger.info("预警指标【{}】executorDrools 开始... ...", warnIndexDef.getWarnIndexNo());
		
		Map<String, List<Map<String, Object>>> sendDroolsDataMap = new HashMap<String, List<Map<String,Object>>>();
		// 先从总的Map中找出哪些结果集是需要发送到Drools的
		if(totalDataMap != null && !totalDataMap.isEmpty()) {
			// 查询出该指标的所有SQL语句
			List<EwsIndexSql> ewsIndexSqlList = ewsIndexSqlService.queryEwsIndexSqlByWarnNo(warnIndexDef.getWarnIndexNo());
			logger.info("告警指标{} {} SQL为：{}", new Object[]{ warnIndexDef.getWarnIndexNo(), 
					warnIndexDef.getWarnIndexName(), ewsIndexSqlList});
			if(ewsIndexSqlList == null || ewsIndexSqlList.isEmpty()) {
				logger.warn("告警指标【{}:{}】SQL为空！", warnIndexDef.getWarnSource(), 
						warnIndexDef.getWarnIndexNo());
			} else {
				// 放入SQL参数
				sendDroolsDataMap.put(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY, 
						totalDataMap.get(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY));
				for(EwsIndexSql ewsIndexSql : ewsIndexSqlList) {
					// 是否需要放入发送Drools的Map中
					if("Y".equals(ewsIndexSql.getRuleOutput())) {
						if(sendDroolsDataMap.containsKey(ewsIndexSql.getSqlKey())) {
							logger.error("预警指标【{}】中发现SQLkey【{}】重复！", warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey());
							throw new ServiceException(String.format("预警指标【%s】中发现SQLkey【%s】重复！", 
									new Object[]{warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
						}
						
						sendDroolsDataMap.put(ewsIndexSql.getSqlKey(), totalDataMap.get(ewsIndexSql.getSqlKey()));
					}
				}
			}
		}
		
		if(sendDroolsDataMap.isEmpty()) {
			logger.info("预警指标【{}】将要发送到drools服务的数据为空！", warnIndexDef.getWarnIndexNo());
			return "";
		}
		
		// 进行drools规则计算
		// 将参数转换成Json格式
		JSONObject jsonObject = JSONObject.fromObject(sendDroolsDataMap);
		String jsonStr = jsonObject.toString();
		Date execDate = new Date();
		logger.info("【doDrools】 {} 规则参数开始调用Drools(dateTask方法), 开始: {} ", 
				warnIndexDef.getWarnIndexNo(), jsonStr);
		EwsWarningCalrltlog warnCalRltLog = warnCalRltLogUtil.initEwsWarningCalrltlog(execDate, warnIndexDef.getWarnIndexNo(), 
				warnIndexDef.getWarnIndexName(), "Drools参数:" + jsonStr.substring(0, jsonStr.length() > 1000 ? 
						1000 : jsonStr.length()), 
				warnIndexDef.getWarnSource());
		
		// 调用Drools服务
		EwsWarnSource ewsWarnSource = ewsWarnSourceService.queryByWarnSource(warnIndexDef.getWarnSource());
		if(ewsWarnSource == null) {
			logger.error("预警指标【{}】中预警来源不存在：【{}】", warnIndexDef.getWarnIndexNo(), warnIndexDef.getWarnSource());
			throw new ServiceException(String.format("预警指标【%s】中预警来源不存在：【%s】", 
					new Object[]{warnIndexDef.getWarnIndexNo(), warnIndexDef.getWarnSource()}));
		}
		
		String warnMsg = null;
		// 开始调用drools服务
		String warnUrl = ewsWarnSource.getDroolsWsUrl();
		List<RuleResponse> ruleResponseList = WarnDroolsUtil.getDroolsWsResult(droolsWsUrl + warnUrl, jsonStr);
		
		// 录本次日期规则参数查询以及调用Drools的花费时间;
		warnCalRltLog.setWarnEndTime(execDate);
		warnCalRltLogService.createCalRltLog(warnCalRltLog);
		logger.info("【doDrools】 {}规则参数调用Drools(getDroolsWsResult方法), 结束: {}", 
				warnIndexDef.getWarnIndexNo(), ruleResponseList.size());

		// 根据规则返回的结果进行数据的插入
		if (!ruleResponseList.isEmpty()) {
			logger.info("【doDrools】 {}规则参数调用根据Drools的结果进行处理开始(dateTask方法): ", 
					warnIndexDef.getWarnIndexNo(), ruleResponseList.size());
			warnCalRltLog = warnCalRltLogUtil.initEwsWarningCalrltlog(new Date(), warnIndexDef.getWarnIndexNo(), 
					warnIndexDef.getWarnIndexName(), String.format("%s规则Drools结果处理", warnIndexDef.getWarnSource()), 
					warnIndexDef.getWarnSource());
			
			// 根据Sypay调用Drools的使用规则返回结果，进行处理 1. 如果违反，根据Sypay的规则代码，进行EWS_WARNING_MS的数据保存和TB资料的保存; 2.并进行日志的处理;
			// 一个指标只会产生一个结果
			RuleResponse ruleResponse = ruleResponseList.get(0);
//					String warnCode = ruleResponse.getCode();
			warnMsg = ruleResponse.getMsg();
			
			// 记录明细信息
			try {
				saveWarningRecord(warnIndexDef, execDate);
			} catch (Exception e) {
				logger.error(String.format("记录主表和明细表出错：指标规则：%s，执行日期：%s", 
						new Object[]{warnIndexDef.getWarnIndexNo(), execDate}), e);
			}

			warnCalRltLog.setWarnEndTime(new Date());
			warnCalRltLogService.createCalRltLog(warnCalRltLog);
			
		} else {
			logger.info("【doDrools】 {}规则参数调用Drools服务返回的结果为空!", 
					warnIndexDef.getWarnIndexNo());
		}
		
		logger.info("预警指标【{}】executorDrools 结束", warnIndexDef.getWarnIndexNo());
		return warnMsg;
	}*/
	
	/**
	 * 执行预警规则
	 * @param warnIndexDef
	 * @param totalDataMap
	 * @return 返回的字符串如果是“”，表示没有中规则，否则表示中了规则
	 */
	public String executorRule(EwsIndexDef warnIndexDef, final Map<String, List<Map<String, Object>>> totalDataMap) {
		if(warnIndexDef == null) {
			throw new ServiceException("预警指标对象不能为空！");
		}
		
		logger.info("预警指标【{}】executorRule 开始... ...", warnIndexDef.getWarnIndexNo());
		
		List<EwsRule> ewsRuleList = ewsRuleService.queryByEwsIndexNo(warnIndexDef.getWarnIndexNo());
		if(ewsRuleList == null || ewsRuleList.isEmpty()) {
			logger.info("预警指标【{}】查到的规则列表为空，executorRule调用结束！", warnIndexDef.getWarnIndexNo());
			return "";
		}
		
		// 解析规则参数
		String resultName = null;
		Map<String, String> paramsMap = new HashMap<String, String>();
		for(EwsRule ewsRule : ewsRuleList) {
			if(paramsMap.containsKey(ewsRule.getParamName())) {
				logger.error("预警指标【{}】规则参数名称重复：【{}】", warnIndexDef.getWarnIndexNo(), 
						ewsRule.getParamName());
				throw new ServiceException(String.format("预警指标【%s】规则参数名称重复：【%s】", new Object[]{warnIndexDef.getWarnIndexNo(), 
						ewsRule.getParamName()}));
			}
			
			paramsMap.put(ewsRule.getParamName(), ewsRule.getParamExpress());
			if("Y".equals(ewsRule.getIsResult())) {
				if(StringUtils.isNotBlank(resultName)) {
					logger.error("预警指标【{}】规则参数只能有一个表达式作为结果输出:【{}】", warnIndexDef.getWarnIndexNo(), resultName);
					throw new ServiceException(String.format("预警指标【%s】规则参数只能有一个表达式作为结果输出", 
							warnIndexDef.getWarnIndexNo()));
				}
				// 记录结果的规则名称
				resultName = ewsRule.getParamName();
			}
		}
		
		if(StringUtils.isBlank(resultName)) {
			logger.error("预警指标【{}】规则参数必须有一个表达式作为结果输出!", warnIndexDef.getWarnIndexNo());
			throw new ServiceException(String.format("预警指标【%s】规则参数必须有一个表达式作为结果输出!", 
					warnIndexDef.getWarnIndexNo()));
		}
		
		// 解析入参Map，然后放入执行器中
		Evaluator evaluator = new Evaluator();
		if(totalDataMap != null) {
			for(Map.Entry<String, List<Map<String, Object>>> entry : totalDataMap.entrySet()) {
				// 只有单行结果集中的Map才有可能被使用
				if(entry.getValue() != null && entry.getValue().size() == 1) {
					for(Map.Entry<String, Object> childEntry : entry.getValue().get(0).entrySet()) {
						evaluator.putVariable(childEntry.getKey(), String.valueOf(childEntry.getValue()));
					}
				}
			}
		}
		
		// 计算规则最多执行次数，超过这次数说明规则参数配置错误
		int loopTimes = paramsMap.size();
		int dealNum = 0;
		while(loopTimes-- > 0 && dealNum < paramsMap.size()) {
			for(Map.Entry<String, String> entry : paramsMap.entrySet()) {
				try {
					if(!StringUtils.equals(resultName, entry.getKey())) {
						entry.setValue(evaluator.evaluate(entry.getValue()));
						
					} else {
						entry.setValue(Boolean.valueOf(evaluator.getBooleanResult(entry.getValue())).toString());			
					}
					evaluator.putVariable(entry.getKey(), entry.getValue());
					dealNum++;
				} catch (EvaluationException e) {
//					logger.error("执行表达式【{}】出错！", entry.getValue());
//					throw new ServiceException(String.format("执行表达式【%s】出错！", entry.getValue()));
				}
			}
		}
		
		if(dealNum < paramsMap.size()) {
			logger.error("预警指标【{}】规则表达式不正确，解析不成功！", warnIndexDef.getWarnIndexNo());
			throw new ServiceException(String.format("预警指标【%s】规则表达式不正确，解析不成功！", warnIndexDef.getWarnIndexNo()));
		}
		
		if("true".equals(paramsMap.get(resultName))) {
			logger.info("预警指标【{}】规则表达式成功命中！", warnIndexDef.getWarnIndexNo());
			
			// 根据格式化字段格式化运算结果
			for(EwsRule ewsRule : ewsRuleList) {
				try {
					if(StringUtils.isNotBlank(ewsRule.getFormatStr())) {
						paramsMap.put(ewsRule.getParamName(), evaluator.evaluate(ewsRule.getFormatStr()));
					}
				} catch (EvaluationException e) {
					logger.error("执行参数【{}】的格式化表达式【{}】出错:", new Object[]{ewsRule.getParamName(), ewsRule.getFormatStr(), e});
//					throw new ServiceException(String.format("执行参数【%s】的格式化表达式【%s】出错！", 
//							new Object[]{ewsRule.getParamName(), ewsRule.getFormatStr()}));
				}
			}
			
			// 将规则参数的计算结果页放入总的Map中
			totalDataMap.get(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY).get(0).putAll(paramsMap);
			String strTemplate = (String) totalDataMap.get(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY).get(0).get(RULEINPUT);
			
			return ParamStrUtil.translationContext(strTemplate, totalDataMap, -1).get(0);
			
		} else {
			logger.info("预警指标【{}】规则表达式没有命中！", warnIndexDef.getWarnIndexNo());
			return "";
		}
		
	}
	
	/**
	 * 将告警明细保存到数据库表中
	 * @param warnIndexDef
	 * @param totalDataMap 数据Map
	 * @param constantColumnMap 常量列Map，如果需要某些列的行都显示固定值，则可使用此Map，此Map的优先级低于totalDataMap，不需要常量列可以传空
	 */
	private void saveToDatabase(EwsIndexDef warnIndexDef, final Map<String, List<Map<String, Object>>> totalDataMap, 
			Map<String, Object> constantColumnMap) {
		logger.info("saveToDatabase 【{}】", warnIndexDef);
		
		if(warnIndexDef == null || totalDataMap == null) {
			logger.error("saveToDatabase 预警指标和数据Map不能为空！");
			throw new ServiceException("预警指标和数据Map不能为空！");
		}
		
		List<EwsIndexSql> ewsIndexSqlList = ewsIndexSqlService.queryEwsIndexSqlByWarnNo(warnIndexDef.getWarnIndexNo());
		if(ewsIndexSqlList == null || ewsIndexSqlList.isEmpty()) {
			logger.info("预警指标【{}】SQL为空，无需保存明细到数据库！", warnIndexDef.getWarnIndexNo());
			return ;
		}
		
		for(EwsIndexSql ewsIndexSql : ewsIndexSqlList) {
			String tableName = ewsIndexSql.getTableName();
			if(StringUtils.isBlank(tableName)) {
				logger.info("预警指标SQL【{}:{}】没有指定表，无需插入数据！", warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey());
				continue ;
			}
			
			tableName = tableName.toUpperCase();
			
			List<Map<String, Object>> sqlMapList = totalDataMap.get(ewsIndexSql.getSqlKey());
			if(sqlMapList == null || sqlMapList.isEmpty()) {
				logger.info("预警指标SQL【{}:{}】结果集为空，无需插入数据！", warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey());
				continue ;
			}
			
			logger.info("预警指标SQL【{}:{}】准备向【{}】表中插入数据... ...", 
					new Object[]{warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey(), tableName});
			try {
				executor.insertData(tableName, sqlMapList, constantColumnMap);
			} catch (SQLException e) {
				logger.error("预警指标【{}】插入【{}】表数据SQL执行异常：", new Object[]{warnIndexDef.getWarnIndexNo(), tableName, e});
			}
		}
		
		logger.info("saveToDatabase end 【{}】", warnIndexDef);
	}
	
	
	/**
	 * 发送邮件和短信
	 * @param warnIndexDef 	告警指标
	 * @param totalDataMap	所有结果集
	 * @param warnMsg		drools返回信息
	 */
	private void sendMail(EwsIndexDef warnIndexDef, Map<String, List<Map<String, Object>>> totalDataMap,
			String warnMsg) {
		logger.info("预警指标【{}】sendMailAndSms开始... ...", warnIndexDef.getWarnIndexNo());
		
		Map<String, List<Map<String, Object>>> sendMailDataMap = new HashMap<String, List<Map<String,Object>>>();
		// 先从总的Map中找出哪些结果集是需要发送到邮件的
		if(totalDataMap != null && !totalDataMap.isEmpty()) {
			// 查询出该指标的所有SQL语句
			List<EwsIndexSql> ewsIndexSqlList = ewsIndexSqlService.queryEwsIndexSqlByWarnNo(warnIndexDef.getWarnIndexNo());
			logger.info("告警指标{} {} SQL为：{}", new Object[]{ warnIndexDef.getWarnIndexNo(), 
					warnIndexDef.getWarnIndexName(), ewsIndexSqlList});
			if(ewsIndexSqlList == null || ewsIndexSqlList.isEmpty()) {
				logger.warn("告警指标【{}:{}】SQL为空！", warnIndexDef.getWarnSource(), 
						warnIndexDef.getWarnIndexNo());
			} else {
				// 放入SQL参数
				sendMailDataMap.put(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY, 
						totalDataMap.get(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY));
				for(EwsIndexSql ewsIndexSql : ewsIndexSqlList) {
					// 是否需要放入发送邮件的Map中
					if("Y".equals(ewsIndexSql.getMailOutput())) {
						// 如果包含重复的SQLkey，说明数据库脚本错误
						if(sendMailDataMap.containsKey(ewsIndexSql.getSqlKey())) {
							logger.error("预警指标【{}】中发现SQLkey【{}】重复！", warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey());
							throw new ServiceException(String.format("预警指标【%s】中发现SQLkey【%s】重复！", 
									new Object[]{warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
						}
						sendMailDataMap.put(ewsIndexSql.getSqlKey(), totalDataMap.get(ewsIndexSql.getSqlKey()));
					}
				}
			}
		}
		
		
		try {
			StringBuilder context = new StringBuilder();
			context.append(warnMsg);
			context.append("<br />");
			
			int row = DEFAULT_SEP_ROW_NUM;
			List<Map<String, Object>> mapDataList = sendMailDataMap.get(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY);
			if(mapDataList != null && !mapDataList.isEmpty()) {
				try {
					row = StringUtils.isBlank((String)mapDataList.get(0).get(MAILROWNUM)) ? DEFAULT_SEP_ROW_NUM : 
						Integer.valueOf((String)mapDataList.get(0).get(MAILROWNUM));
				} catch (Exception e) {
					logger.error("预警指标【{}】发送邮件获取MAILROWNUM行数异常，默认采用200：{}", warnIndexDef.getWarnIndexNo(), e.getMessage());
				}
			}
			
			List<String> contextList = ParamStrUtil.translationContext(context.toString() + (StringUtils.isBlank(warnIndexDef.getMailContextTemplate()) ? 
					"" : warnIndexDef.getMailContextTemplate()) , sendMailDataMap, row);
			String title = StringUtils.isBlank(warnIndexDef.getMailTitleTemplate()) ? (String.format("【%s】%s", new Object[]{warnIndexDef.getWarnIndexNo(), 
					warnIndexDef.getWarnIndexName()})) :
						ParamStrUtil.translationContext(warnIndexDef.getMailTitleTemplate(), sendMailDataMap, -1).get(0);
			
			logger.info("sendMail邮件服务调用开始: {}",  warnIndexDef.getWarnIndexNo());
			List<EwsEmpGroupRefer> ewsEmpGroupReferList = ewsEmpGroupReferService.queryEmpGroupInfoByIndexNo(warnIndexDef.getWarnIndexNo());
			if(ewsEmpGroupReferList != null && !ewsEmpGroupReferList.isEmpty()) {
				warnSendMailAndSmsService.sendWarnIndexMail(ewsEmpGroupReferList, title, contextList);
			} else {
				logger.info("预警指标【{}】发送邮件的人员列表为空，不需要发邮件.", warnIndexDef.getWarnIndexNo());
			}
			
			logger.info("sendMail邮件服务调用结束: {}",  warnIndexDef.getWarnIndexNo());
			
			
		} catch (Exception e) {
			logger.error("【{}】sendMail邮件调用异常:", warnIndexDef.getWarnIndexNo(), e);
		}
		
		logger.info("预警指标【{}】sendMail结束.", warnIndexDef.getWarnIndexNo());
	}
	
	/**
	 * 发送短信
	 * @param warnIndexDef 	告警指标
	 * @param totalDataMap	所有结果集
	 * @param warnMsg		drools返回信息
	 */
	private void sendSms(EwsIndexDef warnIndexDef, Map<String, List<Map<String, Object>>> totalDataMap,
			String warnMsg) {
		logger.info("预警指标【{}】sendMailAndSms开始... ...", warnIndexDef.getWarnIndexNo());
		
		Map<String, List<Map<String, Object>>> sendSmsDataMap = new HashMap<String, List<Map<String,Object>>>();
		// 先从总的Map中找出哪些结果集是需要发送到Drools的
		if(totalDataMap != null && !totalDataMap.isEmpty()) {
			// 查询出该指标的所有SQL语句
			List<EwsIndexSql> ewsIndexSqlList = ewsIndexSqlService.queryEwsIndexSqlByWarnNo(warnIndexDef.getWarnIndexNo());
			logger.info("告警指标{} {} SQL为：{}", new Object[]{ warnIndexDef.getWarnIndexNo(), 
					warnIndexDef.getWarnIndexName(), ewsIndexSqlList});
			if(ewsIndexSqlList == null || ewsIndexSqlList.isEmpty()) {
				logger.warn("告警指标【{}:{}】SQL为空！", warnIndexDef.getWarnSource(), 
						warnIndexDef.getWarnIndexNo());
			} else {
				// 放入SQL参数
				sendSmsDataMap.put(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY, 
						totalDataMap.get(warnIndexDef.getWarnIndexNo() + "." + PARAMKEY));
				for(EwsIndexSql ewsIndexSql : ewsIndexSqlList) {
					// 是否需要放入发送Drools的Map中
					if("Y".equals(ewsIndexSql.getRuleOutput())) {
						if(sendSmsDataMap.containsKey(ewsIndexSql.getSqlKey())) {
							logger.error("预警指标【{}】中发现SQLkey【{}】重复！", warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey());
							throw new ServiceException(String.format("预警指标【%s】中发现SQLkey【%s】重复！", 
									new Object[]{warnIndexDef.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
						}
						
						sendSmsDataMap.put(ewsIndexSql.getSqlKey(), totalDataMap.get(ewsIndexSql.getSqlKey()));
					}
				}
			}
		}
		
		try {
			logger.info("sendSms短信服务调用开始: {}",  warnIndexDef.getWarnIndexNo());
			List<EwsEmpGroupRefer> ewsEmpGroupReferList = ewsEmpGroupReferService.queryEmpGroupInfoByIndexNo(warnIndexDef.getWarnIndexNo());
			if(ewsEmpGroupReferList != null && !ewsEmpGroupReferList.isEmpty()) {
				warnSendMailAndSmsService.sendWarnIndexSms(ewsEmpGroupReferList, ParamStrUtil.translationContext(warnMsg, sendSmsDataMap, -1).get(0));
			} else {
				logger.info("预警指标【{}】发送短信的人员列表为空，不需要发短信.", warnIndexDef.getWarnIndexNo());
			}
			
			logger.info("sendSms短信服务调用结束: {}",  warnIndexDef.getWarnIndexNo());
			
		} catch (Exception e) {
			logger.error("【{}】sendSms短信调用异常:", warnIndexDef.getWarnIndexNo(), e);
		}
		
		logger.info("预警指标【{}】sendSms结束.", warnIndexDef.getWarnIndexNo());
	}

}
