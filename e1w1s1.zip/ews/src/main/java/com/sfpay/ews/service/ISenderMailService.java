package com.sfpay.ews.service;


import com.sfpay.framework.base.exception.ServiceException;

/**
 * 借用别人的发送邮件的信息;
 * @author 575740
 *
 */
public interface ISenderMailService {

	/**
	 * 
	 * 
	 * 方法说明：发送文本邮件
	 * 
	 * @param mTo
	 *            收件人
	 * @throws MailException
	 */
	public void sendMail(String eMail, String userName, String passWord)
			throws ServiceException;

	/**
	 * 
	 *
	 * 方法说明：方法说明：发送文本邮件-对外
	 *
	 * @param eMail 邮件
	 * @param code 信息
	 * @param head 主题(可为空)
	 */
	public void sendOutMail(String eMail, String code, String head);
	
	/**
	 * 
	 * 方法说明：发送HTML格式的邮件<br>
	 * 
	 * @param to 收件人邮箱
	 * @param subject 邮件主题
	 * @param text 邮件内容
	 * @throws MessagingException
	 * @author 349497
	 */
	public void sendHTMLMail(String to, String subject, String text) throws ServiceException ;
}
