/**
 * 
 */
package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsIndexGroupRefer;

/**
 * 类说明：预警指标和指标组映射Dao
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
public interface IEwsIndexGroupReferDao {
	/**
	 * 查询所有预警指标组映射
	 */
	public List<EwsIndexGroupRefer> queryAll();
	
	/**
	 * 通过组编号查询预警指标编号
	 */
	public List<String> queryByGroupNo(@Param("groupNo")String groupNo);
}
