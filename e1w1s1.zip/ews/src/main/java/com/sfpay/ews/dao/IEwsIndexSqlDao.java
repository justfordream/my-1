/**
 * 
 */
package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsIndexSql;

/**
 * 类说明：预警指标SQL DAO
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-3
 */
public interface IEwsIndexSqlDao {
	/**
	 * 通过指标编码查找对应的SQL参数
	 * @return
	 */
	List<EwsIndexSql> queryEwsIndexSqlByWarnNo(@Param("warnIndexNo")String warnIndexNo);
	
	/**
	 * 通过指标编号和SQL键查找预警指标SQL对象
	 * @param warnIndexNo
	 * @param sqlKey
	 * @return
	 */
	public EwsIndexSql queryByWarnIndexNoAndSqlKey(@Param("warnIndexNo")String warnIndexNo, 
			@Param("sqlKey")String sqlKey);
	
	/**
	 * 新增预警指标SQL
	 * @param ewsIndexSql
	 */
	public void addEwsIndexSql(EwsIndexSql ewsIndexSql);
	
	/**
	 * 删除预警指标SQL
	 * @param id
	 */
	public void deleteEwsIndexSql(long id);
	
	/**
	 * 更新预警指标SQL
	 * @param ewsIndexSql
	 */
	public void updateEwsIndexSql(EwsIndexSql ewsIndexSql);
	
	/**
	 * 通过id查询
	 * @param id
	 * @return
	 */
	public EwsIndexSql queryById(long id);
	
	/**
	 * 查询在TABLE_NAME列中出现过的所有表名
	 * @return
	 */
	public List<String> queryAllTableName();
	
	/**
	 * 查询指标SQL总记录
	 * @param indexDef
	 * @return
	 */
	public int queryEwsIndexSqlCount(@Param("indexSql")EwsIndexSql indexSql);
	
	/**
	 * 分页查询指标SQL
	 * @param indexDef
	 * @param index
	 * @param size
	 * @return
	 */
	public List<EwsIndexSql> queryByPage(@Param("indexSql")EwsIndexSql indexSql,
			@Param("start")int start,
			@Param("end")int end);
}
