package com.sfpay.ews.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsParamDao;
import com.sfpay.ews.platform.domain.EwsParam;
import com.sfpay.ews.platform.service.IEwsParamService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 预警参数记录表维护
 * 
 * 
 * @author 544772
 * @version 2015年3月26日 下午4:09:41
 */
@HessianExporter
@Service("ewsParamService")
public class EwsParamServiceImpl implements IEwsParamService {

	@Autowired
	private IEwsParamDao ewsParamDao;

	private static Logger logger = LoggerFactory.getLogger(EwsParamServiceImpl.class);

	@Override
	public void addEwsParam(EwsParam ewsParam) {
		try {
			if (StringUtils.isBlank(ewsParam.getParamCode())) {
				logger.error("参数代码不能为空");
				throw new ServiceException("参数代码不能为空");
			}
			if (StringUtils.isBlank(ewsParam.getParamTypeCode())) {
				logger.error("参数类型代码不能为空");
				throw new ServiceException("参数类型代码不能为空");
			}
			ewsParamDao.addEwsParam(ewsParam);
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("新增预警参数记录错误", e);
			throw new ServiceException("新增预警参数记录错误", e);
		}
	}

	@Override
	public void updateEwsParam(EwsParam ewsParam) {
		try {
			if (StringUtils.isBlank(ewsParam.getParamCode())) {
				logger.error("参数代码不能为空");
				throw new ServiceException("参数代码不能为空");
			}
			if (StringUtils.isBlank(ewsParam.getParamTypeCode())) {
				logger.error("参数类型代码不能为空");
				throw new ServiceException("参数类型代码不能为空");
			}
			ewsParamDao.updateEwsParam(ewsParam);
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("更新预警参数记录错误", e);
			throw new ServiceException("更新预警参数记录错误", e);
		}
	}

	@Override
	public void delEwsParam(String id) {
		try {
			if (StringUtils.isBlank(id)) {
				logger.error("ID为空，请提供ID值进行删除");
				throw new ServiceException("ID为空，请提供ID值进行删除");
			}
			ewsParamDao.delEwsParam(id);
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("删除预警参数记录错误", e);
			throw new ServiceException("删除预警参数记录错误", e);
		}
	}

	@Override
	public EwsParam queryById(String id) {
		try {
			if (StringUtils.isBlank(id)) {
				logger.error("ID为空，请提供ID值进行查询");
				throw new ServiceException("ID为空，请提供ID值进行查询");
			}
			return ewsParamDao.queryById(id);
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("查询预警参数记录错误", e);
			throw new ServiceException("查询预警参数记录错误", e);
		}
	}

	@Override
	public List<EwsParam> queryAll() {
		try {
			return ewsParamDao.queryAll();
		} catch (Exception e) {
			logger.error("查询所有预警参数记录错误", e);
			throw new ServiceException("查询所有预警参数记录错误", e);
		}
	}

	@Override
	public List<EwsParam> queryEwsParamByParam(EwsParam ewsParam) {
		try {
			return ewsParamDao.queryEwsParamByParam(ewsParam);
		} catch (Exception e) {
			logger.error("查询预警参数记录错误", e);
			throw new ServiceException("查询预警参数记录错误", e);
		}
	}

	@Override
	public List<EwsParam> queryEwsParamByPage(int start, int end) {
		if (start < 0 || end < 0) {
			logger.error("分页查询参数start和end为空");
			throw new ServiceException("分页查询参数start和end为空");
		}
		if (start > end) {
			logger.error("分页查询参数start比end的值大");
			throw new ServiceException("分页查询参数start比end的值大");
		}
		try {
			return ewsParamDao.queryEwsParamByPage(start, end);
		} catch (Exception e) {
			logger.error("分页查询出错:", e);
			throw new ServiceException("分页查询出错");
		}

	}

	@Override
	public List<EwsParam> queryEwsParamByOrderPage(int start, int end) {
		if (start < 0 || end < 0) {
			logger.error("分页排序查询参数start和end为空");
			throw new ServiceException("分页排序查询参数start和end为空");
		}
		if (start > end) {
			logger.error("分页排序查询参数start比end的值大");
			throw new ServiceException("分页排序查询参数start比end的值大");
		}
		try {
			return ewsParamDao.queryEwsParamByOrderPage(start, end);
		} catch (Exception e) {
			logger.error("分页排序查询出错:", e);
			throw new ServiceException("分页排序查询出错");
		}
	}

	@Override
	public List<EwsParam> queryAllTypesByParamTypeCode(String paramTypeCode) {
		try {
			if (StringUtils.isBlank(paramTypeCode)) {
				logger.error("查询所有类型的参数所属类别代码为空");
				return null;
			}
			EwsParam ewsParam = new EwsParam();
			ewsParam.setParamTypeCode(paramTypeCode);

			return ewsParamDao.queryEwsParamByParam(ewsParam);

		} catch (Exception e) {
			logger.error("参数类别【{}】查询错误:{}", paramTypeCode, e);
			return null;
		}
	}

	@Override
	public EwsParam queryEwsParamByParamCodeAndTypeCode(String paramCode, String paramTypeCode) {
		try {
			if (StringUtils.isBlank(paramCode)) {
				logger.error("查询参数记录时参数代码不可以为空");
				return null;
			}

			if (StringUtils.isBlank(paramTypeCode)) {
				logger.error("查询参数记录时参数所属类型不可以为空");
				return null;
			}

			return ewsParamDao.queryEwsParamByParamCodeAndTypeCode(paramCode, paramTypeCode);
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("通过参数及参数所属类型查询参数记录错误", e);
			return null;
		}
	}
}
