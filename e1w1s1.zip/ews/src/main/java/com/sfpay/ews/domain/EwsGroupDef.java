package com.sfpay.ews.domain;

import java.util.Date;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 风控预警群组定义表实体
 * EWS_GROUP_DEF
 * @author 625288
 *
 */
public class EwsGroupDef extends BaseEntity {

	private static final long serialVersionUID = 4125982810897657644L;
	
	private String groupNo;
	
	private String groupName;
	
	private String groupExplain;
	
	private String isValid;
	
	private String remark;
	
	private String droolsWsUrl;
	
	private String createId;
	
	private Date createTime;
	
	private String updateId;
	
	private Date updateTime;

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupExplain() {
		return groupExplain;
	}

	public void setGroupExplain(String groupExplain) {
		this.groupExplain = groupExplain;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return (Date)createTime.clone();
	}

	public void setCreateTime(Date createTime) {
		this.createTime = (Date)createTime.clone();
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return (Date)updateTime.clone();
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = (Date)updateTime.clone();
	}
	
	

	public String getDroolsWsUrl() {
		return droolsWsUrl;
	}

	public void setDroolsWsUrl(String droolsWsUrl) {
		this.droolsWsUrl = droolsWsUrl;
	}

	@Override
	public String toString() {
		return "WarnGroupDef [groupNo=" + groupNo + ", groupName=" + groupName
				+ ", groupExplain=" + groupExplain + ", isValid=" + isValid
				+ ", remark=" + remark + ", createId=" + createId
				+ ", createTime=" + createTime + ", updateId=" + updateId
				+ ", updateTime=" + updateTime + "]";
	}
}
