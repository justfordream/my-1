package com.sfpay.ews.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamResult;

import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.NodeList;

public class SOAPUtil {

	private static Logger logger = LoggerFactory.getLogger(SOAPUtil.class);

	private static SOAPMessage createSendSoapMessasge(String value)
			throws UnsupportedOperationException, SOAPException {

		// 创建消息对象
		// ===========================================
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage message = messageFactory.createMessage();
		// message.setProperty(SOAPMessage.CHARACTER_SET_ENCODING,
		// "gb2312");

		// 创建soap消息主体==========================================
		SOAPPart soapPart = message.getSOAPPart();// 创建soap部分
		SOAPEnvelope envelope = soapPart.getEnvelope();

		SOAPBody body = envelope.getBody();
		// 根据要传给mule的参数，创建消息body内容。具体参数的配置可以参照应用集成接口技术规范1.1版本
		// =====================================
		SOAPElement bodyElement = body.addChildElement(envelope.createName(
				SOAPConstants.DEFAULT_XMLNS,
				SOAPConstants.NAME_SPACE_XML_SCHEMA_PREFIX,
				SOAPConstants.NAME_SPACE_XML_SCHEMA));
		bodyElement
				.addChildElement(
						envelope.createName(SOAPConstants.DEFAULT_CHILD_XMLNS,
								SOAPConstants.NAME_SPACE_XML_SCHEMA_PREFIX,
								SOAPConstants.NAME_SPACE_XML_SCHEMA))
				.addChildElement(
						envelope.createName(SOAPConstants.DEFAULT_XMLNS_PARAM,
								SOAPConstants.NAME_SPACE_XML_SCHEMA_PREFIX,
								SOAPConstants.NAME_SPACE_XML_SCHEMA))
				.addTextNode(value);

		return message;

	}

	private static SOAPConnection createSOAPConnection()
			throws UnsupportedOperationException, SOAPException {

		SOAPConnectionFactory soapConnFactory = SOAPConnectionFactory
				.newInstance();
		SOAPConnection connection = soapConnFactory.createConnection();

		return connection;
	}

	public static void main(String[] args) throws SOAPException {
		String url = "http://10.118.201.93:9763/services/test/ruleCheck";

		Map<String, List<Map<String, Object>>> map = new HashMap<String, List<Map<String, Object>>>();
		map.put("test", new ArrayList<Map<String, Object>>());
		System.out.println(JSONObject.fromObject(map).toString());

		Map<String, String> map1 = new HashMap<String, String>();
		map1.put("test", "test");
		SOAPUtil.callWS(
				url,
				"{\"TEST0003.SQLPARAMKEY\":[{\"SYSBEGDATE\":\"2015-03-13 18\",\"SYSENDDATE\":\"2015-03-13 19\",\"UNSUCTHRESHOLD\":\"0.1\",\"DROOLSINPUT\":\"顺手付支付的总记录数A1:${COUNT2}笔，失败的记录数A2:${COUNT1}笔，支付失败率A2/A1:xxx，监控阀值A3:${UNSUCTHRESHOLD},违反监控规则（A2/A1>A3）\",\"SYSDATE\":\"2015-03-13 19:12:33\",\"BEGENDDATEFORMAT\":\"yyyy-mm-dd hh24\"}],\"TRADEALLNUM\":[{\"COUNT2\":999}],\"TRADEUNSUCNUM\":[{\"COUNT1\":199}]}");
	}

	public static List<RuleResponse> callWS(String wsurl, String sendValue)
			throws SOAPException {

		SOAPConnection connection = null;
		List<RuleResponse> responseList = new ArrayList<RuleResponse>();
		try {
			URL url = new URL(wsurl);

			SOAPMessage message = createSendSoapMessasge(sendValue);

			logger.info("send " + wsurl + "  value:" + transform(message));

			connection = createSOAPConnection();

			SOAPMessage reply = connection.call(message, url);

			logger.info("reponse " + wsurl + "  value:" + transform(reply));

			SOAPBody reponseBody = reply.getSOAPBody();
			NodeList nodes = reponseBody.getFirstChild().getChildNodes();

			for (int i = 0; i < nodes.getLength(); i++) {

				NodeList reponse = nodes.item(i).getChildNodes();

				if (reponse.getLength() > 0) {

					RuleResponse ruleResponse = new RuleResponse();
					// if(reponse.item(0) == null ||
					// reponse.item(0).getFirstChild() == null ||
					// reponse.item(0).getFirstChild().getNodeValue() == null) {
					// continue ;
					// }
					// ruleResponse.setCode(reponse.item(0).getFirstChild().getNodeValue());

					// if(reponse.item(1) == null ||
					// reponse.item(1).getFirstChild() == null ||
					// reponse.item(1).getFirstChild().getNodeValue() == null) {
					// continue ;
					// }

					ruleResponse.setMsg(Base64Util.base64ToString(reponse
							.item(1).getFirstChild().getNodeValue()));

					responseList.add(ruleResponse);
				}

			}
		} catch (Exception e) {

			logger.error("call wsurl fail", e);

			throw new SOAPException(e);

		} finally {

			if (connection != null) {
				try {
					connection.close();
				} catch (SOAPException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return responseList;

	}

	public static SOAPMessage transformFromSoapxml(String soapmessagexmml) {

		ByteArrayInputStream bais = null;
		MessageFactory mfactory = null;
		try {
			mfactory = MessageFactory.newInstance();
			bais = new ByteArrayInputStream(soapmessagexmml.getBytes("UTF-8"));
			return mfactory.createMessage(null, bais);

		} catch (SOAPException e) {
			throw new RuntimeException(
					"can NOT transform string to soap message: "
							+ soapmessagexmml, e);
		} catch (IOException e) {
			throw new RuntimeException(
					"can NOT transform string to soap message: "
							+ soapmessagexmml, e);
		} finally {
			if (bais != null) {
				try {
					bais.close();
				} catch (IOException e) {
				}
			}
		}
	}

	public static String transform(SOAPMessage request) {

		String ret = null;
		try {
			Source source = request.getSOAPPart().getContent();
			StreamResult result = new StreamResult(new ByteArrayOutputStream());
			Transformer trans = TransformerFactory.newInstance()
					.newTransformer();
			trans.transform(source, result);
			ByteArrayOutputStream baos = (ByteArrayOutputStream) result
					.getOutputStream();
			ret = new String(baos.toByteArray(), "UTF-8");

		} catch (TransformerConfigurationException e) {
			throw new RuntimeException("could NOT transform the message", e);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("could NOT transform the message", e);
		} catch (TransformerFactoryConfigurationError e) {
			throw new RuntimeException("could NOT transform the message", e);
		} catch (TransformerException e) {
			throw new RuntimeException("could NOT transform the message", e);
		} catch (SOAPException e) {
			throw new RuntimeException("could NOT transform the message", e);
		}
		return ret;
	}

}
