/**
 * 
 */
package com.sfpay.ews.support.sql;

import java.util.List;
import java.util.Map;

/**
 * 类说明：结果集对象
 * 
 * 类描述：能包含多种SQL执行的返回值
 * 
 * @author manzhizhen
 * 
 *         2015年2月20日
 */
public class ObjectResult {
	/**
	 * 普通的多列返回集
	 * 所有数据库字段都会转换成Object类型
	 */
	private volatile List<Map<String, Object>> objectMapList;

	/**
	 * 获取执行的结果
	 * @return
	 */
	public List<Map<String, Object>> get() {
		if(objectMapList != null && objectMapList.isEmpty()) {
			return null;
		} 
		
		return objectMapList;
	}
	
	/**
	 * 获取单个结果（单行单列）
	 * @return
	 */
	public Object getOne() {
		if(objectMapList != null) {
			if(objectMapList.isEmpty()) {
				return null;
			}
			
			Map<String, Object> resultMap = objectMapList.get(0);
			if(resultMap == null) {
				return null;
			}
			
			if(resultMap.values().size() != 1) {
				throw new IllegalStateException("无法获取单个结果！");
			} else {
				return resultMap.values().toArray()[0];
			}
			
		} 
		
		return null;
		
	}
	
	/**
	 * 是否是单行单列结果
	 * @return
	 */
	public boolean isOneResult() {
		if(objectMapList != null) {
			if(objectMapList.isEmpty()) {
				return false;
			}
			
			Map<String, Object> resultMap = objectMapList.get(0);
			if(resultMap == null) {
				return false;
			}
			
			if(resultMap.values().size() == 1) {
				return true;
			}
			
		} 
		
		return false;
	}

	public synchronized void setObjectMapList(List<Map<String, Object>> objectMapList) {
		this.objectMapList = objectMapList;
	}

	@Override
	public String toString() {
		return get() == null ? null : get().toString();
	}
}
