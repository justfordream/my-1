/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsIndexGroupReferDao;
import com.sfpay.ews.platform.domain.EwsIndexGroupRefer;
import com.sfpay.ews.platform.service.IEwsIndexGroupReferService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：预警指标和指标组映射服务实现类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
@HessianExporter
@Service("ewsIndexGroupReferService")
public class EwsIndexGroupReferServiceImpl implements IEwsIndexGroupReferService{

	@Autowired
	private IEwsIndexGroupReferDao ewsIndexGroupReferDao;
	
	private Logger logger = LoggerFactory.getLogger(EwsIndexGroupReferServiceImpl.class);
	
	@Override
	public Map<String, List<String>> queryAllRefer() {
		List<EwsIndexGroupRefer> ewsIndexGroupReferList = ewsIndexGroupReferDao.queryAll();
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		if(ewsIndexGroupReferList != null) {
			for(EwsIndexGroupRefer refer : ewsIndexGroupReferList) {
				if(!map.containsKey(refer.getWarnIndexGroupNo())) {
					map.put(refer.getWarnIndexGroupNo(), new ArrayList<String>());
				}
				
				map.get(refer.getWarnIndexGroupNo()).add(refer.getWarnIndexNo());
			}
		}
		
		return map;
	}

	@Override
	public List<String> queryWarnIndexByGroupNo(String groupNo) {
		logger.info("queryWarnIndexByGroupNo入参：{}", groupNo);
		if(StringUtils.isBlank(groupNo)) {
			throw new ServiceException("查询参数预警指标组编号不能为空！");
		}
		
		return ewsIndexGroupReferDao.queryByGroupNo(groupNo);
	}

}
