/**
 * 
 */
package com.sfpay.ews.service;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-27
 */
public interface IBeanShellService {
	/**
	 * 根据指标编号执行
	 * @param warnIndexNo
	 */
	public void executeShell(String warnIndexNo);
}
