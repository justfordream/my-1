package com.sfpay.ews.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsInfoRecordDao;
import com.sfpay.ews.platform.domain.EwsEffect;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsIndexSql;
import com.sfpay.ews.platform.domain.EwsInfoRecord;
import com.sfpay.ews.platform.domain.EwsParam;
import com.sfpay.ews.platform.service.IEwsEffectService;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsIndexSqlService;
import com.sfpay.ews.platform.service.IEwsInfoRecordService;
import com.sfpay.ews.platform.service.IEwsParamService;
import com.sfpay.ews.platform.util.EwsConstantsUtil;
import com.sfpay.ews.support.sql.ISqlExecutor;
import com.sfpay.ews.support.sql.ObjectResult;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类：预警信息记录Service 类描述：
 * 
 * @author 544772
 * @version 2015年3月28日 下午1:50:44
 */

@HessianExporter
@Service("ewsInfoRecordService")
public class EwsInfoRecordServiceImpl implements IEwsInfoRecordService {

	private static Logger logger = LoggerFactory.getLogger(EwsInfoRecordServiceImpl.class);

	@Autowired
	private IEwsInfoRecordDao ewsInfoRecordDao;

	@Autowired
	private IEwsEffectService ewsEffectService;

	@Autowired
	private IEwsParamService ewsParamService;

	@Autowired
	private IEwsIndexDefService ewsIndexDefService;

	@Autowired
	private IEwsIndexSqlService ewsIndexSqlService;

	@Autowired
	private ISqlExecutor executor;

	@Override
	public void updateEwsInfoRecord(EwsInfoRecord ewsInfoRecord) throws ServiceException {
		try {
			if (ewsInfoRecord == null) {
				logger.error("所需要更新的预警记录为空");
				throw new ServiceException("所需要更新的预警记录为空");
			}

			if (StringUtils.isBlank(ewsInfoRecord.getId())) {
				logger.error("更新预警记录时ID不可以为空");
				throw new ServiceException("更新预警记录时ID不可以为空");
			}
			ewsInfoRecordDao.updateEwsInfoRecord(ewsInfoRecord);
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("更新预警信息错误", e);
			throw new ServiceException("更新预警信息错误", e);
		}
	}

	@Override
	public void delEwsInfoRecord(String id) throws ServiceException {
		try {
			if (StringUtils.isBlank(id)) {
				logger.error("删除预警记录时ID不可以为空");
				throw new ServiceException("删除预警记录时ID不可以为空");
			}
			ewsInfoRecordDao.delEwsInfoRecord(id);
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("删除预警信息错误", e);
			throw new ServiceException("删除预警信息错误", e);
		}
	}

	@Override
	public EwsInfoRecord queryById(String id) {
		try {
			if (StringUtils.isBlank(id)) {
				logger.error("根据ID查询预警记录时ID不可以为空");
				return null;
			}
			EwsInfoRecord ewsInfoRecord = ewsInfoRecordDao.queryById(id);

			try {
				/**
				 * 判断该指标是否有明细结果数据
				 */
				
				if (ewsInfoRecord == null) {
					logger.error("预警记录ID为【{}】对应的记录为空，请提供有效的预警记录ID", id);
					throw new ServiceException("预警记录ID为【{}】对应的记录为空，请提供有效的预警记录ID", id);
				}
				if (StringUtils.isBlank(ewsInfoRecord.getWarnIndexNo())) {
					logger.error("预警记录ID为【{}】的指标编号为空", id);
					throw new ServiceException("预警记录ID为【{}】的指标编号为空", id);
				}

				EwsIndexDef ewsIndexDef = ewsIndexDefService.queryByWarnIndexNo(ewsInfoRecord.getWarnIndexNo());
				if (ewsIndexDef == null) {
					logger.error("指标编号为【{}】的指标未定义", ewsInfoRecord.getWarnIndexNo());
					throw new ServiceException(String.format("指标编号为【{%s}】的指标未定义", ewsInfoRecord.getWarnIndexNo()));
				}

				List<EwsIndexSql> ewsIndexSqlList = ewsIndexSqlService.queryEwsIndexSqlByWarnNo(ewsInfoRecord
						.getWarnIndexNo());
				if (CollectionUtils.isEmpty(ewsIndexSqlList)) {
					logger.error("指标编号为【{}】的指标无对应的指标SQL", ewsInfoRecord.getWarnIndexNo());
					throw new ServiceException(String.format("指标编号为【{%s}】的指标无对应的指标SQL", ewsInfoRecord.getWarnIndexNo()));
				}
				
				StringBuilder sqlString=new StringBuilder("select count(*) from ");
				ObjectResult objectResult;
				int noTableNameCount=0;
				for (EwsIndexSql ewsIndexSql : ewsIndexSqlList) {
					String tableName = ewsIndexSql.getTableName();
					//并不是所有的SQL语句都会有表名，只有输出明细的SQL语句，才会有表名
					if (StringUtils.isBlank(tableName)) {
						noTableNameCount++;
						if (ewsIndexSqlList.size()==noTableNameCount) {
							logger.error("指标【{}】的SQL语句均未配置输出表名",ewsInfoRecord.getWarnIndexNo());
							ewsInfoRecord.setDetailRecordCount("0");
						}
						continue;
					}
					sqlString.append(tableName);
					sqlString.append(" where INFO_RECORD_ID='");
					sqlString.append(id);
					sqlString.append("'");
					try {
						objectResult = executor.executorQuerySql(sqlString.toString());
						Long cnt=(Long)objectResult.getOne();
						ewsInfoRecord.setDetailRecordCount(cnt.toString());
					} catch (Exception e) {
						logger.error(String.format("指标SQL定义表中ID为【%s】的SQL【%s】执行出错", ewsIndexSql.getId(),
								ewsIndexSql.getWarnIndexSql()));
						throw new ServiceException(String.format("指标SQL定义表中ID为【%s】的SQL【%s】执行出错", ewsIndexSql.getId(),
								ewsIndexSql.getWarnIndexSql()));
					}
				}
				
			} catch (ServiceException e) {
				logger.error(e.getMessage());
				if (ewsInfoRecord!=null) {
					ewsInfoRecord.setDetailRecordCount("0");
				}
			}

			return ewsInfoRecord;
		} catch (Exception e) {
			logger.error("根据ID查询预警记录错误"+e.getMessage());
			return null;
		}
	}

	@Override
	public List<EwsInfoRecord> queryAll() {
		try {
			List<EwsInfoRecord> list = ewsInfoRecordDao.queryAll();
			return list;
		} catch (Exception e) {
			logger.error("查询全部预警记录时出错"+e.getMessage());
			return null;
		}

	}

	@Override
	public List<EwsInfoRecord> queryEwsInfoRecordByParam(EwsInfoRecord ewsInfoRecord) {
		try {
			if (ewsInfoRecord == null) {
				logger.error("查询预警记录时对象为空");
				return null;
			}
			List<EwsInfoRecord> list = ewsInfoRecordDao.queryEwsInfoRecordByParam(ewsInfoRecord);
			return list;
		} catch (Exception e) {
			logger.error("查询预警记录时出错"+ e.getMessage());
			return null;
		}
	}

	@Override
	public IPage<EwsInfoRecord> queryEwsHandleInfoByOrderPage(EwsInfoRecord ewsInfoRecord, int index, int size) {

		if (index < 0 || size <= 0) {
			logger.error("分页排序查询预警记录时页码出错");
			return null;
		}

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ewsInfoRecord", ewsInfoRecord);
		map.put("start", (index - 1) * size + 1);
		map.put("end", index * size);
		try {
			Long total = ewsInfoRecordDao.queryEwsInfoRecordCountByParam(ewsInfoRecord);
			List<EwsInfoRecord> list = ewsInfoRecordDao.queryEwsHandleInfoByOrderPage(map);
			return new Page<EwsInfoRecord>(list, total, index, size);

		} catch (Exception e) {
			logger.error("分页排序查询预警记录时出错"+e.getMessage());
			return null;
		}
	}

	@Override
	public String addEwsInfoRecord(EwsIndexDef ewsIndexDef, String warnContent, Date monitorDate, Date warnDate) throws ServiceException {
		try {
			if (ewsIndexDef == null) {
				logger.error("新增预警记录为空");
				throw new ServiceException("新增预警记录为空");
			}

			if (StringUtils.isBlank(ewsIndexDef.getWarnIndexNo())) {
				logger.error("指标编号不可以为空");
				throw new ServiceException("指标编号不可以为空");
			}

			if (StringUtils.isBlank(ewsIndexDef.getWarnStage())) {
				logger.error("预警阶段不可以为空");
				throw new ServiceException("预警阶段不可以为空");
			}
			if (StringUtils.isBlank(ewsIndexDef.getWarnSource())) {
				logger.error("预警来源不可以为空");
				throw new ServiceException("预警来源不可以为空");
			}

			if (StringUtils.isBlank(ewsIndexDef.getEffectCode())) {
				logger.error("指标时效代码不可以为空");
				throw new ServiceException("指标时效代码不可以为空");
			}

			String warnEffectCode = ewsIndexDef.getEffectCode();

			EwsEffect ewsEffect = ewsEffectService.queryByEffectCode(warnEffectCode);

			if (ewsEffect == null) {
				logger.error("指标时效代码错误");
				throw new ServiceException("指标时效代码错误");
			}
			EwsInfoRecord ewsInfoRecord = new EwsInfoRecord();
			ewsInfoRecord.setWarnIndexNo(ewsIndexDef.getWarnIndexNo());
			ewsInfoRecord.setWarnClassCode(ewsEffect.getWarnClassCode());
			EwsParam warnClassName=null;
			try {
				warnClassName = ewsParamService.queryEwsParamByParamCodeAndTypeCode(ewsEffect.getWarnClassCode(),
						EwsConstantsUtil.WARN_CLASS_CODE);
			} catch (Exception e) {
				logger.error("指标参数查询中，预警分类代码为【{}】的查询报错",ewsEffect.getWarnClassCode());
				logger.error("错误明细为:",e);
			}
			
			if (warnClassName != null) {
				ewsInfoRecord.setWarnClassName(warnClassName.getParamName());
			}else {
				logger.warn("指标参数查询中，预警分类代码为【{}】的分类名称为空",ewsEffect.getWarnClassCode());
			}
			ewsInfoRecord.setWarnStage(ewsIndexDef.getWarnStage());
			ewsInfoRecord.setRemark(ewsIndexDef.getRemark());
			
			EwsParam warnStageName=null;
			try {
				warnStageName = ewsParamService.queryEwsParamByParamCodeAndTypeCode(ewsIndexDef.getWarnStage(),
						EwsConstantsUtil.WARN_STAGE);
			} catch (Exception e) {
				logger.error("指标参数查询中，预警阶段代码为【{}】的查询报错",ewsIndexDef.getWarnStage());
				logger.error("错误明细为:",e);
			}
			if (warnStageName != null) {
				ewsInfoRecord.setWarnStageName(warnStageName.getParamName());
			}else {
				logger.warn("指标参数查询中，预警阶段代码为【{}】的名称为空",ewsIndexDef.getWarnStage());
			}

			ewsInfoRecord.setWarnSource(ewsIndexDef.getWarnSource());
			EwsParam warnSourceName=null;
			try {
				warnSourceName = ewsParamService.queryEwsParamByParamCodeAndTypeCode(ewsIndexDef.getWarnSource(),
						EwsConstantsUtil.WARN_SOURCE);
			} catch (Exception e) {
				logger.error("指标参数查询中，预警来源代码为【{}】的查询报错",ewsIndexDef.getWarnSource());
				logger.error("错误明细为:",e);
			}
			
			if (warnSourceName != null) {
				ewsInfoRecord.setWarnSourceName(warnSourceName.getParamName());
			}else {
				logger.warn("指标参数查询中，预警来源代码为【{}】的名称为空",ewsIndexDef.getWarnSource());
			}

			ewsInfoRecord.setWarnLevel(ewsEffect.getWarnLevel());
			
			EwsParam warnLevelName=null;
			try {
				warnLevelName = ewsParamService.queryEwsParamByParamCodeAndTypeCode(ewsEffect.getWarnLevel(),
						EwsConstantsUtil.WARN_LEVEL);
			} catch (Exception e) {
				logger.error("指标参数查询中，预警等级代码为【{}】的查询报错",ewsIndexDef.getWarnLevel());
				logger.error("错误明细为:",e);
			}
			if (warnLevelName != null) {
				ewsInfoRecord.setWarnLevelName(warnLevelName.getParamName());
			}else {
				logger.warn("指标参数查询中，预警等级代码为【{}】的名称为空",ewsIndexDef.getWarnLevel());
			}

			if (StringUtils.isBlank(warnContent)) {
				logger.error("预警内容不可以为空");
				throw new ServiceException("预警内容不可以为空");
			}
			ewsInfoRecord.setInfoContext(warnContent);
			ewsInfoRecord.setMonitorDate(monitorDate);
			ewsInfoRecord.setWarnDate(warnDate);
			ewsInfoRecord.setEffectTime(ewsEffect.getEffectTime());
			ewsInfoRecord.setOverEffectTime(ewsEffect.getOverEffectTime());
			ewsInfoRecord.setOprStatus("UNPROCESSED");// 未处理
			ewsInfoRecord.setCreateId("000000");
			ewsInfoRecord.setCreateTime(new Date());

			Long ewsInfoRecordSeq = ewsInfoRecordDao.getEwsInfoRecordSeqValue();
			String ewsInfoRecordId = ewsInfoRecord.getWarnIndexNo()
					+ DateUtils.formatDate(new Date(), "yyyyMMddHHmmss") + String.format("%04d", ewsInfoRecordSeq)
					+ ewsEffect.getWarnClassCode().charAt(0);
			ewsInfoRecord.setId(ewsInfoRecordId);
			ewsInfoRecordDao.addEwsInfoRecord(ewsInfoRecord);
			return ewsInfoRecordId;

		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("新增预警信息错误", e);
			throw new ServiceException("新增预警信息错误", e);
		}
	}

	@Override
	public Map<String, List<Map<String, Object>>> queryEwsDetailInfoByEwsInfoId(String ewsInfoRecordId) {
		try {
			if (StringUtils.isBlank(ewsInfoRecordId)) {
				logger.error("预警记录ID不可以为空");
				return null;
			}
			EwsInfoRecord ewsInfoRecord = ewsInfoRecordDao.queryById(ewsInfoRecordId);
			if (ewsInfoRecord == null) {
				logger.error("预警记录ID为【{}】对应的记录为空，请提供有效的预警记录ID", ewsInfoRecordId);
				return null;
			}
			if (StringUtils.isBlank(ewsInfoRecord.getWarnIndexNo())) {
				logger.error("预警记录ID为【{}】的指标编号为空", ewsInfoRecordId);
				return null;
			}

			EwsIndexDef ewsIndexDef = ewsIndexDefService.queryByWarnIndexNo(ewsInfoRecord.getWarnIndexNo());
			if (ewsIndexDef == null) {
				logger.error("指标编号为【{}】的指标未定义", ewsInfoRecord.getWarnIndexNo());
				return null;
			}

			List<EwsIndexSql> ewsIndexSqlList = ewsIndexSqlService.queryEwsIndexSqlByWarnNo(ewsInfoRecord
					.getWarnIndexNo());
			if (CollectionUtils.isEmpty(ewsIndexSqlList)) {
				logger.error("指标编号为【{}】的指标无对应的指标SQL", ewsInfoRecord.getWarnIndexNo());
				return null;
			}
			// 定义结果Map，存放所有SQL执行结果
			Map<String, List<Map<String, Object>>> resultMap = new HashMap<String, List<Map<String, Object>>>();
			// 定义Where语句,使用预警记录主键（INFO_RECORD_ID）进行关联
			Map<String, Object> whereMap = new HashMap<String, Object>();
			whereMap.put("INFO_RECORD_ID", ewsInfoRecordId);
			
			for (EwsIndexSql ewsIndexSql : ewsIndexSqlList) {
				String tableName = ewsIndexSql.getTableName();
				//并不是所有的SQL语句都会有表名，只有输出明细的SQL语句，才会有表名
				if (StringUtils.isBlank(tableName)) {
					continue;
				}
				List<Map<String, Object>> singleSqlResult = null;
				try {
					singleSqlResult = executor.queryByParam(tableName, whereMap, null);
					resultMap.put(tableName, singleSqlResult);

				} catch (Exception e) {
					logger.error(String.format("指标SQL定义表中ID为【%s】的SQL【%s】执行出错", ewsIndexSql.getId(),
							ewsIndexSql.getWarnIndexSql()));
					throw new ServiceException(String.format("指标SQL定义表中ID为【%s】的SQL【{%s}】执行出错", ewsIndexSql.getId(),
							ewsIndexSql.getWarnIndexSql()));
				}
			}

			return resultMap;
		} catch (ServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("新增预警信息错误", e);
			throw new ServiceException("新增预警信息错误", e);
		}
	}

}
