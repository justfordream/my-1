/**
 * 
 */
package com.sfpay.ews.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsGroupDef;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 *	类：预警群组维护
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月8日 上午11:15:10
 */
public interface IEwsGroupDefDao {
	/**
	 * 
	 * 方法：新增预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef
	 */
	public void addEwsGroupDef(EwsGroupDef ewsGroupDef);
	
	/**
	 * 
	 * 方法：更新预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef
	 */
	public void updateEwsGroupDef(EwsGroupDef ewsGroupDef);
	
	/**
	 * 
	 * 方法：删除预警群组
	 * 方法说明：
	 *
	 * @param groupNo
	 */
	public void delEwsGroupDef(@Param("groupNo")String groupNo);
	
	/**
	 * 
	 * 方法：通过主键查询预警群组
	 * 方法说明：
	 *
	 * @param groupNo
	 * @return
	 */
	public EwsGroupDef queryByGroupNo(@Param("groupNo")String groupNo);
	
	/**
	 * 
	 * 方法：通过参数查询预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef
	 * @return
	 */
	public List<EwsGroupDef> queryEwsGroupDefByParam(EwsGroupDef ewsGroupDef);
	
	/**
	 * 
	 * 方法：通过参数分页查询预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef
	 * @param start
	 * @param end
	 * @return
	 */
	public List<EwsGroupDef> queryEwsGroupDefByOrderPage(Map<String, Object> map);
	
	/**
	 * 
	 * 方法：通过参数查询预警总数
	 * 方法说明：
	 *
	 * @param ewsGroupDef
	 * @return
	 */
	public Long queryEwsGroupDefCntByParam(EwsGroupDef ewsGroupDef);
	
	/**
	 * 根据群组编号查询已授权指标
	 * @param groupNo 群组编号
	 * @return 返回记录
	 * @throws ServiceException 自定义异常
	 */
	public List<EwsIndexDef> queryAuthIndexByGroupNo(@Param("groupNo")String groupNo);
	
	/**
	 * 根据群组编号查询未授权指标
	 * @param groupNo 群组编号
	 * @return 返回记录
	 * @throws ServiceException 自定义异常
	 */
	public List<EwsIndexDef> queryUnAuthIndexByGroupNo(@Param("groupNo")String groupNo);
	
}
