package com.sfpay.ews.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsInfoRecord;

/**
 * 
 *	类：预警信息记录表DAO接口
 *	类描述：预警信息记录表DAO接口
 *
 * @author 544772
 * @version 2015年3月28日 下午1:26:09
 */
public interface IEwsInfoRecordDao {
	
	/**
	 * 
	 * 方法：获取预警信息序列ID
	 * 方法说明：获取的序列ID供新增预警信息记录的ID使用
	 *
	 * @return
	 */
	public Long getEwsInfoRecordSeqValue();
	/**
	 * 
	 * 方法：新增预警信息记录
	 * 方法说明：
	 *
	 * @param ewsInfoRecord
	 */
	public void addEwsInfoRecord(EwsInfoRecord ewsInfoRecord);
	
	/**
	 * 
	 * 方法：更新预警信息记录
	 * 方法说明：
	 *
	 * @param ewsInfoRecord
	 */
	public void updateEwsInfoRecord(EwsInfoRecord ewsInfoRecord);
	
	/**
	 * 
	 * 方法:删除预警信息记录
	 * 方法说明：
	 *
	 * @param id
	 */
	public void delEwsInfoRecord(@Param("id") String id);
	
	/**
	 * 
	 * 方法：根据主键查询预警信息记录
	 * 方法说明：
	 *
	 * @param id
	 * @return
	 */
	public EwsInfoRecord queryById(@Param("id") String id);
	
	/**
	 * 
	 * 方法：返回所有预警信息记录
	 * 方法说明：
	 *
	 * @return
	 */
	public List<EwsInfoRecord> queryAll();
	
	/**
	 * 
	 * 方法：根据输入参数，查询预警信息记录
	 * 方法说明：
	 *
	 * @param ewsInfoRecord
	 * @return
	 */
	public List<EwsInfoRecord> queryEwsInfoRecordByParam(EwsInfoRecord ewsInfoRecord);
	
	
	/**
	 * 
	 * 方法：分页排序查询预警信息
	 * 方法说明：
	 *
	 * @param map
	 * @return
	 */
	public List<EwsInfoRecord> queryEwsHandleInfoByOrderPage(Map<String, Object> map);
	
	/**
	 * 
	 * 方法：根据参数查询总数
	 * 方法说明：
	 *
	 * @param ewsInfoRecord
	 * @return
	 */
	public Long queryEwsInfoRecordCountByParam(EwsInfoRecord ewsInfoRecord);

}
