package com.sfpay.ews.common;

import java.io.UnsupportedEncodingException;

import org.apache.shiro.codec.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Base64Util {
	private static Logger logger = LoggerFactory.getLogger(Base64Util.class);
	
	public static String base64ToString(String value) {
		String result = "";
		try {
			result = new String(Base64.decode(value), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error("base64ToString转化失败：", e);
		}

		return result;
	}

	public static String stringTobase64(String value) {
		String result = "";
		try {
			result =  Base64.encodeToString(value.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			logger.error("stringTobase64转化失败：", e);
		}

		return result;
	}

}
