package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsIndexDef;


/**
 * 预警指标的数据接口
 * @author 575740
 *
 */
public interface IEwsIndexDefDao {

     /**
      * 根据预警编号查找该预警指标的信息;
      * @param warnIndexNo
      * @return
      */
	public EwsIndexDef queryByWarnIndexNo(@Param("warnIndexNo") String warnIndexNo,@Param("isValid") String isValid);
	
	/**
	 * 新增一个指标
	 * @param indexDef
	 * @return
	 */
	public int addEwsIndexDef(EwsIndexDef indexDef);
	
	/**
	 * 查询指标总记录
	 * @param indexDef
	 * @return
	 */
	public int queryEwsIndexDefCount(@Param("param")EwsIndexDef indexDef);
	
	/**
	 * 分页查询指标
	 * @param indexDef
	 * @param index
	 * @param size
	 * @return
	 */
	public List<EwsIndexDef> queryEwsIndexDefByPage(@Param("param")EwsIndexDef indexDef,
			@Param("index")int index,
			@Param("size")int size);
	
	/**
	 * 修改指标
	 * @param indexDef
	 * @return
	 */
	public int updateEwsIndexDef(EwsIndexDef indexDef);
	
	/**
	 * 根据指标编号查询指标
	 * @param indexNo
	 * @return
	 */
	public EwsIndexDef queryByWarnIndexNo(@Param("warnIndexNo") String indexNo);
	
	/**
	 * 根据预警来源查询所有指标
	 * @param warnSource
	 * @return
	 */
	public List<EwsIndexDef> queryByWarnSource(@Param("warnSource")String warnSource);
	
	/**
	 * 查询所有预警指标
	 * @return
	 */
	public List<EwsIndexDef> queryAllIndexDef();
	
	/**
	 * 更新指标调度状态
	 * @param warnIndexNo
	 * @param status 只能是START和CLOSE两种值
	 */
	public void updateIndexSchStatus(@Param("warnIndexNo")String warnIndexNo, @Param("status")String status);
	
	/**
	 * 更新指标调度运行状态
	 * @param warnIndexNo
	 * @param runStatus 只能是RUNNING和STOP两种值
	 */
	public void updateIndexSchRunStatus(@Param("warnIndexNo")String warnIndexNo,
			@Param("runStatus")String runStatus);
	
	/**
	 * 将所有指标调度运行状态修改成STOP
	 */
	public void updateAllIndexSchRunStatusToStop();
}
