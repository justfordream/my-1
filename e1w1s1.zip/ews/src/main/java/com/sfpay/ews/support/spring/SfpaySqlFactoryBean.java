/**
 * 
 */
package com.sfpay.ews.support.spring;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;


/**
 * 类说明：Spring框架中的会话工厂Bean
 *
 * 类描述：
 * @author manzhizhen
 *
 * 2015年2月25日
 */
public class SfpaySqlFactoryBean {
	private DataSource dataSource;
	
	  /**
	   * Set the JDBC {@code DataSource} that this instance should manage transactions for. The {@code DataSource}
	   * should match the one used by the {@code SqlSessionFactory}: for example, you could specify the same
	   * JNDI DataSource for both.
	   *
	   * A transactional JDBC {@code Connection} for this {@code DataSource} will be provided to application code
	   * accessing this {@code DataSource} directly via {@code DataSourceUtils} or {@code DataSourceTransactionManager}.
	   *
	   * The {@code DataSource} specified here should be the target {@code DataSource} to manage transactions for, not
	   * a {@code TransactionAwareDataSourceProxy}. Only data access code may work with
	   * {@code TransactionAwareDataSourceProxy}, while the transaction manager needs to work on the
	   * underlying target {@code DataSource}. If there's nevertheless a {@code TransactionAwareDataSourceProxy}
	   * passed in, it will be unwrapped to extract its target {@code DataSource}.
	   *
	   */
	  public void setDataSource(DataSource dataSource) {
	    if (dataSource instanceof TransactionAwareDataSourceProxy) {
	      // If we got a TransactionAwareDataSourceProxy, we need to perform
	      // transactions for its underlying target DataSource, else data
	      // access code won't see properly exposed transactions (i.e.
	      // transactions for the target DataSource).
	      this.dataSource = ((TransactionAwareDataSourceProxy) dataSource).getTargetDataSource();
	    } else {
	      this.dataSource = dataSource;
	    }
	  }
	  
	  /**
	   * 获取数据库连接
	   * @return
	 * @throws SQLException 
	   */
	  public Connection getConnection() throws SQLException {
		  if(dataSource == null) {
			  throw new IllegalStateException("数据源为空！");
		  }
		  return dataSource.getConnection();
	  }
	  
}
