package com.sfpay.ews.service;

public interface ISendSMSService {
	
	/**
	 * 方法说明：发短信通知
	 * @param mobile 手机号
	 * @param message 短信内容
	 */
	public void sendMessage(final String mobile,final String message);

}
