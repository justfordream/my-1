package com.sfpay.ews.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsIndexDefDao;
import com.sfpay.ews.platform.domain.EwsEffect;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsParam;
import com.sfpay.ews.platform.service.IEwsEffectService;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsParamService;
import com.sfpay.ews.platform.util.EwsConstantsUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 指标定义的接口
 * 
 * @author 575740
 * 
 */
@HessianExporter
@Service("ewsIndexDefService")
public class EwsIndexDefServiceImpl implements IEwsIndexDefService {
//	@Autowired
//	private IEwsSchedulerService ewsSchedulerService;
	private Logger logger = LoggerFactory.getLogger(EwsIndexDefServiceImpl.class);
	
	@Autowired
	private IEwsIndexDefDao ewsIndexDefDao;
	@Autowired
	private IEwsEffectService ewsEffectService;
	@Autowired
	private IEwsParamService ewsParamService;
	

	@Override
	public EwsIndexDef queryByWarnIndexNo(String warnIndexNo) throws ServiceException {
		if (StringUtils.isBlank(warnIndexNo)) {
			throw new ServiceException("预警指标编号为空，不能查询!");
		}

		EwsIndexDef ewsIndexDef = null;
		try {
			logger.info("根据指标编号和标志查询风控指标资料--开始(queryEwsIndexDefByWarnIndexNo): ");
			ewsIndexDef = ewsIndexDefDao.queryByWarnIndexNo(
					warnIndexNo);
			logger.info("根据指标编号和标志查询风控指标资料--结束(queryEwsIndexDefByWarnIndexNo)--结果： "
					+ ewsIndexDef);
			
		} catch (Exception e) {
			logger.error("根据指标编号和标志查询指标异常" + e.getMessage());
			throw new ServiceException("根据指标编号和标志查询指标异常", e);
		}
		
		return ewsIndexDef;
	}

	@Override
	public void addEwsIndexDef(EwsIndexDef indexDef) throws ServiceException {
		logger.info("addEwsIndexDef 指标对象 = " + indexDef);

		checkEwsIndexDef(indexDef);
		
		logger.info("指标编号 = " + indexDef.getWarnIndexNo());
		EwsIndexDef oldEwsIndexDef = ewsIndexDefDao.queryByWarnIndexNo(indexDef
				.getWarnIndexNo());
		try {
			if (oldEwsIndexDef != null) {
				throw new ServiceException("该指标编号已经存在");
			}
			
			checkEffectCode(indexDef);
			
			checkWarnSource(indexDef);
			
			checkWarnStage(indexDef);
			
			checkWarnProperty(indexDef);
			
			// 新增指标调度信息
//			ewsSchedulerService.addEwsIndexDefSch(indexDef);
			
			ewsIndexDefDao.addEwsIndexDef(indexDef);
			
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage(), e);
			
		} catch (Exception e) {
			logger.error("新增指标记录错误", e);
			throw new ServiceException("新增指标记录错误", e);
		}
	}

	@Override
	public void updateEwsIndexDef(EwsIndexDef indexDef) throws ServiceException {
		logger.info("updateEwsIndexDef 指标参数对象 = " + indexDef);

		checkUpdateIndexDef(indexDef);

		logger.info("指标编号 = " + indexDef.getWarnIndexNo());
		EwsIndexDef oldEwsIndexDef = ewsIndexDefDao.queryByWarnIndexNo(indexDef
				.getWarnIndexNo());
		try {
			if (oldEwsIndexDef == null) {
				throw new ServiceException(String.format("指标编号【%s】不存在！", indexDef.getWarnIndexNo()));
			}
			
			if(StringUtils.isNotBlank(indexDef.getEffectCode()) && 
					!StringUtils.equals(indexDef.getEffectCode(), oldEwsIndexDef.getEffectCode())) {
				checkEffectCode(indexDef);
			}
			
			checkWarnSource(indexDef);
			
			checkWarnStage(indexDef);
			
			checkWarnProperty(indexDef);
			
//			if(!StringUtils.equals(indexDef.getCronExpress(), oldEwsIndexDef.getCronExpress())) {
//				logger.info("预警指标【{}】调度表达式有更改，开始更改指标调度任务... ...", indexDef.getWarnIndexNo());
//				ewsSchedulerService.updateEwsIndexDefSch(indexDef);
//				logger.info("预警指标【{}】调度任务任务更新完毕！", indexDef.getWarnIndexNo());
//			}
			
			// 修改指标
			indexDef.setUpdateTime(new Date());
			
			ewsIndexDefDao.updateEwsIndexDef(indexDef);
			
		} catch (ServiceException e) {
			throw e;
			
		} catch (Exception e) {
			logger.error("修改指标记录错误", e);
			throw new ServiceException("修改指标记录错误", e);
		}
	}

	@Override
	public IPage<EwsIndexDef> queryEwsIndexDefByPage(EwsIndexDef indexDef,
			int index, int size) throws ServiceException {
		logger.info("指标分页查询参数对象 = " + indexDef);
		if (indexDef == null) {
			throw new ServiceException("查询参数为空");
		}

		if (index <= 0 || size <= 0) {
			throw new ServiceException("分页参数index,size为空");
		}

		try {
			int row = ewsIndexDefDao.queryEwsIndexDefCount(indexDef);
			logger.info("指标分页总数量 = " + row);
			List<EwsIndexDef> result = new ArrayList<EwsIndexDef>();
			if (row > 0) {
				result = ewsIndexDefDao.queryEwsIndexDefByPage(indexDef,
						index, size);
			}
			
			return new Page<EwsIndexDef>(result, row, index, size);
			
		} catch (Exception e) {
			logger.error("指标分页查询错误", e);
			throw new ServiceException("指标分页查询错误", e);
		}
	}

	@Override
	public List<EwsIndexDef> queryByWarnSource(String warnSource) {
		logger.info("warnSource = " + warnSource);
		
		if(StringUtils.isBlank(warnSource)) {
			logger.error("预警来源不能为空");
			throw new ServiceException("预警来源不能为空");
		}
		
		try {
			return ewsIndexDefDao.queryByWarnSource(warnSource);
			
		} catch (Exception e) {
			logger.error("根据预警来源查询下属指标错误", e);
			throw new ServiceException("根据预警来源查询下属指标错误", e);
		}
	}

	@Override
	public List<EwsIndexDef> queryAllIndexDef() {
		logger.info("queryAllIndexDef ... ...");
		try {
			return ewsIndexDefDao.queryAllIndexDef();
			
		} catch (Exception e) {
			logger.error("查询所有预警指标错误", e);
			throw new ServiceException("查询所有预警指标错误", e);
		}
	}
	
	/**
	 * 检查新增指标对象正确性
	 * @param indexDef
	 */
	private void checkEwsIndexDef(EwsIndexDef indexDef) {
		checkUpdateIndexDef(indexDef);

		if (StringUtils.isBlank(indexDef.getWarnIndexName())) {
			throw new ServiceException("指标名称不能为空");
		}
		
		if (StringUtils.isBlank(indexDef.getCronExpress())) {
			throw new ServiceException("指标调度表达式不能为空");
		}
		
		if (StringUtils.isBlank(indexDef.getWarnSource())) {
			throw new ServiceException("指标预警来源不能为空");
		}

		if (StringUtils.isBlank(indexDef.getWarnStage())) {
			throw new ServiceException("预警阶段不能为空");
		}

		if (StringUtils.isBlank(indexDef.getWarnProperty())) {
			throw new ServiceException("预警性质不能为空");
		}

		if (StringUtils.isBlank(indexDef.getEffectCode())) {
			throw new ServiceException("实效代码不能为空");
		}

		if (StringUtils.isBlank(indexDef.getIsValid())) {
			throw new ServiceException("指标的有效标志不能为空");
		}
	}
	
	/**
	 * 检查更新指标对象正确性
	 * @param indexDef
	 */
	private void checkUpdateIndexDef(EwsIndexDef indexDef) {
		if (indexDef == null) {
			throw new ServiceException("指标对象为空");
		}

		if (StringUtils.isBlank(indexDef.getWarnIndexNo())) {
			throw new ServiceException("指标编号为空");
		}
	}
	
	/**
	 * 检查实效代码是否存在
	 * @param indexDef
	 */
	private void checkEffectCode(EwsIndexDef indexDef) {
		if(StringUtils.isNotBlank(indexDef.getEffectCode()) && ewsEffectService.queryByEffectCode(indexDef.getEffectCode()) == null) {
			logger.error("新增预警指标【{}】出错，无效的实效代码【{}】！", indexDef.getWarnIndexNo(), 
					indexDef.getEffectCode());
			throw new ServiceException(String.format("新增预警指标【%s】出错，无效的实效代码【%s】！", 
					new Object[]{indexDef.getWarnIndexNo(), indexDef.getEffectCode()}));
			
		} else if(StringUtils.isBlank(indexDef.getEffectCode()) && StringUtils.isNotBlank(indexDef.getWarnClassCode()) 
				&& StringUtils.isNotBlank(indexDef.getWarnLevel())) {
			EwsEffect ewsEffect = ewsEffectService.queryByWarnClassAndWarnLevel(indexDef.getWarnClassCode(), indexDef.getWarnLevel());
			if(ewsEffect == null) {
				logger.error(String.format("新增预警指标【%s】出错，没有对应【%s-%s】的实效代码！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnClassCode(), indexDef.getWarnLevel()}));
				throw new ServiceException(String.format("新增预警指标【%s】出错，没有对应【%s-%s】的实效代码！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnClassCode(), indexDef.getWarnLevel()}));
			}
			
			indexDef.setEffectCode(ewsEffect.getEffectCode());
		}
	}
	
	/**
	 * 检查告警源是否存在
	 * @param indexDef
	 */
	private void checkWarnSource(EwsIndexDef indexDef) {
		if(StringUtils.isNotBlank(indexDef.getWarnSource())) {
			List<EwsParam> ewsParamList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_SOURCE);
			boolean isExist = false;
			if(ewsParamList != null) {
				for(EwsParam param : ewsParamList) {
					if(StringUtils.equals(indexDef.getWarnSource(), param.getParamCode())) {
						isExist = true;
						break ;
					}
				}
			}
			
			if(!isExist) {
				logger.error(String.format("新增预警指标【%s】出错，无效的预警来源【%s】！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnSource()}));
				throw new ServiceException(String.format("新增预警指标【%s】出错，无效的预警来源【%s】！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnSource()}));
			}
		}
	}
	
	/**
	 * 检查告预警阶段
	 * @param indexDef
	 */
	private void checkWarnStage(EwsIndexDef indexDef) {
		if(StringUtils.isNotBlank(indexDef.getWarnStage())) {
			List<EwsParam> ewsParamList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_STAGE);
			boolean isExist = false;
			if(ewsParamList != null) {
				for(EwsParam param : ewsParamList) {
					if(StringUtils.equals(indexDef.getWarnStage(), param.getParamCode())) {
						isExist = true;
						break ;
					}
				}
			}
			
			if(!isExist) {
				logger.error(String.format("新增预警指标【%s】出错，无效的预警阶段【%s】！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnStage()}));
				throw new ServiceException(String.format("新增预警指标【%s】出错，无效的预警阶段【%s】！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnStage()}));
			}
		}
	}
	
	/**
	 * 检查告预警性质
	 * @param indexDef
	 */
	private void checkWarnProperty(EwsIndexDef indexDef) {
		if(StringUtils.isNotBlank(indexDef.getWarnProperty())) {
			List<EwsParam> ewsParamList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_PROPERTY);
			boolean isExist = false;
			if(ewsParamList != null) {
				for(EwsParam param : ewsParamList) {
					if(StringUtils.equals(indexDef.getWarnProperty(), param.getParamCode())) {
						isExist = true;
						break ;
					}
				}
			}
			
			if(!isExist) {
				logger.error(String.format("新增预警指标【%s】出错，无效的预警性质【%s】！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnProperty()}));
				throw new ServiceException(String.format("新增预警指标【%s】出错，无效的预警性质【%s】！", 
						new Object[]{indexDef.getWarnIndexNo(), indexDef.getWarnProperty()}));
			}
		}
	}

	/**
	 * 更新指标调度状态
	 * @param warnIndexNo
	 * @param status 只能是START和CLOSE两种值
	 */
	@Override
	public void updateIndexSchStatus(String warnIndexNo, String status) {
		logger.info(String.format("updateIndexSchStatus %s %s ... ...", new Object[]{warnIndexNo, status}));
		
		if(StringUtils.isBlank(warnIndexNo)) {
			logger.error("指标编号不能为空");
			throw new ServiceException("指标编号不能为空");
		}
		
		if(StringUtils.isBlank(status)) {
			logger.error("调度状态不能为空");
			throw new ServiceException("调度状态不能为空");
		}
		
		if(!"CLOSE".equals(status) && !"START".equals(status)) {
			logger.error("调度状态的值只能是【START】或【CLOSE】");
			throw new ServiceException("调度状态的值只能是【START】或【CLOSE】");
		}
		
		if(queryByWarnIndexNo(warnIndexNo) == null) {
			logger.error("指标编号【{}】不存在！", warnIndexNo);
			throw new ServiceException(String.format("指标编号【%s】不存在！", warnIndexNo));
		}
		
		ewsIndexDefDao.updateIndexSchStatus(warnIndexNo, status);
		logger.info(String.format("成功将指标【%s】调度状态修改成【%s】！", new Object[]{warnIndexNo, status}));
		
		logger.info(String.format("updateIndexSchStatus %s %s end", new Object[]{warnIndexNo, status}));
	}

	/**
	 * 更新指标调度运行状态
	 * @param warnIndexNo
	 * @param runStatus 只能是RUNNING和STOP两种值
	 */
	@Override
	public void updateIndexSchRunStatus(String warnIndexNo, String runStatus) {
		logger.info(String.format("updateIndexSchRunStatus %s %s ... ...", new Object[]{warnIndexNo, runStatus}));
		
		if(StringUtils.isBlank(warnIndexNo)) {
			logger.error("指标编号不能为空");
			throw new ServiceException("指标编号不能为空");
		}
		
		if(StringUtils.isBlank(runStatus)) {
			logger.error("调度运行状态不能为空");
			throw new ServiceException("调度运行状态不能为空");
		}
		
		if(!"RUNNING".equals(runStatus) && !"STOP".equals(runStatus)) {
			logger.error("调度状态的值只能是【RUNNING】或【STOP】");
			throw new ServiceException("调度状态的值只能是【RUNNING】或【STOP】");
		}
		
		if(queryByWarnIndexNo(warnIndexNo) == null) {
			logger.error("指标编号【{}】不存在！", warnIndexNo);
			throw new ServiceException(String.format("指标编号【%s】不存在！", warnIndexNo));
		}
		
		ewsIndexDefDao.updateIndexSchRunStatus(warnIndexNo, runStatus);
		logger.info(String.format("成功将指标【%s】调度运行状态修改成【%s】！", new Object[]{warnIndexNo, runStatus}));
		
		logger.info(String.format("updateIndexSchRunStatus %s %s end", new Object[]{warnIndexNo, runStatus}));
	}

	@Override
	public void updateAllIndexSchRunStatusToStop() {
		ewsIndexDefDao.updateAllIndexSchRunStatusToStop();
	}
	
}
