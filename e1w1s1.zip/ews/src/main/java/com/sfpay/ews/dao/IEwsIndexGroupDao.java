/**
 * 
 */
package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsIndexGroup;

/**
 * 类说明：预警指标组Dao
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
public interface IEwsIndexGroupDao {
	/**
	 * 查询所有的预警指标组
	 * @return
	 */
	public List<EwsIndexGroup> queryAllEwsIndexGroup();
	
	/**
	 * 根据预警组编号查询预警指标组
	 * @param groupNo 预警组编号
	 * @return
	 */
	public EwsIndexGroup queryEwsIndexGroupByGroupNo(@Param("warnIndexGroupNo")String groupNo);

}
