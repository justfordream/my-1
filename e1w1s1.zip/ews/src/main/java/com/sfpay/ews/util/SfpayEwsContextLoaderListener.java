/**
 * 
 */
package com.sfpay.ews.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

/**
 * 类说明：监控预警的上下文加载监听器
 *
 * 类描述：
 * @author manzhizhen
 *
 * 2015年3月1日
 */
@Service
public class SfpayEwsContextLoaderListener implements ApplicationContextAware {
	private static ApplicationContext context;
	/**
	 * 获取Spring容器中的对象
	 * @return
	 */
	public static Object getBean(String beanName) {
		if(context == null) {
			return null;
		}
		
		return context.getBean(beanName);
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		context = applicationContext;
	}

}
