/**
 * 
 */
package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsRule;

/**
 * 类说明：预警规则Dao
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-25
 */
public interface IEwsRuleDao {
	/**
	 * 通过指标编号查找预警规则
	 * @param ewsIndexNo
	 * @return
	 */
	public List<EwsRule> queryByEwsIndexNo(@Param("warnIndexNo")String ewsIndexNo);
	
	/**
	 * 通过指标编号查找被标记为结果的预警规则
	 * @param ewsIndexNo
	 * @return
	 */
	public EwsRule queryResultEwsRule(String ewsIndexNo);
	
	/**
	 * 新增一个预警规则
	 * @param ewsRule
	 */
	public void addEwsRule(EwsRule ewsRule);
	
	/**
	 * 更新一个预警规则
	 * @param ewsRule
	 */
	public void updateEwsRule(EwsRule ewsRule);
	
	/**
	 * 删除一个预警规则
	 * @param ewsRule
	 */
	public void deleteEwsRule(@Param("id") long id);
	
	/**
	 * 通过ID来查询预警规则
	 * @param id
	 * @return
	 */
	public EwsRule queryById(@Param("id") long id);
	
	/**
	 * 通过指标编号和参数名称查询
	 * @param warnIndexNo
	 * @param paramName
	 * @return
	 */
	public EwsRule queryByIndexNoAndParamName(@Param("warnIndexNo") String warnIndexNo, 
			@Param("paramName") String paramName);
	
	/**
	 * 查询指标规则总记录
	 * @param ewsRule
	 * @return
	 */
	public int queryEwsRuleCount(@Param("ewsRule")EwsRule ewsRule);
	
	/**
	 * 分页查询指标规则
	 * @param ewsRule
	 * @param index
	 * @param size
	 * @return
	 */
	public List<EwsRule> queryByPage(@Param("ewsRule")EwsRule ewsRule,
			@Param("start")int start,
			@Param("end")int end);
}
