package com.sfpay.ews.service.impl;


import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.ews.service.IEwsSendMailAndSmsService;
import com.sfpay.ews.service.ISendSMSService;
import com.sfpay.ews.service.ISenderMailService;

@Service("ewsSendMailAndSmsService")
public class EwsSendMailAndSmsServiceImpl implements IEwsSendMailAndSmsService {
	private static Logger logger = LoggerFactory.getLogger(EwsSendMailAndSmsServiceImpl.class);

	/**
	 * 调用邮件服务
	 */
	@Autowired
	private ISenderMailService sendMailServce;

	/**
	 * 调用短信服务
	 */
	@Autowired
	private ISendSMSService sendSMSServce;


	@Override
	public void sendWarnIndexMail(List<EwsEmpGroupRefer> ewsEmpGroupReferList, String mailTitle,
			List<String> mailContextList) {
		logger.info("调用邮件服务sendWarnIndexMail开始... ...");

		if (ewsEmpGroupReferList == null) {
			logger.warn("监控预警发送的邮件对象为空！");
			return;
		}
		if (StringUtils.isBlank(mailTitle) || mailContextList == null || mailContextList.isEmpty()) {
			logger.warn("监控预警发送的邮件标题或邮件内容不能为空！");
			return;
		}

		for (EwsEmpGroupRefer ewsEmpGroupRefer : ewsEmpGroupReferList) {
			if ("Y".equals(ewsEmpGroupRefer.getIsMailNotify())) {
				logger.info("向人员【{}】【{}】发送邮件开始", ewsEmpGroupRefer.getEmpName(), ewsEmpGroupRefer.getEmail());
				for (String context : mailContextList) {
					try {
						sendMailServce.sendHTMLMail(ewsEmpGroupRefer.getEmail(), mailTitle, context);
					} catch (Exception e) {
						logger.warn("人员【{}】【{}】邮件发送异常:{} ", new Object[] { ewsEmpGroupRefer.getEmpName(),
								ewsEmpGroupRefer.getEmail(), e });
					}
				}
			}
			logger.info("向人员【{}】【{}】发送邮件结束", ewsEmpGroupRefer.getEmpName(), ewsEmpGroupRefer.getEmail());
		}
		logger.info("调用邮件服务sendWarnIndexMail结束... ...");
	}
	
	@Override
	public void sendWarnIndexSms(List<EwsEmpGroupRefer> ewsEmpGroupReferList, String smsText) {
		logger.info("调用短信服务sendWarnIndexSms开始... ...");
		if (ewsEmpGroupReferList == null) {
			logger.warn("监控预警发送的短信对象为空！");
			return;
		}
		if (smsText == null) {
			logger.warn("监控预警发送的短信内容不能为空!");
			return;
		}
		for (EwsEmpGroupRefer ewsEmpGroupRefer : ewsEmpGroupReferList) {
			if ("Y".equals(ewsEmpGroupRefer.getIsSmsNotify())) {
				logger.info("向人员【{}】【{}】发送短信【{}】开始",
						new Object[] { ewsEmpGroupRefer.getEmpName(), ewsEmpGroupRefer.getMobile(), smsText });
				try {
					sendSMSServce.sendMessage(ewsEmpGroupRefer.getMobile(), smsText);
				} catch (Exception e) {
					logger.warn("人员【{}】【{}】短信【{}】发送异常:{} ", new Object[] { ewsEmpGroupRefer.getEmpName(),
							ewsEmpGroupRefer.getMobile(), smsText, e });
				}
				logger.info("向人员【{}】【{}】发送短信【{}】结束",
						new Object[] { ewsEmpGroupRefer.getEmpName(), ewsEmpGroupRefer.getMobile(), smsText });
			}
		}

		logger.info("调用短信服务sendWarnIndexSms结束... ...");
	}

	
}
