package com.sfpay.ews.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;


/**
 * 类说明：预警人员与指标组对应表DAO
 *
 *
 * @author 544772
 * 
 * 2015年3月11日 下午2:26:56
 */
public interface IEwsEmpGroupReferDao {

	
	/**
	 * 新增预警人员与指标组对应表记录
	 * 
	 * @param ewsEmpGroupRefer
	 */
	public void addEwsEmpGroupRefer(EwsEmpGroupRefer ewsEmpGroupRefer);
	
	/**
	 * 更新预警人员与指标组对应表记录
	 * 
	 * @param ewsEmpGroupRefer
	 */
	public void updateEwsEmpGroupRefer(EwsEmpGroupRefer ewsEmpGroupRefer);
	
	/**
	 * 删除对应的预警人员与指标组的对应关系
	 * 
	 * @param empId
	 */
	public void delEwsEmpGroupRefer(@Param("id") String id);
	
	/**
	 * 查询预警人员与指标组的对应记录
	 * 
	 * @param ewsEmpGroupRefer
	 * @return
	 */
	public List<EwsEmpGroupRefer> queryEwsEmpGroupReferByParam(EwsEmpGroupRefer ewsEmpGroupRefer);
	
	/**
	 * 根据指标编号获取预警人员的信息
	 * 
	 * @param warIndexNo
	 * @return
	 */
	public List<EwsEmpGroupRefer> queryEmpGroupInfoByIndexNo(@Param("warIndexNo") String warIndexNo);
}
