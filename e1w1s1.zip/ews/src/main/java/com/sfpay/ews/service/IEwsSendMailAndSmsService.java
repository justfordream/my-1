package com.sfpay.ews.service;

import java.util.List;

import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;

/**
 * 类说明：提供对指标组和指标发送邮件、短信服务
 * 
 * 
 * @author 544772 2015年3月11日 下午4:48:08
 */
public interface IEwsSendMailAndSmsService {

	/**
	 * 根据人员群组信息发送邮件
	 * 
	 * @param ewsEmpGroupReferList
	 * @param mailTitle
	 * @param mailContextList
	 */
	void sendWarnIndexMail(List<EwsEmpGroupRefer> ewsEmpGroupReferList, String mailTitle,
			List<String> mailContextList);

	/**
	 * 根据人员群组信息发送短信
	 * 
	 * @param ewsEmpGroupReferList
	 * @param smsText
	 */
	void sendWarnIndexSms(List<EwsEmpGroupRefer> ewsEmpGroupReferList, String smsText);

}
