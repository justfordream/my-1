/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsIndexGroupDao;
import com.sfpay.ews.platform.domain.EwsIndexGroup;
import com.sfpay.ews.platform.service.IEwsIndexGroupService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：预警指标组服务实现类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
@HessianExporter
@Service("ewsIndexGroupService")
public class EwsIndexGroupServiceImpl implements IEwsIndexGroupService {
	@Autowired
	private IEwsIndexGroupDao ewsIndexGroupDao;
	
	private static Logger logger = LoggerFactory.getLogger(EwsIndexGroupServiceImpl.class);
	
	@Override
	public List<EwsIndexGroup> queryAllEwsIndexGroup() {
		return ewsIndexGroupDao.queryAllEwsIndexGroup();
	}

	@Override
	public EwsIndexGroup queryEwsIndexGroupByGroupNo(String groupNo) {
		logger.info("queryEwsIndexGroupByGroupNo入参:{}", groupNo);
		if(StringUtils.isBlank(groupNo)) {
			throw new ServiceException("预警指标组编号不能为空！");
		}
		
		return ewsIndexGroupDao.queryEwsIndexGroupByGroupNo(groupNo);
	}

}
