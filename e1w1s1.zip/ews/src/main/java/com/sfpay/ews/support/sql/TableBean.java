/**
 * 
 */
package com.sfpay.ews.support.sql;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * 类说明：数据库表定义Bean
 * 
 * 类描述：
 * 
 * @author manzhizhen
 * 
 *         2015年3月29日
 */
public class TableBean {
	private String tableName;
	private Map<String, ColumnBean> columnMap = new LinkedHashMap<String, ColumnBean>(); 	// 所有列
	private Set<String> primaryKeyColumnSet = new LinkedHashSet<String>();			// 主键列

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public Map<String, ColumnBean> getColumnMap() {
		return columnMap;
	}

	public Set<String> getPrimaryKeyColumnSet() {
		return primaryKeyColumnSet;
	}
}
