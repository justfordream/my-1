package com.sfpay.ews.domain;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * @Description
 * @author 700316
 * @createdTime 2015-1-5 下午3:06:48
 */
public class EwsErrorLog  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6422272010958609060L;
	
	/**
	 * 预警指标编号
	 */
	private String warnIndexNo;
	
	/**
	 * 错误描述信息
	 */
	private String remark;
	
	/**
	 * 预警来源;
	 */
	private String warnSource;

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}
	
}
