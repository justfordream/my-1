/**
 * 
 */
package com.sfpay.ews.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dao.IEwsGroupIndexDao;
import com.sfpay.ews.platform.domain.EwsGroupIndex;
import com.sfpay.ews.platform.service.IEwsGroupIndexService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：预警群组与指标映射服务实现类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-20
 */
@HessianExporter
@Service("ewsGroupIndexService")
public class EwsGroupIndexServiceImpl implements IEwsGroupIndexService{
	@Autowired
	private IEwsGroupIndexDao ewsGroupIndexDao;
	
	private Logger logger = LoggerFactory.getLogger(EwsGroupIndexServiceImpl.class);
	
	@Override
	public void addEwsGroupIndex(EwsGroupIndex ewsGroupIndex) {
		if(ewsGroupIndex == null) {
			throw new ServiceException("预警群组与指标映射对象不能为空!");
		}
		
		ewsGroupIndexDao.addEwsGroupIndex(ewsGroupIndex);
		
	}

	@Override
	public EwsGroupIndex queryEwsGroupIndex(String groupNo, String warnIndexNo) {
		if(StringUtils.isBlank(groupNo) || StringUtils.isBlank(warnIndexNo)) {
			throw new ServiceException("预警群组编号与指标编号都不能为空!");
		}
		
		return ewsGroupIndexDao.queryEwsGroupIndex(groupNo, warnIndexNo);
	}

	@Override
	public void addEwsGroupIndexByList(String groupNo, List<EwsGroupIndex> ewsGroupIndexList) {
		if (StringUtils.isBlank(groupNo)) {
			logger.error("新增群组与指标对应关系时，群组编号为空");
			throw new ServiceException("新增群组与指标对应关系时，群组编号为空");
		}
		
		try {
			ewsGroupIndexDao.deleteEwsGroupIndexByGroupNo(groupNo);
		} catch (Exception e) {
			logger.error("删除群组与指标对应关系出错。群组编号为{}",groupNo,e);
			throw new ServiceException(String.format("删除群组与指标对应关系出错。群组编号为{%s}",groupNo));
		}
		
		if (ewsGroupIndexList!=null) {
			for (EwsGroupIndex ewsIndexDef : ewsGroupIndexList) {
				EwsGroupIndex ewsGroupIndex=new EwsGroupIndex();
				ewsGroupIndex.setGroupNo(groupNo);
				ewsGroupIndex.setWarnIndexNo(ewsIndexDef.getWarnIndexNo());
				try {
					ewsGroupIndexDao.addEwsGroupIndex(ewsGroupIndex);
				} catch (Exception e) {
					logger.error("新增群组与指标对应关系出错。群组编号为{}",groupNo,e);
					throw new ServiceException(String.format("新增群组与指标对应关系出错。群组编号为{%s},指标编号为{%s}",groupNo,ewsIndexDef.getWarnIndexNo()));
				}
				
			}
		}else {
			logger.error("新增群组与指标对应关系时，指标List为空");
			throw new ServiceException("新增群组与指标对应关系时，指标List为空");
		}
	}

}
