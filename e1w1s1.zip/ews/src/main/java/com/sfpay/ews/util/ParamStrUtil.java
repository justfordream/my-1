/**
 * 
 */
package com.sfpay.ews.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ews.support.service.impl.EwsTaskServiceImpl;
import com.sfpay.framework.base.exception.IllegalArgumentException;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：参数替换工具类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-25
 */
public class ParamStrUtil {
	private static Logger logger = LoggerFactory.getLogger(ParamStrUtil.class);
	
	private static final String LOOP = "loop";
	private static final String ENDLOOP = "endloop";
	private static final String ROWNUM = "rownum";
	
	
	/**
	 * 根据SQL结果集和SQL参数来翻译模板
	 * 1.模板中的占位符只能采用${param}的形式
	 * 2.模板中loop和endloop只能使用一次，循环体中可以使用rownum关键字
	 * @param strTemplate
	 * @param sqlResultDataMap 结果集Map
	 * @param rowSeparator loop循环体最大行数，超过该行数将另发一封邮件，默认为200，如果模板中没有loop字段，则rowSeparator的值不生效
	 * @return
	 */
	public static List<String> translationContext(String strTemplate, 
			final Map<String, List<Map<String, Object>>> sqlResultDataMap, int rowSeparator) {
		if(StringUtils.isBlank(strTemplate) || sqlResultDataMap == null) {
			logger.info("模板或结果集Map为空，不需替换占位符.");
			List<String> list = new ArrayList<String>();
			list.add(strTemplate);
			return list;
		}
		
		// 内容正文列表
		List<String> contextList = new ArrayList<String>();
		// 如果模板中有循环体，则该变量用于保存非循环部分
		String loopTemplateStart = null, loopTemplateEnd = null;
		
		// 检查模板里面是否有循环关键字loop和endloop
		if(strTemplate.contains(LOOP)) {
			rowSeparator = rowSeparator <= 0 ? EwsTaskServiceImpl.DEFAULT_SEP_ROW_NUM : rowSeparator;
			int loopIndex = strTemplate.indexOf(LOOP);
			int endLoopIndex = strTemplate.indexOf(ENDLOOP, loopIndex + 1);
			if(endLoopIndex <= 0) {
				logger.error("邮件模板中loop关键字和endloop关键字不匹配：{}", strTemplate);
				throw new ServiceException("邮件模板中loop关键字和endloop关键字不匹配!");
			}
			
			// 用占位符来替换循环部分
			loopTemplateStart = strTemplate.substring(0, loopIndex);
			loopTemplateEnd = strTemplate.substring(endLoopIndex + ENDLOOP.length());
			
			// 先提取需要循环的部分
			String loopStr = strTemplate.substring(loopIndex + LOOP.length(), endLoopIndex);
			// 获取关键字的Set
			Set<String> paramSet = takeParamFromStr(loopStr, "$");
			StringBuilder contextString = new StringBuilder();
			int rownum = 0;
			// 一封邮件需要循环的部分肯定不是参数部分，而是结果集
			for(Map.Entry<String, List<Map<String, Object>>> entry : sqlResultDataMap.entrySet()) {
				List<Map<String, Object>> listObject = entry.getValue();
				// 如果结果集中没有结果，则直接跳过
				if(listObject.isEmpty()) {
					continue ;
				}
				// 如果有结果，则取第一行看看结果集的列是否包含所有参数关键字
				Map<String, Object> mapObject = listObject.get(0);
				if(mapObject.keySet().containsAll(paramSet)) {
					for(Map<String, Object> map : listObject) {
						// 将循环的部分占位符替换成值后放入正文字符串中
						String newStr = setParamToStr(loopStr, "$", map);
						contextString.append(newStr.contains(ROWNUM) ? newStr.replace(ROWNUM, 
								String.valueOf(++rownum)) : newStr);
						
						// 默认每循环两百次发一封邮件
						if(rownum % rowSeparator == 0) {
							// 组装一封邮件的正文
							contextList.add(contextString.toString());
							contextString = new StringBuilder();
						}
					}
				}
			}
			
			// 将剩余部分内容（最后那批少于200行的数据）添加到一封邮件正文
			if(contextString.length() != 0) {
				contextList.add(contextString.toString());
			}
		
		// 如果邮件模板中没有使用loop，则直接将邮件模板放入该List，为了后面处理方便。
		} else {
			contextList.add(strTemplate);
		}
		
		// 开始处理其他部分（非循环部分）
		for(Map.Entry<String, List<Map<String, Object>>> entry : sqlResultDataMap.entrySet()) {
			List<Map<String, Object>> tempMapList = entry.getValue();
			// 只有行数为1的结果集才可能用于非循环部分的
			if(tempMapList.size() == 1) {
				// 如果该结果集只有一个结果，则把它的Sql键也映射到该结果
				if(isOneResult(tempMapList)) {
					tempMapList.get(0).put(entry.getKey(), tempMapList.get(0).values().toArray()[0]);
				}
				
				loopTemplateStart = setParamToStr(loopTemplateStart, "$", tempMapList.get(0));
				loopTemplateEnd = setParamToStr(loopTemplateEnd, "$", tempMapList.get(0));
			}
			// 没有占位符，则跳出循环
			if(!loopTemplateStart.contains("${") && !loopTemplateEnd.contains("${")) {
				break ;
			}
		}
		
		// 组装循环部分和非循环部分
		for(int i = 0; i < contextList.size(); i++) {
			contextList.set(i, loopTemplateStart + contextList.get(i) + loopTemplateEnd);
		}
		
		return contextList;
	}
	
	/**
	 * 从字符串中提取参数关键字
	 * @param str
	 * @param symbol
	 * @return
	 */
	private static Set<String> takeParamFromStr(String str, String symbol) {
		if(StringUtils.isBlank(str) || StringUtils.isBlank(symbol)) {
			throw new IllegalArgumentException("字符串和占位符不能为空！");
		}
		
		String startStr = symbol + "{";
		String endStr = "}";
				
		Set<String> returnSet = new HashSet<String>();
		String param = null;
		int index = 0;
		int endIndex;
		while(true) {
			index = str.indexOf(startStr, index);
			if(index < 0) {
				break ;
			}
			endIndex = str.indexOf(endStr, index + 1);
			if(endIndex < 0) {
				throw new IllegalArgumentException("占位符格式错误！");
			}
			
			param = str.substring(index + 2, endIndex);
			if(StringUtils.isBlank(param)) {
				throw new IllegalArgumentException("占位符中的关键字不能为空！");
			}
			
			returnSet.add(param.trim());
			
			index ++;
		}
		
		return returnSet;
	}
	
	/**
	 * 将语句中的占位符替换成参数值
	 * 注意：如果传入的Map中没有此参数值，则不替换
	 * @param str
	 * @param symbol
	 * @param valueMap
	 * @return
	 */
	private static String setParamToStr(String str, String symbol, Map<String, Object> valueMap) {
		String startStr = symbol + "{";
		String endStr = "}";
		
		int index = 0;
		int endIndex;
		String label = null;
		String param = null;
		while(true) {
			index = str.indexOf(startStr, index);
			if(index < 0) {
				break ;
			}
			endIndex = str.indexOf(endStr, index + 1);
			if(endIndex < 0) {
				throw new IllegalArgumentException("占位符格式错误！");
			}
			
			label = str.substring(index, endIndex + 1);
			param = label.substring(2, label.length() - 1);
			if(StringUtils.isBlank(param)) {
				throw new IllegalArgumentException("占位符中的关键字不能为空！");
			}
			
			if(valueMap.containsKey(param.trim())) {
				str = str.replaceAll(label.replace(symbol, "\\" + symbol).replace("{", "\\{").replace("}", "\\}"), 
						valueMap.get(param.trim()) == null ? "" : String.valueOf(valueMap.get(param.trim())).
								replace("$", "\\$").replace("{", "\\{").replace("}", "\\}"));
			}
			
			index ++;
		}
		
		return str;
	}
	
	/**
	 * 数据结构是否只有一个结果
	 * @param dataMap
	 * @return
	 */
	public static boolean isOneResult(final List<Map<String, Object>> dataList) {
		if(dataList != null) {
			if(dataList.isEmpty()) {
				return false;
			}
			
			Map<String, Object> resultMap = dataList.get(0);
			if(resultMap == null) {
				return false;
			}
			
			if(resultMap.values().size() != 1) {
				return false;
			} else {
				return true;
			}
			
		} 
		
		return false;
	}
}
