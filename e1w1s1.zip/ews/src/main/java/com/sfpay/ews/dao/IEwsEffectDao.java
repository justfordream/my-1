/**
 * 
 */
package com.sfpay.ews.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.ews.platform.domain.EwsEffect;

/**
 * 类说明：预警实效Dao
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-27
 */
public interface IEwsEffectDao {
	/**
	 * 通过实效代码查询实效对象
	 * @param effectCode
	 * @return
	 */
	public EwsEffect queryByEffectCode(@Param("effectCode") String effectCode);
	
	/**
	 * 通过实效代码查询实效对象
	 * @param effectCode
	 * @return
	 */
	public EwsEffect queryByWarnClassAndWarnLevel(@Param("warnClassCode")String warnClassCode,
			@Param("warnLevel")String warnLevel);
	
	/**
	 * 通过ID查询
	 * @param id
	 * @return
	 */
	public EwsEffect queryById(@Param("id") long id);
	
	/**
	 * 新增预警实效
	 * @param ewsEffect
	 */
	public void addEwsEffect(EwsEffect ewsEffect);
	
	/**
	 * 更新预警实效
	 * @param ewsEffect
	 */
	public void updateEwsEffect(EwsEffect ewsEffect);
	
	/**
	 * 删除预警实效
	 * @param ewsEffect
	 */
	public void deleteEwsEffect(@Param("id") long id);
	
	/**
	 * 
	 * 方法：预警时效总数
	 * 方法说明：
	 *
	 * @param ewsEffect
	 * @return
	 */
	public long selectEwsEffectCount(@Param("param")EwsEffect ewsEffect);
	
	/**
	 * 
	 * 方法：预警时效记录
	 * 方法说明：
	 *
	 * @param ewsEffect
	 * @param index
	 * @param size
	 * @return
	 */
	public List<EwsEffect> selectEwsEffectByPage(@Param("param")EwsEffect ewsEffect,@Param("index")int index,@Param("size")int size);
}
