package com.sfpay.ews.util;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sfpay.console.util.ExcelNameEncode;
import com.sfpay.framework.base.exception.ServiceException;

public class MutilViewExcel extends AbstractExcelView {

	@SuppressWarnings({ "unchecked" })
	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String filename = model.get("fileName") + ".xls";// 设置下载时客户端Excel的名称
		filename = ExcelNameEncode.encodeFilename(filename, request);// 处理中文文件名
		try {
			// sheetName;
			if (model.get("sheetList") == null) {
				logger.error("该指标无明细数据，所需要导出的数据为空");
				throw new ServiceException("该指标无明细数据，所需要导出的数据为空");
			}
			List<Map<String, Object>> sheetList = (List<Map<String, Object>>) model.get("sheetList");

			if (CollectionUtils.isEmpty(sheetList)) {
				logger.error("该指标无明细数据，所需要导出的数据为空");
				throw new ServiceException("该指标无明细数据，所需要导出的数据为空");
			}
			
			for (Map<String, Object> sheet : sheetList) {

				String sheetName = (String) sheet.get("sheetName");
				HSSFSheet singleSheet = workbook.createSheet(sheetName);

				if (sheet.get("sheetCellsTitle") == null) {
					logger.error("该指标需要导出的Sheet中的标题为空");
					throw new ServiceException("该指标需要导出的Sheet中的标题为空");
				}
				String[] sheetCellsTitle = (String[]) sheet.get("sheetCellsTitle");

				if (sheet.get("sheetData") == null) {
					logger.error("该指标需要导出到Sheet中的数据为空");
					throw new ServiceException("该指标需要导出到Sheet中的数据为空");
				}
				ArrayList<String[]> sheetData = (ArrayList<String[]>) sheet.get("sheetData");

				HSSFCell hssfCell = null;

				int columnIndex = 0;
				// 按行设置sheet列头
				for (String cellTitle : sheetCellsTitle) {
					hssfCell = getCell(singleSheet, 0, columnIndex);
					hssfCell.setCellType(HSSFCell.ENCODING_UTF_16);
					setText(hssfCell, cellTitle);
					columnIndex = columnIndex + 1;
				}

				// 从第一行开始（第0行留给表头），逐行逐列填充单元格数据
				if (sheetData != null) {
					int rowIndex = 1;
					for (String[] a : sheetData) {
						columnIndex = 0;
						for (String _a : a) {
							hssfCell = getCell(singleSheet, rowIndex, columnIndex);
							hssfCell.setCellType(HSSFCell.ENCODING_UTF_16);
							setText(hssfCell, _a);
							columnIndex++;
						}
						rowIndex++;
					}
				}
			}
		}catch(ServiceException e){
			HSSFSheet singleSheet = workbook.createSheet("new");
			HSSFCell hssfCell= getCell(singleSheet, 0, 0);
			setText(hssfCell, e.getMessage());
		}
		catch (Exception e) {
			HSSFSheet singleSheet = workbook.createSheet("error");
			HSSFCell hssfCell= getCell(singleSheet, 0, 0);
			setText(hssfCell, e.getMessage());
		}
		response.setContentType("application/vnd.ms-excel;charset=UTF-8");
		response.setHeader("Content-disposition", "attachment;filename=" + filename);
		OutputStream ouputStream = response.getOutputStream();
		workbook.write(ouputStream);
		ouputStream.flush();
		ouputStream.close();

	}
}
