package com.sfpay.ews.platform.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.ews.platform.domain.EwsGroupDef;
import com.sfpay.ews.platform.domain.EwsGroupEmp;
import com.sfpay.ews.platform.service.IEwsEmpGroupReferService;
import com.sfpay.ews.platform.service.IEwsGroupDefService;
import com.sfpay.ews.platform.service.IEwsGroupEmpService;
import com.sfpay.ews.platform.web.vo.EwsGroup;
import com.sfpay.ews.web.vo.WarnEmpParam;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.utils.StringUtils;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.organ.domain.OrgHrEmp;
import com.sfpay.organ.service.IOrgHrEmpService;
import com.sfpay.um.domain.User;

@Controller
@RequestMapping("/ewsempinfo")
public class EwsEmpGroupController {
	private static Logger logger = LoggerFactory.getLogger(EwsEmpGroupController.class);
	@Resource
	private IEwsGroupEmpService ewsGroupEmpService;

	@Resource
	private IEwsGroupDefService ewsGroupDefService;

	@Resource
	private IEwsEmpGroupReferService ewsEmpGroupReferService;

	@Resource
	IOrgHrEmpService orgHrEmpService;

	/**
	 * 人员群组维护主界面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/empinfomaintain")
	public ModelAndView initEmpInfoMaintain() {
		ModelAndView mav = new ModelAndView("ews/ewsemp/empinfomaintain");
		return mav;
	}

	/**
	 * 预警人员查询列表
	 * 
	 * @return
	 */
	@RequestMapping(value = "/queryewsemplist")
	@ResponseBody
	public Object queryWarnEmpList(String empId, String empMobile, String empEmail, int page, int rows) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("查询参数empId:{},empMobile:{},empMail:{}", new Object[] { empId, empMobile, empEmail });
			EwsGroupEmp emp = new EwsGroupEmp();
			if (StringUtils.isNotEmpty(empId)) {
				emp.setEmpId(empId.trim());
			}
			if (StringUtils.isNotEmpty(empMobile)) {
				emp.setEmpMobile(empMobile.trim());
			}
			if (StringUtils.isNotEmpty(empEmail)) {
				emp.setEmpMail(empEmail.trim());
			}
			return ewsGroupEmpService.queryEwsGroupEmpByPage(emp, page, rows);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("预警人员查询异常");
			return jm;
		}
	}

	/**
	 * 根据工号带出信息
	 * 
	 * @return
	 */
	@RequestMapping(value = "/queryempinfo")
	@ResponseBody
	public Object queryempinfo(String empId) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("查询工号 = " + empId);
			OrgHrEmp emp = orgHrEmpService.queryByEmpNum(empId);
			if (emp == null) {
				jm.setCode("warn");
				jm.setSuccess("warning");
				jm.setMessage("找不到该工号的人资信息");
				return jm;
			}
			EwsGroupEmp ewsGroupEmp = ewsGroupEmpService.queryEwsGroupEmpByEmpId(empId);
			if (ewsGroupEmp != null) {
				jm.setCode("warn");
				jm.setSuccess("warning");
				jm.setMessage("该预警人员已存在");
				return jm;
			}
			jm.setCode("s");
			jm.setSuccess("succeed");
			Map<String, String> data = new HashMap<String, String>();
			data.put("empId", empId);
			data.put("empName", emp.getLastName());
			data.put("empMail", emp.getMailAddress());
			data.put("empMobile", emp.getMobilePhone());
			jm.setData(data);
			logger.info("data = " + data);
			return jm;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("查询人资信息错误");
			return jm;
		}
	}

	/**
	 * 导出人员信息
	 */
	@RequestMapping(value = "/exportemplist")
	public ModelAndView exportWarnEmpList(String empId, String empMobile, String empEmail) {
		logger.info("导出预警人员信息开始...");
		Map<String, Object> empMap = new HashMap<String, Object>();
		try {
			EwsGroupEmp emp = new EwsGroupEmp();
			if (StringUtils.isNotEmpty(empId)) {
				emp.setEmpId(empId.trim());
			}
			if (StringUtils.isNotEmpty(empMobile)) {
				emp.setEmpMobile(empMobile.trim());
			}
			if (StringUtils.isNotEmpty(empEmail)) {
				emp.setEmpMail(empEmail.trim());
			}
			IPage<EwsGroupEmp> result = ewsGroupEmpService.queryEwsGroupEmpByPage(emp, 1, Integer.MAX_VALUE);
			ArrayList<String[]> exportExcel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] { "工号", "姓名", "邮件", "手机号码", "所属群组", "是否有效", "创建人", "创建日期", "修改人", "修改日期" };
			// 填充数据
			String[] contenCells = new String[10];
			for (EwsGroupEmp ewsEmp : result.getData()) {
				contenCells[0] = ewsEmp.getEmpId();
				contenCells[1] = ewsEmp.getEmpName();
				contenCells[2] = ewsEmp.getEmpMail();
				contenCells[3] = ewsEmp.getEmpMobile();
				contenCells[4] = ewsEmp.getGroupNoList();
				if ("Y".equals(ewsEmp.getIsValid())) {
					contenCells[5] = "有效";
				} else {
					contenCells[5] = "无效";
				}
				contenCells[6] = ewsEmp.getCreateId();
				contenCells[7] = DateUtils.formatDate(ewsEmp.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
				contenCells[8] = ewsEmp.getUpdateId();
				if (ewsEmp.getUpdateTime() != null) {
					contenCells[9] = DateUtils.formatDate(ewsEmp.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
				} else {
					contenCells[9] = "";
				}
				exportExcel.add(contenCells.clone());
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;

			String fileName = "预警人员信息-" + DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			empMap.put("data", exportExcel);
			empMap.put("cellsTitle", cellsTitle);
			empMap.put("fileName", fileName);
			empMap.put("dataAlign", dataAlign);
			empMap.put("sheetName", "监控预警信息列表");
			empMap.put("orgCode", "预警人员信息");
			logger.info("导出预警人员信息结束...");
		} catch (ServiceException e) {
			logger.error("预警人员信息导出异常：", e.getMessage());
		}
		logger.debug("end WarnEmpNotifyController.exportWarnEmp()");
		return new ModelAndView(new ViewExcel(), empMap);
	}

	@RequestMapping(value = "/addewsemp")
	public ModelAndView addWarnEmp() {
		ModelAndView mav = new ModelAndView("ews/ewsemp/addewsemp");
		List<EwsGroupDef> groupdefs = ewsGroupDefService.querytAllEwsGroupDef();
		mav.addObject("groupdefs", groupdefs);
		return mav;
	}

	@RequestMapping(value = "/addemp")
	@ResponseBody
	public Object addemp(WarnEmpParam emp) {
		JsonMessage jsonMessage = new JsonMessage();
		User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
		try {
			logger.info("向预警用户信息表中添加用户预警信息：{}", emp.toString());
			EwsGroupEmp warnEmp = new EwsGroupEmp();
			warnEmp.setEmpId(emp.getEmpId());

			OrgHrEmp empInfo = orgHrEmpService.queryByEmpNum(emp.getEmpId());
			if (empInfo == null) {
				jsonMessage.setCode("warn");
				jsonMessage.setSuccess("warning");
				jsonMessage.setMessage("找不到该工号的人资信息");
				return jsonMessage;
			}
			EwsGroupEmp ewsGroupEmp = ewsGroupEmpService.queryEwsGroupEmpByEmpId(emp.getEmpId());
			if (ewsGroupEmp != null) {
				jsonMessage.setCode("warn");
				jsonMessage.setSuccess("warning");
				jsonMessage.setMessage("该预警人员已存在");
				return jsonMessage;
			}

			warnEmp.setEmpName(emp.getEmpName());
			warnEmp.setEmpMail(emp.getEmpMail());
			warnEmp.setEmpMobile(emp.getEmpMobile());
			warnEmp.setIsValid(emp.getIsValid());
			warnEmp.setRemark(emp.getRemark());
			warnEmp.setCreateId(user.getUserName());
			ewsGroupEmpService.addEwsGroupEmp(warnEmp);

			String[] groupInfo = emp.getGroupNos().split(",");
			EwsEmpGroupRefer warnEmpGroup = new EwsEmpGroupRefer();
			warnEmpGroup.setEmpId(emp.getEmpId());
			for (int i = 0; i < groupInfo.length; i = i + 3) {
				warnEmpGroup.setGroupNo(groupInfo[i]);
				warnEmpGroup.setIsMailNotify(groupInfo[i + 1]);
				warnEmpGroup.setIsSmsNotify(groupInfo[i + 2]);
				warnEmpGroup.setCreateId(user.getUserName());
				ewsEmpGroupReferService.addEwsEmpGroupRefer(warnEmpGroup);
			}
			jsonMessage.setCode("s");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("新增预警人员信息成功");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("新增预警人员信息异常");
			return jsonMessage;
		}

	}

	@RequestMapping(value = "/updateewsemp")
	public ModelAndView updateEmp(String empId) {
		ModelAndView mv = new ModelAndView("ews/ewsemp/updateewsemp");
		EwsGroupEmp ewsGroupEmp = ewsGroupEmpService.queryEwsGroupEmpByEmpId(empId);
		mv.addObject("emp", ewsGroupEmp);

		EwsEmpGroupRefer ewsEmpGroupRefer = new EwsEmpGroupRefer();
		ewsEmpGroupRefer.setEmpId(empId);
		List<EwsEmpGroupRefer> ewsEmpGroupRefers = ewsEmpGroupReferService
				.queryEwsEmpGroupReferByParam(ewsEmpGroupRefer);
		List<EwsGroupDef> groupdefs = ewsGroupDefService.querytAllEwsGroupDef();
		List<EwsGroup> groups = new ArrayList<EwsGroup>();

		Map<String, EwsEmpGroupRefer> mapEmpGroupRefers = new HashMap<String, EwsEmpGroupRefer>();
		for (EwsEmpGroupRefer empGroupRefer : ewsEmpGroupRefers) {
			mapEmpGroupRefers.put(empGroupRefer.getGroupNo(), empGroupRefer);
		}

		// 对已选的预警群组进行标记
		for (EwsGroupDef ewsGroup : groupdefs) {
			EwsGroup group = new EwsGroup();
			if ("Y".equals(ewsGroup.getIsValid())) {
				group.setEwsGroupNo(ewsGroup.getGroupNo());
				group.setEwsGroupName(ewsGroup.getGroupName());
				group.setIsMailChecked("N");
				group.setIsSmsChecked("N");
				group.setEwsEmpNo(empId);
				if (mapEmpGroupRefers.containsKey(ewsGroup.getGroupNo())) {
					group.setIsChecked("Y");
					group.setIsMailChecked(mapEmpGroupRefers.get(ewsGroup.getGroupNo()).getIsMailNotify());
					group.setIsSmsChecked(mapEmpGroupRefers.get(ewsGroup.getGroupNo()).getIsSmsNotify());
				}
				groups.add(group);
			}
		}

		mv.addObject("groups", groups);
		return mv;
	}

	@RequestMapping(value = "/updateemp")
	@ResponseBody
	public Object updateemp(WarnEmpParam emp) {
		JsonMessage jsonMessage = new JsonMessage();
		User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
		try {
			logger.info("对预警用户信息表中用户预警信息进行修改：{}", emp.toString());
			EwsGroupEmp warnEmp = new EwsGroupEmp();
			warnEmp.setEmpId(emp.getEmpId());
			warnEmp.setEmpName(emp.getEmpName());
			warnEmp.setEmpMail(emp.getEmpMail());
			warnEmp.setEmpMobile(emp.getEmpMobile());
			warnEmp.setIsValid(emp.getIsValid());
			warnEmp.setRemark(emp.getRemark());
			warnEmp.setCreateId(user.getUserName());
			ewsGroupEmpService.updateEwsGroupEmp(warnEmp);

			String[] groupInfo = emp.getGroupNos().split(",");
			EwsEmpGroupRefer ewsEmpGroupRefer = new EwsEmpGroupRefer();
			ewsEmpGroupRefer.setEmpId(emp.getEmpId());
			// 通过人员编码获取所有人员与预警群组的对应关系
			List<EwsEmpGroupRefer> listEmpGroupRefers = ewsEmpGroupReferService
					.queryEwsEmpGroupReferByParam(ewsEmpGroupRefer);

			Map<String, EwsEmpGroupRefer> mapEmpGroupRefers = new HashMap<String, EwsEmpGroupRefer>();
			for (EwsEmpGroupRefer ewsRefer : listEmpGroupRefers) {
				mapEmpGroupRefers.put(ewsRefer.getGroupNo(), ewsRefer);
			}

			// 对新的人员与预警群组的对应关系进行处理，新增或者更新
			// 前端传送的组的内容格式为[组名，是否发送邮件标志，是否发送短信标志...]
			for (int i = 0; i < groupInfo.length; i = i + 3) {
				ewsEmpGroupRefer.setGroupNo(groupInfo[i]);
				ewsEmpGroupRefer.setIsMailNotify(groupInfo[i + 1]);
				ewsEmpGroupRefer.setIsSmsNotify(groupInfo[i + 2]);

				if (mapEmpGroupRefers.containsKey(groupInfo[i])) {
					ewsEmpGroupRefer.setId(mapEmpGroupRefers.get(groupInfo[i]).getId());
					ewsEmpGroupRefer.setUpdateId(user.getUserName());
					ewsEmpGroupReferService.updateEwsEmpGroupRefer(ewsEmpGroupRefer);
					listEmpGroupRefers.remove(mapEmpGroupRefers.get(groupInfo[i]));
				} else {
					ewsEmpGroupRefer.setCreateId(user.getUserName());
					ewsEmpGroupReferService.addEwsEmpGroupRefer(ewsEmpGroupRefer);
				}
			}

			// 删除已被取消勾选的对应关系
			for (EwsEmpGroupRefer ewsEmpGroup : listEmpGroupRefers) {
				ewsEmpGroupReferService.delEwsEmpGroupRefer(String.valueOf(ewsEmpGroup.getId()));
			}

			jsonMessage.setCode("s");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("修改预警人员信息成功");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("新增预警通知异常");
			return jsonMessage;
		}
	}

	/**
	 * 
	 * 方法：返回群组管理页面 方法说明：
	 * 
	 * @return
	 */
	@RequestMapping("/groupmanage")
	public ModelAndView manageGroup() {
		ModelAndView mv = new ModelAndView("ews/ewsemp/groupmanagemain");
		return mv;
	}

	/**
	 * 
	 * 方法：返回新增群组页面 方法说明：
	 * 
	 * @param groupNo
	 * @return
	 */
	@RequestMapping(value = "/addewsgroup")
	public ModelAndView addEwsGroup() {
		ModelAndView mav = new ModelAndView("ews/ewsemp/addgroup");
		return mav;
	}

	@RequestMapping("/querygrouplist")
	@ResponseBody
	public Object getGroupList(String groupNo, String groupName, int page, int rows) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			EwsGroupDef group = new EwsGroupDef();
			group.setGroupNo(groupNo);
			group.setGroupName(groupName);
			return ewsGroupDefService.queryEwsGroupDefByOrderPage(group, page, rows);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("查询预警群组信息异常");
			return jsonMessage;
		}
	}

	@RequestMapping("/querygroup")
	@ResponseBody
	public Object getGroup(String groupNo) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			EwsGroupDef group = new EwsGroupDef();
			group.setGroupNo(groupNo);
			EwsGroupDef ewsGroupDef = ewsGroupDefService.queryByGroupNo(groupNo);
			if (ewsGroupDef != null) {
				jsonMessage.setCode("warn");
				jsonMessage.setSuccess("warning");
				jsonMessage.setMessage("该预警群组代码已存在");
			}
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("查询预警群组信息异常");
			return jsonMessage;
		}
	}

	/**
	 * 
	 * 方法：新增群组 方法说明：
	 * 
	 * @param group
	 * @return
	 */
	@RequestMapping("/addgroup")
	@ResponseBody
	public Object addGroup(EwsGroupDef group) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			EwsGroupDef groupDef = new EwsGroupDef();
			groupDef.setGroupNo(group.getGroupNo());
			groupDef.setGroupName(group.getGroupName());
			groupDef.setGroupExplain(group.getGroupExplain());
			groupDef.setRemark(group.getRemark());
			groupDef.setIsValid(group.getIsValid());
			groupDef.setCreateId(user.getUserName());

			EwsGroupDef ewsGroupDef = ewsGroupDefService.queryByGroupNo(group.getGroupNo());
			if (ewsGroupDef != null) {
				jsonMessage.setCode("warn");
				jsonMessage.setSuccess("warning");
				jsonMessage.setMessage("该预警群组代码已存在");
				return jsonMessage;
			}
			ewsGroupDefService.addEwsGroupDef(groupDef);
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("新增预警群组成功");
		} catch (Exception e) {
			jsonMessage.setCode("error");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("新增预警群组失败");
		}
		return jsonMessage;
	}

	/**
	 * 
	 * 方法：返回更新群组页面 方法说明：
	 * 
	 * @param groupNo
	 * @return
	 */
	@RequestMapping(value = "/updateewsgroup")
	public ModelAndView updateEwsGroup(String groupNo) {
		ModelAndView mav = new ModelAndView("ews/ewsemp/updategroup");
		EwsGroupDef group = ewsGroupDefService.queryByGroupNo(groupNo);
		mav.addObject("group", group);
		return mav;
	}

	/**
	 * 
	 * 方法：更新预警群组 方法说明：
	 * 
	 * @param group
	 * @return
	 */
	@RequestMapping("/updategroup")
	@ResponseBody
	public Object updateGroup(EwsGroupDef group) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			EwsGroupDef groupDef = new EwsGroupDef();
			groupDef.setGroupNo(group.getGroupNo());
			groupDef.setGroupName(group.getGroupName());
			groupDef.setGroupExplain(group.getGroupExplain());
			groupDef.setRemark(group.getRemark());
			groupDef.setIsValid(group.getIsValid());
			groupDef.setUpdateId(user.getUserName());
			ewsGroupDefService.updateEwsGroupDef(groupDef);
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("更新预警群组成功");
		} catch (Exception e) {
			jsonMessage.setCode("error");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("新增预警群组失败");
		}
		return jsonMessage;
	}

	@RequestMapping("/deletegroup")
	@ResponseBody
	public Object deleteGroup(String groupNo) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			ewsGroupDefService.delEwsGroupDef(groupNo);
			// 删除该群组对应的群组关系
			EwsEmpGroupRefer ewsEmpGroupRefer = new EwsEmpGroupRefer();
			ewsEmpGroupRefer.setGroupNo(groupNo);
			List<EwsEmpGroupRefer> ewsEmpGroupRefersList = ewsEmpGroupReferService
					.queryEwsEmpGroupReferByParam(ewsEmpGroupRefer);
			for (EwsEmpGroupRefer empGroup : ewsEmpGroupRefersList) {
				ewsEmpGroupReferService.delEwsEmpGroupRefer(String.valueOf(empGroup.getId()));
			}

			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("删除预警群组成功");
		} catch (Exception e) {
			jsonMessage.setCode("error");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("删除预警群组失败");
		}
		return jsonMessage;
	}

	/**
	 * 导出预警群组信息
	 */
	@RequestMapping(value = "/exportgrouplist")
	public ModelAndView exportGroupList(String groupNo, String groupName) {
		logger.info("导出预警群组信息开始...");
		Map<String, Object> groupMap = new HashMap<String, Object>();
		try {
			EwsGroupDef ewsGroupDef = new EwsGroupDef();
			ewsGroupDef.setGroupNo(groupNo);
			ewsGroupDef.setGroupName(groupName);
			IPage<EwsGroupDef> result = ewsGroupDefService.queryEwsGroupDefByOrderPage(ewsGroupDef, 1,
					Integer.MAX_VALUE);
			ArrayList<String[]> exportExcel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] { "群组编码", "群组名称", "群组说明", "备注", "是否有效", "创建人", "创建日期", "修改人", "修改日期" };
			// 填充数据
			String[] contenCells = new String[9];
			for (EwsGroupDef group : result.getData()) {
				contenCells[0] = group.getGroupNo();
				contenCells[1] = group.getGroupName();
				contenCells[2] = group.getGroupExplain();
				contenCells[3] = group.getRemark();
				if ("Y".equals(group.getIsValid())) {
					contenCells[4] = "有效";
				} else {
					contenCells[4] = "无效";
				}
				contenCells[5] = group.getCreateId();
				contenCells[6] = DateUtils.formatDate(group.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
				contenCells[7] = group.getUpdateId();
				if (group.getUpdateTime() != null) {
					contenCells[8] = DateUtils.formatDate(group.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
				} else {
					contenCells[8] = "";
				}
				exportExcel.add(contenCells.clone());
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;

			String fileName = "预警群组信息-" + DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			groupMap.put("data", exportExcel);
			groupMap.put("cellsTitle", cellsTitle);
			groupMap.put("fileName", fileName);
			groupMap.put("dataAlign", dataAlign);
			groupMap.put("orgCode", "预警群组信息");
			logger.info("导出预警群组信息结束...");
		} catch (ServiceException e) {
			logger.error("预警群组信息导出异常：", e.getMessage());
		}
		return new ModelAndView(new ViewExcel(), groupMap);
	}
}
