/**
 * 
 */
package com.sfpay.ews.web.vo;

import java.util.Date;

/**
 * @author 321566 张泽豪
 *
 * 2014-4-18 上午11:38:32
 */
public class WarnGroupParam {
	
	private String groupNo;
	
	private String groupName;
	
	private String groupExplain;
	
	private String isValid;
	
	private String remark;
	
	private String createId;
	
	private Date createTime;
	
	private String updateId;
	
	private Date updateTime;
	
	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupExplain() {
		return groupExplain;
	}

	public void setGroupExplain(String groupExplain) {
		this.groupExplain = groupExplain;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return (Date)createTime.clone();
	}

	public void setCreateTime(Date createTime) {
		this.createTime = (Date)createTime.clone();
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return (Date)updateTime.clone();
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = (Date)updateTime.clone();
	}

	@Override
	public String toString() {
		return "WarnGroupParam [groupNo=" + groupNo + ", groupName="
				+ groupName + ", groupExplain=" + groupExplain + ", isValid="
				+ isValid + ", remark=" + remark + ", createId=" + createId
				+ ", createTime=" + createTime + ", updateId=" + updateId
				+ ", updateTime=" + updateTime + "]";
	}
	
}
