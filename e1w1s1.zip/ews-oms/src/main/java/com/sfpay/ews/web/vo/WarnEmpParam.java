/**
 * 
 */
package com.sfpay.ews.web.vo;

/**
 * @author 321566 张泽豪
 *
 * 2014-4-18 上午11:38:32
 */
public class WarnEmpParam {
	
	private String empId;
	
	private String empName;
	
	private String empMail;
	
	private String empMobile;
	
	private String groupNos;
	
	private String remark;
	
	private String isMailNotify;
	
	private String isSmsNotify;
	
	private String isValid;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpMail() {
		return empMail;
	}

	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}

	public String getEmpMobile() {
		return empMobile;
	}

	public void setEmpMobile(String empMobile) {
		this.empMobile = empMobile;
	}

	public String getGroupNos() {
		return groupNos;
	}

	public void setGroupNos(String groupNos) {
		this.groupNos = groupNos;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIsMailNotify() {
		return isMailNotify;
	}

	public void setIsMailNotify(String isMailNotify) {
		this.isMailNotify = isMailNotify;
	}


	public String getIsSmsNotify() {
		return isSmsNotify;
	}

	public void setIsSmsNotify(String isSmsNotify) {
		this.isSmsNotify = isSmsNotify;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	@Override
	public String toString() {
		return "WarnEmpParam [empId=" + empId + ", empName=" + empName
				+ ", empMail=" + empMail + ", empMobile=" + empMobile
				+ ", groupNos=" + groupNos + ", remark=" + remark
				+ ", isMailNotify=" + isMailNotify + ", isSmsNotify="
				+ isSmsNotify + ", isValid=" + isValid + "]";
	}

}
