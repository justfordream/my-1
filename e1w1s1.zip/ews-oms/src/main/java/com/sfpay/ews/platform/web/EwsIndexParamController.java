package com.sfpay.ews.platform.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import ch.qos.logback.classic.Logger;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.platform.domain.EwsIndexParam;
import com.sfpay.ews.platform.service.IEwsIndexParamService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;

@Controller
@RequestMapping("/ewsindexparam")
public class EwsIndexParamController {

	private Logger logger = (Logger) LoggerFactory.getLogger(EwsIndexParamController.class);

	@Resource
	private IEwsIndexParamService ewsIndexParamService;

	/**
	 * 指标参数维护主界面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/indexparammain")
	public ModelAndView initIndexParamMaintain() {
		ModelAndView mav = new ModelAndView("ews/indexparam/indexparammain");
		return mav;
	}

	/**
	 * 预警指标参数查询列表
	 * 
	 * @return
	 */
	@RequestMapping(value = "/queryewsindexparamlist")
	@ResponseBody
	public Object queryEwsIndexParamList(EwsIndexParam ewsIndexParam, int page, int rows) {
		JsonMessage jm = new JsonMessage();
		try {
			return ewsIndexParamService.queryIndexParamByPage(ewsIndexParam, page, rows);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("预警指标参数查询异常");
			return jm;
		}
	}

	/**
	 * 指标参数新增界面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/addindexparam")
	public ModelAndView addIndexParam() {
		ModelAndView mav = new ModelAndView("ews/indexparam/addindexparam");
		return mav;
	}

	/**
	 * 新增预警指标参数
	 * 
	 * @return
	 */
	@RequestMapping(value = "/addewsindexparam")
	@ResponseBody
	public Object addEwsIndexParam(EwsIndexParam ewsIndexParam) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			EwsIndexParam indexParam=new EwsIndexParam();
			indexParam.setParamName(ewsIndexParam.getParamName());
			indexParam.setWarnIndexNo(ewsIndexParam.getWarnIndexNo());
			EwsIndexParam queryEwsIndexParam = ewsIndexParamService.queryByIndexNoAndParamName(
					ewsIndexParam.getWarnIndexNo(), ewsIndexParam.getParamName());
			if (queryEwsIndexParam != null ) {
				jsonMessage.setCode("warn");
				jsonMessage.setSuccess("warning");
				jsonMessage.setMessage("该预警指标参数已存在");
				return jsonMessage;
			}
			
			ewsIndexParamService.addEwsIndexParam(ewsIndexParam);
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("新增预警指标参数成功");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("新增预警指标参数异常");
			return jsonMessage;
		}
	}

	/**
	 * 指标参数更新界面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/updateindexparam")
	public ModelAndView updateIndexParam(String id) {
		ModelAndView mav = new ModelAndView("ews/indexparam/updateindexparam");
		EwsIndexParam ewsIndexParam = ewsIndexParamService.queryWarnIndexParamById(Long.valueOf(id));
		mav.addObject("ewsIndexParam", ewsIndexParam);
		return mav;
	}

	/**
	 * 
	 * 方法：更新预警指标参数 方法说明：
	 * 
	 * @param ewsIndexParam
	 * @return
	 */
	@RequestMapping(value = "/updateewsindexparam")
	@ResponseBody
	public Object updateEwsIndexParam(EwsIndexParam ewsIndexParam) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			EwsIndexParam queryEwsIndexParam = ewsIndexParamService.queryByIndexNoAndParamName(
					ewsIndexParam.getWarnIndexNo(), ewsIndexParam.getParamName());
			if (queryEwsIndexParam != null ) {
				jsonMessage.setCode("warn");
				jsonMessage.setSuccess("warning");
				jsonMessage.setMessage("该预警指标参数已存在");
				return jsonMessage;
			}
			ewsIndexParamService.updateEwsIndexParam(ewsIndexParam);
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("更新预警指标参数成功");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("更新预警指标参数异常");
			return jsonMessage;
		}
	}

	/**
	 * 
	 * 方法：删除预警指标参数 方法说明：
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/deleteewsindexparam")
	@ResponseBody
	public Object deleteEwsIndexParam(String id) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			ewsIndexParamService.deleteEwsIndexParamById(Long.valueOf(id));
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("删除预警指标参数成功");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("删除预警指标参数异常");
			return jsonMessage;
		}
	}

	/**
	 * 导出预警指标参数信息
	 */
	@RequestMapping(value = "/exportparamlist")
	public ModelAndView exportGroupList(String paramName,String warnIndexNo) {
		logger.info("导出预警指标参数信息开始...");
		Map<String, Object> groupMap = new HashMap<String, Object>();
		try {
			EwsIndexParam ewsIndexParam=new EwsIndexParam();
			ewsIndexParam.setParamName(paramName);
			ewsIndexParam.setWarnIndexNo(warnIndexNo);
			IPage<EwsIndexParam> result = ewsIndexParamService.queryIndexParamByPage(ewsIndexParam, 1,
					Integer.MAX_VALUE);
			ArrayList<String[]> exportExcel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] { "参数名称", "参数值", "参数值的单位", "指标编号", "备注", "创建人", "创建日期", "修改人", "修改日期" };
			// 填充数据
			String[] contenCells = new String[9];
			for (EwsIndexParam group : result.getData()) {
				contenCells[0] = group.getParamName();
				contenCells[1] = group.getParamVal();
				contenCells[2] = group.getParamUnit();
				contenCells[3] = group.getWarnIndexNo();
				contenCells[4] = group.getRemark();
				contenCells[5] = group.getCreateId();
				contenCells[6] = DateUtils.formatDate(group.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
				contenCells[7] = group.getUpdateId();
				if (group.getUpdateTime() != null) {
					contenCells[8] = DateUtils.formatDate(group.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
				} else {
					contenCells[8] = "";
				}
				exportExcel.add(contenCells.clone());
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;

			String fileName = "预警指标参数信息-" + DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			groupMap.put("data", exportExcel);
			groupMap.put("cellsTitle", cellsTitle);
			groupMap.put("fileName", fileName);
			groupMap.put("dataAlign", dataAlign);
			groupMap.put("orgCode", "预警指标参数信息");
			logger.info("导出预警指标参数信息结束...");
		} catch (ServiceException e) {
			logger.error("预警预警指标参数信息导出异常：", e.getMessage());
		}
		return new ModelAndView(new ViewExcel(), groupMap);
	}

}
