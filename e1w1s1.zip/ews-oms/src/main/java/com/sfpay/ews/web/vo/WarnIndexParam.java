/**
 * 
 */
package com.sfpay.ews.web.vo;

import java.util.Date;

/**
 * @author 321566 张泽豪
 *
 * 2014-4-21 下午6:02:49
 */
public class WarnIndexParam {
	
	private String warnIndexNo;
	
	private String warnIndexName;
	
	private String warnSource;
	
	private String warnType;
	
	private String warnProperty;
	
	private String warnCycle;
	
	private String warnCycleVal;
	
	private String warnResultSource;
	
	private String warnLevel;
	
	private String isValid;
	
	private String remark;
	
	private String createId;
	
	private Date createTime;
	
	private String updateId;
	
	private Date updateTime;
	
	private String isMailNotify;
	
	private String isSmsNotify;

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexName() {
		return warnIndexName;
	}

	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public String getWarnType() {
		return warnType;
	}

	public void setWarnType(String warnType) {
		this.warnType = warnType;
	}

	public String getWarnProperty() {
		return warnProperty;
	}

	public void setWarnProperty(String warnProperty) {
		this.warnProperty = warnProperty;
	}

	public String getWarnCycle() {
		return warnCycle;
	}

	public void setWarnCycle(String warnCycle) {
		this.warnCycle = warnCycle;
	}

	public String getWarnCycleVal() {
		return warnCycleVal;
	}

	public void setWarnCycleVal(String warnCycleVal) {
		this.warnCycleVal = warnCycleVal;
	}

	public String getWarnResultSource() {
		return warnResultSource;
	}

	public void setWarnResultSource(String warnResultSource) {
		this.warnResultSource = warnResultSource;
	}

	public String getWarnLevel() {
		return warnLevel;
	}

	public void setWarnLevel(String warnLevel) {
		this.warnLevel = warnLevel;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return (Date)createTime.clone();
	}

	public void setCreateTime(Date createTime) {
		this.createTime = (Date)createTime.clone();
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return (Date)updateTime.clone();
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = (Date)updateTime.clone();
	}

	public String getIsMailNotify() {
		return isMailNotify;
	}

	public void setIsMailNotify(String isMailNotify) {
		this.isMailNotify = isMailNotify;
	}

	public String getIsSmsNotify() {
		return isSmsNotify;
	}

	public void setIsSmsNotify(String isSmsNotify) {
		this.isSmsNotify = isSmsNotify;
	}

	@Override
	public String toString() {
		return "WarnIndexParam [warnIndexNo=" + warnIndexNo
				+ ", warnIndexName=" + warnIndexName + ", warnSource="
				+ warnSource + ", warnType=" + warnType + ", warnProperty="
				+ warnProperty + ", warnCycle=" + warnCycle + ", warnCycleVal="
				+ warnCycleVal + ", warnResultSource=" + warnResultSource
				+ ", warnLevel=" + warnLevel + ", isValid=" + isValid
				+ ", remark=" + remark + ", createId=" + createId
				+ ", createTime=" + createTime + ", updateId=" + updateId
				+ ", updateTime=" + updateTime + ", isMailNotify="
				+ isMailNotify + ", isSmsNotify=" + isSmsNotify + "]";
	}

}
