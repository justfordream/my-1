/**
 * 
 */
package com.sfpay.ews.platform.web;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.JsonMessage;
import com.sfpay.ews.platform.domain.EwsIndexSql;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsIndexSqlService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

/**
 * 类说明：预警指标SQL控制器
 *
 * 类描述：预警指标SQL控制器
 * @author 625288
 *
 * 2015-4-9
 */
@Controller
@RequestMapping("/ews/indexsql")
public class EwsIndexSqlController {
	private static Logger logger = LoggerFactory.getLogger(EwsIndexSqlController.class);
	@Autowired
	private IEwsIndexSqlService ewsIndexSqlService;
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	
	/**
	 * 预警指标SQL维护主界面
	 * @return
	 */
	@RequestMapping(value = "/mainpage")
	public ModelAndView mainPage() {
		return new ModelAndView("ews/ewsindexsql/sqlmain");
	}
	
	/**
	 * 查询指标SQL
	 * @param ewsIndexSql
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping(value = "/querylist")
	@ResponseBody
	public Object queryList(EwsIndexSql ewsIndexSql, int page, int rows) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("查询参数  = " + ewsIndexSql);
			
			if(ewsIndexSql == null) {
				ewsIndexSql = new EwsIndexSql();
			}
			
 			return ewsIndexSqlService.queryByPage(ewsIndexSql, page, rows);
			
		} catch (Exception e) {
			logger.error("queryList 预警指标SQL分页查询异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("指标SQL查询异常");
			return jm;
		}
	}
	
	/**
	 * 查看预警指标SQL语句
	 * @param ewsIndexSql
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping(value = "/viewindexsql")
	@ResponseBody
	public ModelAndView viewIndexSql(long id) {
		logger.info("查询参数  = " + id);
		
		EwsIndexSql ewsIndexSql = ewsIndexSqlService.queryById(id);
		
		if(ewsIndexSql == null) {
			logger.error("指标SQL的ID【{}】不存在,查看指标SQL失败", id);
			ewsIndexSql = new EwsIndexSql();
		}
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("sql", ewsIndexSql.getWarnIndexSql());
		modelAndView.setViewName("ews/ewsindexsql/viewindexsql");
		
		return modelAndView;
	}
	
	/**
	 * 修改指标SQL页面
	 * @param indexNo
	 * @return
	 */
	@RequestMapping(value = "/updateindexsqlpage")
	@ResponseBody
	public ModelAndView updateIndexSqlPage(long id) {
		ModelAndView modelAndView = new ModelAndView("ews/ewsindexsql/updateindexsql");
		
		EwsIndexSql ewsIndexSql = ewsIndexSqlService.queryById(id);
		
		if(ewsIndexSql == null) {
			logger.error("指标SQL的ID【{}】不存在，更新指标SQL对象失败", id);
			ewsIndexSql = new EwsIndexSql();
		}
		
		modelAndView.addObject("ewsIndexSql", ewsIndexSql);
		
		return modelAndView;
	}
	
	/**
	 * 更新指标SQL
	 * @param ewsIndexDef
	 * @return
	 */
	@RequestMapping(value = "/updateindexsql")
	@ResponseBody
	public Object updateIndexSql(EwsIndexSql ewsIndexSql) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("更新指标SQL对象 = " + ewsIndexSql);
			
			checkUpdateEwsIndexSql(ewsIndexSql);
			
			EwsIndexSql oldEwsIndexSql = ewsIndexSqlService.queryById(ewsIndexSql.getId());
			if(oldEwsIndexSql == null) {
				logger.error(String.format("更新预警指标SQL失败，无效的预警指标SQL ID:【%s】", ewsIndexSql.getId()));
				throw new ServiceException(String.format("无效的预警指标SQL ID:【%s】", ewsIndexSql.getId()));
			}

			// 检查SQL键是否重复
			if(!StringUtils.equals(ewsIndexSql.getSqlKey(), oldEwsIndexSql.getSqlKey()) || 
					!StringUtils.equals(ewsIndexSql.getWarnIndexNo(), oldEwsIndexSql.getWarnIndexNo())) {
				if(ewsIndexSqlService.queryByWarnIndexNoAndSqlKey(ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()) != null) {
					logger.error(String.format("更新预警指标SQL失败，指标编号-SQL键已存在【%s-%s】", 
							new Object[]{ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
					throw new ServiceException(String.format("更新预警指标SQL失败，指标编号-SQL键已存在【%s-%s】", 
							new Object[]{ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
				}
			}
			
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			ewsIndexSql.setUpdateId(user.getUserName());
			
			ewsIndexSqlService.updateEwsIndexSql(ewsIndexSql);

			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("更新指标SQL成功");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("更新预警指标SQL异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("更新预警指标SQL异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("更新预警指标SQL异常");
			return jm;
		}
	}
	
	/**
	 * 删除指标SQL
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/deleteindexsql")
	@ResponseBody
	public Object deleteIndexSql(long id) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("删除指标SQL对象 = " + id);
			
			
			EwsIndexSql delEwsIndexSql = ewsIndexSqlService.queryById(id);
			if(delEwsIndexSql == null) {
				logger.error(String.format("删除预警指标SQL失败，无效的预警指标SQL ID:【%s】", id));
				throw new ServiceException(String.format("无效的预警指标SQL ID:【%s】", id));
			}

			ewsIndexSqlService.deleteEwsIndexSql(id);

			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("删除指标SQL成功");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("删除预警指标SQL异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("删除预警指标SQL异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("删除预警指标SQL异常");
			return jm;
		}
	}
	
	/**
	 * 新增指标SQL页面
	 * @return
	 */
	@RequestMapping(value = "/addindexsqlpage")
	@ResponseBody
	public ModelAndView addIndexSqlPage() {
		return new ModelAndView("ews/ewsindexsql/addindexsql");
	}
	
	/**
	 * 新增指标SQL
	 * @param ewsIndexDef
	 * @return
	 */
	@RequestMapping(value = "/addindexsql")
	@ResponseBody
	public Object addIndexSql(EwsIndexSql ewsIndexSql) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("新增指标SQL对象 = " + ewsIndexSql);
			
			checkUpdateEwsIndexSql(ewsIndexSql);
			
			// 检查SQL键是否重复
			if(ewsIndexSqlService.queryByWarnIndexNoAndSqlKey(ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()) != null) {
				logger.error(String.format("新增预警指标SQL失败，指标编号-SQL键已存在【%s-%s】", 
						new Object[]{ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
				throw new ServiceException(String.format("新增预警指标SQL失败，指标编号-SQL键已存在【%s-%s】", 
						new Object[]{ewsIndexSql.getWarnIndexNo(), ewsIndexSql.getSqlKey()}));
			}
			
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			ewsIndexSql.setCreateId(user.getUserName());
			
			ewsIndexSqlService.addEwsIndexSql(ewsIndexSql);

			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("新增指标SQL成功");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("新增预警指标SQL异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("新增预警指标SQL异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("新增预警指标SQL异常");
			return jm;
		}
	}
	
	/**
	 * 检查更新指标SQL对象正确性
	 * @param indexDef
	 */
	private void checkUpdateEwsIndexSql(EwsIndexSql indexSql) {
		if (indexSql == null) {
			logger.error("预警指标SQL对象为空");
			throw new ServiceException("预警指标SQL对象为空");
		}

		if (StringUtils.isBlank(indexSql.getWarnIndexNo())) {
			logger.error("指标编号为空");
			throw new ServiceException("指标编号为空");
		}
		
		if (StringUtils.isBlank(indexSql.getSqlKey())) {
			logger.error("指标SQL键为空");
			throw new ServiceException("指标SQL键为空");
		}
		
		if (StringUtils.isBlank(indexSql.getWarnIndexSql())) {
			logger.error("指标SQL语句为空");
			throw new ServiceException("指标SQL语句为空");
		}
		
		if(ewsIndexDefService.queryByWarnIndexNo(indexSql.getWarnIndexNo()) == null) {
			logger.error("指标编号【{}】不存在", indexSql.getWarnIndexNo());
			throw new ServiceException(String.format("指标编号【%s】不存在", indexSql.getWarnIndexNo()));
			
		}
	}
}
