/**
 * 
 */
package com.sfpay.ews.platform.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.platform.domain.EwsEffect;
import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsParam;
import com.sfpay.ews.platform.sch.service.IEwsSchedulerService;
import com.sfpay.ews.platform.sch.service.IEwsTaskService;
import com.sfpay.ews.platform.service.IEwsEffectService;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsParamService;
import com.sfpay.ews.platform.util.EwsConstantsUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

/**
 * 类说明：预警指标维护页面控制器
 * 
 * 类描述：
 * 
 * @author 625288
 * 
 *         2015-3-27
 */
@Controller
@RequestMapping("/ews/indexdef")
public class EwsIndexDefController {

	private static Logger logger = LoggerFactory.getLogger(EwsIndexDefController.class);

	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	@Autowired	
	private IEwsParamService ewsParamService;
	@Autowired
	private IEwsEffectService ewsEffectService;
	@Autowired
	private IEwsSchedulerService ewsSchedulerService;
	@Autowired
	private IEwsTaskService ewsTaskService;

	/**
	 * 预警指标维护主界面
	 * @return
	 */
	@RequestMapping(value = "/mainpage")
	public ModelAndView mainPage() {
		ModelAndView modelAndView = new ModelAndView("ews/ewsindexdef/defmain");
		setModelAndView(modelAndView);
		
		return modelAndView;
	}

	/**
	 * 指标查询列表
	 * @param ewsIndexDef
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping(value = "/querylist")
	@ResponseBody
	public Object queryList(EwsIndexDef ewsIndexDef, int page, int rows) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("查询参数  = " + ewsIndexDef);
			
			if(ewsIndexDef == null) {
				ewsIndexDef = new EwsIndexDef();
			}
			
 			return ewsIndexDefService.queryEwsIndexDefByPage(ewsIndexDef, page, rows);
			
		} catch (Exception e) {
			logger.error("queryList 预警指标分页查询异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("指标查询异常");
			return jm;
		}
	}

	/**
	 * 新增指标页面
	 * @return
	 */
	@RequestMapping(value = "/addindexpage")
	@ResponseBody
	public ModelAndView addIndexDefPage() {
		ModelAndView modelAndView = new ModelAndView("ews/ewsindexdef/addindex");
		setModelAndView(modelAndView);
		return modelAndView;
	}

	/**
	 * 新增指标
	 * @param ewsIndexDef
	 * @return
	 */
	@RequestMapping(value = "/addindex")
	@ResponseBody
	public Object addIndexDef(EwsIndexDef ewsIndexDef) {
		JsonMessage json = new JsonMessage();
		try {
			logger.info("新增指标对象 = " + ewsIndexDef);
			
			checkEwsIndexDef(ewsIndexDef);

			checkEffect(ewsIndexDef);
			
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			ewsIndexDef.setCreateId(user.getUserName());
			
			ewsSchedulerService.addEwsIndexDefSch(ewsIndexDef);

			ewsIndexDefService.addEwsIndexDef(ewsIndexDef);

			json.setCode("s");
			json.setSuccess("succeed");
			json.setMessage("新增指标成功");
			return json;
			
		} catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			json.setCode("e");
			json.setSuccess("error");
			json.setMessage(e.getMessage());
			return json;
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			json.setCode("e");
			json.setSuccess("error");
			json.setMessage("新增指标异常");
			return json;
		}
	}

	/**
	 * 修改指标页面
	 * @param indexNo
	 * @return
	 */
	@RequestMapping(value = "/updateindexpage")
	@ResponseBody
	public ModelAndView updateIndexDefPage(String indexNo) {
		ModelAndView modelAndView = new ModelAndView("ews/ewsindexdef/updateindex");
		EwsIndexDef ewsIndexDef = ewsIndexDefService.queryByWarnIndexNo(indexNo);
		modelAndView.addObject("index", ewsIndexDef);
		setModelAndView(modelAndView);
		
		return modelAndView;
	}

	/**
	 * 更新指标
	 * @param ewsIndexDef
	 * @return
	 */
	@RequestMapping(value = "/updateindex")
	@ResponseBody
	public Object updateIndexDef(EwsIndexDef ewsIndexDef) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("更新指标定义对象 = " + ewsIndexDef);
			checkUpdateEwsIndexDef(ewsIndexDef);
			
			EwsIndexDef oldEwsIndexDef = ewsIndexDefService.queryByWarnIndexNo(ewsIndexDef.getWarnIndexNo());
			if(oldEwsIndexDef == null) {
				logger.error(String.format("更新预警指标失败，无效的预警指标编号:【%s】", ewsIndexDef.getWarnIndexNo()));
				throw new ServiceException(String.format("无效的预警指标编号:【%s】", ewsIndexDef.getWarnIndexNo()));
			}

			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			ewsIndexDef.setUpdateId(user.getUserName());
			
			// 检查是否有对应的时效代码
			checkEffect(ewsIndexDef);
			
			// 如果调度表达式或调度状态有更新，则需要更新指标调度
			if(!StringUtils.equals(ewsIndexDef.getCronExpress(), oldEwsIndexDef.getCronExpress()) || 
					!StringUtils.equals(ewsIndexDef.getStatus(), oldEwsIndexDef.getStatus())) {
				logger.info("预警指标【{}】调度表达式有变化，准备更新调度任务：【{}】... ...", 
						ewsIndexDef.getWarnIndexNo(), ewsIndexDef.getCronExpress());
				ewsSchedulerService.updateEwsIndexDefSch(ewsIndexDef);
				logger.info("预警指标【{}】调度任务更新完毕！", 	ewsIndexDef.getWarnIndexNo());
			}

			ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);

			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("更新指标成功");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("更新预警指标异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("更新预警指标异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("更新预警指标异常");
			return jm;
		}
	}

	/**
	 * 开启或关闭某个指标的调度任务
	 * @param warnIndexNo 指标编号
	 * @param curStatus   （页面上）指标的当前状态
	 * @return
	 */
	@RequestMapping(value = "/updateindexsch")
	@ResponseBody
	public Object updateIndexSch(@RequestParam(value="warnIndexNo")String warnIndexNo, 
			@RequestParam(value="curStatus")String curStatus) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info(String.format("更新指标调度任务参数 = 【%s】【%s】", new Object[]{warnIndexNo, curStatus}));
			
			if(StringUtils.isBlank(warnIndexNo)) {
				throw new ServiceException("指标编号不能为空！");
			}
			
			if(StringUtils.isBlank(curStatus)) {
				throw new ServiceException("当前指标调度状态不能为空！");
			}
			
			EwsIndexDef ewsIndexDef = ewsIndexDefService.queryByWarnIndexNo(warnIndexNo);
			if(ewsIndexDef == null) {
				throw new ServiceException(String.format("指标编号【%s】不存在！", warnIndexNo));
			}
			
			// 页面上状态是START，所以用户是要关闭调度
			if("START".endsWith(curStatus)) {
				// 如果当前是开启状态，就关闭该调度任务
				if("START".equals(ewsIndexDef.getStatus())) {
					// 去调度中心更新任务调度
					logger.info("准备去调度系统暂停指标【{}】的调度任务... ...", ewsIndexDef.getWarnIndexNo());
					ewsSchedulerService.pauseEwsIndexDefSch(ewsIndexDef);
					logger.info("成功暂停指标【{}】的调度任务", ewsIndexDef.getWarnIndexNo());
					
					ewsIndexDefService.updateIndexSchStatus(warnIndexNo, "CLOSE");
				} else {
					logger.info("预警指标【{}】调度任务为CLOSE状态，无须关闭调度！", warnIndexNo);
				}
				
				jm.setMessage("成功关闭指标调度任务");
			
			// 页面上状态是CLOSE，所以用户是要开启调度
			} else {
				// 如果当前是关闭状态，就卡其该调度任务
				if("CLOSE".equals(ewsIndexDef.getStatus())) {
					// 去调度中心更新任务调度
					logger.info("准备去调度系统恢复指标【{}】的调度任务... ...", ewsIndexDef.getWarnIndexNo());
					ewsSchedulerService.recoveryEwsIndexDefSch(ewsIndexDef);
					logger.info("成功恢复指标【{}】的调度任务", ewsIndexDef.getWarnIndexNo());
					
					ewsIndexDefService.updateIndexSchStatus(warnIndexNo, "START");
				} else {
					logger.info("预警指标【{}】调度任务为START状态，无须开启调度！", warnIndexNo);
				}
				
				jm.setMessage("成功开启指标调度任务");
			}

			jm.setCode("s");
			jm.setSuccess("succeed");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("更新指标调度任务异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("更新指标调度任务异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("更新指标调度任务异常");
			return jm;
		}
	}
	
	/**
	 * 立即执行调度任务
	 * @param warnIndexNo 指标编号
	 * @param curStatus   （页面上）指标的当前状态
	 * @return
	 */
	@RequestMapping(value = "/runindexsch")
	@ResponseBody
	public Object runIndexSch(final String warnIndexNo) {
		final JsonMessage jm = new JsonMessage();
		try {
			logger.info(String.format("立即执行指标调度任务参数 = 【%s】", warnIndexNo));
			
			if(StringUtils.isBlank(warnIndexNo)) {
				throw new ServiceException("指标编号不能为空！");
			}
			
			EwsIndexDef ewsIndexDef = ewsIndexDefService.queryByWarnIndexNo(warnIndexNo);
			if(ewsIndexDef == null) {
				throw new ServiceException(String.format("指标编号【%s】不存在！", warnIndexNo));
			}
			
//			if("RUNNING".equals(ewsIndexDef.getRunStatus())) {
//				logger.warn(String.format("指标任务【%s】正在执行，请稍后尝试.", warnIndexNo));
//				throw new ServiceException("指标任务正在执行，请稍后尝试");
//			}
			
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						logger.info("准备执行指标【{}】调度任务... ...", warnIndexNo);
						ewsTaskService.doTask(warnIndexNo);
					} catch (Exception e) {
						logger.error("准备执行指标【{}】调度任务异常：", warnIndexNo, e);
					}
				}
			}).start();
			
			jm.setMessage("指标调度任务已经提交");
			jm.setCode("s");
			jm.setSuccess("succeed");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("指标调度任务执行失败", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("指标调度任务执行失败", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("指标调度任务执行失败");
			return jm;
		}
	}
	
	
	/**
	 * 导出所有指标
	 * @param ewsIndexDef
	 * @return
	 */
	@RequestMapping(value = "/export")
	@ResponseBody
	public ModelAndView exportWarnIndex(EwsIndexDef ewsIndexDef) {
		logger.info("预警指标维护--导出所有指标信息: Start exportWarnIndex");
		Map<String, Object> empMap = new HashMap<String, Object>();
		try {
			IPage<EwsIndexDef> indexDefResult = ewsIndexDefService.queryEwsIndexDefByPage(ewsIndexDef, 1,
					Integer.MAX_VALUE);
			ArrayList<String[]> excel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] { "指标编号", "指标名称", "是否有效", "预警来源", "预警阶段", "预警性质", "预警分类", 
					"调度表达式", "风险等级", "创建人员", "创建日期", "修改人员", "修改日期" };
			// 填充数据
			String[] cells = null;
			for (EwsIndexDef indexDef : indexDefResult.getData()) {
				cells = new String[13];
				cells[0] = indexDef.getWarnIndexNo();
				cells[1] = indexDef.getWarnIndexName();
				if ("Y".equals(indexDef.getIsValid())) {
					cells[2] = "有效";
				} else if ("N".equals(indexDef.getIsValid())) {
					cells[2] = "无效";
				}
				
				EwsParam ewsParam = ewsParamService.queryEwsParamByParamCodeAndTypeCode(indexDef.getWarnSource(), EwsConstantsUtil.WARN_SOURCE);
				cells[3] = ewsParam == null ? "" : ewsParam.getParamName();
				
				ewsParam = ewsParamService.queryEwsParamByParamCodeAndTypeCode(indexDef.getWarnStage(), EwsConstantsUtil.WARN_STAGE);
				cells[4] = ewsParam == null ? "" : ewsParam.getParamName();
				
				ewsParam = ewsParamService.queryEwsParamByParamCodeAndTypeCode(indexDef.getWarnProperty(), EwsConstantsUtil.WARN_PROPERTY);
				cells[5] = ewsParam == null ? "" : ewsParam.getParamName();
				
				ewsParam = ewsParamService.queryEwsParamByParamCodeAndTypeCode(indexDef.getWarnClassCode(), EwsConstantsUtil.WARN_CLASS_CODE);
				cells[6] = ewsParam == null ? "" : ewsParam.getParamName();
				
				cells[7] = indexDef.getCronExpress();

				ewsParam = ewsParamService.queryEwsParamByParamCodeAndTypeCode(indexDef.getWarnLevel(), EwsConstantsUtil.WARN_LEVEL);
				cells[8] = ewsParam == null ? "" : ewsParam.getParamName();
				
				cells[9] = indexDef.getCreateId();
				cells[10] = DateUtils.formatDate(indexDef.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
				cells[11] = indexDef.getUpdateId();
				if (indexDef.getUpdateTime() != null) {
					cells[12] = DateUtils.formatDate(indexDef.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
				}
				
				excel.add(cells);
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;

			String fileName = "监控预警指标导出-" + DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			empMap.put("data", excel);
			empMap.put("cellsTitle", cellsTitle);
			empMap.put("fileName", fileName);
			empMap.put("dataAlign", dataAlign);
			empMap.put("sheetName", "监控预警指标维护列表");
			empMap.put("orgCode", "Sheet1");// 设置excel工作表名,orgCode为ViewExcel的特定名称
			
		} catch (ServiceException e) {
			logger.error("预警指标维护信息导出异常：", e.getMessage());
		}
		
		logger.debug("end exportWarnIndex");
		
		return new ModelAndView(new ViewExcel(), empMap);
	}

	/**
	 * 给模型赋值下拉列表内容
	 * @param modelAndView
	 */
	private void setModelAndView(ModelAndView modelAndView) {
		// 预警阶段
		List<EwsParam> warnStageList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_STAGE);
		// 预警性质
		List<EwsParam> warnPropertyList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_PROPERTY);
		// 预警分类
		List<EwsParam> warnClassList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_CLASS_CODE);
		// 风险等级
		List<EwsParam> warnLevelList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_LEVEL);
		// 预警来源
		List<EwsParam> warnSourceList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_SOURCE);
		
		modelAndView.addObject("warnStageList", warnStageList);
		modelAndView.addObject("warnPropertyList", warnPropertyList);
		modelAndView.addObject("warnClassList", warnClassList);
		modelAndView.addObject("warnLevelList", warnLevelList);
		modelAndView.addObject("warnSourceList", warnSourceList);
	}
	
	/**
	 * 检查新增指标对象正确性
	 * @param indexDef
	 */
	private void checkEwsIndexDef(EwsIndexDef indexDef) {
		checkUpdateEwsIndexDef(indexDef);

		if (StringUtils.isBlank(indexDef.getWarnIndexName())) {
			logger.error("指标名称为空");
			throw new ServiceException("指标名称为空");
		}
		
		if (StringUtils.isBlank(indexDef.getCronExpress())) {
			logger.error("指标调度表达式为空");
			throw new ServiceException("指标调度表达式为空");
		}
		
		if (StringUtils.isBlank(indexDef.getWarnSource())) {
			logger.error("指标预警来源为空");
			throw new ServiceException("指标预警来源为空");
		}

		if (StringUtils.isBlank(indexDef.getWarnStage())) {
			logger.error("预警阶段为空");
			throw new ServiceException("预警阶段为空");
		}

		if (StringUtils.isBlank(indexDef.getWarnProperty())) {
			logger.error("预警性质为空");
			throw new ServiceException("预警性质为空");
		}

		if (StringUtils.isBlank(indexDef.getIsValid())) {
			logger.error("指标的有效标志为空");
			throw new ServiceException("指标的有效标志为空");
		}
		
		if (StringUtils.isBlank(indexDef.getWarnLevel())) {
			logger.error("指标的风险等级为空");
			throw new ServiceException("指标的风险等级为空");
		}
		
		if (StringUtils.isBlank(indexDef.getWarnClassCode())) {
			logger.error("指标的预警分类为空");
			throw new ServiceException("指标的预警分类为空");
		}
		
		if(ewsIndexDefService.queryByWarnIndexNo(indexDef.getWarnIndexNo()) != null) {
			logger.error("指标编号【{}】已存在", indexDef.getWarnIndexNo());
			throw new ServiceException(String.format("指标编号【%s】已存在", indexDef.getWarnIndexNo()));
		}
	}
	
	/**
	 * 检查更新指标对象正确性
	 * @param indexDef
	 */
	private void checkUpdateEwsIndexDef(EwsIndexDef indexDef) {
		if (indexDef == null) {
			logger.error("预警指标对象为空");
			throw new ServiceException("预警指标对象为空");
		}

		if (StringUtils.isBlank(indexDef.getWarnIndexNo())) {
			logger.error("指标编号为空");
			throw new ServiceException("指标编号为空");
		}
	}
	
	/**
	 * 检查时效代码是否存在
	 * @param ewsIndexDef
	 */
	private void checkEffect(EwsIndexDef ewsIndexDef) {
		// 检查是否有对应的时效代码
		String warnClassCode = ewsIndexDef.getWarnClassCode();
		String warnLevel = ewsIndexDef.getWarnLevel();
		
		EwsEffect ewsEffect = ewsEffectService.queryByWarnClassAndWarnLevel(warnClassCode, warnLevel);
		if(ewsEffect == null) {
			logger.error(String.format("更新预警指标失败，预警分类【%s】和风险等级【%s】对应的预警时效不存在！", 
					new Object[]{warnClassCode, warnLevel}));
			throw new ServiceException(String.format("预警分类【%s】和风险等级【%s】对应的预警时效不存在！", 
					new Object[]{warnClassCode, warnLevel}));
		}
		
		ewsIndexDef.setEffectCode(ewsEffect.getEffectCode());
	}
	
}
