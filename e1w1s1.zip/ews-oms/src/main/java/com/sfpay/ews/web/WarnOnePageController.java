package com.sfpay.ews.web;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.dto.WarnIndexDefDTO;
import com.sfpay.ews.dto.WarnOnePageDTO;
import com.sfpay.ews.dto.WarnOnePageQryDTO;
import com.sfpay.ews.service.IWarnIndexDefService;
import com.sfpay.ews.service.IWarnOnePageConService;
import com.sfpay.ews.util.CalendarUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.StringUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;



/**
 * 
 * 类说明：风控预警各模块OnePage页面
 * 
 * 
 * <p>
 * 详细描述：
 * 
 * 
 * </p>
 * 
 * @author 575740 Victory
 * 
 * CreateDate: 2014-04-15
 */

@Controller
@RequestMapping("/viewall")
public class WarnOnePageController {
	
	private static Logger logger = LoggerFactory.getLogger(WarnOnePageController.class);
	
	private final CalendarUtil calUtil=new CalendarUtil();
	
	@Resource
	private IWarnOnePageConService warnOnePageConService;
	
	@Resource
	private IWarnIndexDefService warnIndexDefService;
	/**
	 * 
	 * 方法说明：获取当前用户<br>
	 * 
	 * @return 当前用户
	 */
	private User getCurrentUser() {
		return (User) SecurityManager.getSessionAttribute("SESSION_USER");
	}

	/**
	 * 风控预警各模块OnePage主界面
	 * @return
	 */
	@RequestMapping(value = "/onepage/warnmain")
	public ModelAndView initOnePage(){
		logger.info("1. 风控预警OnePage主界面 ---进入:(WarnOnePageController.initOnePage) ");	
		ModelAndView mav = new ModelAndView("ewswarn/onepage/warnmain");
		mav.addObject("beginDate", calUtil.getYesday());
		mav.addObject("endDate", calUtil.getToday());
		logger.info("1. 风控预警OnePage主界面 ---转到页面:(WarnOnePageController.initOnePage)->ewswarn/onepage/warnmain ");
		return mav;
	}
	
	/**
	 * 
	 * 方法说明：告警历史查询
	 * 
	 * @param param
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping(value = "/onepage/list")
	@ResponseBody
	public Object queryWarnHistory(WarnOnePageQryDTO param, int page, int rows){
		JsonMessage jm = new JsonMessage();
		try{
			//校验时间参数是否31天内
			SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd");
			Date datesEnd=null;
			Date datesStart=null;
			datesEnd=formatter.parse(param.getWarnDateE());
			datesStart=formatter.parse(param.getWarnDateS());
			long result = datesEnd.getTime()-datesStart.getTime();
			result=result/(1000*24*60*60);
			if(result>32){
				jm.setCode("e");
				jm.setSuccess("error");
				jm.setMessage("查询的时间范围必须在一个月内！");
				return jm;
			}
			logger.info("2. 风控预警OnePage主界面告警历史查询 ---进入:(WarnOnePageController.queryWarnHistory) ");
			param.setEmpId(getCurrentUser().getUserName());
			logger.info("2. 风控预警OnePage主界面 告警历史查询---转到页面:(WarnOnePageController.queryWarnHistory)->登陆人: "+param.getEmpId()+",page:"+page+",rows:"+rows);
			return warnOnePageConService.queryWarnMsData(param, page, rows);	
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("查询异常");
			return jm;
		}
	}
	
	/**
	 * 进入预警指标结果的处理页面;
	 * @return
	 */
	@RequestMapping(value = "/onepage/dealresult")
	@ResponseBody
	public ModelAndView addwarnDealResult(String warnNo){
		logger.info("3. 风控预警OnePage主界面 ---进入指标结果的处理页面:(WarnOnePageController.addwarnDealResult) ");
		ModelAndView mav = new ModelAndView("ewswarn/onepage/warndealresult");
		mav.addObject("warnNo",warnNo);
		logger.info("3. 风控预警OnePage主界面 ---转到指标结果的处理页面页面:(WarnOnePageController.addwarnDealResult)->ewswarn/onepage/warndealresult ");
		return mav;
	}
	
	/**
	 * 指标结果处理
	 * @return
	 */
	@RequestMapping(value = "/onepage/dodealresult")
	@ResponseBody
	public Object dodealresult(String warnNo,String remark){
		JsonMessage jm = new JsonMessage();
		try{
			if(StringUtils.isNullOrEmpty(remark)){
				throw new ServiceException("请填写处理说明");
			}
			if(remark.length() > 500){
				throw new ServiceException("处理说明不能超过500个字符");
			}
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			logger.info("4. 风控预警OnePage主界面 ---指标结果处理-开始:(WarnOnePageController.dodealresult),warnNo: "+warnNo+",remark:"+remark);
			warnOnePageConService.updateWarnMsDealResult(warnNo, remark, user.getUserName());
			logger.info("4. 风控预警OnePage主界面 ---指标结果处理-结束:(WarnOnePageController.addwarnDealResult) ");
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("处理成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("处理异常");
			return jm;
		}
	}
	
	
    /**
     * 进入预警系统的显示明细页面，根据系统来源查询URL;
     * @param warnNo
     * @param warnIndexNo,预警指标编号,主要是为了展示顺手付红包的明细（added by xiognwei7）
     * @param warnSource
     * @return
     */
	@RequestMapping(value = "/onepage/turndetailurl")
	@ResponseBody
	public ModelAndView showSysDetail(String warnNo,String warnSource,String tmpIsDealing,String warnIndexNo){
		
		JsonMessage jm = new JsonMessage();
		WarnOnePageDTO warnOnePageDTO=null;
		WarnIndexDefDTO warnIndexDefDTO = null;
		ModelAndView mav = null;
		try{
			logger.info("5. 风控预警OnePage主界面 ---根据系统来源查询URL-开始:(WarnOnePageController.showSysDetail),warnNo: "+warnNo+",warnSource:"+warnSource+",warnIndexNo:"+warnIndexNo);
			String sysurl = warnOnePageConService.getDetailUrlByWarnSource(warnSource,warnIndexNo);
			warnOnePageDTO = warnOnePageConService.getMsDataOnlyByWarnNo(warnNo);
			warnIndexDefDTO = warnIndexDefService.queryWarnIndexDefByIndexNo(warnIndexNo);
			warnOnePageDTO.setRemark(warnIndexDefDTO.getRemark());
			logger.info("5. 风控预警OnePage主界面 ---根据系统来源查询URL-结束:(WarnOnePageController.showSysDetail),sysurl: "+sysurl);
			
	    	mav = new ModelAndView(sysurl);
	    	mav.addObject("warnNo",warnNo);
	    	mav.addObject("warnSource",warnSource);
			mav.addObject("msData",warnOnePageDTO);	
			mav.addObject("tmpIsDealing",tmpIsDealing);	
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("查预警系统的明细资料异常");		
		}		
		return mav;		
	}
	/**
	 * 
	 * 方法说明：进入预警系统的显示明细页面,根据WarnNo，warnSource，
	 *          查询该页面的资料
	 * @param param
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping(value = "/onepage/detailshow")
	@ResponseBody
	public Object queryWarnDetailList(String warnSource,String warnNo, int page, int rows){
		JsonMessage jm = new JsonMessage();
		try{
			//设置一个明细单号;
			logger.info("6. 风控预警OnePage主界面 ---进入显示明细页面:(WarnOnePageController.queryWarnDetailList),warnNo: "+warnNo+",warnSource:"+warnSource+",page:"+page+",rows:"+rows);
			return warnOnePageConService.getDetailDataByWarnNo(warnSource, warnNo, page, rows);			
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("查预警系统的明细资料异常");
			return jm;
		}
	}
	
	
	@RequestMapping(value = "/onepage/export")
	public ModelAndView exportWarnHistory(WarnOnePageQryDTO warnOnePageQryDTO){
		logger.info("7. 风控预警OnePage主界面---导出预警历史信息：(WarnOnePageController.exportWarnHistory()");
		//WarnOnePageDTO resultDTO = warnOnePageService.queryWarnMSHistory(warnOnePageQryDTO);
		Map<String, Object> warnMap = new HashMap<String, Object>();
		try {
			//设置当前登录的用户id
			warnOnePageQryDTO.setEmpId(getCurrentUser().getUserName());
			IPage<WarnOnePageDTO> resultDto = warnOnePageConService.queryWarnMsData(warnOnePageQryDTO, 1, Integer.MAX_VALUE);
			ArrayList<String[]> excel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] { "风险等级","预警来源", "预警指标","监控日期","预警异常日期","预警说明","预警频率","处理状态","处理结果说明","预警类别"};
			// 填充数据
			String[] cells = null;
			for(WarnOnePageDTO dto:resultDto.getData()){
				cells = new String[10];
				if(dto.getWarnLevel().equals("L1")){
					cells[0]="高";
				}else if(dto.getWarnLevel().equals("L2")){
					cells[0]="较高";
				}else if(dto.getWarnLevel().equals("L3")){
					cells[0]="中";
				}else if(dto.getWarnLevel().equals("L4")){
					cells[0]="较低";
				}else if(dto.getWarnLevel().equals("L5")){
					cells[0]="低";
				}
				
				if(dto.getWarnSource().equals("COD")){
					cells[1]="COD系统";
				}else if(dto.getWarnSource().equals("MARKET")){
					cells[1]="营销系统";
				}else if(dto.getWarnSource().equals("WAYBILL")){
					cells[1]="运单系统";
				}else if(dto.getWarnSource().equals("ACQ")){
					cells[1]="银企系统";
				}else if(dto.getWarnSource().equals("BTOC")){
					cells[1]="银企B2C系统";
				}else if(dto.getWarnSource().equals("MPAY")){
					cells[1]="手机支付系统";
				}else if(dto.getWarnSource().equals("STOREDCARD")){
					cells[1]="储值卡系统";
				}else if(dto.getWarnSource().equals("ELEACCOUNT")){
					cells[1]="电子账户系统";
				}else if(dto.getWarnSource().equals("TRADEORDER")){
					cells[1]="核心订单系统";
				}else if(dto.getWarnSource().equals("COREACCOUNT")){
					cells[1]="核心账户系统";
				}else if(dto.getWarnSource().equals("PAS")){
					cells[1]="垫付货款系统";
				}else if(dto.getWarnSource().equals("SYPAY")){
					cells[1]="顺手付系统";
				}else if(dto.getWarnSource().equals("DEBIT")){
					cells[1]="公款代扣系统";
				}else if(dto.getWarnSource().equals("SFGOM")){
					cells[1]="安心购系统";
				}else if(dto.getWarnSource().equals("SFM")){
					cells[1]="米兰港系统";
				}else if(dto.getWarnSource().equals("RM")){
					cells[1]="风控系统";
				}
				cells[2] = dto.getWarnIndexNo();
				cells[3] = dto.getWarnDate();
				cells[4] = dto.getWarnTime();
				cells[5] = dto.getWarnExplain();
				cells[6] = dto.getWarnCycle();
				if(dto.getIsDealing().equals("N")){
					cells[7] = "未处理";
				}else if(dto.getIsDealing().equals("Y")){
					cells[7] = "已处理";
				}
				
				cells[8] = dto.getWarnDealResult();
				cells[9] = dto.getWarnType();
				excel.add(cells);
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;
			
			String fileName = "warnDataMs-"+DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			warnMap.put("data", excel);
			warnMap.put("cellsTitle", cellsTitle);
			warnMap.put("fileName", fileName);
			warnMap.put("dataAlign", dataAlign);
			warnMap.put("sheetName", "监控预警信息列表");
			warnMap.put("orgCode", "Sheet1");//设置excel工作表名,orgCode为ViewExcel的特定名称
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("监控预警信息导出异常：", e.getMessage());
		}
		logger.debug("end WarnOnePageController.exportWarnHistory()");
		return new ModelAndView(new ViewExcel(), warnMap);		
	
	
	}
	
	
}
