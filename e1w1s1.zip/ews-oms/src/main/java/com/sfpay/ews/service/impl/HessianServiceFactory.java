package com.sfpay.ews.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.ews.service.IHessianServiceFactory;
import com.sfpay.ews.service.IWarnOnePageService;
import com.sfpay.framework.common.hession.HessianInvoke;


/**
 * 
 * 
 * 类说明：HessianService工厂类
 * 
 * 
 * <p>
 * 详细描述：
 * 
 * 
 * @author 324945
 * 
 *         CreateDate: 2012-3-22
 */
@Service(value = "hessianServiceFactory")
public class HessianServiceFactory implements IHessianServiceFactory {

	
	/**
	 * Hessian服务工厂构造器
	 */
	public HessianServiceFactory() {

	}

	@Resource
	private HessianInvoke ewsServiceInvoke;
	
	
	private IWarnOnePageService warnOnePageService;
		
	
	@Override
	public IWarnOnePageService getWarnOnePageService() {
		if (warnOnePageService == null) {
			warnOnePageService = (IWarnOnePageService) ewsServiceInvoke.getImpl(IWarnOnePageService.class, "warnOnePageService");
		}
		return warnOnePageService;
	}

}
