package com.sfpay.ews.platform.web.vo;

public class EwsGroup {
	//组号
	private String ewsGroupNo;
	//组名
	private String ewsGroupName;
	//预警人员代码
	private String ewsEmpNo;
	//短信是否被选中
	private String isSmsChecked;
	//邮件是否被选中
	private String isMailChecked;
	//是否被选中
	private String isChecked;
	//是否启用
	private String isValid;
	
	public String getEwsGroupNo() {
		return ewsGroupNo;
	}
	public void setEwsGroupNo(String ewsGroupNo) {
		this.ewsGroupNo = ewsGroupNo;
	}
	public String getEwsGroupName() {
		return ewsGroupName;
	}
	public void setEwsGroupName(String ewsGroupName) {
		this.ewsGroupName = ewsGroupName;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getIsSmsChecked() {
		return isSmsChecked;
	}
	public void setIsSmsChecked(String isSmsChecked) {
		this.isSmsChecked = isSmsChecked;
	}
	public String getIsMailChecked() {
		return isMailChecked;
	}
	public void setIsMailChecked(String isMailChecked) {
		this.isMailChecked = isMailChecked;
	}
	public String getEwsEmpNo() {
		return ewsEmpNo;
	}
	public void setEwsEmpNo(String ewsEmpNo) {
		this.ewsEmpNo = ewsEmpNo;
	}
	public String getIsChecked() {
		return isChecked;
	}
	public void setIsChecked(String isChecked) {
		this.isChecked = isChecked;
	}


}
