package com.sfpay.ews.platform.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.platform.domain.EwsEffect;
import com.sfpay.ews.platform.domain.EwsParam;
import com.sfpay.ews.platform.service.IEwsEffectService;
import com.sfpay.ews.platform.service.IEwsParamService;
import com.sfpay.ews.platform.util.EwsConstantsUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

import ch.qos.logback.classic.Logger;

@Controller
@RequestMapping("/ewseffect")
public class EwsIndexEffectController {
	private Logger logger = (Logger) LoggerFactory.getLogger(EwsIndexEffectController.class);
	
	@Autowired
	private IEwsEffectService ewsEffectService;
	
	@Autowired
	private IEwsParamService ewsParamService;
	
	/**
	 * 时效维护主界面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/effectmain")
	public ModelAndView initEffectMaintain() {
		ModelAndView mv = new ModelAndView("ews/ewseffect/effectmain");
		
		List<EwsParam> warnClassList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_CLASS_CODE);
		mv.addObject("allWarnClassCodes", warnClassList);

		List<EwsParam> warnLevelList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_LEVEL);
		mv.addObject("allWarnLevels", warnLevelList);
		return mv;
	}

	/**
	 * 预警指标参数查询列表
	 * 
	 * @return
	 */
	@RequestMapping(value = "/queryeffectlist")
	@ResponseBody
	public Object queryEffectList(EwsEffect ewsEffect, int page, int rows) {
		JsonMessage jm = new JsonMessage();
		try {
			return ewsEffectService.selectEwsEffectByPage(ewsEffect, page, rows);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("预警指标参数查询异常");
			return jm;
		}
	}

	/**
	 * 指标参数新增界面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/addeffect")
	public ModelAndView addEffect() {
		ModelAndView mv = new ModelAndView("ews/ewseffect/addeffect");
		
		List<EwsParam> warnClassList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_CLASS_CODE);
		mv.addObject("allWarnClassCodes", warnClassList);

		List<EwsParam> warnLevelList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_LEVEL);
		mv.addObject("allWarnLevels", warnLevelList);
		
		return mv;
	}

	/**
	 * 新增时效记录
	 * 
	 * @return
	 */
	@RequestMapping(value = "/addewseffect")
	@ResponseBody
	public Object addEwsEffect(EwsEffect ewsEffect) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			EwsEffect effect = ewsEffectService.queryByEffectCode(ewsEffect.getEffectCode());
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			if (effect != null) {
				jsonMessage.setCode("warn");
				jsonMessage.setSuccess("warning");
				jsonMessage.setMessage("该时效记录已存在");
				return jsonMessage;
			}
			EwsEffect effectEws=new EwsEffect();
			effectEws.setEffectCode(ewsEffect.getEffectCode());
			effectEws.setEffectName(ewsEffect.getEffectName());
			effectEws.setCreateId(user.getUserName());
			effectEws.setEffectTime(ewsEffect.getEffectTime());
			effectEws.setOverEffectTime(ewsEffect.getOverEffectTime());
			effectEws.setRemark(ewsEffect.getRemark());
			effectEws.setThresholdLevel(ewsEffect.getThresholdLevel());
			effectEws.setWarnClassCode(ewsEffect.getWarnClassCode());
			effectEws.setWarnLevel(ewsEffect.getWarnLevel());
			ewsEffectService.addEwsEffect(effectEws);
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("新增时效记录成功");
			return jsonMessage;
		}catch(ServiceException e){
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage(e.getMessage());
			return jsonMessage;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("新增时效记录异常");
			return jsonMessage;
		}
	}

	/**
	 * 时效记录更新界面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/updateeffect")
	public ModelAndView updateEffect(String id) {
		ModelAndView mav = new ModelAndView("ews/ewseffect/updateeffect");
		EwsEffect effect = ewsEffectService.queryById(Long.valueOf(id));
		mav.addObject("effect", effect);
		
		List<EwsParam> warnClassList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_CLASS_CODE);
		mav.addObject("allWarnClassCodes", warnClassList);

		List<EwsParam> warnLevelList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_LEVEL);
		mav.addObject("allWarnLevels", warnLevelList);
		
		return mav;
	}

	/**
	 * 
	 * 方法：更新时效记录 方法说明：
	 * 
	 * @param ewsIndexParam
	 * @return
	 */
	@RequestMapping(value = "/updateewseffect")
	@ResponseBody
	public Object updateEwsEffect(EwsEffect effect) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			ewsEffectService.updateEwsEffect(effect);
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("更新时效记录成功");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("更新时效记录异常");
			return jsonMessage;
		}
	}

	/**
	 * 
	 * 方法：删除时效记录 方法说明：
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/deleteewsparam")
	@ResponseBody
	public Object deleteEwsIndexParam(String id) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			ewsEffectService.deleteEwsEffect(Long.valueOf(id));
			jsonMessage.setCode("success");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("删除时效记录成功");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("删除时效记录异常");
			return jsonMessage;
		}
	}

	/**
	 * 导出时效记录信息
	 */
	@RequestMapping(value = "/exporteffectlist")
	public ModelAndView exportEffectList(EwsEffect effect) {
		logger.info("导出时效记录信息开始...");
		Map<String, Object> groupMap = new HashMap<String, Object>();
		try {
			IPage<EwsEffect> result = ewsEffectService.selectEwsEffectByPage(effect, 1, Integer.MAX_VALUE);
			ArrayList<String[]> exportExcel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] { "时效编码", "时效名称", "时效时间", "超时处理时效时间", "预警分类", "风险等级", "级别阀值", "备注",
					"创建人", "创建时间", "修改人", "修改时间" };
			// 填充数据
			String[] contenCells = new String[12];
			for (EwsEffect ewsEffect : result.getData()) {
				contenCells[0] = ewsEffect.getEffectCode();
				contenCells[1] = ewsEffect.getEffectName();
				contenCells[2] = ewsEffect.getEffectTime().toString();
				contenCells[3] = ewsEffect.getOverEffectTime().toString();
				contenCells[4] = ewsEffect.getWarnClassName();
				contenCells[5] = ewsEffect.getWarnLevelName();
				contenCells[6] = ewsEffect.getThresholdLevel();
				contenCells[7] = ewsEffect.getRemark();
				contenCells[8] = ewsEffect.getCreateId();
				contenCells[9] = DateUtils.formatDate(ewsEffect.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
				contenCells[10] = ewsEffect.getUpdateId();
				if (ewsEffect.getUpdateTime() != null) {
					contenCells[11] = DateUtils.formatDate(ewsEffect.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
				} else {
					contenCells[11] = "";
				}
				exportExcel.add(contenCells.clone());
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;

			String fileName = "时效记录信息-" + DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			groupMap.put("data", exportExcel);
			groupMap.put("cellsTitle", cellsTitle);
			groupMap.put("fileName", fileName);
			groupMap.put("dataAlign", dataAlign);
			groupMap.put("orgCode", "时效记录信息");
			logger.info("导出时效记录信息结束...");
		} catch (ServiceException e) {
			logger.error("时效记录信息导出异常：", e.getMessage());
		}
		return new ModelAndView(new ViewExcel(), groupMap);
	}
}
