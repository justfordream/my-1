package com.sfpay.ews.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.dto.WarnGroupDefDTO;
import com.sfpay.ews.dto.WarnGroupVsIndexDTO;
import com.sfpay.ews.dto.WarnIndexDefDTO;
import com.sfpay.ews.service.IWarnGroupDefService;
import com.sfpay.ews.web.vo.WarnGroupParam;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.common.util.StringUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

/**
 * 群组维护页面
 * @author 321566 张泽豪
 *
 * 2014-4-21 上午10:00:52
 */

@Controller
@RequestMapping("/group")
public class WarnGroupDataController {
	
	private static Logger logger = LoggerFactory.getLogger(WarnGroupDataController.class);
	
	@Resource
	IWarnGroupDefService warnGroupDefService;
	
	//错误页面
//	private final String ERROR_PAGE = "global/error";
	
	/**
	 * 预警群组维护主界面
	 * @return
	 */
	@RequestMapping(value = "/warngroup/warngroupmain")
	public ModelAndView initGroupDataPage(){
		ModelAndView mav = new ModelAndView("ewswarn/warngroup/warngroupmain");
		return mav;
	}
	
	/**
	 * 预警群组查询列表
	 * @return
	 */
	@RequestMapping(value = "/warngroup/querylist")
	@ResponseBody
	public Object querylist(String groupName,String indexName, String isValid,int page, int rows){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询参数groupName = " + groupName);
			logger.info("查询参数indexName = " + indexName);
			logger.info("查询参数isValid = " + isValid);
			WarnGroupDefDTO groupDto = new WarnGroupDefDTO();
			if(groupName != null){
				groupDto.setGroupName(groupName.trim());
			}
			if(indexName != null){
				groupDto.setIndexName(indexName.trim());
			}
			if(isValid != null){
				groupDto.setIsValid(isValid.trim());
			}
			return warnGroupDefService.queryWarnGroupDefByPage(groupDto, page, rows);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("预警群组查询异常");
			return jm;
		}
	}
	
	/**
	 * 新增群组页面
	 * @return
	 */
	@RequestMapping(value = "/warngroup/addwarngroup")
	@ResponseBody
	public ModelAndView addwarngroup(){
		ModelAndView mav = new ModelAndView("ewswarn/warngroup/addwarngroup");
		return mav;
	}
	
	/**
	 * 新增群组
	 * @return
	 */
	@RequestMapping(value = "/warngroup/addgroup")
	@ResponseBody
	public Object addgroup(WarnGroupParam param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("新增群组参数对象 = " + param);
			if(param == null){
				throw new Exception("新增群组参数对象为空");
			}
			WarnGroupDefDTO group = new WarnGroupDefDTO();
			if(param.getGroupNo() != null){
				group.setGroupNo(param.getGroupNo().trim());
			}
			if(param.getGroupName() != null){
				group.setGroupName(param.getGroupName().trim());
			}
			if(param.getIsValid() != null){
				group.setIsValid(param.getIsValid());
			}
			group.setGroupExplain(param.getGroupExplain());
			group.setRemark(param.getRemark());
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			group.setCreateId(user.getUserName());
			warnGroupDefService.saveOrUpdateWarnGroupDef(group);
			
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("新增群组成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("新增群组异常");
			return jm;
		}
	}
	
	/**
	 * 修改群组页面
	 * @return
	 */
	@RequestMapping(value = "/warngroup/updatewarngroup")
	@ResponseBody
	public ModelAndView updatewarngroup(String groupNo){
		ModelAndView mav = new ModelAndView("ewswarn/warngroup/updatewarngroup");
		WarnGroupDefDTO groupDto = warnGroupDefService.queryWarnGroupDefByGroupNo(groupNo);
		mav.addObject("group", groupDto);
		return mav;
	}
	
	/**
	 * 修改群组
	 * @return
	 */
	@RequestMapping(value = "/warngroup/updategroup")
	@ResponseBody
	public Object updategroup(WarnGroupParam param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("修改群组参数对象 = " + param);
			if(param == null){
				throw new Exception("修改群组参数为空");
			}
			WarnGroupDefDTO group = new WarnGroupDefDTO();
			if(param.getGroupNo() != null){
				group.setGroupNo(param.getGroupNo().trim());
			}
			if(param.getGroupName() != null){
				group.setGroupName(param.getGroupName().trim());
			}
			if(param.getIsValid() != null){
				group.setIsValid(param.getIsValid().trim());
			}
			group.setGroupExplain(param.getGroupExplain());
			group.setRemark(param.getRemark());
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			group.setUpdateId(user.getUserName());
			//标记该记录要修改
			group.setFlag("update");
			warnGroupDefService.saveOrUpdateWarnGroupDef(group);
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("修改群组成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("修改群组异常");
			return jm;
		}
	}
	
	/**
	 * 查看群组关联指标
	 * @return
	 */
	@RequestMapping(value = "/warngroup/showgroup")
	@ResponseBody
	public Object showgroup(String groupNo){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("群组编号 = " + groupNo);
			List<WarnIndexDefDTO> indexList = warnGroupDefService.queryAuthIndexByGroupNo(groupNo);
			for(WarnIndexDefDTO dto : indexList){
				if("BEFORE".equals(dto.getWarnType())){
					dto.setWarnType("事前");
				}else if("DURING".equals(dto.getWarnType())){
					dto.setWarnType("事中");
				}else if("AFTER".equals(dto.getWarnType())){
					dto.setWarnType("事后");
				}
				
				if("WARNING".equals(dto.getWarnProperty())){
					dto.setWarnProperty("预警");
				}else if("ERROR".equals(dto.getWarnProperty())){
					dto.setWarnProperty("错误");
				}
				
				if("DAY".equals(dto.getWarnCycle())){
					dto.setWarnCycle("天");
				}else if("HOUR".equals(dto.getWarnCycle())){
					dto.setWarnCycle("小时");
				}else if("MINUTE".equals(dto.getWarnCycle())){
					dto.setWarnCycle("分钟");
				}else if("SECOND".equals(dto.getWarnCycle())){
					dto.setWarnCycle("秒");
				}else if("WEEK".equals(dto.getWarnCycle())){
					dto.setWarnCycle("周");
				}
			}
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("length", indexList.size());
			paramMap.put("indexList", indexList);
			paramMap.put("groupNo", groupNo);
			WarnGroupDefDTO groupDef = warnGroupDefService.queryWarnGroupDefByGroupNo(groupNo);
			paramMap.put("groupName", groupDef.getGroupName());
			jm.setData(paramMap);
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}
	}
	
	/**
	 * 赋指标页面
	 * @return
	 */
	@RequestMapping(value = "/warngroup/authindex")
	@ResponseBody
	public ModelAndView authindex(String groupNo){
		ModelAndView mav = new ModelAndView("ewswarn/warngroup/authindex");
		WarnGroupDefDTO groupDto = warnGroupDefService.queryWarnGroupDefByGroupNo(groupNo);
		mav.addObject("group", groupDto);
		List<WarnIndexDefDTO> authIndexList = warnGroupDefService.queryAuthIndexByGroupNo(groupNo);
		mav.addObject("authList",authIndexList);
		List<WarnIndexDefDTO> unauthIndexList = warnGroupDefService.queryUnAuthIndexByGroupNo(groupNo);
		mav.addObject("unauthList",unauthIndexList);
		return mav;
	}
	
	/**
	 * 赋指标
	 * @return
	 */
	@RequestMapping(value = "/warngroup/doauthindex")
	@ResponseBody
	public Object doauthindex(String groupNo,String indexs){
		JsonMessage jm = new JsonMessage();
		try{
			
			logger.info("群组编号 = " + groupNo);
			logger.info("指标列表 = " + indexs);
			if(StringUtils.isNullOrEmpty(groupNo)){
				throw new ServiceException("群组编号为空");
			}
			if(StringUtils.isNullOrEmpty(indexs)){
				throw new ServiceException("请选择要授权的指标");
			}
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			String[] indexList = indexs.split(";");
			logger.info("分割指标 = " + indexList);
			List<WarnGroupVsIndexDTO> indexDtos = new ArrayList<WarnGroupVsIndexDTO>();
			for(String index : indexList){
				WarnGroupVsIndexDTO groupIndexDTO = new WarnGroupVsIndexDTO();
				groupIndexDTO.setGroupNo(groupNo);
				groupIndexDTO.setWarnIndexNo(index);
				groupIndexDTO.setCreateId(user.getUserName());
				indexDtos.add(groupIndexDTO);
			}
			warnGroupDefService.saveWarnGroupVsIndex(groupNo, indexDtos);
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("赋指标成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("赋指标异常");
			return jm;
		}
	}
	
	/**
	 * 导出预警群组信息
	 * @param groupName
	 * @param indexName
	 * @param isValid
	 * @return
	 */
	@RequestMapping(value = "/warngroup/export")
	@ResponseBody
	public ModelAndView groupExport(String groupName,String indexName, String isValid){
		logger.info("预警管理--预警群组成员导出");
		Map<String,Object> groupMap = new HashMap<String,Object>();
		try {
			WarnGroupDefDTO groupDto = new WarnGroupDefDTO();
			if(groupName != null){
				groupDto.setGroupName(groupName.trim());
			}
			if(indexName != null){
				groupDto.setIndexName(indexName.trim());
			}
			if(isValid != null){
				groupDto.setIsValid(isValid.trim());
			}
			IPage<WarnGroupDefDTO> resultDTO = warnGroupDefService.queryWarnGroupDefByPage(groupDto, 1, Integer.MAX_VALUE); 
			ArrayList< String[]> excel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] {"群组编号","群组名称","是否有效","群组说明","创建人员","创建日期","修改人员","修改日期"};
			//填充数据
			String[] cells = null;
			for(WarnGroupDefDTO dto:resultDTO.getData()){
				cells = new String[8];
				cells[0] = dto.getGroupNo();
				cells[1] = dto.getGroupName();
				if("Y".equals(dto.getIsValid())) {
					cells[2] = "有效";
				}else{
					cells[2] = "无效";
				}
				cells[3] = dto.getGroupExplain();
				cells[4] = dto.getCreateId();
				cells[5] = DateUtils.formatDate(dto.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
				cells[6] = dto.getUpdateId();
				if(dto.getUpdateTime()!=null){
					 cells[7] = DateUtils.formatDate(dto.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
				 }else{
					 cells[7]="";
				 }
				 excel.add(cells);
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;
			
			String fileName = "warnGroupInfo-"+DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			groupMap.put("data", excel);
			groupMap.put("cellsTitle", cellsTitle);
			groupMap.put("fileName", fileName);
			groupMap.put("dataAlign", dataAlign);
			groupMap.put("sheetName", "监控预警信息列表");
			groupMap.put("orgCode", "Sheet1");//设置excel工作表名,orgCode为ViewExcel的特定名称
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			logger.error("预警群组信息导出异常：", e.getMessage());
		}
		logger.debug("end WarnGroupDataController.groupExport");
		return new ModelAndView(new ViewExcel(), groupMap);
	}
	
}
