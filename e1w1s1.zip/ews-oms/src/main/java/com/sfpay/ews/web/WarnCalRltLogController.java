package com.sfpay.ews.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.JsonMessage;
import com.sfpay.ews.dto.WarnCalRltLogDTO;
import com.sfpay.ews.service.IWarnLogService;

/**
 * 日志记录controller
 * 
 * @author 321566 张泽豪
 *
 * 2014-5-8 下午3:49:15
 */
@Controller
@RequestMapping("/invokedrools")
public class WarnCalRltLogController {
	
	private static Logger logger = LoggerFactory.getLogger(WarnCalRltLogController.class);
	
	@Resource
	IWarnLogService warnLogService;
	
	/**
	 * 日志记录主页面
	 * @return
	 */
	@RequestMapping(value = "/warnlog/warnlogview")
	public ModelAndView warnlogview(){
		ModelAndView mav = new ModelAndView("ewswarn/warnlog/logmanager");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		mav.addObject("defaultDate", dateFormat.format(new Date()));
		return mav;
	}
	
	/**
	 * 日志记录查询列表
	 * @return
	 */
	@RequestMapping(value = "/warnlog/querylist")
	@ResponseBody
	public Object querylist(String warnSource,String startWarnDate,String endWarnDate, int page, int rows){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询参数warnSource = " + warnSource);
			logger.info("查询参数startWarnDate = " + startWarnDate);
			logger.info("查询参数endWarnDate = " + endWarnDate);
			WarnCalRltLogDTO param = new WarnCalRltLogDTO();
			if(warnSource != null){
				param.setWarnSource(warnSource.trim());
			}
			if(startWarnDate != null){
				param.setStartWarnDate(startWarnDate.trim());
			}
			
			if(endWarnDate != null){
				param.setEndWarnDate(endWarnDate.trim());
			}
			return warnLogService.queryWarnCalRltLogByPage(param, page, rows);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("日志记录查询异常");
			return jm;
		}
	}
	
	/**
	 * 查看详细页面
	 * @return
	 */
	@RequestMapping(value = "/warnlog/showdetail")
	@ResponseBody
	public ModelAndView showdetail(String id){
		ModelAndView mav = new ModelAndView("ewswarn/warnlog/logdetail");
		WarnCalRltLogDTO logDTO =  warnLogService.queryCalRltLogById(Long.parseLong(id));
		mav.addObject("log", logDTO);
		return mav;
	}
	
}
