package com.sfpay.ews.platform.web;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.platform.domain.EwsInfoRecord;
import com.sfpay.ews.platform.domain.EwsOprRecord;
import com.sfpay.ews.platform.domain.EwsParam;
import com.sfpay.ews.platform.service.IEwsInfoRecordService;
import com.sfpay.ews.platform.service.IEwsOprRecordService;
import com.sfpay.ews.platform.service.IEwsParamService;
import com.sfpay.ews.platform.util.EwsConstantsUtil;
import com.sfpay.ews.util.MutilViewExcel;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

@Controller
@RequestMapping("/ewsinfohandle")
public class EwsInfoHandleController {
	private static Logger logger = LoggerFactory.getLogger(EwsInfoHandleController.class);

	@Autowired
	private IEwsParamService ewsParamService;

	@Autowired
	private IEwsInfoRecordService ewsInfoRecordService;

	@Autowired
	private IEwsOprRecordService ewsOprRecordService;

	@RequestMapping("/ewsinfohandlemain")
	public ModelAndView ewsInfoHandleMain() {
		ModelAndView mv = new ModelAndView("/ews/ewsinfohandle/ewsinfohandlemain");
		List<EwsParam> warnClassList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_CLASS_CODE);
		mv.addObject("allWarnClassCodes", warnClassList);

		List<EwsParam> warnLevelList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_LEVEL);
		mv.addObject("allWarnLevels", warnLevelList);

		List<EwsParam> warnSourceList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.WARN_SOURCE);
		mv.addObject("allWarnSources", warnSourceList);

		List<EwsParam> oprStatuList = ewsParamService.queryAllTypesByParamTypeCode(EwsConstantsUtil.OPR_STATUS);
		mv.addObject("allOprStatus", oprStatuList);
		return mv;
	}

	/**
	 * 
	 * 方法：查询预警信息 方法说明：
	 * 
	 * @param param
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping("/queryewsinfo")
	@ResponseBody
	public Object queryEwsInfo(EwsInfoRecord param, int page, int rows) {
		JsonMessage jsonMessage = new JsonMessage();
		try {
			IPage<EwsInfoRecord> ewsInfoRecordList = ewsInfoRecordService.queryEwsHandleInfoByOrderPage(param, page,
					rows);
			return ewsInfoRecordList;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("e");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("预警信息查询异常");
			return jsonMessage;
		}

	}

	/**
	 * 
	 * 方法：处理单条预警信息 方法说明：
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/handleewsinforecord")
	public ModelAndView handleEwsInfoRecord(String id) {
		ModelAndView mv = new ModelAndView("/ews/ewsinfohandle/handleewsinforecord");

		EwsInfoRecord ewsInfoRecord = ewsInfoRecordService.queryById(id);
		mv.addObject("ewsInfoRecord", ewsInfoRecord);

		List<EwsOprRecord> oprRecordList = ewsOprRecordService.queryEwsOprRecordByWarnInfoRecordId(id);
		if (oprRecordList.size() == 0) {
			mv.addObject("handleTimes", "0");
		} else if (oprRecordList.size() > 0) {
			mv.addObject("handleTimes", oprRecordList.size());
			mv.addObject("oprRecord", oprRecordList);
		}
		return mv;
	}

	/**
	 * 
	 * 方法：查看单条已处理信息 方法说明：
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/viewewsinforecord")
	public ModelAndView viewEwsInfoRecord(String id) {
		ModelAndView mv = new ModelAndView("/ews/ewsinfohandle/viewewsinforecord");
		EwsInfoRecord ewsInfoRecord = ewsInfoRecordService.queryById(id);
		mv.addObject("ewsInfoRecord", ewsInfoRecord);

		List<EwsOprRecord> oprRecordList = ewsOprRecordService.queryEwsOprRecordByWarnInfoRecordId(id);
		if (oprRecordList.size() == 0) {
			mv.addObject("handleTimes", "0");
		} else if (oprRecordList.size() > 0) {
			mv.addObject("handleTimes", oprRecordList.size());
			mv.addObject("oprRecord", oprRecordList);
		}
		return mv;
	}

	/**
	 * 
	 * 方法：批量预警信息处理查看 方法说明：
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/batchhandleewsinforecord")
	public ModelAndView batchHandleEwsInfoRecord(String[] id) {
		ModelAndView mv = new ModelAndView("/ews/ewsinfohandle/batchhandleewsinforecord");
		List<EwsInfoRecord> ewsInfoRecordList = new ArrayList<EwsInfoRecord>();
		for (String warnRecordId : id) {
			ewsInfoRecordList.add(ewsInfoRecordService.queryById(warnRecordId));
		}
		mv.addObject("ewsInfoRecordList", ewsInfoRecordList);
		return mv;
	}

	/**
	 * 
	 * 方法：单条预警信息处理 方法说明：
	 * 
	 * @param id
	 * @param operDesc
	 * @return
	 */
	@RequestMapping("/processrecord")
	@ResponseBody
	public Object processRecord(String id, String operDesc) {
		JsonMessage jsonMessage = new JsonMessage();
		User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
		try {
			EwsOprRecord ewsOprRecord = new EwsOprRecord();
			ewsOprRecord.setOperDate(new Date());
			ewsOprRecord.setOperDesc(operDesc);
			ewsOprRecord.setWarnInfoRecordId(id);
			ewsOprRecord.setCreateId(user.getUserName());
			ewsOprRecord.setOperId(user.getUserName());
			ewsOprRecordService.addEwsOprRecord(ewsOprRecord);
			jsonMessage.setCode("succeed");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("预警信息处理成功！！");
			return jsonMessage;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("error");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("预警信息处理异常");
			return jsonMessage;
		}
	}

	/**
	 * 
	 * 方法：预警信息提交成功 方法说明：
	 * 
	 * @param id
	 * @param operDesc
	 * @return
	 */
	@RequestMapping("/submitrecord")
	@ResponseBody
	public Object submitRecord(String id, String operDesc) {
		JsonMessage jsonMessage = new JsonMessage();
		User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
		try {
			EwsOprRecord ewsOprRecord = new EwsOprRecord();
			ewsOprRecord.setOperDate(new Date());
			ewsOprRecord.setOperDesc(operDesc);
			ewsOprRecord.setWarnInfoRecordId(id);
			ewsOprRecord.setCreateId(user.getUserName());
			ewsOprRecord.setOperId(user.getUserName());
			ewsOprRecordService.addEwsOprRecord(ewsOprRecord);
			EwsInfoRecord ewsInfoRecord = new EwsInfoRecord();
			ewsInfoRecord.setId(id);
			ewsInfoRecord.setOprStatus("PROCESSED");
			ewsInfoRecordService.updateEwsInfoRecord(ewsInfoRecord);
			jsonMessage.setCode("succeed");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("预警信息提交成功！！");
			return jsonMessage;

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("error");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("预警信息提交异常");
			return jsonMessage;
		}
	}

	/**
	 * 
	 * 方法：批量处理预警信息 方法说明：
	 * 
	 * @param ids
	 * @param operDesc
	 * @return
	 */
	@RequestMapping("/batchprocessrecord")
	@ResponseBody
	public Object batchProcessRecord(String[] ids, String operDesc) {
		JsonMessage jsonMessage = new JsonMessage();
		User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
		try {
			for (String warnRecordId : ids) {
				EwsOprRecord ewsOprRecord = new EwsOprRecord();
				ewsOprRecord.setOperDate(new Date());
				ewsOprRecord.setOperDesc(operDesc);
				ewsOprRecord.setOperId(user.getUserName());
				ewsOprRecord.setCreateId(user.getUserName());
				ewsOprRecord.setWarnInfoRecordId(warnRecordId);
				ewsOprRecordService.addEwsOprRecord(ewsOprRecord);
				EwsInfoRecord ewsInfoRecord = new EwsInfoRecord();
				ewsInfoRecord.setId(warnRecordId);
				ewsInfoRecord.setOprStatus("PROCESSED");
				ewsInfoRecordService.updateEwsInfoRecord(ewsInfoRecord);
			}

			jsonMessage.setCode("succeed");
			jsonMessage.setSuccess("succeed");
			jsonMessage.setMessage("批量处理预警信息成功！！");
			return jsonMessage;

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			jsonMessage.setCode("error");
			jsonMessage.setSuccess("error");
			jsonMessage.setMessage("预警信息批量处理异常");
			return jsonMessage;
		}
	}

	/**
	 * 
	 * 方法：导出预警信息 方法说明：
	 * 
	 * @param warnIndexNo
	 * @param warnSource
	 * @param oprStatus
	 * @param warnClassCode
	 * @param warnLevel
	 * @param warnStartDate
	 * @param warnEndDate
	 * @return
	 */
	@RequestMapping("/exportewsinfolist")
	public ModelAndView exportEwsInfoList(String warnIndexNo, String warnSource, String oprStatus,
			String warnClassCode, String warnLevel, Date warnStartDate, Date warnEndDate, String id) {
		Map<String, Object> exportMap = new HashMap<String, Object>();
		try {
			EwsInfoRecord ewsInfoRecord = new EwsInfoRecord();
			ewsInfoRecord.setId(id);
			ewsInfoRecord.setWarnIndexNo(warnIndexNo);
			ewsInfoRecord.setWarnSource(warnSource);
			ewsInfoRecord.setOprStatus(oprStatus);
			ewsInfoRecord.setWarnClassCode(warnClassCode);
			ewsInfoRecord.setWarnLevel(warnLevel);
			ewsInfoRecord.setWarnStartDate(warnStartDate);
			ewsInfoRecord.setWarnEndDate(warnEndDate);
			IPage<EwsInfoRecord> ewsInfoRecordList = ewsInfoRecordService.queryEwsHandleInfoByOrderPage(ewsInfoRecord,
					1, Integer.MAX_VALUE);
			ArrayList<String[]> exportExcel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] { "预警来源", "预警指标编号", "预警指标", "监控日期", "预警异常日期", "预警说明", "处理结果说明", "风险等级",
					"预警分类", "处理时效", "超时处理时效" };
			String[] contenCells = new String[11];
			for (EwsInfoRecord infoRecord : ewsInfoRecordList.getData()) {
				contenCells[0] = infoRecord.getWarnSourceName();
				contenCells[1] = infoRecord.getId();
				contenCells[2] = infoRecord.getWarnIndexNo();
				if (infoRecord.getMonitorDate() == null) {
					contenCells[3] = null;
				} else {
					contenCells[3] = DateUtils.formatDate(infoRecord.getMonitorDate(), "yyyy-MM-dd");
				}

				if (infoRecord.getWarnDate() == null) {
					contenCells[4] = null;
				} else {
					contenCells[4] = DateUtils.formatDate(infoRecord.getWarnDate(), "yyyy-MM-dd HH:mm:ss");
				}

				contenCells[5] = infoRecord.getInfoContext();
				contenCells[6] = infoRecord.getOprResult();
				contenCells[7] = infoRecord.getWarnLevelName();
				contenCells[8] = infoRecord.getWarnClassName();
				if (infoRecord.getWarnDate() == null || infoRecord.getEffectTime() < 0
						|| infoRecord.getOverEffectTime() < 0) {
					contenCells[9] = null;
					contenCells[10] = null;
				} else {
					contenCells[9] = initEffectTimeContent(infoRecord);
					contenCells[10] = initOverEffectTimeContent(infoRecord);
				}
				exportExcel.add(contenCells.clone());
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;
			String fileName = "预警信息处理-" + DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			exportMap.put("data", exportExcel);
			exportMap.put("cellsTitle", cellsTitle);
			exportMap.put("fileName", fileName);
			exportMap.put("dataAlign", dataAlign);
			exportMap.put("sheetName", "监控预警信息列表");
			exportMap.put("orgCode", "监控预警信息");
			logger.info("导出监控预警信息结束...");
		} catch (Exception e) {
			logger.error("监控预警信息导出异常：", e.getMessage());
		}
		return new ModelAndView(new ViewExcel(), exportMap);
	}

	/**
	 * 
	 * 方法：导出单条预警记录输出的明细结果 方法说明：
	 * 
	 * @param warnInfoRecordId
	 * @return
	 */
	@RequestMapping("/exportdetailinforecord")
	public ModelAndView exportdetailinforecord(String ewsInfoRecordId) {
		Map<String, List<Map<String, Object>>> resultMap = new HashMap<String, List<Map<String, Object>>>();
		try {
			resultMap = ewsInfoRecordService.queryEwsDetailInfoByEwsInfoId(ewsInfoRecordId);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		Map<String, Object> exportExcel = new HashMap<String, Object>();
		List<Map<String, Object>> sheetList = new ArrayList<Map<String, Object>>();
		// 对多个Sheet的数据进行处理
		for (Map.Entry<String, List<Map<String, Object>>> result : resultMap.entrySet()) {
			// sheet对象包含“sheetCellsTitle,sheetData,sheetName”
			Map<String, Object> sheet = new HashMap<String, Object>();
			String sheetName = result.getKey();
			ArrayList<String[]> sheetData = new ArrayList<String[]>();
			List<Map<String, Object>> singleResultList = result.getValue();
			if (CollectionUtils.isNotEmpty(singleResultList)) {
				// 获取第一行Map的Size为标题的长度
				String[] sheetCellsTitle = singleResultList.get(0).keySet().toArray(new String[0]);
				String[] contenCells = new String[singleResultList.get(0).size()];

				int cycleNumber;
				for (Map<String, Object> records : singleResultList) {
					cycleNumber = 0;
					for (Map.Entry<String, Object> record : records.entrySet()) {
						if (record.getValue() == null || record.getValue() == "") {
							contenCells[cycleNumber] = null;
						} else {
							contenCells[cycleNumber] = record.getValue().toString();
						}
						cycleNumber++;
					}
					sheetData.add(contenCells.clone());
				}

				sheet.put("sheetCellsTitle", sheetCellsTitle);
				sheet.put("sheetData", sheetData);
				sheet.put("sheetName", sheetName);
				sheetList.add(sheet);
			}
		}

		// 表数据对齐
		short[] dataAlign = new short[4];
		dataAlign[2] = CellStyle.ALIGN_LEFT;
		String fileName = "预警记录信息明细-" + DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
		exportExcel.put("fileName", fileName);
		exportExcel.put("dataAlign", dataAlign);
		exportExcel.put("sheetList", sheetList);
		logger.info("导出监控预警信息结束...");

		return new ModelAndView(new MutilViewExcel(), exportExcel);
	}

	/**
	 * 
	 * 方法：处理页面中的String类型转换为Date类型 方法说明：
	 * 
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(DataBinder binder) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		CustomDateEditor editor = new CustomDateEditor(df, true);
		binder.registerCustomEditor(Date.class, editor);
	}

	/**
	 * 
	 * 方法：处理导出时的处理时间 方法说明：
	 * 
	 * @param ewsInfoRecord
	 * @return
	 */
	private String initEffectTimeContent(EwsInfoRecord ewsInfoRecord) {
		Long now = new Date().getTime();
		Long effectTime = ewsInfoRecord.getEffectTime() * 1000;
		Long warnDate = ewsInfoRecord.getWarnDate().getTime();
		String effectTimeContent = null;
		if (warnDate + effectTime > now && warnDate < now) {
			Long time = warnDate + effectTime - now;
			int hh = (int) (time / (1000 * 60 * 60)) % 24;
			int mm = (int) (time / (1000 * 60)) % 60;
			int ss = (int) (time / 1000) % 60;
			effectTimeContent = hh + ":" + mm + ":" + ss;
		}
		if (warnDate + effectTime < now) {
			effectTimeContent = "已超时";
		}
		return effectTimeContent;
	}

	/**
	 * 
	 * 方法：处理导出时的超时处理时间 方法说明：
	 * 
	 * @param ewsInfoRecord
	 * @return
	 */
	private String initOverEffectTimeContent(EwsInfoRecord ewsInfoRecord) {
		Long now = new Date().getTime();
		Long effectTime = ewsInfoRecord.getEffectTime() * 1000;
		Long warnDate = ewsInfoRecord.getWarnDate().getTime();
		Long overEffectTime = ewsInfoRecord.getOverEffectTime() * 1000;
		String overEffectTimeContent = null;
		if (warnDate + effectTime + overEffectTime > now && warnDate + effectTime < now) {
			Long time = warnDate + effectTime - now;
			int hh = (int) (time / (1000 * 60 * 60)) % 24;
			int mm = (int) (time / (1000 * 60)) % 60;
			int ss = (int) (time / 1000) % 60;
			overEffectTimeContent = hh + ":" + mm + ":" + ss;
		}
		if (warnDate + effectTime < now) {
			overEffectTimeContent = "超时未处理";
		}
		return overEffectTimeContent;
	}

}
