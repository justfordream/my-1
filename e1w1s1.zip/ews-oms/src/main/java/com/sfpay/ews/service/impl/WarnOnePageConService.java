package com.sfpay.ews.service.impl;


import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.ews.dto.WarnOnePageDTO;
import com.sfpay.ews.dto.WarnOnePageDetailDTO;
import com.sfpay.ews.dto.WarnOnePageQryDTO;
import com.sfpay.ews.enums.WarnSource;
import com.sfpay.ews.service.IHessianServiceFactory;
import com.sfpay.ews.service.IWarnOnePageConService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

@Service
public class WarnOnePageConService implements IWarnOnePageConService {
	
	private static Logger logger = LoggerFactory.getLogger(WarnOnePageConService.class);

	@Resource
	private IHessianServiceFactory hessianServiceFactory;
	
	/**
	 * 方法说明：监控预警OnePage页面
	 * @param onepageqry
	 * @param index
	 * @param size
	 * @return
	 * @throws ServiceException
	 */
	@Override
	public IPage<WarnOnePageDTO> queryWarnMsData(WarnOnePageQryDTO onepageqry,
			int index, int size) throws ServiceException {
		return hessianServiceFactory.getWarnOnePageService().queryWarnMsData(onepageqry, index, size);
	}
	

	/**
	 * 仅查询MS的数据资料WarnOnePageDTO;
	 * @param warnNo
	 * @return
	 * @throws ServiceException
	 */
	@Override
	public WarnOnePageDTO getMsDataOnlyByWarnNo(String warnNo)
			throws ServiceException {
		return hessianServiceFactory.getWarnOnePageService().queryMsDataOnlyByWarnNo(warnNo);
	}


	/**
	 * 根据warnSource查询不同的明细资料，并放到WarnOnePageDetailDTO中;
	 * @param warnSource
	 * @param warnNo
	 * @param index
	 * @param size
	 * @return
	 * @throws ServiceException
	 */	
	@Override
	public IPage<WarnOnePageDetailDTO> getDetailDataByWarnNo(String warnSource,
			String warnNo, int index, int size) throws ServiceException {
		return hessianServiceFactory.getWarnOnePageService().queryWarnSystemDetailById(warnSource, warnNo, index, size);
	} 
	
	
	/**
	 * 根据系统来源返回系统明细显示的链接URL(包括顺手付系统红包不同指标的不同明细显示added by xiongwei7);
	 * @param warnSource
	 * @param warnIndexNo
	 * @return
	 */
	@Override
	public String getDetailUrlByWarnSource(String warnSource,String warnIndexNo) throws ServiceException{
		String sysurl="";
		if((warnSource==null) || (warnSource.equals(""))){
			throw new IllegalArgumentException("预警来源为空，不能转换其显示页面链接URL!");
		}
		try{
			WarnSource source = (WarnSource) Enum.valueOf(WarnSource.class, warnSource);
			switch(source){
				//一期
				case COD:
					sysurl="ewswarn/onepage/detail/warncoddetail";
					break;
				case MARKET:
					sysurl="ewswarn/onepage/detail/warnmarketdetail";
					break;
				case WAYBILL:
					sysurl="ewswarn/onepage/detail/warnwaybilldetail";
					break;
				//二期	
				case ACQ:
					sysurl="ewswarn/onepage/detail/warnacqdetail";
					break;	
				case BTOC:
					sysurl="ewswarn/onepage/detail/warnbtocdetail";
					break;
				case MPAY:
					sysurl="ewswarn/onepage/detail/warnmpaydetail";
					break;					
				//三期		
				case COREACCOUNT:
					sysurl="ewswarn/onepage/detail/warncoreaccountdetail";
					break;	
				case STOREDCARD:
					sysurl="ewswarn/onepage/detail/warnstoredcarddetail";
					break;	
				case ELEACCOUNT:
					sysurl="ewswarn/onepage/detail/warneleaccountdetail";
					break;	
				case TRADEORDER:
					sysurl="ewswarn/onepage/detail/warntradeorderdetail";
					break;	
				//四期;
				case PAS:
					//垫付货款
					sysurl="ewswarn/onepage/detail/warnpasdetail";
					break;
				case SYPAY:
					//顺手付;
					sysurl="ewswarn/onepage/detail/warnsypaydetail";
					break;
				case DEBIT:
					//公款代扣系统
					sysurl="ewswarn/onepage/detail/warndebitdetail";
					break;
				case SFGOM:
					//安心购
					sysurl="ewswarn/onepage/detail/warnsfgomdetail";
					break;
				case FMS:
					//融资平台
					sysurl="ewswarn/onepage/detail/warnfmsdetail";
					break;
				case RM:
					//风控系统
					sysurl="ewswarn/onepage/detail/warnrmpasdetail";
					break;
				case ISS:
					//理赔统付系统
					sysurl="ewswarn/onepage/detail/warnissdetail";
					break;
				case LCPT:
					//理财平台系统
					sysurl="ewswarn/onepage/detail/warnlcptdetail";
					break;
			}
            if(warnIndexNo.equals("SYPAY0007")||warnIndexNo.equals("SYPAY0008")
                 ||warnIndexNo.equals("SYPAY0009")||warnIndexNo.equals("SYPAY0011")){
				
				sysurl="ewswarn/onepage/detail/RedBag/warnsypayredbagonedetail";			
			}
			if(warnIndexNo.equals("SYPAY00010")){
				sysurl="ewswarn/onepage/detail/RedBag/warnsypayredbagtwodetail";
			}
			if(warnIndexNo.equals("SYPAY00012")){
				sysurl="ewswarn/onepage/detail/RedBag/warnsypayredbagthreedetail";
			}	
			
		} catch (Exception e) {
			logger.error("根据系统来源返回系统明细显示的链接URL异常：" + e.getMessage());
			throw new ServiceException("根据系统来源返回系统明细显示的链接URL异常",e);
		}	
		return sysurl;
	}
	/**
	 * 根据顺手付系统来源返回红包明细显示的链接URL;
	 * @param warnSource
	 * @return
	 */
	/*@Override
	public String getRedBagDetailUrlByWarnIndexNo(String warnIndexNo) throws ServiceException{
		String sysurl="";
		if((warnIndexNo==null) || (warnIndexNo.equals(""))){
			throw new IllegalArgumentException("预警指标编号为空，不能转换其显示页面链接URL!");
		}
		try{
		
			if(warnIndexNo.equals("SYPAY0007")||warnIndexNo.equals("SYPAY0008")||warnIndexNo.equals("SYPAY0009")||warnIndexNo.equals("SYPAY0011")){
				
				sysurl="ewswarn/onepage/detail/RedBag/warnsypayonedetail";			
			}
			if(warnIndexNo.equals("SYPAY00010")){
				sysurl="ewswarn/onepage/detail/RedBag/warnsypaytwodetail";
			}
			if(warnIndexNo.equals("SYPAY00012")){
				sysurl="ewswarn/onepage/detail/RedBag/warnsypaythreedetail";
			}	
		} catch (Exception e) {
			logger.error("根据系统来源返回系统明细显示的链接URL异常：" + e.getMessage());
			throw new ServiceException("根据系统来源返回系统明细显示的链接URL异常",e);
		}	
		return sysurl;
	}*/
	
	/**
	 * 更改一个告警编号的处理意见;
	 * @param warnNo 告警编号
	 * @param DealResult 处理意见
	 * @param EmpId 操作人员;
	 * @throws ServiceException
	 */
	@Override
	public void updateWarnMsDealResult(String warnNo, String dealResult,
			String empId) throws ServiceException {
		hessianServiceFactory.getWarnOnePageService().updateWarnMsDealResult(warnNo, dealResult, empId);		
	}

}
