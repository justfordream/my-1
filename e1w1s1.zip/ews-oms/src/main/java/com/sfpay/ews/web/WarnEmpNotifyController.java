package com.sfpay.ews.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.dto.WarnGroupDefDTO;
import com.sfpay.ews.dto.WarnGroupVsEmpDTO;
import com.sfpay.ews.service.IWarnGroupDefService;
import com.sfpay.ews.service.IWarnGroupEmpService;
import com.sfpay.ews.web.vo.WarnEmpParam;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.organ.domain.OrgHrEmp;
import com.sfpay.organ.service.IOrgHrEmpService;
import com.sfpay.um.domain.User;

/**
 * 预警通知管理页面
 * @author 321566 张泽豪
 *
 * 2014-4-21 下午5:28:18
 */
@Controller
@RequestMapping("/empnotify")
public class WarnEmpNotifyController {
	
	private static Logger logger = LoggerFactory.getLogger(WarnEmpNotifyController.class);
	
	//错误页面
	//private final String ERROR_PAGE = "global/error";
	
	@Resource
	IWarnGroupEmpService warnGroupEmpService;
	
	@Resource
	IOrgHrEmpService orgHrEmpService;
	
	@Resource
	IWarnGroupDefService warnGroupDefService;
	
	/**
	 * 预警人员通知设置主界面
	 * @return
	 */
	@RequestMapping(value = "/notifydef/empdefmain")
	public ModelAndView initEmpNotifyPage(){
		ModelAndView mav = new ModelAndView("ewswarn/notifydef/empdefmain");
		return mav;
	}
	
	/**
	 * 预警人员查询列表
	 * @return
	 */
	@RequestMapping(value = "/notifydef/querylist")
	@ResponseBody
	public Object querylist(String empId,String groupNo, int page, int rows){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询参数empId = " + empId);
			logger.info("查询参数groupNo = " + groupNo);
			WarnGroupVsEmpDTO empDTO = new WarnGroupVsEmpDTO();
			if(empId != null){
				empDTO.setEmpId(empId.trim());
			}
			if(groupNo != null){
				empDTO.setGroupNoList(groupNo.trim());
			}
			return warnGroupEmpService.queryGroupEmpByPage(empDTO, page, rows);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("预警人员查询异常");
			return jm;
		}
	}
	
	/**
	 * 新增预警通知页面
	 * @return
	 */
	@RequestMapping(value = "/notifydef/addwarngroupemp")
	@ResponseBody
	public ModelAndView addwarngroupemp(){
		ModelAndView mav = new ModelAndView("ewswarn/notifydef/addwarngroupemp");
		List<WarnGroupDefDTO> groupdefs = warnGroupDefService.querytAllWarnGroupDef();
		mav.addObject("groupdefs", groupdefs);
		return mav;
	}
	
	
	/**
	 * 新增预警
	 * @return
	 */
	@RequestMapping(value = "/notifydef/addemp")
	@ResponseBody
	public Object addEmp(WarnEmpParam param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("新增预警通知参数对象 = " + param);
			if(param == null){
				throw new Exception("新增预警通知对象为空");
			}
			WarnGroupVsEmpDTO emp = new WarnGroupVsEmpDTO();
			if(param.getEmpId() != null){
				emp.setEmpId(param.getEmpId().trim());
			}
			if(param.getEmpMail() != null){
				emp.setEmpMail(param.getEmpMail().trim());
			}
			if(param.getEmpMobile() != null){
				emp.setEmpMobile(param.getEmpMobile().trim());
			}
			if(param.getEmpName() != null){
				emp.setEmpName(param.getEmpName().trim());
			}
			emp.setGroupNoList(param.getGroupNos());
			emp.setIsMailNotify(param.getIsMailNotify());
			emp.setIsSmsNotify(param.getIsSmsNotify());
			emp.setIsValid(param.getIsValid());
			emp.setRemark(param.getRemark());
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			emp.setCreateId(user.getUserName());
			warnGroupEmpService.saveorUpdateWarnGroupEmp(emp);
			
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("新增预警通知成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("新增预警通知异常");
			return jm;
		}
	}
	
	/**
	 * 根据工号带出信息
	 * @return
	 */
	@RequestMapping(value = "/notifydef/queryempinfo")
	@ResponseBody
	public Object queryempinfo(String empId){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询工号 = " + empId);
			OrgHrEmp emp = orgHrEmpService.queryByEmpNum(empId);
			if(emp == null){
				throw new ServiceException("找不到该工号的人资信息");
			}
			jm.setCode("s");
			jm.setSuccess("succeed");
			Map<String, String> data = new HashMap<String, String>();
			data.put("empId", empId);
			data.put("empName", emp.getLastName());
			data.put("empMail", emp.getMailAddress());
			data.put("empMobile", emp.getMobilePhone());
			jm.setData(data);
			logger.info("data = " + data);
			return jm;
		}catch (ServiceException e) {
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("查询人资信息错误");
			return jm;
		}
	}
	
	/**
	 * 修改预警通知页面
	 * @return
	 */
	@RequestMapping(value = "/notifydef/updatewarngroupemp")
	@ResponseBody
	public ModelAndView updatewarngroupemp(String empId){
		ModelAndView mav = new ModelAndView("ewswarn/notifydef/updatewarngroupemp");
		WarnGroupVsEmpDTO empDTO = warnGroupEmpService.queryGroupEmpByEmpId(empId);
		mav.addObject("emp", empDTO);
		List<WarnGroupDefDTO> groupdefs = warnGroupDefService.querytAllWarnGroupDef();
		String emp = String.format(",%s,", empDTO.getGroupNoList());
		for(WarnGroupDefDTO dto : groupdefs){
			if(emp.contains(","+dto.getGroupNo()+",")){
				dto.setSelected("checked");
			}
		}
		mav.addObject("groupdefs", groupdefs);
		return mav;
	}
	
	/**
	 * 修改预警
	 * @return
	 */
	@RequestMapping(value = "/notifydef/updateemp")
	@ResponseBody
	public Object updateEmp(WarnEmpParam param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("修改预警通知参数对象 = " + param);
			if(param == null){
				throw new Exception("修改预警通知对象为空");
			}
			WarnGroupVsEmpDTO emp = new WarnGroupVsEmpDTO();
			if(param.getEmpId() != null){
				emp.setEmpId(param.getEmpId().trim());
			}
			if(param.getEmpMail() != null){
				emp.setEmpMail(param.getEmpMail().trim());
			}
			if(param.getEmpMobile() != null){
				emp.setEmpMobile(param.getEmpMobile().trim());
			}
			if(param.getEmpName() != null){
				emp.setEmpName(param.getEmpName().trim());
			}
			emp.setGroupNoList(param.getGroupNos());
			emp.setIsMailNotify(param.getIsMailNotify());
			emp.setIsSmsNotify(param.getIsSmsNotify());
			emp.setIsValid(param.getIsValid());
			emp.setRemark(param.getRemark());
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			emp.setUpdateId(user.getUserName());
			//标记该记录要修改
			emp.setFlag("update");
			warnGroupEmpService.saveorUpdateWarnGroupEmp(emp);
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("修改预警通知成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("修改预警通知异常");
			return jm;
		}
	}
	
	/**
	 * 导出人员信息
	 */
	@RequestMapping(value ="/notifydef/export")
	@ResponseBody
	public ModelAndView exportWarnEmp(String empId,String groupNo){
		logger.info("预警管理--导出预警人员信息: Start WarnEmpNotifyController.exportWarnEmp()");
		Map<String, Object> empMap = new HashMap<String, Object>();
		try {
			WarnGroupVsEmpDTO empDTO = new WarnGroupVsEmpDTO();
			if(empId != null){
				empDTO.setEmpId(empId.trim());
			}
			if(groupNo != null){
				empDTO.setGroupNoList(groupNo.trim());
			}
			//empDTO.setEmpId(getCurrentUser().getUserName());
			IPage<WarnGroupVsEmpDTO> resultDTO = warnGroupEmpService.queryGroupEmpByPage(empDTO, 1, Integer.MAX_VALUE);
			ArrayList< String[]> excel = new ArrayList<String[]>();
			String[] cellsTitle = new String[] {"工号","姓名","是否有效","邮件","手机号码","群组编号集合","邮件通知","短信通知","创建人","创建日期","修改人","修改日期"};
			//填充数据
			String[] cells = null;
			for(WarnGroupVsEmpDTO dto:resultDTO.getData()){
				 cells = new String[12];
				 cells[0] = dto.getEmpId();
				 cells[1] = dto.getEmpName();
				 if("Y".equals(dto.getIsValid())){
					 cells[2] = "有效";
				 }else{
					 cells[2] = "无效";
				 }
				 cells[3] = dto.getEmpMail();
				 cells[4] = dto.getEmpMobile();
				 cells[5] = dto.getGroupNoList();
				 if("Y".equals(dto.getIsMailNotify())){
					 cells[6] = "通知";
				 }else{
					 cells[6] = "不通知";
				 }
				 if("Y".equals(dto.getIsSmsNotify())){
					 cells[7] = "通知";
				 }else{
					 cells[7] = "不通知";
				 }
				 cells[8] = dto.getCreateId();
				 cells[9] = DateUtils.formatDate(dto.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
				 cells[10] = dto.getUpdateId();
				 if(dto.getUpdateTime()!=null){
					 cells[11] = DateUtils.formatDate(dto.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
				 }else{
					 cells[11]="";
				 }
				 excel.add(cells);
				
			}
			// 表数据对齐
			short[] dataAlign = new short[4];
			dataAlign[2] = CellStyle.ALIGN_LEFT;
			
			String fileName = "warnEmpInfo-"+DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
			empMap.put("data", excel);
			empMap.put("cellsTitle", cellsTitle);
			empMap.put("fileName", fileName);
			empMap.put("dataAlign", dataAlign);
			empMap.put("sheetName", "监控预警信息列表");
			empMap.put("orgCode", "Sheet1");//设置excel工作表名,orgCode为ViewExcel的特定名称
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			logger.error("预警人员信息导出异常：", e.getMessage());
		}
		logger.debug("end WarnEmpNotifyController.exportWarnEmp()");
		return new ModelAndView(new ViewExcel(), empMap);
	}
	
}
