package com.sfpay.ews.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.dto.WarnIndexDefDTO;
import com.sfpay.ews.dto.WarnIndexParamDTO;
import com.sfpay.ews.service.IWarnIndexDefService;
import com.sfpay.ews.service.IWarnIndexParamService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

/**
 * 指标参数controller
 * 
 * @author 321566 张泽豪
 *
 * 2014-5-9 上午11:48:03
 */
@Controller
@RequestMapping("/warnparam")
public class WarnIndexParamController {
	
	private static Logger logger = LoggerFactory.getLogger(WarnIndexParamController.class);
	
	@Resource
	IWarnIndexParamService warnIndexParamService;
	
	@Resource
	IWarnIndexDefService warnIndexDefService;
	
	/**
	 * 指标参数记录主页面
	 * @return
	 */
	@RequestMapping(value = "/indexparam/indexparammain")
	public ModelAndView indexparammain(){
		ModelAndView mav = new ModelAndView("ewswarn/indexparam/parammain");
		return mav;
	}
	
	/**
	 * 指标参数记录查询列表
	 * @return
	 */
	@RequestMapping(value = "/indexparam/querylist")
	@ResponseBody
	public Object querylist(String warnSource,String paramNo,String paramName,String warnIndexNo, int page, int rows){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询参数warnSource = " + warnSource);
			logger.info("查询参数paramNo = " + paramNo);
			logger.info("查询参数paramName = " + paramName);
			logger.info("查询参数warnIndexNo = " + warnIndexNo);
			WarnIndexParamDTO param = new WarnIndexParamDTO();
			if(warnSource != null){
				param.setWarnSource(warnSource.trim());
			}
			
			if(paramNo != null){
				param.setParamNo(paramNo.trim());
			}
			
			if(paramName != null){
				param.setParamName(paramName.trim());
			}
			
			if(warnIndexNo != null){
				param.setWarnIndexNo(warnIndexNo.trim());
			}
			return warnIndexParamService.queryIndexParamByPage(param, page, rows);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("指标参数查询异常");
			return jm;
		}
	}
	
	/**
	 * 新增指标参数页面
	 * @return
	 */
	@RequestMapping(value = "/indexparam/addindexparam")
	@ResponseBody
	public ModelAndView addindexparam(){
		ModelAndView mav = new ModelAndView("ewswarn/indexparam/addindexparam");
		List<String> warnSources = warnIndexDefService.queryAllIndexWarnSource();
		mav.addObject("warnSources", warnSources);
		return mav;
	}
	
	/**
	 * 根据预警来源带出指标
	 * @return
	 */
	@RequestMapping(value = "/indexparam/queryindexs")
	@ResponseBody
	public Object queryindexs(String warnSource){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询预警来源 = " + warnSource);
			List<WarnIndexDefDTO> indexDef =  warnIndexDefService.queryIndexDefByWarnSource(warnSource);
			Map<String, List<WarnIndexDefDTO>> data = new HashMap<String, List<WarnIndexDefDTO>>();
			data.put("index", indexDef);
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setData(data);
			logger.info("data = " + data);
			return jm;
		}catch (ServiceException e) {
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("根据预警来源带出指标错误");
			return jm;
		}
	}
	
	/**
	 * 根据指标代码带出指标名称
	 * @return
	 */
	@RequestMapping(value = "/indexparam/queryindexname")
	@ResponseBody
	public Object queryindexname(String warnIndexNo){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询指标代码 = " + warnIndexNo);
			WarnIndexDefDTO indexDef =  warnIndexDefService.queryWarnIndexDefByIndexNo(warnIndexNo);
			String indexName = "";
			if(indexDef != null){
				indexName = indexDef.getWarnIndexName();
			}
			Map<String, String> data = new HashMap<String, String>();
			data.put("indexName", indexName);
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setData(data);
			logger.info("data = " + data);
			return jm;
		}catch (ServiceException e) {
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("根据指标代码带出指标名称错误");
			return jm;
		}
	}
	
	
	/**
	 * 新增指标参数
	 * @return
	 */
	@RequestMapping(value = "/indexparam/doaddindexparam")
	@ResponseBody
	public Object doaddindexparam(WarnIndexParamDTO param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("新增指标参数对象 = " + param);
			if(param == null){
				throw new ServiceException("新增指标参数对象为空");
			}
			
/*			try{
				logger.info("参数设置值 = " + param.getParamVal());
				Integer.parseInt(param.getParamVal());
			}catch (NumberFormatException e) {
				throw new ServiceException("参数设置值 请输入整数");
			}*/
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			param.setCreateId(user.getUserName());
			warnIndexParamService.saveorUpdateWarnIndexParam(param);
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("新增指标参数成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("新增指标参数异常");
			return jm;
		}
	}
	
	/**
	 * 修改指标参数页面
	 * @return
	 */
	@RequestMapping(value = "/indexparam/updateindexparam")
	@ResponseBody
	public ModelAndView updateindexparam(String id){
		ModelAndView mav = new ModelAndView("ewswarn/indexparam/updateindexparam");
		WarnIndexParamDTO indexParam = warnIndexParamService.queryWarnIndexParamById(Long.parseLong(id));
		mav.addObject("indexParam", indexParam);
		return mav;
	}
	
	/**
	 * 修改指标参数
	 * @return
	 */
	@RequestMapping(value = "/indexparam/doupdateindexparam")
	@ResponseBody
	public Object doupdateindexparam(WarnIndexParamDTO param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("修改指标参数对象 = " + param);
			if(param == null){
				throw new ServiceException("修改指标参数对象为空");
			}
			
/*			try{
				logger.info("参数设置值 = " + param.getParamVal());
				Integer.parseInt(param.getParamVal());
			}catch (NumberFormatException e) {
				throw new ServiceException("参数设置值 请输入整数");
			}*/
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			param.setUpdateId(user.getUserName());
			//标记该记录要修改
			param.setFlag("update");
			warnIndexParamService.saveorUpdateWarnIndexParam(param);
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("修改指标参数成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("修改指标参数异常");
			return jm;
		}
	}
	
	/**
	 * 导出人员信息
	 */
	@RequestMapping(value ="/notifydef/export")
	@ResponseBody
	public ModelAndView exportWarnEmp(WarnIndexParamDTO param){
		logger.info("预警指标参数值设置--导出预警人员信息: Start WarnIndexParamController.exportWarnParam()");
		Map<String, Object> empMap = new HashMap<String, Object>();
		try{
			WarnIndexParamDTO indexDto = new WarnIndexParamDTO();
			if(param.getWarnSource() != null){
				param.setWarnSource(param.getWarnSource().trim());
			}
			
			if(param.getParamNo() != null){
				param.setParamNo(param.getParamNo().trim());
			}			
			if(param.getParamName()!= null){
				param.setParamName(param.getParamName().trim());
			}
			
			if(param.getWarnIndexNo() != null){
				param.setWarnIndexNo(param.getWarnIndexNo().trim());
			}
				//empDTO.setEmpId(getCurrentUser().getUserName());
				IPage<WarnIndexParamDTO> resultDTO = warnIndexParamService.queryIndexParamByPage(indexDto, 1, Integer.MAX_VALUE);
				ArrayList< String[]> excel = new ArrayList<String[]>();
				String[] cellsTitle = new String[] {"参数代码","参数设置值","参数值的单位","参数说明","预警来源","预警指标","预警指标名称","备注","是否有效","创建人员","创建日期","修改人员","修改日期"};
				//填充数据
				String[] cells = null;
				for(WarnIndexParamDTO dto:resultDTO.getData()){
					 cells = new String[13];
					 cells[0] = dto.getParamNo();
					 cells[1] = dto.getParamVal();
				     cells[2] = dto.getParamUnit();
					 cells[3] = dto.getParamName();
					 cells[4] = dto.getWarnSource();
					 cells[5] = dto.getWarnIndexNo();
					 cells[6] = dto.getWarnIndexName();
					 cells[7] = dto.getRemark();
					 if("Y".equals(dto.getIsValid())){
						 cells[8] = "有效";
					 }else if("N".equals(dto.getIsValid())){
						 cells[8] = "无效";
					 }					
					 cells[9] = dto.getCreateId();
					 if(dto.getCreateTime2()!=null){
						 cells[10] = DateUtils.formatDate(dto.getCreateTime2(),"yyyy-MM-dd HH:mm:ss"); 
					 }
					 cells[11]=dto.getUpdateId();
					 if(dto.getUpdateTime2()!=null){
						 cells[12] = DateUtils.formatDate(dto.getUpdateTime2(),"yyyy-MM-dd HH:mm:ss");
					 }
					 excel.add(cells);
				}
				// 表数据对齐
				short[] dataAlign = new short[4];
				dataAlign[2] = CellStyle.ALIGN_LEFT;
				String fileName = "warnIndexParamInfo-"+DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
				empMap.put("data", excel);
				empMap.put("cellsTitle", cellsTitle);
				empMap.put("fileName", fileName);
				empMap.put("dataAlign", dataAlign);
				empMap.put("sheetName", "预警指标参数值设置列表");
				empMap.put("orgCode", "Sheet1");//设置excel工作表名,orgCode为ViewExcel的特定名称
		}catch (ServiceException e) {
			// TODO Auto-generated catch block
			logger.error("预警指标参数值设置信息导出异常：", e.getMessage());
		}
		logger.debug("end WarnIndexParamController.exportWarnIndexParam()");
		return new ModelAndView(new ViewExcel(), empMap);
	}
	
}
