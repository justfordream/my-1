package com.sfpay.ews.service;


import com.sfpay.ews.dto.WarnOnePageDTO;
import com.sfpay.ews.dto.WarnOnePageDetailDTO;
import com.sfpay.ews.dto.WarnOnePageQryDTO;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

public interface IWarnOnePageConService {
	
	/**
	 * 方法说明：监控预警OnePage页面
	 * @param onepageqry
	 * @param index
	 * @param size
	 * @return
	 * @throws ServiceException
	 */
	public IPage<WarnOnePageDTO> queryWarnMsData(WarnOnePageQryDTO onepageqry, int index, int size) throws ServiceException;

	/**
	 * 根据warnSource返回一个StringUrl的链接,其中String代表返回的系统显示的URL，	
	 * @param warnNo
	 * @param warnSource
	 * @return
	 * @throws ServiceException
	 */	
	public String getDetailUrlByWarnSource(String warnSource,String warnIndexNo) throws ServiceException;
	/**
	 * 根据warnSource以及顺手付红包预警指标号返回一个StringUrl的链接,其中String代表返回的系统显示的URL，	
	 * @param warnNo
	 * @param warnSource
	 * @return
	 * @throws ServiceException
	 */	
/*	public String getRedBagDetailUrlByWarnIndexNo(String warnIndexNo) throws ServiceException;*/
	
	/**
	 * 仅查询MS的数据资料WarnOnePageDTO;
	 * @param warnNo
	 * @return
	 * @throws ServiceException
	 */
	public WarnOnePageDTO getMsDataOnlyByWarnNo(String warnNo) throws ServiceException;
	
	/**
	 * 更改一个告警编号的处理意见;
	 * @param warnNo 告警编号
	 * @param DealResult 处理意见
	 * @param EmpId 操作人员;
	 * @throws ServiceException
	 */
	public void updateWarnMsDealResult(String warnNo,String dealResult,String empId)  throws ServiceException;	
	
	
	/**
	 * 根据warnSource查询不同的明细资料，并放到WarnOnePageDetailDTO中;
	 * @param warnSource
	 * @param warnNo
	 * @param index
	 * @param size
	 * @return
	 * @throws ServiceException
	 */	
	public  IPage<WarnOnePageDetailDTO> getDetailDataByWarnNo(String warnSource,String warnNo,int index, int size) throws ServiceException;
	
}
