/**
 * 
 */
package com.sfpay.ews.platform.web;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.JsonMessage;
import com.sfpay.ews.platform.domain.EwsRule;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsRuleService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

/**
 * 类说明：预警指标规则控制器
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-10
 */
@Controller
@RequestMapping("/ews/indexrule")
public class EwsIndexRuleController {
	private static Logger logger = LoggerFactory.getLogger(EwsIndexRuleController.class);

	@Autowired
	private IEwsRuleService ewsRuleService;
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	
	/**
	 * 预警指标规则维护主界面
	 * @return
	 */
	@RequestMapping(value = "/mainpage")
	public ModelAndView mainPage() {
		return new ModelAndView("ews/ewsindexrule/rulemain");
	}
	
	/**
	 * 查询指标规则
	 * @param ewsRule
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping(value = "/querylist")
	@ResponseBody
	public Object queryList(EwsRule ewsRule, int page, int rows) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("查询参数  = " + ewsRule);
			
			if(ewsRule == null) {
				ewsRule = new EwsRule();
			}
			
 			return ewsRuleService.queryByPage(ewsRule, page, rows);
			
		} catch (Exception e) {
			logger.error("queryList 预警指标规则分页查询异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("指标规则查询异常");
			return jm;
		}
	}
	
	/**
	 * 修改指标规则页面
	 * @param indexNo
	 * @return
	 */
	@RequestMapping(value = "/updateindexrulepage")
	@ResponseBody
	public ModelAndView updateIndexRulePage(long id) {
		ModelAndView modelAndView = new ModelAndView("ews/ewsindexrule/updateindexrule");
		
		EwsRule ewsRule = ewsRuleService.queryById(id);
		
		if(ewsRule == null) {
			logger.error("指标规则的ID【{}】不存在，更新指标规则对象失败", id);
			ewsRule = new EwsRule();
		}
		
		modelAndView.addObject("ewsRule", ewsRule);
		
		return modelAndView;
	}
	
	/**
	 * 更新指标规则
	 * @param ewsRule
	 * @return
	 */
	@RequestMapping(value = "/updateindexrule")
	@ResponseBody
	public Object updateIndexRule(EwsRule ewsRule) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("更新指标规则对象 = " + ewsRule);
			
			checkEwsRule(ewsRule);
			
			EwsRule oldEwsRule = ewsRuleService.queryById(ewsRule.getId());
			if(oldEwsRule == null) {
				logger.error(String.format("更新预警指标规则失败，无效的预警指标规则 ID:【%s】", ewsRule.getId()));
				throw new ServiceException(String.format("无效的预警指标规则 ID:【%s】", ewsRule.getId()));
			}

			// 检查参数名称是否重复
			if(!StringUtils.equals(ewsRule.getParamName(), oldEwsRule.getParamName()) || 
					!StringUtils.equals(ewsRule.getWarnIndexNo(), oldEwsRule.getWarnIndexNo())) {
				if(ewsRuleService.queryByIndexNoAndParamName(ewsRule.getWarnIndexNo(), ewsRule.getParamName()) != null) {
					logger.error(String.format("更新预警指标规则失败，指标编号-参数名称已存在【%s-%s】", 
							new Object[]{ewsRule.getWarnIndexNo(), ewsRule.getParamName()}));
					throw new ServiceException(String.format("更新预警指标规则失败，指标编号-参数名称已存在【%s-%s】", 
							new Object[]{ewsRule.getWarnIndexNo(), ewsRule.getParamName()}));
				}
			}
			
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			ewsRule.setUpdateId(user.getUserName());
			
			ewsRuleService.updateEwsRule(ewsRule);

			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("更新指标规则成功");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("更新预警指标规则异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("更新预警指标规则异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("更新预警指标规则异常");
			return jm;
		}
	}
	
	/**
	 * 删除指标规则
	 * @param ewsIndexDef
	 * @return
	 */
	@RequestMapping(value = "/deleteindexrule")
	@ResponseBody
	public Object deleteIndexRule(long id) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("删除指标规则对象 = " + id);
			
			
			EwsRule ewsRule = ewsRuleService.queryById(id);
			if(ewsRule == null) {
				logger.error(String.format("删除预警指标规则失败，无效的预警指标规则  ID:【%s】", id));
				throw new ServiceException(String.format("无效的预警指标规则 ID:【%s】", id));
			}

			ewsRuleService.deleteEwsRule(id);

			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("删除指标规则成功");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("删除预警指标规则异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("删除预警指标规则异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("删除预警指标规则异常");
			return jm;
		}
	}
	
	/**
	 * 新增指标规则页面
	 * @return
	 */
	@RequestMapping(value = "/addindexrulepage")
	@ResponseBody
	public ModelAndView addIndexRulePage() {
		return new ModelAndView("ews/ewsindexrule/addindexrule");
	}
	
	/**
	 * 新增指标规则
	 * @param ewsRule
	 * @return
	 */
	@RequestMapping(value = "/addindexrule")
	@ResponseBody
	public Object addIndexRule(EwsRule ewsRule) {
		JsonMessage jm = new JsonMessage();
		try {
			logger.info("新增指标规则对象 = " + ewsRule);
			
			checkEwsRule(ewsRule);
			
			// 检查参数名称是否重复
			if(ewsRuleService.queryByIndexNoAndParamName(ewsRule.getWarnIndexNo(), ewsRule.getParamName()) != null) {
				logger.error(String.format("更新预警指标规则失败，指标编号-参数名称已存在【%s-%s】", 
						new Object[]{ewsRule.getWarnIndexNo(), ewsRule.getParamName()}));
				throw new ServiceException(String.format("更新预警指标规则失败，指标编号-参数名称已存在【%s-%s】", 
						new Object[]{ewsRule.getWarnIndexNo(), ewsRule.getParamName()}));
			}
			
			User user = (User) SecurityManager.getSessionAttribute("SESSION_USER");
			ewsRule.setCreateId(user.getUserName());
			
			ewsRuleService.addEwsRule(ewsRule);

			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("新增指标规则成功");
			return jm;
			
		} catch (ServiceException e) {
			logger.error("新增预警指标规则异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
			
		} catch (Exception e) {
			logger.error("新增预警指标规则异常", e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("新增预警指标规则异常");
			return jm;
		}
	}
	
	/**
	 * 检查指标规则是否正确
	 * @param ewsRule
	 */
	private void checkEwsRule(EwsRule ewsRule) {
		if (ewsRule == null) {
			logger.error("预警指标规则对象为空");
			throw new ServiceException("预警指标规则对象为空");
		}

		if (StringUtils.isBlank(ewsRule.getWarnIndexNo())) {
			logger.error("指标编号为空");
			throw new ServiceException("指标编号为空");
		}
		
		if (StringUtils.isBlank(ewsRule.getParamName())) {
			logger.error("指标规则参数名称为空");
			throw new ServiceException("指标规则参数名称为空");
		}
		
		if (StringUtils.isBlank(ewsRule.getParamExpress())) {
			logger.error("指标规则参数表达式为空");
			throw new ServiceException("指标规则参数表达式为空");
		}
		
		if(ewsIndexDefService.queryByWarnIndexNo(ewsRule.getWarnIndexNo()) == null) {
			logger.error("指标编号【{}】不存在", ewsRule.getWarnIndexNo());
			throw new ServiceException(String.format("指标编号【%s】不存在", ewsRule.getWarnIndexNo()));
		}
	}
}
