package com.sfpay.ews.service;

public interface IHessianServiceFactory {
	

	/**
	 * 
	 * 
	 * 方法说明：基础参数管理（运营系统内部使用）
	 * 
	 * @return
	 */
	public IWarnOnePageService getWarnOnePageService();

}
