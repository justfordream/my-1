package com.sfpay.ews.web;

import java.util.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sfpay.console.util.DateUtil;
import com.sfpay.console.util.JsonMessage;
import com.sfpay.console.util.ViewExcel;
import com.sfpay.ews.dto.WarnIndexDefDTO;
import com.sfpay.ews.service.IWarnIndexDefService;
import com.sfpay.ews.web.vo.WarnIndexParam;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.common.util.DateUtils;
import com.sfpay.framework.security.core.SecurityManager;
import com.sfpay.um.domain.User;

/**
 * 指标管理页面
 * 
 * @author 321566 张泽豪
 *
 * 2014-4-21 下午5:27:54
 */
@Controller
@RequestMapping("/index")
public class WarnIndexController {
	
	private static Logger logger = LoggerFactory.getLogger(WarnIndexController.class);
	
	@Resource
	IWarnIndexDefService warnIndexDefService;
	
	/**
	 * 预警群组维护主界面
	 * @return
	 */
	@RequestMapping(value = "/warnindex/warnindexmain")
	public ModelAndView initGroupDataPage(){
		ModelAndView mav = new ModelAndView("ewswarn/warnindex/warnindexmain");
		return mav;
	}
	
	/**
	 * 指标查询列表
	 * @return
	 */
	@RequestMapping(value = "/warnindex/querylist")
	@ResponseBody
	public Object querylist(WarnIndexParam param,int page, int rows){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("查询参数param = " + param);
			WarnIndexDefDTO indexDto = new WarnIndexDefDTO();
			if(param.getWarnIndexNo() != null){
				indexDto.setWarnIndexNo(param.getWarnIndexNo().trim());
			}
			if(param.getWarnIndexName() != null){
				indexDto.setWarnIndexName(param.getWarnIndexName().trim());
			}
			if(param.getWarnLevel() != null){
				indexDto.setWarnLevel(param.getWarnLevel().trim());
			}
			if(param.getWarnProperty() != null){
				indexDto.setWarnProperty(param.getWarnProperty().trim());
			}
			if(param.getWarnType() != null){
				indexDto.setWarnType(param.getWarnType().trim());
			}
			return warnIndexDefService.queryWarnIndexDefByPage(indexDto, page, rows);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("指标查询异常");
			return jm;
		}
	}
	
	/**
	 * 新增指标页面
	 * @return
	 */
	@RequestMapping(value = "/warnindex/addwarnindex")
	@ResponseBody
	public ModelAndView addwarngroup(){
		ModelAndView mav = new ModelAndView("ewswarn/warnindex/addwarnindex");
		return mav;
	}
	
	/**
	 * 新增指标
	 * @return
	 */
	@RequestMapping(value = "/warnindex/addindex")
	@ResponseBody
	public Object addindex(WarnIndexParam param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("新增指标参数对象 = " + param);
			if(param == null){
				throw new ServiceException("新增指标参数对象为空");
			}
			WarnIndexDefDTO indexDto = new WarnIndexDefDTO();
			if(param.getWarnIndexNo() != null){
				indexDto.setWarnIndexNo(param.getWarnIndexNo().trim());
			}
			if(param.getWarnIndexName() != null){
				indexDto.setWarnIndexName(param.getWarnIndexName().trim());
			}
			
			indexDto.setWarnSource(param.getWarnSource());
			indexDto.setWarnType(param.getWarnType());
			indexDto.setWarnProperty(param.getWarnProperty());
			indexDto.setWarnCycle(param.getWarnCycle());
			try{
				logger.info("周期值 = " + param.getWarnCycleVal());
				Integer cycleVal = Integer.parseInt(param.getWarnCycleVal());
				indexDto.setWarnCycleVal(cycleVal);
			}catch (NumberFormatException e) {
				throw new ServiceException("周期值请输入整数");
			}
			
			indexDto.setWarnResultSource(param.getWarnResultSource());
			indexDto.setWarnLevel(param.getWarnLevel());
			indexDto.setRemark(param.getRemark());
			indexDto.setIsValid(param.getIsValid());
			indexDto.setIsMailNotify(param.getIsMailNotify());
			indexDto.setIsSmsNotify(param.getIsSmsNotify());
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			indexDto.setCreateId(user.getUserName());
			
			warnIndexDefService.saveOrUpdateWarnIndexDef(indexDto);
			
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("新增指标成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("新增指标异常");
			return jm;
		}
	}
	
	/**
	 * 修改指标页面
	 * @return
	 */
	@RequestMapping(value = "/warnindex/updatewarnindex")
	@ResponseBody
	public ModelAndView updatewarnindex(String indexNo){
		ModelAndView mav = new ModelAndView("ewswarn/warnindex/updatewarnindex");
		WarnIndexDefDTO indexDto = warnIndexDefService.queryWarnIndexDefByIndexNo(indexNo);
		mav.addObject("index", indexDto);
		return mav;
	}
	
	/**
	 * 修改指标
	 * @return
	 */
	@RequestMapping(value = "/warnindex/updateindex")
	@ResponseBody
	public Object updateindex(WarnIndexParam param){
		JsonMessage jm = new JsonMessage();
		try{
			logger.info("修改指标参数对象 = " + param);
			if(param == null){
				throw new ServiceException("修改指标参数对象为空");
			}
			WarnIndexDefDTO indexDto = new WarnIndexDefDTO();
			if(param.getWarnIndexNo() != null){
				indexDto.setWarnIndexNo(param.getWarnIndexNo().trim());
			}
			if(param.getWarnIndexName() != null){
				indexDto.setWarnIndexName(param.getWarnIndexName().trim());
			}
			
			indexDto.setWarnSource(param.getWarnSource());
			indexDto.setWarnType(param.getWarnType());
			indexDto.setWarnProperty(param.getWarnProperty());
			indexDto.setWarnCycle(param.getWarnCycle());
			try{
				logger.info("周期值 = " + param.getWarnCycleVal());
				Integer cycleVal = Integer.parseInt(param.getWarnCycleVal());
				indexDto.setWarnCycleVal(cycleVal);
			}catch (NumberFormatException e) {
				throw new ServiceException("周期值请输入整数");
			}
			
			indexDto.setWarnResultSource(param.getWarnResultSource());
			indexDto.setWarnLevel(param.getWarnLevel());
			indexDto.setRemark(param.getRemark());
			indexDto.setIsValid(param.getIsValid());
			indexDto.setIsMailNotify(param.getIsMailNotify());
			indexDto.setIsSmsNotify(param.getIsSmsNotify());
			
			User user = (User)SecurityManager.getSessionAttribute("SESSION_USER");
			indexDto.setUpdateId(user.getUserName());
			//标记该记录要修改
			indexDto.setFlag("update");
			
			warnIndexDefService.saveOrUpdateWarnIndexDef(indexDto);
			
			jm.setCode("s");
			jm.setSuccess("succeed");
			jm.setMessage("修改指标成功");
			return jm;
		}catch (ServiceException e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage(e.getMessage());
			return jm;
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			jm.setCode("e");
			jm.setSuccess("error");
			jm.setMessage("修改指标异常");
			return jm;
		}
	}
	
	/**
	 * 导出人员信息
	 */
	@RequestMapping(value ="/notifydef/export")
	@ResponseBody
	public ModelAndView exportWarnEmp(WarnIndexParam param){
		logger.info("预警指标维护--导出预警人员信息: Start WarnEmpNotifyController.exportWarnEmp()");
		Map<String, Object> empMap = new HashMap<String, Object>();
		try{
			WarnIndexDefDTO indexDto = new WarnIndexDefDTO();
			if(param.getWarnIndexNo() != null){
				indexDto.setWarnIndexNo(param.getWarnIndexNo().trim());
			}
			if(param.getWarnIndexName() != null){
				indexDto.setWarnIndexName(param.getWarnIndexName().trim());
			}
			if(param.getWarnLevel() != null){
				indexDto.setWarnLevel(param.getWarnLevel().trim());
			}
			if(param.getWarnProperty() != null){
				indexDto.setWarnProperty(param.getWarnProperty().trim());
			}
			if(param.getWarnType() != null){
				indexDto.setWarnType(param.getWarnType().trim());
			}
				//empDTO.setEmpId(getCurrentUser().getUserName());
				IPage<WarnIndexDefDTO> resultDTO = warnIndexDefService.queryWarnIndexDefByPage(indexDto, 1, Integer.MAX_VALUE);
				ArrayList< String[]> excel = new ArrayList<String[]>();
				String[] cellsTitle = new String[] {"指标编号","指标名称","是否有效","预警来源","预警类别","预警性质","预警周期","预警周期值","结果来源","风险等级","邮件通知","短信通知","创建人员","创建日期","修改人员","修改日期"};
				//填充数据
				String[] cells = null;
				for(WarnIndexDefDTO dto:resultDTO.getData()){
					 cells = new String[16];
					 cells[0] = dto.getWarnIndexNo();
					 cells[1] = dto.getWarnIndexName();
					 if("Y".equals(dto.getIsValid())){
						 cells[2] = "有效";
					 }else if("N".equals(dto.getIsValid())){
						 cells[2] = "无效";
					 }
					 if("COD".equals(dto.getWarnSource())){
							cells[3]="COD系统";
						}else if("MARKET".equals(dto.getWarnSource())){
							cells[3]="营销系统";
						}else if("WAYBILL".equals(dto.getWarnSource())){
							cells[3]="运单系统";
						}else if("ACQ".equals(dto.getWarnSource())){
							cells[3]="银企系统";
						}else if("BTOC".equals(dto.getWarnSource())){
							cells[3]="银企B2C系统";
						}else if("MPAY".equals(dto.getWarnSource())){
							cells[3]="手机支付系统";
						}else if("STOREDCARD".equals(dto.getWarnSource())){
							cells[3]="储值卡系统";
						}else if("ELEACCOUNT".equals(dto.getWarnSource())){
							cells[3]="电子账户系统";
						}else if("TRADEORDER".equals(dto.getWarnSource())){
							cells[3]="核心订单系统";
						}else if("COREACCOUNT".equals(dto.getWarnSource())){
							cells[3]="核心账户系统";
						}else if("PAS".equals(dto.getWarnSource())){
							cells[3]="垫付货款系统";
						}else if("SYPAY".equals(dto.getWarnSource())){
							cells[3]="顺手付系统";
						}else if("DEBIT".equals(dto.getWarnSource())){
							cells[3]="公款代扣系统";
						}else if("SFGOM".equals(dto.getWarnSource())){
							cells[3]="安心购系统";
						}else if("FMS".equals(dto.getWarnSource())){
							cells[3]="米兰港系统";
						}else if("RM".equals(dto.getWarnSource())){
							cells[3]="风控系统";							
						}else if("ISS".equals(dto.getWarnSource())){
							cells[3]="理赔通付系统";							
						}else if("LCPT".equals(dto.getWarnSource())){
							cells[3]="理财平台系统";							
						}					 
					 if("BEFORE".equals(dto.getWarnType())){
						 cells[4]="事前";
					 }else if("DURING".equals(dto.getWarnType())){
						 cells[4]="事中";
					 }else if("AFTER".equals(dto.getWarnType())){						 
						 cells[4]="事后";
					 }
					 if("WARNING".equals(dto.getWarnProperty())){
						 cells[5] = "预警";
					 }else if("ERROR".equals(dto.getWarnProperty())){
						 cells[5] = "错误";
					 }
					 if("DAY".equals(dto.getWarnCycle())){
						 cells[6]="天";
					 }else if("WEEK".equals(dto.getWarnCycle())){
						 cells[6]="周";
					 }else if("HOUR".equals(dto.getWarnCycle())){
						 cells[6]="时";
					 }else if("MINUTE".equals(dto.getWarnCycle())){
						 cells[6]="分";
					 }else if("SECOND".equals(dto.getWarnCycle())){
						 cells[6]="秒";
					 }
					 cells[7]=String.valueOf(dto.getWarnCycleVal());
					 if("A".equals(dto.getWarnResultSource())){
						 cells[8] = "自定义";
					 }else if("B".equals(dto.getWarnResultSource())){
						 cells[8] = "Drools";
					 }
					 if("L1".equals(dto.getWarnLevel())){
						 cells[9]="高";
					 }else if("L2".equals(dto.getWarnLevel())){
						 cells[9]="较高";
					 }else if("L3".equals(dto.getWarnLevel())){
						 cells[9]="中";
					 }else if("L2".equals(dto.getWarnLevel())){
						 cells[9]="较低";
					 }else if("L2".equals(dto.getWarnLevel())){
						 cells[9]="低";
					 }
					 if("N".equals(dto.getIsMailNotify())){
						 cells[10] = "不通知"; 
					 }else if("Y".equals(dto.getIsMailNotify())){
						 cells[10] = "通知"; 
					 }
					 if("N".equals(dto.getIsSmsNotify())){
						 cells[11] = "不通知"; 
					 }else if("Y".equals(dto.getIsSmsNotify())){
						 cells[11] = "通知"; 
					 }
					 cells[12]=dto.getCreateId();
					 cells[13]=DateUtils.formatDate(dto.getCreateTime(), "yyyy-MM-dd HH:mm:ss");
					 cells[14]=dto.getUpdateId();
					 if(dto.getUpdateTime()!=null){
					 cells[15]=DateUtils.formatDate(dto.getUpdateTime(), "yyyy-MM-dd HH:mm:ss");
					 }
					 excel.add(cells);
				}
				// 表数据对齐
				short[] dataAlign = new short[4];
				dataAlign[2] = CellStyle.ALIGN_LEFT;
				
				String fileName = "warnIndexInfo-"+DateUtil.getDateStr(new Date(), DateUtil.DATE_FORMAT_STR);
				empMap.put("data", excel);
				empMap.put("cellsTitle", cellsTitle);
				empMap.put("fileName", fileName);
				empMap.put("dataAlign", dataAlign);
				empMap.put("sheetName", "监控预警指标维护列表");
				empMap.put("orgCode", "Sheet1");//设置excel工作表名,orgCode为ViewExcel的特定名称
		}catch (ServiceException e) {
			// TODO Auto-generated catch block
			logger.error("预警指标维护信息导出异常：", e.getMessage());
		}
		logger.debug("end WarnIndexController.exportWarnIndex()");
		return new ModelAndView(new ViewExcel(), empMap);
	}
	
}
