$.fn.searchTree=function(option){
	var thisId=$(this).attr("id");
	var zTree;
	var li_index=-1;
	var e;
	var dataLen;
	var defaults = {
			//url: "pentaho/SolutionRepositoryPermissionServlet",					//模糊查询调用的url	
			//ztreeUrl:"pentaho/SolutionRepositoryPermissionServlet?method=getSolutionRepositoryTree",				//机构树url
			url: "jsp/datagrid_data.json",					//模糊查询调用的url	
			ztreeUrl:"jsp/datagrid_data.json",				//机构树url
			ztreeId: thisId,						//生成模糊查询机构树的box
    		ztreeListBox: thisId+'_listBox',		//机构树模糊查询列表box
			id: thisId+'_list',						//机构树模糊查询列表
			treeList:thisId+'_treeList',			//机构树列表
			inputName: thisId+'_key',				//机构树搜索输入框
			ztree_dw: thisId+'_ztree_dw',			//下拉点击按钮
			ztree_tip: thisId+'_tip',				//机构树搜索提示
	  		fileName: thisId+'_fileName',      				//机构名称
	  		fullPath: thisId+"_fullPath",       		//机构代码
	        orgId: thisId+"_orgId",           			//机构id
	        pId: thisId+"_pId",           			//上级机构id
	        searchNumber: 10,           				//设置搜索的最大数量
	        //validate:false,
	        callback:null,
	        orgIdCallback:null
	};
	var _op = $.extend(defaults, option);
	//生成机构树对应的内容
	$(this).append('<input type="text" name="'+_op.inputName+'" id="'+_op.inputName+'" value="" class="ztree_empty ui_input" autocomplete="off" /> <a id="'+_op.ztree_dw+'" href="javascript:void(0)" class="dw_ico"></a>'
		 	+'<div class="org_list dn" id="'+_op.ztreeListBox+'"> <ul id="'+_op.id+'" class="search_tree"></ul><ul id="'+_op.treeList+'" class="ztree"></ul></div>'
		 	+'<input type="hidden" id="'+_op.fileName+'" name="'+_op.fileName+'"  value=""/>'
		 	+'<input type="hidden" id="'+_op.fullPath+'" name="'+_op.fullPath+'"  value=""/>'
		 	+'<input type="hidden" id="'+_op.pId+'" name="'+_op.pId+'"  value=""/>'
		 	+'<input type="hidden" id="'+_op.orgId+'" name="'+_op.orgId+'" value="" />');
	var timeOutId="";
	$("#"+_op.inputName).keyup(function(event){
		e=event;
		if($(this).val()==""){
			$("#"+_op.ztreeListBox).hide();
			li_index=-1;
     	  	if(_op.orgIdCallback!=null){
               	_op.orgIdCallback("");
      	  	}
			return false;
		}
		if (e.keyCode == 38||e.keyCode == 40||e.keyCode==13){
		}else{
			 if($(this).val()!=""){
		           clearTimeout(timeOutId);
		       }
			 //设置延时函数，防止输入一个内容就向后台发送请求
			 timeOutId=setTimeout(function(){
				$.ajax({
					   type: "POST",
					   url: _op.url,
					   data:{
						   //total:_op.searchNumber,
						   //keyword:$("#"+_op.inputName).val()
						   method:"querySolutionRepositoryPrpt",
						   queryName:$("#"+_op.inputName).val()
					   },
					   success: function(msg){
						   dataLen=msg.length;
						   li_index=-1;
						   var str="";
					    for(var i=0; i<msg.length;i++){
					    	str+="<li orgId='"+msg[i].id+"' pId='"+msg[i].pId+"' name='"+msg[i].name+"' fullPath='"+msg[i].fullPath+"' fileName='"+msg[i].fileName+"'>"+msg[i].name+"</li>";
					   }
					    //显示模糊搜索机构树内容
					    $("#"+_op.ztreeListBox).bgiframe();//解决IE6下select穿透问题
					    $("#"+_op.ztreeListBox).show();
					    $("#"+_op.id).show();
					    //隐藏标准机构树
					    $("#"+_op.treeList).hide();
					  	$("#"+_op.id).html(str);
					  	$("#"+_op.id).find("li").hover(
			                    function(){
			                      $(this).addClass("current");
			                      li_index=$(this).index();
			                    },
			                    function(){
			                        $(this).removeClass("current");
			                });
					  	$("#"+_op.id).find("li").click(function(){
					  		var name=$(this).attr("name");
					  		var fileName=$(this).attr("fileName");
					  		var fullPath=$(this).attr("fullPath");
					  		var orgId=$(this).attr("orgId");
					  		var pId=$(this).attr("pId");
					  		$("#"+_op.inputName).val(name);
					  		$("#"+_op.fileName).val(fileName);
					  		$("#"+_op.fullPath).val(fullPath);
					  		$("#"+_op.orgId).val(orgId);
					  		$("#"+_op.pId).val(pId);
					  		 if(_op.callback!=null){
						          	_op.callback();
						 	  	}
					  		$("#"+_op.ztreeListBox).hide();
			         	  	if(_op.orgIdCallback!=null){
			         	  		
			                   	_op.orgIdCallback(orgId);
			          	  	}
			         	  	fileListOptClkHandler(fullPath);
					  	});
					}
			});
			},200);
		}
		//键盘操作--------------------start
		keyboard();
	//键盘操作-------------------end
	});
	
	//下拉按钮点击
/*	$("#"+_op.ztree_dw).click(function(){
		 //隐藏模糊搜索机构树内容
		$("#"+_op.ztreeListBox).show();
	    $("#"+_op.id).hide();
	    //显示标准机构树
	    $("#"+_op.treeList).show();
	});*/
	$("#"+_op.ztree_dw).toggle(
			  function () {
				  //隐藏模糊搜索机构树内容
				  $("#"+_op.ztreeListBox).bgiframe();
					$("#"+_op.ztreeListBox).show();
				    $("#"+_op.id).hide();
				    //显示标准机构树
				    $("#"+_op.treeList).show();
			  },
			  function () {
				  //隐藏模糊搜索机构树内容
					$("#"+_op.ztreeListBox).hide();
				    $("#"+_op.id).hide();
				    //显示标准机构树
				    $("#"+_op.treeList).show();
			  }
			);
	
	var setting={
    		async:{
				enable: true,
				autoParam:["id"],
				url:_op.ztreeUrl,
				type:"get"
			},
        data: {
            key:{
            	name:'name'
            },
            simpleData:{
            	enable: true,
				idKey: "id",
				pIdKey: "pId",
				rootPId: 0
            }
        },
        callback: {
            onClick:zTreeOnClick
        }
    };
	
	$(function($){
		zTree=$.fn.zTree.init($("#"+_op.treeList),setting);
	});
	
	function zTreeOnClick(e, treeId, treeNode){
		var nodes = zTree.getSelectedNodes();
		 //$("#"+_op.inputName).attr("value",nodes[0].name);
		 $("#"+_op.inputName).val(nodes[0].name);
		 $("#"+_op.orgId).val(nodes[0].id);
		 var tem=nodes[0].id;
  		 if(_op.orgIdCallback!=null){
          	_op.orgIdCallback(tem);
 	  	 }
		 $("#"+_op.fullPath).val(nodes[0].fullPath);
		 $("#"+_op.fileName).val(nodes[0].fileName);
		 $("#"+_op.pId).val(nodes[0].pId);
		 /*$("#"+_op.orgId).attr("value",nodes[0].id);
		 $("#"+_op.fullPath).attr("value",nodes[0].fullPath);
		 $("#"+_op.fileName).attr("value",nodes[0].fileName);
		 $("#"+_op.pId).attr("value",nodes[0].pId);*/
		 if(_op.callback!=null){
         	_op.callback();
	  	}
		 $("#"+_op.ztreeListBox).hide();
		 //选择了文件立即获取文件对应的角色信息
		 fileListOptClkHandler($("#"+thisId+"_fullPath").val());
	}
	 function fileListOptClkHandler(filePath){
			jQuery.ajax({
				//url: 'pentaho/SolutionRepositoryPermissionServlet?method=getSolutionRepositoryPermission&filePath='+filePath,
				url:"jsp/permission_data.json",
				dataType:"json",
				success: function (data) {
					//var allRoleArray = jQuery.parseJSON(data);
					//先清除两边列表
					$("#no_limit li").remove();
					$("#yes_limit li").remove();
					for(var i = 0; i < data.unselectedroles.length;i++){
						$("#no_limit").append("<li id=\""+data.unselectedroles[i].roleid+"\">"+data.unselectedroles[i].rolename+"</li>");
					}
					for(var i = 0; i < data.selectedroles.length;i++){
						$("#yes_limit").append("<li id=\""+data.selectedroles[i].roleid+"\">"+data.selectedroles[i].rolename+"</li>");
					}
				},
				error:function(jqXHR , textStatus, errorThrown){
					alert(jqXHR);
				}
			});	
		}
	 function keyboard(){
		 //向上
            if (e.keyCode == 38) {
                li_index--;
                if(li_index<-1){
                    li_index=dataLen-1;
                    $("#"+_op.id).find("li").removeClass("current");
                    $("#"+_op.id).find("li").eq(li_index).addClass("current");
                    getTreeValue(li_index);
                    return false;
                }
                $("#"+_op.id).find("li").removeClass("current");
                $("#"+_op.id).find("li").eq(li_index).addClass("current");
                getTreeValue(li_index);
            }
            //向下
            else if (e.keyCode == 40) {
            	++li_index;
            	 if(li_index==dataLen){
                    li_index=0;
                    $("#"+_op.id).find("li").removeClass("current");
                    $("#"+_op.id).find("li").eq(li_index).addClass("current");
                    getTreeValue(li_index);
                    return false;
                }
            	 if(li_index>dataLen){
            		 li_index=0;
                 }
                $("#"+_op.id).find("li").removeClass("current");
                $("#"+_op.id).find("li").eq(li_index).addClass("current");
                getTreeValue(li_index);
            }
            //回车键
            else if(e.keyCode==13){
            	if(_op.callback!=null){
                	_op.callback();
    	  		}
            	 var tem=$("#"+_op.id).find("li").eq(li_index).attr("orgId");
         	  	if(_op.orgIdCallback!=null){
                   	_op.orgIdCallback(tem);
          	  	}
                $("#"+_op.ztreeListBox).hide();
            }
	 }
	 function getTreeValue(index){
		 $("#"+_op.inputName).val($("#"+_op.id).find("li").eq(index).attr("name"));
		 $("#"+_op.fileName).val($("#"+_op.id).find("li").eq(index).attr("fileName"));
	  	 $("#"+_op.fullPath).val($("#"+_op.id).find("li").eq(index).attr("fullPath"));
	  	 $("#"+_op.orgId).val($("#"+_op.id).find("li").eq(index).attr("orgId"));
	  	 var tem=$("#"+_op.id).find("li").eq(index).attr("orgId");
	  	if(_op.orgIdCallback!=null){
          	_op.orgIdCallback(tem);
 	  	}
	  	 $("#"+_op.pId).val($("#"+_op.id).find("li").eq(index).attr("pId"));
	 }
};