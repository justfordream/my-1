package com.sfpay.ews.service.param.cod;

import java.util.List;
import com.sfpay.ews.dto.cod.WarnCodPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * COD预警服务的获取;
 * @author 575740
 *
 */
public interface IWarnGetCodParamService {
	
	/**
	 * =========================
	 * 监控指标(事前)-重复付款记录监控
	 * 预警阀值  A1  or  A2  or  A3  or  A4  > 0 
	 * 
	 * =========================
	 */
	
	
	/**
	 * A1 COD付款申请记录表当天“付款中”记录集合有重复的记录编号的集合；
	 * 重复记录数：= List.size()
	 * @param qryDate 查询某个日期;
	 * @return 返回值
	 * @throws ServiceException 自定义异常 
	 */
	public List<WarnCodPageDTO> getPayingRepeatList(String qryDate) throws ServiceException;
	
	/**
	 * A1 COD付款申请记录表当天“付款中”记录集合有重复的记录编号的集合；===数量;
	 * 重复记录数：= List.size()
	 * @param qryDate 查询某个日期;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPayingRepeatNum(String qryDate)  throws ServiceException;
	
	/**
	 * A2 COD付款申请记录表“已付款”记录集合存在付款中的记录编号
	 * paySucExitNum = List.size()
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnCodPageDTO> getPaySucExitList(String qryDate) throws ServiceException;
	
	/**
	 * A2 COD付款申请记录表“已付款”记录集合存在付款中的记录编号===数量;
	 * paySucExitNum = List.size()
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPaySucExitNum(String qryDate)  throws ServiceException;
	
	
	/**
	 * A3 收单ACQ 中外部付款信息表COD来源记录集合
	 * acqOutExitNum = List.size()
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnCodPageDTO> getAcqExitList(String qryDate) throws ServiceException;
	
	/**
	 * A3 收单ACQ 中外部付款信息表COD来源记录集合===数量;
	 * paySucExitNum = List.size()
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getAcqExitNum(String qryDate)  throws ServiceException;
	
	/**
	 * A4 收单ACQ 中外部付款信息表COD来源记录集合
	 * acqOutExitNum = List.size()
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnCodPageDTO> getAcqOutExitList(String qryDate) throws ServiceException;

	/**
	 * A4 收单ACQ 中外部付款信息表COD来源记录集合===数量
	 * acqOutExitNum = List.size()
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getAcqOutExitNum(String qryDate)  throws ServiceException;
	
	/**
	 * =========================
	 * 监控指标(事前)-付款申请记录数与应付款记录数等值指标
	 * 预警阀值  A1  <>  B1
	 * 
	 * =========================
	 */
	
	/**
	 * COD付款申请记录表“付款中”记录数
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPayingRecordNum(String qryDate)  throws ServiceException;
	
	/**
	 * 收单ACQ外部付款信息表“应付款”记录数
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getTradeRecordNum(String qryDate)  throws ServiceException;
	
	
	/**
	 * =========================
	 * 2.2.3	监控指标(事前)-付款申请金额与应付款金额等值 
	 * 预警阀值  A1  <>  B1
	 * 
	 * =========================
	 */
	
	/**
	 *  COD付款申请记录表当天“付款中”记录金额合计
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPayingMoneyNum(String qryDate)  throws ServiceException;
	
	
	/**
	 *  收单ACQ外部付款信息表应付记录金额合计
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getTradeMoneyNum(String qryDate)  throws ServiceException;
	
	
	/**
	 * 根据COD的账单编号，查找该COD的资料；
	 * 因为根据 A3:收单ACQ 中外部付款信息表COD来源记录集合存在外部交易订单编号
	 * 这个规则，查出COD的账单号后，需要插入到记录中。
	 * @param id 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnCodPageDTO getCodPayApplyInfoById(long id)  throws ServiceException;
	
	/**
	 * 根据dm_acq.PAYOUT_INFO的ID找出资料; 
	 * @param id 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnCodPageDTO getPayOutInfoDataById(long id)  throws ServiceException;
	
	/**
	 * 批量保存 A1 COD付款申请记录表当天“付款中”记录集合有重复的记录编号的集合
	 * @param qryDate 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnCodRule 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchPayingRepeat(String qryDate,String warnNo,String expExpLain,String warnCodRule,long paramRowNum) throws ServiceException;
	
	
	/**
	 * 批量保存 COD付款申请记录表“已付款”记录集合存在付款中的记录编号
	 * @param qryDate 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnCodRule 参数
	 * @param paramRowNum 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchPaySucExit(String qryDate,String warnNo,String expExpLain,String warnCodRule,long paramRowNum) throws ServiceException;

	
	/**
	 * 批量保存 A3 收单ACQ 中外部付款信息表COD来源记录集合
	 * @param qryDate 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnCodRule 参数
	 * @param paramRowNum 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchAcqExit(String qryDate,String warnNo,String expExpLain,String warnCodRule,long paramRowNum) throws ServiceException;

	
	/**
	 * 批量保存 A4 收单ACQ 中外部付款信息表COD来源记录集合
	 * @param qryDate 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnCodRule 参数
	 * @param paramRowNum 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchAcqOutExit(String qryDate,String warnNo,String expExpLain,String warnCodRule,long paramRowNum) throws ServiceException;

	
}
