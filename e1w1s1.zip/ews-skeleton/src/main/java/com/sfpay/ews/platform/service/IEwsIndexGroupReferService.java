/**
 * 
 */
package com.sfpay.ews.platform.service;

import java.util.List;
import java.util.Map;

/**
 * 类说明：预警指标和指标组映射服务接口
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
public interface IEwsIndexGroupReferService {
	/**
	 * 查询所有映射
	 * key-指标组编号 List-指标编号列表
	 * @return key-指标组编号 List-指标编号列表
	 */
	public Map<String, List<String>> queryAllRefer();
	
	/**
	 * 查询某个预警指标组下面的所有预警指标编号
	 * @param groupNo 预警群组编号
	 * @return 指标编号集合
	 */
	public List<String> queryWarnIndexByGroupNo(String groupNo);
	
}
