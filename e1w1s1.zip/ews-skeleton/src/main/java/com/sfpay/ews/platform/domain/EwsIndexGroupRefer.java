/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：预警指标和指标组映射表
 * 
 * 类描述：
 * 
 * @author 625288
 * 
 *         2015-3-11
 */
public class EwsIndexGroupRefer extends BaseEntity {
	private static final long serialVersionUID = 3853269709907647529L;
	// 指标编号
	private String warnIndexNo;
	// 组编号
	private String warnIndexGroupNo;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexGroupNo() {
		return warnIndexGroupNo;
	}

	public void setWarnIndexGroupNo(String warnIndexGroupNo) {
		this.warnIndexGroupNo = warnIndexGroupNo;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
