package com.sfpay.ews.service.param.sfgom;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 安心购调度执行服务
 * @author 627247
 * 2014-06-19
 */
public interface IWarnCallSfgomRuleService extends IWarnCallDayRuleService {

}
