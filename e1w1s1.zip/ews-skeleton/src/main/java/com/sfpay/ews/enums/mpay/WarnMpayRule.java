package com.sfpay.ews.enums.mpay;

/**
 * 手机支付的规则;
 * @author 575740
 *
 */
public enum WarnMpayRule {
	/**
	 * 一段时间交易失败率较高指标监控
	 */
	MPAY0001
}
