package com.sfpay.ews.dto.waybill;

import java.util.List;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:38:52
 */
public class WarnWayBillParamDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 2.1.1	A1:运单漏抽XXXX笔，既交易数据中状态为交易成功的运单数据未在运单数据中存在
	 */
	

	/**
	 * 漏掉在运单明细
	 */
	private List<WarnWayBillPageDTO>  missWayBillNoList;
	
	/**
	 * 漏掉在运单记录数量 = missWayBillNoList.size();
	 */
	private Long missWayBillNoRecordNum;
	/**
	 * A1:昨日交易成功的总运单数
	 */
	private Long tradeWayBillNum;
	/**
	 * 	A2:昨日交易成功但未在同步表漏抽的运单数
	 */
	private Long tradeMissingNum;	
	/**
	 * A3:昨日交易成功已在同步表但未从资科同步的运单数
	 */
	private Long tradeUnSysNcNum;
	/**
	 * 2.1.1	XXX日仍存在未同步抄写的运单XXXX笔
	 */
	
	
	/**
	 * N天前运单未同步的明细List
	 */
	private  List<WarnWayBillPageDTO>  ngSyncWayBillNoList;
	
	/**
	 * N天前运单未同步的明细记录数量 = ngSyncWayBillNoList.size();
	 */
	private Long ngSyncWayBillNoRecordNum;
	

	public List<WarnWayBillPageDTO> getMissWayBillNoList() {
		return missWayBillNoList;
	}

	public void setMissWayBillNoList(List<WarnWayBillPageDTO> missWayBillNoList) {
		this.missWayBillNoList = missWayBillNoList;
	}

	public Long getMissWayBillNoRecordNum() {
		return missWayBillNoRecordNum;
	}

	public void setMissWayBillNoRecordNum(Long missWayBillNoRecordNum) {
		this.missWayBillNoRecordNum = missWayBillNoRecordNum;
	}

	public List<WarnWayBillPageDTO> getNgSyncWayBillNoList() {
		return ngSyncWayBillNoList;
	}

	public void setNgSyncWayBillNoList(List<WarnWayBillPageDTO> ngSyncWayBillNoList) {
		this.ngSyncWayBillNoList = ngSyncWayBillNoList;
	}

	public Long getNgSyncWayBillNoRecordNum() {
		return ngSyncWayBillNoRecordNum;
	}

	public void setNgSyncWayBillNoRecordNum(Long ngSyncWayBillNoRecordNum) {
		this.ngSyncWayBillNoRecordNum = ngSyncWayBillNoRecordNum;
	}
	
	
	public Long getTradeWayBillNum() {
		return tradeWayBillNum;
	}

	public void setTradeWayBillNum(Long tradeWayBillNum) {
		this.tradeWayBillNum = tradeWayBillNum;
	}

	public Long getTradeMissingNum() {
		return tradeMissingNum;
	}

	public void setTradeMissingNum(Long tradeMissingNum) {
		this.tradeMissingNum = tradeMissingNum;
	}

	public Long getTradeUnSysNcNum() {
		return tradeUnSysNcNum;
	}

	public void setTradeUnSysNcNum(Long tradeUnSysNcNum) {
		this.tradeUnSysNcNum = tradeUnSysNcNum;
	}

	
}
