package com.sfpay.ews.service.param.waybill;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

public interface IWarnWayBillRuleService extends IWarnCallDayRuleService {
	/**
	 * 什么也不做;
	 */
}
