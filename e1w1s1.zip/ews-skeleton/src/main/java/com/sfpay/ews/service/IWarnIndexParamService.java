package com.sfpay.ews.service;

import java.util.Map;

import com.sfpay.ews.dto.WarnIndexParamDTO;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;


/**
 * 指标参数业务接口
 * @author 321566 张泽豪
 *
 * 2014-5-9 上午10:38:45
 */
public interface IWarnIndexParamService {
	
	/**
	 * 新增或者修改一个指标参数
	 * @param param
	 * @throws ServiceException
	 */
	public void saveorUpdateWarnIndexParam(WarnIndexParamDTO param) throws ServiceException;
	
	
	/**
	 * 分页查询指标参数
	 * @param param
	 * @param index
	 * @param size
	 * @return
	 * @throws ServiceException
	 */
	public IPage<WarnIndexParamDTO> queryIndexParamByPage(WarnIndexParamDTO param,int index,int size) throws ServiceException;
	
	/**
	 * 根据id查询指标参数
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public WarnIndexParamDTO queryWarnIndexParamById(long id) throws ServiceException;
	
	/**
	 * 根据监控系统，指标代码，指标参数查询一个资料，如果没有，就返回传入的默认值;
	 * 在规则调用中使用
	 * @param warnSource
	 * @param warnIndexNo
	 * @param paramNo
	 * @param defaultVal
	 * @return
	 * @throws ServiceException
	 */
	public String queryIndexParamValByCond(String warnSource,String warnIndexNo,String paramNo,String defaultVal) throws ServiceException;
	
	/**
	 *根据指标编号查询参数
	 * @param warnIndexNo
	 * @return
	 * @throws ServiceException
	 */
	public WarnIndexParamDTO queryIndexParamByWarnIndexNo(String warnIndexNo) throws ServiceException;
	
	/**
	 * 根据监控系统和指标代码来获取某指标的全部参数
	 * 
	 * @param warnSource
	 * @param warnIndexNo
	 * @return
	 */
	public Map<String, Map<String, String>> queryIndexNoParams(String warnSource);
	
}
