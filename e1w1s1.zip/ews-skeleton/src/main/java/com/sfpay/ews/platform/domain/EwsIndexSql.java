/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：预警指标SQL
 * 
 * 类描述：每个预警指标可以对应一条或多条SQL
 * 
 * @author 625288
 * 
 *         2015-3-3
 */
public class EwsIndexSql extends BaseEntity {
	// SQL语句
	private String warnIndexSql;
	// 指标编号
	private String warnIndexNo;
	// sql键，用来标记SQL和存储SQL结果集
	// sql键不能使用关键字SQLPARAMKEY
	private String sqlKey;
	// 是否需要在邮件中输出结果集
	private String mailOutput;
	// 是否需要在规则中输出结果集
	private String ruleOutput;
	// 该SQL的指标明细的表名
	private String tableName;
	// 备注
	private String remark;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;
	
	private static final long serialVersionUID = 8314689728879875278L;

	public String getWarnIndexSql() {
		return warnIndexSql;
	}

	public void setWarnIndexSql(String warnIndexSql) {
		this.warnIndexSql = warnIndexSql;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}
	
	public String getMailOutput() {
		return mailOutput;
	}

	public void setMailOutput(String mailOutput) {
		this.mailOutput = mailOutput;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSqlKey() {
		return sqlKey;
	}

	public void setSqlKey(String sqlKey) {
		this.sqlKey = sqlKey;
	}

	public String getRuleOutput() {
		return ruleOutput;
	}

	public void setRuleOutput(String ruleOutput) {
		this.ruleOutput = ruleOutput;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
