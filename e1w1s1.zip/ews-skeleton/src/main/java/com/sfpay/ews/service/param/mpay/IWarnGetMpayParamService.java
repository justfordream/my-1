package com.sfpay.ews.service.param.mpay;

import com.sfpay.ews.dto.mpay.WarnMpayPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 手机支付预警服务的获取;
 * @author 575740
 *
 */
public interface IWarnGetMpayParamService {
	/**
	 * 规则一:A1:一段时间交易收单的记录
	 * @param qryDate
	 * @param paramDay
	 * @return
	 * @throws ServiceException
	 */
	public long getMpayAllNum(String qryDate,float paramDay) throws ServiceException;
	
	
	/**
	 * 规则一:A2: 一段时间交易收单成功的记录
	 * @param qryDate
	 * @param paramDay
	 * @return
	 * @throws ServiceException
	 */
	public long getMpaySuccessNum(String qryDate,float paramDay) throws ServiceException;
	
	/**
	 * 根据手机支付的id获取该行资料，id存储于ews_warning_tb的buss_id;
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public WarnMpayPageDTO getPayMentOrderById(Long id) throws ServiceException;
	

	/**
	 * 批量保存：规则一：2.4.1  监控指标(事中)一段时间交易失败率较高指标
	 * @param qryDate
	 * @param paramDay
	 * @param warnNo
	 * @param expExpLain
	 * @param warnMpayRule
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return
	 */
	public int saveBatchUnMpaySuccess(String qryDate,float paramDay,String warnNo,String expExpLain,String warnMpayRule,long paramRowNum) throws ServiceException;
		
	
}
