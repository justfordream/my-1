package com.sfpay.ews.dto.mpay;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 手机支付系统风险预警监控指标 
 * @author 575740
 * 2014/05/08 
 *
 */
public class WarnMpayParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * A1:一段时间交易收单的记录
	 */
	private long mpayAllNum;
	
	/**
	 * A2: 一段时间交易收单成功的记录
	 */
	private long mpaySuccessNum;
	

	public long getMpayAllNum() {
		return mpayAllNum;
	}

	public void setMpayAllNum(long mpayAllNum) {
		this.mpayAllNum = mpayAllNum;
	}

	public long getMpaySuccessNum() {
		return mpaySuccessNum;
	}

	public void setMpaySuccessNum(long mpaySuccessNum) {
		this.mpaySuccessNum = mpaySuccessNum;
	}
	
}
