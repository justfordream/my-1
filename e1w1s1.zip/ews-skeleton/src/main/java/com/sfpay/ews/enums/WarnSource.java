package com.sfpay.ews.enums;

public enum WarnSource {
	/**
	 * COD系统
	 */
	COD,	
	/**
	 * 营销系统
	 */
	MARKET,
	/**
	 * 运单系统
	 */
	WAYBILL,
	/**
	 * 银企系统
	 */
	ACQ,
	/**
	 * 银企B2C系统
	 */
	BTOC,
	/**
	 * 手机支付系统
	 */
	MPAY,
	/**
	 * 储值卡系统
	 */
	STOREDCARD,
	/**
	 * 电子账户系统
	 */
	ELEACCOUNT,
	/**
	 * 核心订单系统
	 */
	TRADEORDER,
	/**
	 * 核心账户系统
	 */
	COREACCOUNT,
	/**
	 * 垫付货款系统
	 */
	PAS,
	/**
	 * 顺手付系统
	 */
	SYPAY,
	/**
	 * 公款代扣系统
	 */
	DEBIT,
	/**
	 * 安心购系统
	 */
	SFGOM,
	/**
	 * 米兰港(融资平台)系统
	 */
	FMS,
	/**
	 * 风控系统
	 */
	RM,
	/**
	 * 理财平台系统
	 */
	LCPT,
	/**
	 * 理赔统付系统
	 */
	ISS
	
}
