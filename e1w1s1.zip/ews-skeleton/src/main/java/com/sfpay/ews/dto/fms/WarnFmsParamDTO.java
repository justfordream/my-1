package com.sfpay.ews.dto.fms;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 米兰港(融资平台) 预警监测的资料，在明细中显示；
 * @author 575740
 * 2014-06-19
 */
public class WarnFmsParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 指标一:融通向顺手付支付进行中的记录数
	 */
	private long doingNum;
	
	/**
	 * 指标二: 融通与顺手付系统交易对账不匹配记录数
	 */
	private long fmsToPayNum;

	public long getDoingNum() {
		return doingNum;
	}

	public void setDoingNum(long doingNum) {
		this.doingNum = doingNum;
	}

	public long getFmsToPayNum() {
		return fmsToPayNum;
	}

	public void setFmsToPayNum(long fmsToPayNum) {
		this.fmsToPayNum = fmsToPayNum;
	}

	
	
}
