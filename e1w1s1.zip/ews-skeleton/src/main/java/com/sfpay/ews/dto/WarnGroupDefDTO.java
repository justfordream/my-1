package com.sfpay.ews.dto;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:32:49
 */
public class WarnGroupDefDTO extends BaseEntity{

	private static final long serialVersionUID = -4981148638819442214L;
	
	private String groupNo;
	
	private String groupName;
	
	private String groupExplain;
	
	private String isValid;
	
	private String remark;
	
	private String createId;
	
	private Date createTime;
	
	private String updateId;
	
	private Date updateTime;
	
	private String indexName;
	
	private String selected;
	
	private String flag;
	
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroupExplain() {
		return groupExplain;
	}
	public void setGroupExplain(String groupExplain) {
		this.groupExplain = groupExplain;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getIndexName() {
		return indexName;
	}
	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}
	
	public String getSelected() {
		return selected;
	}
	public void setSelected(String selected) {
		this.selected = selected;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	@Override
	public String toString() {
		return "WarnGroupDefDTO [groupNo=" + groupNo + ", groupName="
				+ groupName + ", groupExplain=" + groupExplain + ", isValid="
				+ isValid + ", remark=" + remark + ", createId=" + createId
				+ ", createTime=" + createTime + ", updateId=" + updateId
				+ ", updateTime=" + updateTime + ", indexName=" + indexName
				+ ", selected=" + selected + "]";
	}

}
