package com.sfpay.ews.platform.service;

import java.util.List;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 指标定义服务接口
 * 
 * @author 575740
 * 
 */
public interface IEwsIndexDefService {

	/**
	 * 根据编号查找一个预警指标
	 * 
	 * @param indexNo 指标编号
	 * @return 指标对象
	 * @throws ServiceException 自定义异常
	 */
	public EwsIndexDef queryByWarnIndexNo(String warnIndexNo)
			throws ServiceException;

	/**
	 * 新增一个指标
	 * 
	 * @param indexDef 指标对象
	 * @throws ServiceException 自定义异常
	 */
	public void addEwsIndexDef(EwsIndexDef indexDef) throws ServiceException;

	/**
	 * 修改一个指标
	 * 
	 * @param indexDef 指标对象
	 * @throws ServiceException 自定义异常
	 */
	public void updateEwsIndexDef(EwsIndexDef indexDef) throws ServiceException;

	/**
	 * 分页查询指标
	 * 
	 * @param indexDef 指标对象
	 * @param index 页索引
	 * @param size 页大小
	 * @return 分页预警指标
	 * @throws ServiceException 自定义异常
	 */
	public IPage<EwsIndexDef> queryEwsIndexDefByPage(EwsIndexDef indexDef, int index, int size)
			throws ServiceException;

	/**
	 * 根据预警来源查询所有指标
	 * 
	 * @param warnSource 预警来源
	 * @return 指标集合
	 */
	public List<EwsIndexDef> queryByWarnSource(String warnSource);

	/**
	 * 查询所有预警指标
	 * 
	 * @return 指标集合
	 */
	public List<EwsIndexDef> queryAllIndexDef();
	
	/**
	 * 更新指标调度状态
	 * @param warnIndexNo 指标编号
	 * @param status 只能是START和CLOSE两种值
	 */
	public void updateIndexSchStatus(String warnIndexNo, String status);
	
	/**
	 * 更新指标调度运行状态
	 * @param warnIndexNo 指标编号
	 * @param runStatus 只能是RUNNING和STOP两种值
	 */
	public void updateIndexSchRunStatus(String warnIndexNo, String runStatus);
	
	/**
	 * 将所有指标调度运行状态修改成STOP
	 */
	public void updateAllIndexSchRunStatusToStop();
}
