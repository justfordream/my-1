package com.sfpay.ews.service.param.sypay;

import java.util.List;

import com.sfpay.ews.dto.WarnMemberAccountDTO;
import com.sfpay.ews.dto.WarnMemberDTO;
import com.sfpay.ews.dto.WarnSuspectedUserDTO;
import com.sfpay.ews.dto.sypay.WarnSypayPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 顺手付系统的指标参数服务 接口
 * 
 * @author 627247 2014-06-18
 */
public interface IWarnGetSypayParamService {

	/**
	 * 获取顺手付和小订单的提前对账不一致数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @param endTimeMore 增加的时间值
	 * @return 返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getInconsistentTradeNum(String beginTime, String endTime, String endTimeMore) throws ServiceException;

	/**
	 * 获取网银支付长时间未付款的记录数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getLongTimeNoPayNum(String beginTime, String endTime) throws ServiceException;

	/**
	 * 获取某段时间内支付的总数量
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getTradeAllNum(String beginTime, String endTime) throws ServiceException;

	/**
	 * 获取某段时间内支付的失败数量
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回总数
	 * @throws ServiceException 自定义异常 
	 */
	public long getTradeUnSucNum(String beginTime, String endTime) throws ServiceException;

	/**
	 * 指定时间内发生连续交易的会员数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @param minute 多少分钟内发生连续交易
	 * @return  返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getContinuousTradeMemberNum(String beginTime, String endTime, int minute) throws ServiceException;

	/**
	 * 账户余额为负的账户数
	 * 
	 * @return  账户数
	 * @throws ServiceException
	 */
	public long getMinusAccountNum() throws ServiceException;

	/**
	 * 顺手付与银企预对账不一致数
	 * 
	 * @param beginTime
	 * @param endTime
	 * @param endTimeMore
	 * @return 返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getInconsistentTradeForYqNum(String beginTime, String endTime, String endTimeMore) throws ServiceException;

	/**
	 * 批量保存网银支付长时间未付款的记录数;
	 * 
	 * @param qryBeginTime    开始时间
	 * @param qryEndTime  结束时间
	 * @param warnNo 告警编号
	 * @param expExpLain 告警说明;
	 * @param warnSypayRule 违反规则
	 * @param paramRowNum  建议10笔;
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public int saveIndexTwoDetails(String qryBeginTime, String qryEndTime, String warnNo, String expExpLain, String warnSypayRule,
			long paramRowNum) throws ServiceException;

	/**
	 * 保存指定时间内发生连续交易的会员的交易明细
	 * 
	 * @param qryBeginTime  开始时间
	 * @param qryEndTime  结束时间
	 * @param minute 多少分钟内发生连续交易
	 * @param warnNo  告警编号
	 * @param expExpLain  告警说明
	 * @param warnSypayRule  违反规则
	 * @param paramRowNum 建议10笔
	 * @return 交易数
	 * @throws ServiceException 自定义异常
	 */
	public int saveIndexFourDetails(String qryBeginTime, String qryEndTime, int minute, String warnNo, String expExpLain,
			String warnSypayRule, long paramRowNum) throws ServiceException;

	/**
	 * 根据ID查询一笔资料;
	 * 
	 * @param id 主键ID
	 * @return 资料记录
	 * @throws ServiceException 自定义异常
	 */
	public WarnSypayPageDTO getPayBusinessInfoById(Long id) throws ServiceException;
	
	/**
	 * 查询已领取、已拆开、过期已退款的小红包金额是否等于红包批次小红包的总金额;
	 * 
	 * @return 总金额
	 * @throws ServiceException 自定义异常
	 */
	public long getReceivedRedBagAmountOverSendedTotalNum() throws ServiceException;
	
	/**
	 * 查询已领取、已拆开、过期已退款的小红包累计个数是否等于红包批次小红包的总个数;
	 * 
	 * @return 总个数
	 * @throws ServiceException 自定义异常
	 */
	public long getReceivedRedBagNumOverSendedTotalNum() throws ServiceException;
	
	/**
	 * 查询红包批次抢完后小红包累计金额不等于大红包总金额的红包批次信息;
	 * 
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getSmallRedBagNotEqualBigRedBag() throws ServiceException;
	/**
	 * 查询红包批次抢完后小红包累计金额不等于大红包总金额的红包批次信息;
	 * 
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getOneMemGetRedBagServalTimes() throws ServiceException;
	
	/**
	 * 查询是否存在单个1万元以上的红包的批次信息;
	 * 
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getOneRedBagAmountOverTenThousand() throws ServiceException;
	/**
	 * 查询是否存在单个20万元以上的红包的批次信息;
	 * 
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getOneMemSendRedBagOverTwoHunThousand() throws ServiceException;
	
	/**
	 * 
	 * 方法：SFPR0007:查询【1】小时内【理财申购】累计金额≥【10000】RMB的记录
	 * 方法说明：
	 *
	 * @param beginTime 开始时间
	 * @param paramTime	时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getPurchaseSumAmtWarnList(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0001 【1】小时内【充值】累计金额≥【10000】RMB
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getRechargeOverInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 *  SFPR0002【1】小时内【转账】累计金额≥【10000】RMB
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度 
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getTransAccInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0003	【1】小时内【本金消费】累计金额≥【10000】RMB
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getPrincConsuInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0004	【1】小时内【提现】累计金额≥【10000】RMB
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getWithDrawCashInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0006	【1】小时内【收红包】累计金额≥【1000】RMB
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getRedEveCashInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0008	【1】小时内【理财赎回】累计金额≥【10000】RMB
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getFinacialRedemptionInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0011	【1】小时内【消费】次数≥【5】次
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getConsumeTimesInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0012	【1】小时内【提现】次数≥【5】次
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param amtParam 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getMentionTimesInfo(String beginTime,String paramTime,long amtParam) throws ServiceException;
	
	/**
	 * SFPR0024:客户一天内出现10次以上转账成功
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnTimes 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getTransferSuccessWarn(String beginTime,String paramTime,long txnTimes) throws ServiceException;
	
	/**
	 * SFPR0025:客户一天内出现10次以上提现成功
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnTimes 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getWithdrawalsWarn(String beginTime,String paramTime,long txnTimes) throws ServiceException;
	
	/**
	 * SFPR0026:客户一天内出现转账累计金额≥20000元
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnAmount 阀值
	 * @return 记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getTransfersWarn(String beginTime,String paramTime,long txnAmount) throws ServiceException;
	
	/**
	 * SFPR0027:客户一天内出现提现累计金额≥20000元
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnAmount 阀值
	 * @return 详细记录
	 * @throws ServiceException  自定义异常
	 */
	public List<WarnMemberDTO> getWithdrawalsTotalWarn(String beginTime,String paramTime,long txnAmount) throws ServiceException;
	
	/**
	 * SFPR0028:一周内新开用户，出现转账次数累计20次
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnTimes 阀值
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getTransferWeekWarn(String beginTime,String paramTime,long txnTimes) throws ServiceException;
	
	/**
	 * SFPR0029	一周内新开用户，出现提现次数累计20次
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnTimes 阀值
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getWithdrawalsWeekWarn(String beginTime,String paramTime,long txnTimes) throws ServiceException;
	
	/**
	 * SFPR0030	一周内新开用户，出现转账累计金额≥20000元
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnAmount 阀值
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */ 
	public List<WarnMemberDTO> getTransferFundWeekWarn(String beginTime,String paramTime,long txnAmount) throws ServiceException;
	
	/**
	 *  SFPR0031	一周内新开用户，出现提现累计金额≥20000元
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnAmount 阀值
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getWithdrawalsFundWeekWarn(String beginTime,String paramTime,long txnAmount) throws ServiceException;
	
	/**
	 * SFPR0033 转账专项监控指标：【48】小时内账户转账的转入次数大于等于【3】次且转入的总金额大于等于【200】RMB
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param txnTimes 阀值
	 * @param txnAmount 阀值
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnMemberDTO> getTransfersWarmTwoDays(String beginTime,String paramTime,long txnTimes,long txnAmount) throws ServiceException;
	
	
	/**
	 * 
	 * 方法：SFPR0034 (1)总用户量
	 * 方法说明：
	 *
	 * @param beginTime 开始时间
	 * @return 总用户量
	 * @throws ServiceException 自定义异常
	 */
	public Integer getTotalUser(String beginTime) throws ServiceException;
	

	/**
	 * 
	 * 方法：SFPR0034 (2)昨日新增
	 * 方法说明：
	 *
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 昨日新增
	 * @throws ServiceException 自定义异常
	 */
	public Integer getUserInc(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * 
	 * 方法：SFPR0034 (3)未实名数
	 * 方法说明：
	 *
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return  未实名数
	 * @throws ServiceException 自定义异常
	 */
	public Integer getUserNoAuth(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0034 (4)实名数 
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return  实名数 
	 * @throws ServiceException 自定义异常
	 */
	public Integer getUserAuth(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0034 (5)当日登录数
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @param paramOverTime 时间增量
	 * @return 当日登录数
	 * @throws ServiceException 自定义异常
	 */
	public Integer getTotalLoginUser(String beginTime,String paramTime,String paramOverTime) throws ServiceException;
	
	/**
	 * SFPR0034 (6)已绑卡总量 
	 * 
	 * @param beginTime 开始时间
	 * @return 已绑卡总量 
	 * @throws ServiceException 自定义异常
	 */
	public Integer getTotalCardNum(String beginTime) throws ServiceException;
	
	/**
	 * SFPR0035 (1)累计申购金额
	 * 
	 * @return 累计申购金额
	 * @throws ServiceException 自定义异常
	 */
	public Long getTotalBuyAmt() throws ServiceException;
	
	/**
	 * SFPR0035 (2)累计扎差额
	 * 
	 * @return
	 */
//	public Long getDiffAmt() throws ServiceException;
	
	/**
	 * SFPR0035 (3)申购笔数
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 申购金额
	 * @throws ServiceException 自定义异常
	 */
	public Long getTotalBuyNum(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0035 (4)申购金额
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 申购金额
	 * @throws ServiceException 自定义异常
	 */
	public Long getBuyAmt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0035 (5)赎回金额含普赎
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 赎回金额含普赎
	 * @throws ServiceException 自定义异常
	 */
	public Long getTotalRedeemAmt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0035 (6)累计赎回金额
	 * 
	 * @return 累计赎回金额
	 */
	public Long getTotalSumRedeemAmt();
	
	/**
	 * SFPR0035 (7)累计收益
	 * 
	 * @return 累计收益
	 */
	public Long getTotalSumIncomeAmt();
	
	/**
	 * SFPR0035 (8)理财余额
	 * 
	 * @return 理财余额
	 */
	public Long getTotalLotAmt();
	
	/**
	 * SFPR0036 (1)消费
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getExpressAmt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0036 (2)转账
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getTransferAmt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0036 (3)提现
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getWithdrawAmt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0036 (4)充值
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getRechargeAmt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0036 (1)消费笔数
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getExpressCnt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0036 (2)转账笔数
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return  详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getTransferCnt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0036 (3)提现笔数
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getWithdrawCnt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SFPR0036 (4)充值笔数
	 * 
	 * @param beginTime 开始时间
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 * @throws ServiceException 自定义异常
	 */
	public Long getRechargeCnt(String beginTime,String paramTime) throws ServiceException;
	
	/**
	 * SYPAY0013 疑似被盗的账户：【7】天内该账户只充值和转账的账户
	 * 
	 * @param paramTime 时间跨度
	 * @return 详细记录
	 */
	public List<WarnMemberAccountDTO> getSuspectedStolen(String paramTime);
	
	/**
	 * SYPAY0014 疑似欺诈的账户：【?】天内该账户没有充值且提现和消费总额大于【?】RMB的账户
	 * 
	 * @param paramTime 时间跨度
	 * @param txnAmount 阀值
	 * @return 详细记录
	 */
	public List<WarnMemberAccountDTO> getSuspectedFraud(String paramTime, String txnAmount);
	
	/**
	 * SYPAY0015 绑定【2】张及以上的用户理财赎回就告警
	 * 
	 * @param txnAmount	银行卡张数
	 * @return 详细记录
	 */
	public List<WarnSuspectedUserDTO> getSuspectedFinanceUser(String paramTime,String txnAmount);
}
