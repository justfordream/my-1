package com.sfpay.ews.platform.service;

import java.util.List;

import com.sfpay.ews.platform.domain.EwsEmpGroupRefer;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：预警人员与指标组对应表记录维护
 *
 *
 * @author 544772
 * 2015年3月11日 下午2:39:44
 */
public interface IEwsEmpGroupReferService {

	/**
	 * 新增预警人员与指标组对应表记录
	 * 
	 * @param ewsEmpGroupRefer 预警人员与指标组对应实体
	 * @throws ServiceException 自定义服务异常
	 */
	public void addEwsEmpGroupRefer(EwsEmpGroupRefer ewsEmpGroupRefer) throws ServiceException;

	/**
	 * 更新预警人员与指标组对应表记录
	 * 
	 * @param ewsEmpGroupRefer 预警人员与指标组对应实体
	 * @throws ServiceException 自定义服务异常
	 */
	public void updateEwsEmpGroupRefer(EwsEmpGroupRefer ewsEmpGroupRefer) throws ServiceException;

	/**
	 * 删除对应的预警人员与指标组的对应关系
	 * 
	 * @param empId 主键
	 * @throws ServiceException 自定义服务异常
	 */
	public void delEwsEmpGroupRefer(String id) throws ServiceException;

	/**
	 * 查询预警人员与指标组的对应记录
	 * 
	 * @param ewsEmpGroupRefer  预警人员与指标组对应实体
	 * @return 返回记录
	 * @throws ServiceException 自定义服务异常
	 */
	public List<EwsEmpGroupRefer> queryEwsEmpGroupReferByParam(EwsEmpGroupRefer ewsEmpGroupRefer) throws ServiceException;
	
	/**
	 * 根据指标编号获取预警人员的信息
	 * 
	 * @param warIndexNo 指标编号
	 * @return 返回记录
	 * @throws ServiceException 自定义服务异常
	 */
	public List<EwsEmpGroupRefer> queryEmpGroupInfoByIndexNo(String warIndexNo) throws ServiceException;
	
}
