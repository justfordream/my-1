package com.sfpay.ews.dto.storedcard;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 储值卡系统的页面显示
 * @author 575740
 *
 */
public class WarnStoredCardPageDTO extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 业务流水号
	 */
	private String businessSn;
	
	/**
	 * 商户会员编号
	 */
	private Long memberNo;
	
	/**
	 * 消费、消费撤销、消费作废、消费退长款、补收款
	 */
	private String businessType;
	
	/**
	 * 金额
	 */	
	private Long amt;
	
	/**
	 * 业务状态(交易进行中、交易成功、交易失败、交易关闭、退款进行中、退款成功、退款失败、撤销进行中、撤销成功、撤销失败、长款进行中、长款成功、长款失败、补收款中、补收款成功、补收款失败)
	 */
	private String businessStatus;
	
	/**
	 * 业务开始时间
	 */
	private String beginTime;
	
	/**
	 * 业务结束时间
	 */
	private String endTime;
	
	/**
	 * 线下业务支付类型：储值卡、借记卡、信用卡、现金、快捷支付等
	 */
	private String bizPayType;
	
	/**
	 * 卡号，包括借记卡、信用卡和速运通卡，现金支付没有卡号
	 */
	private String cardCode;

	public String getBusinessSn() {
		return businessSn;
	}

	public void setBusinessSn(String businessSn) {
		this.businessSn = businessSn;
	}

	public Long getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(Long memberNo) {
		this.memberNo = memberNo;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public Long getAmt() {
		return amt;
	}

	public void setAmt(Long amt) {
		this.amt = amt;
	}

	public String getBusinessStatus() {
		return businessStatus;
	}

	public void setBusinessStatus(String businessStatus) {
		this.businessStatus = businessStatus;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getBizPayType() {
		return bizPayType;
	}

	public void setBizPayType(String bizPayType) {
		this.bizPayType = bizPayType;
	}

	public String getCardCode() {
		return cardCode;
	}

	public void setCardCode(String cardCode) {
		this.cardCode = cardCode;
	}

}
