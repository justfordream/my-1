package com.sfpay.ews.dto;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;
/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:32:02
 */
public class WarnCalRltLogDTO extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 预警日期 YYYY-MM-DD;资料库后台Trunc
	 */
	private String warnDate;
	
	private Date warnDate2;

	/**
	 * 预警编号
	 */
	private String warnIndexNo;
	/**
	 * 预警指标说明
	 */
	private String warnIndexName;
	/**
	 * 指标计算开始时间
	 */
	private String warnBeginTime;
	
	private Date warnBeginTime2;
	/**
	 * 指标计算结束时间
	 */
	private String warnEndTime;
	
	private Date warnEndTime2;
	/**
	 * 指标计算的秒 = 计算结束时间  - 计算开始时间
	 */
	private Long warnCalSecond;
	/**
	 * 备注
	 */
	private String remark;
	
	/**
	 * 创建时间
	 */
	private String createTime;
	
	private Date createTime2;
	
	/**
	 * 预警来源;
	 */
	private String warnSource;
	
	/**
	 * 开始预警日期
	 */
	private String startWarnDate;
	
	/**
	 * 结束预警日期
	 */
	private String endWarnDate;
	
	public Date getWarnDate2() {
		return warnDate2;
	}

	public void setWarnDate2(Date warnDate2) {
		this.warnDate2 = warnDate2;
	}

	public Date getWarnBeginTime2() {
		return warnBeginTime2;
	}

	public void setWarnBeginTime2(Date warnBeginTime2) {
		this.warnBeginTime2 = warnBeginTime2;
	}

	public Date getWarnEndTime2() {
		return warnEndTime2;
	}

	public void setWarnEndTime2(Date warnEndTime2) {
		this.warnEndTime2 = warnEndTime2;
	}

	public Date getCreateTime2() {
		return createTime2;
	}

	public void setCreateTime2(Date createTime2) {
		this.createTime2 = createTime2;
	}

	public String getStartWarnDate() {
		return startWarnDate;
	}

	public void setStartWarnDate(String startWarnDate) {
		this.startWarnDate = startWarnDate;
	}

	public String getEndWarnDate() {
		return endWarnDate;
	}

	public void setEndWarnDate(String endWarnDate) {
		this.endWarnDate = endWarnDate;
	}

	public String getWarnDate() {
		return warnDate;
	}

	public void setWarnDate(String warnDate) {
		this.warnDate = warnDate;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexName() {
		return warnIndexName;
	}

	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}

	public String getWarnBeginTime() {
		return warnBeginTime;
	}

	public void setWarnBeginTime(String warnBeginTime) {
		this.warnBeginTime = warnBeginTime;
	}

	public String getWarnEndTime() {
		return warnEndTime;
	}

	public void setWarnEndTime(String warnEndTime) {
		this.warnEndTime = warnEndTime;
	}

	public Long getWarnCalSecond() {
		return warnCalSecond;
	}

	public void setWarnCalSecond(Long warnCalSecond) {
		this.warnCalSecond = warnCalSecond;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	@Override
	public String toString() {
		return "WarnCalRltLogDTO [warnDate=" + warnDate + ", warnIndexNo="
				+ warnIndexNo + ", warnIndexName=" + warnIndexName
				+ ", warnBeginTime=" + warnBeginTime + ", warnEndTime="
				+ warnEndTime + ", warnCalSecond=" + warnCalSecond
				+ ", remark=" + remark + ", createTime=" + createTime
				+ ", warnSource=" + warnSource + ", startWarnDate="
				+ startWarnDate + ", endWarnDate=" + endWarnDate + "]";
	}

}
