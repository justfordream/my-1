package com.sfpay.ews.enums.tradeorder;

/**
 * 核心订单系统的规则;
 * @author 575740
 * 2014-05-23
 */
public enum WarnTradeOrderRule {
	/**
	 * 新订单系统中某段时间内交易订单未成功的异常比率
	 */
	TRADEORDER0001,
	/**
	 * 消费，转账，提现等交易超过设置时间30分钟未成功的记录
	 */
	TRADEORDER0002,
	/**
	 * O2A对账中账目不平的记录数
	 */
	TRADEORDER0003,
	/**
	 * 新订单系统交易异常
	 */
	TRADEORDER0004,
	/**
	 *  O2B对账中账目不平的记录数
	 */
	TRADEORDER0005
}
