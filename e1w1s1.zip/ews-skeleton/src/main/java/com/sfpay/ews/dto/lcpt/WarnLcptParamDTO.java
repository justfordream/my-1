package com.sfpay.ews.dto.lcpt;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:37:23
 */
public class WarnLcptParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 指标一：LCPT0001  大额赎回订单预警
	 */
	private long largeAmtRedeemNum;
	/**
	 * 指标二：LCPT0002  申购未支付订单占比
	 */
	private float purchaseNotPayedNum;
	/**
	 * 指标二：阀值
	 */
	private float indexTwoTthreshold;

	/**
	 * 指标三：LCPT0003  开户失败
	 */
	private long openAccountFailedNum;
	
	/**
	 * 指标四：LCPT0004  申购失败
	 */
	private long purchaseFailedNum;
	
	/**
	 * 指标五：LCPT0005  普通赎回交易订单失败
	 */
	private long redeemTradeFailedNum;
	
	/**
	 * 指标六：LCPT0006  快速赎回交易订单失败
	 */
	private long soonRedeemTradeFailedNum;
	
	/**
	 * 普赎支付失败数量
	 */
	private long redeemPayFailNum;
	
	/**
	 * 快赎支付失败数量
	 */
	private long soonRedeemPayFailNum;
	
	/**
	 * 异常订单数量
	 */
	private long exceptionTradeOrderNum;
	
	/**
	 * 快速赎回未当天到账
	 */
     private long soonReedemUnAccount;
     
     /**
      * 相同客户重复赎回
      */
     private long repeatRedeemNum;
     
     /**
      * 相同客户重复申购
      */
     private long repeatPurchaseNum;
     
     /**
      * 业务订单-支付订单金额不符
      */
     private long payAmtUnMatch;
     
     /**
      * 业务订单-支付订单笔数不符
      */
     private long payCountUnMatchNum;


	public long getRedeemPayFailNum() {
		return redeemPayFailNum;
	}

	public void setRedeemPayFailNum(long redeemPayFailNum) {
		this.redeemPayFailNum = redeemPayFailNum;
	}

	public long getSoonRedeemPayFailNum() {
		return soonRedeemPayFailNum;
	}

	public void setSoonRedeemPayFailNum(long soonRedeemPayFailNum) {
		this.soonRedeemPayFailNum = soonRedeemPayFailNum;
	}

	public long getExceptionTradeOrderNum() {
		return exceptionTradeOrderNum;
	}

	public void setExceptionTradeOrderNum(long exceptionTradeOrderNum) {
		this.exceptionTradeOrderNum = exceptionTradeOrderNum;
	}

	public long getSoonReedemUnAccount() {
		return soonReedemUnAccount;
	}

	public void setSoonReedemUnAccount(long soonReedemUnAccount) {
		this.soonReedemUnAccount = soonReedemUnAccount;
	}

	public long getRepeatRedeemNum() {
		return repeatRedeemNum;
	}

	public void setRepeatRedeemNum(long repeatRedeemNum) {
		this.repeatRedeemNum = repeatRedeemNum;
	}

	public long getRepeatPurchaseNum() {
		return repeatPurchaseNum;
	}

	public void setRepeatPurchaseNum(long repeatPurchaseNum) {
		this.repeatPurchaseNum = repeatPurchaseNum;
	}

	public long getPayAmtUnMatch() {
		return payAmtUnMatch;
	}

	public void setPayAmtUnMatch(long payAmtUnMatch) {
		this.payAmtUnMatch = payAmtUnMatch;
	}

	public long getPayCountUnMatchNum() {
		return payCountUnMatchNum;
	}

	public void setPayCountUnMatchNum(long payCountUnMatchNum) {
		this.payCountUnMatchNum = payCountUnMatchNum;
	}

	public long getLargeAmtRedeemNum() {
		return largeAmtRedeemNum;
	}

	public void setLargeAmtRedeemNum(long largeAmtRedeemNum) {
		this.largeAmtRedeemNum = largeAmtRedeemNum;
	}

	public float getPurchaseNotPayedNum() {
		return purchaseNotPayedNum;
	}

	public void setPurchaseNotPayedNum(float purchaseNotPayedNum) {
		this.purchaseNotPayedNum = purchaseNotPayedNum;
	}

	public long getOpenAccountFailedNum() {
		return openAccountFailedNum;
	}

	public void setOpenAccountFailedNum(long openAccountFailedNum) {
		this.openAccountFailedNum = openAccountFailedNum;
	}

	public long getPurchaseFailedNum() {
		return purchaseFailedNum;
	}

	public void setPurchaseFailedNum(long purchaseFailedNum) {
		this.purchaseFailedNum = purchaseFailedNum;
	}

	public long getRedeemTradeFailedNum() {
		return redeemTradeFailedNum;
	}

	public void setRedeemTradeFailedNum(long redeemTradeFailedNum) {
		this.redeemTradeFailedNum = redeemTradeFailedNum;
	}

	public long getSoonRedeemTradeFailedNum() {
		return soonRedeemTradeFailedNum;
	}

	public void setSoonRedeemTradeFailedNum(long soonRedeemTradeFailedNum) {
		this.soonRedeemTradeFailedNum = soonRedeemTradeFailedNum;
	}
	
	public float getIndexTwoTthreshold() {
		return indexTwoTthreshold;
	}

	public void setIndexTwoTthreshold(float indexTwoTthreshold) {
		this.indexTwoTthreshold = indexTwoTthreshold;
	}
}
