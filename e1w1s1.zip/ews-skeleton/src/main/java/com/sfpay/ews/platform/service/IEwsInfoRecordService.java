package com.sfpay.ews.platform.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsInfoRecord;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 
 *	类：预警信息记录表Service
 *	类描述：
 *
 * @author 544772
 * @version 2015年3月28日 下午1:33:51
 */

public interface IEwsInfoRecordService {
	
	/**
	 * 
	 * 方法：新增预警信息记录
	 * 方法说明：
	 *
	 * @param ewsIndexDef 预警指标
	 * @param warnContent 预警内容
	 * @param monitorDate 监控日期
	 * @param warnDate 预警异常日期
	 * @throws ServiceException 自定义异常
	 */
	public String addEwsInfoRecord(EwsIndexDef ewsIndexDef,String warnContent,Date monitorDate,Date warnDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：更新预警信息记录
	 * 方法说明：
	 *
	 * @param ewsInfoRecord 预警信息记录对象
	 * @throws ServiceException 自定义异常
	 */
	public void updateEwsInfoRecord(EwsInfoRecord ewsInfoRecord) throws ServiceException;
	
	/**
	 * 
	 * 方法:删除预警信息记录
	 * 方法说明：
	 *
	 * @param id 主键
	 * @throws ServiceException 自定义异常
	 */
	public void delEwsInfoRecord(String id) throws ServiceException;
	
	/**
	 * 
	 * 方法：根据主键查询预警信息记录
	 * 方法说明：
	 *
	 * @param id 主键
	 * @return 预警信息记录对象
	 */
	public EwsInfoRecord queryById(String id);
	
	/**
	 * 
	 * 方法：返回所有预警信息记录
	 * 方法说明：
	 *
	 * @return 预警信息记录对象集合
	 */
	public List<EwsInfoRecord> queryAll();
	
	/**
	 * 
	 * 方法：根据输入参数，查询预警信息记录
	 * 方法说明：
	 *
	 * @param ewsInfoRecord 预警信息记录对象
	 * @return 预警信息记录集合
	 */
	public List<EwsInfoRecord> queryEwsInfoRecordByParam(EwsInfoRecord ewsInfoRecord);
	
	/**
	 * 
	 * 方法：分页排序查询预警信息
	 * 方法说明：
	 *
	 * @param ewsInfoRecord 预警信息记录对象
	 * @param index 页索引
	 * @param size 页大小
	 * @return 分页预警信息
	 */
	public IPage<EwsInfoRecord> queryEwsHandleInfoByOrderPage(EwsInfoRecord ewsInfoRecord,int index, int size);
	
	/**
	 * 
	 * 方法：根据预警信息记录ID获取预警明细记录
	 * 方法说明：
	 *
	 * @param ewsInfoRecordId 预警信息记录ID
	 * @return 预警明细记录
	 */
	public Map<String, List<Map<String, Object>>> queryEwsDetailInfoByEwsInfoId(String ewsInfoRecordId);
}
