package com.sfpay.ews.service.param.sypay;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 顺手付调度执行服务
 * @author 627247
 * 2014-06-18
 */
public interface IWarnCallSypayRuleService extends IWarnCallDayRuleService {

	/**
	 * 指标一调度服务
	 */
	public void timeToWarnCallIndexOneRule();
	
	/**
	 * 顺手付红包指标7、8调度服务
	 */
	public void timeToWarnCallIndexSevenEightRule();
	/**
	 * 顺手付红包指标9、10、11、12调度服务
	 */
	public void timeToWarnCallRedBagDayRule();
	
	/**
	 * 指标一天调度一次
	 */
	public void timeToWarnCallDayOnceRule();
	
	/**
	 * 指标一周调度一次
	 */
	public void timeToWarnCallWeekOnceRule();


	/**
	 * 指标SFPR0033的调度
	 */
	public void invokeSypayRandomHourJob();
	
	/**
	 * 指标八点调度
	 */
	public void invokeSypayDayOnceEightJob();
	
	/**
	 * 指标九点调度
	 */
	public void invokeSypayDayOnceNineJob();
	
	/**
	 * 指标10分钟调度一次
	 */
	public void invokeSypayDayMinsJob();
	
}
