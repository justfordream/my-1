package com.sfpay.ews.service;

import java.util.List;

import com.sfpay.ews.dto.WarnGroupVsEmpDTO;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 预警通知接口
 * 
 * @author 321566
 *
 */
public interface IWarnGroupEmpService {
	
	/**
	 * 插入预警通知记录
	 * @param emp
	 * @return
	 */
	public void saveorUpdateWarnGroupEmp(WarnGroupVsEmpDTO emp) throws ServiceException;
	
	/**
	 * 分页查询预警记录
	 * @param emp
	 * @param index
	 * @param size
	 * @return
	 */
	public IPage<WarnGroupVsEmpDTO> queryGroupEmpByPage(WarnGroupVsEmpDTO emp,int index,int size) throws ServiceException;
	
	/**
	 * 根据工号查询预警记录
	 * @param empId
	 * @return
	 * @throws ServiceException
	 */
	public WarnGroupVsEmpDTO queryGroupEmpByEmpId(String empId) throws ServiceException;
	
	/**
	 * 根据指标代码找出对应的有效人员;
	 * @param indexNo 指标代码
	 * @return
	 * @throws ServiceException
	 */
	public List<WarnGroupVsEmpDTO> queryNotifyEmpByIndexNo(String indexNo)  throws ServiceException;

}
