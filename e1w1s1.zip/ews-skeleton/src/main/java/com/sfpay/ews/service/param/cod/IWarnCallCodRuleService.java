package com.sfpay.ews.service.param.cod;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

public interface IWarnCallCodRuleService extends IWarnCallDayRuleService {
	/**
	 * 什么也不做;
	 */
}
