package com.sfpay.ews.dto;

import java.util.Date;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:35:32
 */
public class WarnSuspectedUserDTO {
	/**
	 * 会员号
	 */
	private String oppositeMemberNo;
	
	/**
	 * 绑定银行卡手机号
	 */
	private String bankMobile;
	
	/**
	 * 会员名称
	 */
	private String oppositeMemberName;
	
	/**
	 * 交易流水号
	 */
	private String payBusinessNo;
	
	/**
	 * 赎回金额
	 */
	private String amount;
	
	/**
	 * 赎回时间
	 */
	private Date beginTime;
	
	/**
	 * 赎回银行卡号
	 */
	private String bankAccountNo;

	public String getOppositeMemberNo() {
		return oppositeMemberNo;
	}

	public void setOppositeMemberNo(String oppositeMemberNo) {
		this.oppositeMemberNo = oppositeMemberNo;
	}

	public String getBankMobile() {
		return bankMobile;
	}

	public void setBankMobile(String bankMobile) {
		this.bankMobile = bankMobile;
	}

	public String getOppositeMemberName() {
		return oppositeMemberName;
	}

	public void setOppositeMemberName(String oppositeMemberName) {
		this.oppositeMemberName = oppositeMemberName;
	}

	public String getPayBusinessNo() {
		return payBusinessNo;
	}

	public void setPayBusinessNo(String payBusinessNo) {
		this.payBusinessNo = payBusinessNo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}



	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	
}
