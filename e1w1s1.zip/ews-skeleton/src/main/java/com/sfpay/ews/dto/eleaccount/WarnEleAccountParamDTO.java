package com.sfpay.ews.dto.eleaccount;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:35:58
 */
public class WarnEleAccountParamDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 交易进行中的记录数
	 */
	private long tradingNum;
	
	/**
	 * 某段时间的交易总数
	 */
	private long tradeAllNum;
	
	/**
	 * 某段时间的交易成功总数
	 */
	private long tradeSucNum;
	
	/**
	 * 某段时间内的交易失败率的阀值;
	 */
	private float failThreshold;
	

	public float getFailThreshold() {
		return failThreshold;
	}

	public void setFailThreshold(float failThreshold) {
		this.failThreshold = failThreshold;
	}
		
	public long getTradingNum() {
		return tradingNum;
	}

	public void setTradingNum(long tradingNum) {
		this.tradingNum = tradingNum;
	}

	public long getTradeAllNum() {
		return tradeAllNum;
	}

	public void setTradeAllNum(long tradeAllNum) {
		this.tradeAllNum = tradeAllNum;
	}

	public long getTradeSucNum() {
		return tradeSucNum;
	}

	public void setTradeSucNum(long tradeSucNum) {
		this.tradeSucNum = tradeSucNum;
	}

	

}
