package com.sfpay.ews.service;

/**
 * 预警系统的定时任务调度
 * @author 575740
 *
 */

public interface IEwsTimeJobService {
	
	/**
	 * 调用COD的定时任务;
	 */
	public void invokeCodTimeJob();
	
	/**
	 * 调用营销的定时任务;
	 */
	public void invokeMarketTimeJob();
	
	/**
	 * 调用运单的定时任务;
	 */
	public void invokeWayBillTimeJob();
	
	/**
	 * 调用ACQ的定时任务;
	 */
	public void invokeAcqTimeJob();
	
	/**
	 * 调用银企B2C的定时任务;
	 */
	public void invokeBtocTimeJob();
	
	/**
	 * 调用手机支付的定时任务;
	 */
	public void invokeMpayTimeJob();
	
	/**
	 * 储值卡调度(一天一次)
	 */
	public void invokeStoredCardOnceTimeJob();
	
	/**
	 * 储值卡调度(一天多次)
	 */
	public void invokeStoredCardManyTimeJob();
	
	/**
	 * 储值卡调度(30分钟一次)
	 */
	public void invokeStoredCardMinTimeJob();
	
	
	/**
	 * 调用电子账户的定时任务(10分钟一次);
	 */
	public void invokeEleAccountTimeJob();	
	
	/**
	 * 调用核心订单的定时任务(10分钟一次);
	 */
	public void invokeTradeOrderMinJob();
	
	/**
	 * 调用核心订单的定时任务(一天一次);
	 */
	public void invokeTradeOrderDayJob();
	
	/**
	 * 调用核心订单的定时任务(指定时间30分钟);
	 */
	public void invokeTradeOrderOverTimeJob();
	
	/**
	 * 调用核心账户的定时任务(10分钟一次);
	 */
	public void invokeCoreAccountTimeJob();
	
	/**
	 * 以下是监控系统四期的资料; 
	 */
	
	/**
	 * 调用Pas 每天的任务 (13:00);
	 */
	public void invokePasDayJob();
	
	/**
	 * 调用Pas  每小时的任务(0~24);
	 */
	public void invokePasHourJob();
	
	/**
	 * 调用Pas  约定时间 的任务（8:30）;
	 */
	public void invokePasAgreeTimeJob();
	
	/**
	 * 调用Pas  两小时调度一次，每日的9/11/13/15/17点执行
	 */
	public void invokePasTwoHourJob();
	
	/**
	 * 调用Pas  每天两次，每日的09:00 和 15:00执行
	 */
	public void invokePasTwiceJob();
	
	
	//20141201版本新增PAS指标调度
	/**
	 * 调用Pas  约定时间 的任务（10:00）;
	 */
	public void invokePasAgreeTimeJob1();
	/**
	 * 调用Pas  约定时间 的任务（14:00）;
	 */
	public void invokePasAgreeTimeJob2();
	/**
	 * 调用Pas  约定时间 的任务（17:00）;
	 */
	public void invokePasAgreeTimeJob3();
	/**
	 * 调用Pas  约定时间 的任务（11:00）;
	 */
	public void invokePasAgreeTimeJob4();
	/**
	 * 调用Pas  约定时间 的任务（15:00）;
	 */
	public void invokePasAgreeTimeJob5();
	/**
	 * 调用Pas  约定时间 的任务（15:00、16:00、17:00、18:00）;
	 */
	public void invokePasAgreeTimeJob6();
	
	/**
	 * add by yurongjie 2014-12-16 PAS新增调度任务：每天的16:00,监控垫付和CBIL对账异常
	 */
	public void invokePasAgreeTimeJob7();
	
	/**
	 * add by yurongjie 2014-12-23 PAS新增调度任务：每天的11:30,监控是否有异常的未见回单记录
	 */
	public void invokePasAgreeTimeJob8();
	
	/**
	 * 调用ACQ系统 每小时的任务 (0~24);
	 */
	public void invokeAcqHourJob();
	
	/**
	 * 调用ACQ系统 银企ACQ按照分钟调度（2分钟一次）
	 */
	public void invokeAcqMinuteJob();
	
	/**
	 * 调用FMS系统  每天的任务 (23:00);
	 */
	public void invokeFmsDayJob();
	
	/**
	 * 调用SYPAY系统  每天约定时间 的任务（18:00）;
	 */
	public void invokeSypayAgreeTimeJob();
	
	/**
	 * 调用SYPAY红包系统 每4个小时的任务 (08:00~16:00);
	 */
	public void invokeSypayRedBagFourHourJob();
	/**
	 * 调用SYPAY红包系统 每天一次的任务 (上午08:40);
	 */
	public void invokeSypayRedBagDayJob();
	
	/**
	 * 调用DEBIT系统  每天的任务 (10:00~24:00);
	 */
	public void invokeDebitDayJob();
	
	/**
	 * 调用DEBIT系统 每天一次的调度(21:00)
	 */
	public void invokeDebitOnceJob();
	/**
	 * 调用DEBIT系统 每一个小时一次的调度(10：24:00)
	 */
	public void invokeDebitOneHourJob();
	/**
	 * 调用Sfgom系统  每天的任务 (08:30);
	 */
	public void invokeSfgomDayJob();
	
	/**
	 * 调用Debit系统 每4小时一次的调度(00:00—24:00)
	 */
	public void invokeDebitFourHourJob();
	
	/**
	 * 调用Debit系统 每6小时一次的调度(08:00—24:00)
	 */
	public void invokeDebitSixHourJob();
	
	/**
	 * 调用LCPT系统 每小时一次的调度(00:00-24:00)
	 */
	public void invokeLcptHourJob();
	
	/**
	 * 调用LCPT系统 每天的任务(02:00)
	 */
	public void invokeLcptAgreeTimeJob();
	
	/**
	 * 调用ISS系统 每天2次的调度（1:00,13:00）
	 */
	public void invokeIssDayJob();
	
	/**
	 * 调用SYPAY系统 每小时的任务 (0~24);
	 */
	public void invokeSypayHourJob();
	
	/**
	 * 调用SYPAY系统每天的任务
	 */
	public void invokeSypayDayJob();
	
	/**
	 * 调用SYPAY系统每周的任务
	 */
	public void invokeSypayWeekJob();
	
	/**
	 * 调用SYPAY系统每天9点、11点、14点的任务
	 */
	public void invokeSypayRandomHourJob();
	
	/**
	 * 调用SYPAY系统每天8点调度一次
	 */
	public void invokeSypayDayOnceEightJob();
	
	/**
	 * 调用SYPAY系统每天9点调度一次
	 */
	public void invokeSypayDayOnceNineJob();
	
	/**
	 * 调用SYPAY系统每10分钟调度一次
	 */
	public void invokeSypayDayMinsJob(); 
}
