package com.sfpay.ews.service.param.tradeorder;

import com.sfpay.ews.dto.tradeorder.WarnTradeOrderPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 核心订单系统的指标参数服务 接口
 * @author 575740
 * 2014-05-23
 */
public interface IWarnGetTradeOrderParamService {
	/**
	 * 查询储值卡中某段时间内的交易总数
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getTradeAllNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 查询储值卡中某段时间内的交易成功总数
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */ 
	public long getTradeSucNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 消费，转账，提现等交易超过设置时间30分钟未成功的记录
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getTradeOverTimeNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * O2A对账中账目不平的记录数
	 * @param qryBeginTime --当日的:00:00
	 * @param qryEndTime 当日的:17:30
	 * @param qryEndTimeMore 当日的:17:35
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getTradeOtoAccountNum(String qryBeginTime, String qryEndTime, String qryEndTimeMore) throws ServiceException;
	
	/**
	 * 查询储值卡中某段时间内的交易数量为0的记录
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getTradeZeroNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * O2B对账中账目不平的记录数
	 * @param qryBeginTime --当日的:00:00
	 * @param qryEndTime --当日的:17:30
	 * @param qryEndTimeMore --当日的:17:35
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getTradeOtoBillNum(String qryBeginTime,String qryEndTime, String qryEndTimeMore) throws ServiceException;
	
	/**
	 * 根据ID查询一笔资料;
	 * @param id ID
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTradeOrderPageDTO getTradeOrderById(Long id) throws ServiceException;
	
		
	/**
	 * 批量保存某个时间段内未成功的记录数;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param warnNo 告警编号
	 * @param expExpLain	告警说明;
	 * @param warnTradeOrderRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchUnSuccess(String qryBeginTime,String qryEndTime,String warnNo,String expExpLain,String warnTradeOrderRule,long paramRowNum) throws ServiceException;


	/**
	 * 批量保存某个时间段内 消费，转账，提现等交易超过设置时间30分钟未成功的记录数明细
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param warnNo 告警编号
	 * @param expExpLain	告警说明;
	 * @param warnStoredCardRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchOverTimeData(String qryBeginTime,String qryEndTime,String warnNo,String expExpLain,String warnTradeOrderRule,long paramRowNum) throws ServiceException;

	/**
	 * 批量保存O2A某个时间段内未匹配的记录明细;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param qryEndTimeMore 结束时间多一些时间
	 * @param warnNo 告警编号
	 * @param expExpLain	告警说明;
	 * @param warnTradeOrderRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchOtoaUnMatching(String qryBeginTime,String qryEndTime,String qryEndTimeMore,String warnNo,String expExpLain,String warnTradeOrderRule,long paramRowNum) throws ServiceException;

	/**
	 * 批量保存O2B某个时间段内未匹配的记录明细;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param qryEndTimeMore 结束时间多一些时间
	 * @param warnNo 告警编号
	 * @param expExpLain	告警说明;
	 * @param warnTradeOrderRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchOtobUnMatching(String qryBeginTime,String qryEndTime,String qryEndTimeMore,String warnNo,String expExpLain,String warnTradeOrderRule,long paramRowNum) throws ServiceException;

}
