/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：告警来源表
 * 
 * 类描述：告警来源表
 * 
 * @author 625288
 * 
 *         2015-3-4
 */
public class EwsWarnSource extends BaseEntity {
	private static final long serialVersionUID = 4031639904653191850L;
	// 预警来源
	private String warnSource;
	// DROOLS服务URL
	private String droolsWsUrl;
	// 备注
	private String remark;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public String getDroolsWsUrl() {
		return droolsWsUrl;
	}

	public void setDroolsWsUrl(String droolsWsUrl) {
		this.droolsWsUrl = droolsWsUrl;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
