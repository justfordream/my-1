package com.sfpay.ews.dto;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 预警资料的明细，存储个系统的业务编号，以及违反的原因。
 * 各系统预警明细的资料，查询时需要继承该类
 * @author 575740
 *
 */
public class WarnOnePageDetailDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 预警编号，与主表关联
	 */
	private String warnNo;
	
	/**
	 * 明细的预警编号
	 */	
	private String detailNo;
	
	/**
	 * 预警的各系统的业务ID;非常重要
	 */
	private String bussId;
	
	/**
	 * 预警的各系统的资料发生异常时间
	 */
	private Date expTime;
	
	/**
	 * 预警的说明，记录该单号当时的状态;
	 */
	private String expExplain;
	
	/**
	 * 资料创建时间;
	 */
	private Date createTime;
	
	/**
	 * 备注
	 */
	private String remark;

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getWarnNo() {
		return warnNo;
	}

	public void setWarnNo(String warnNo) {
		this.warnNo = warnNo;
	}

	public String getDetailNo() {
		return detailNo;
	}

	public void setDetailNo(String detailNo) {
		this.detailNo = detailNo;
	}

	public String getBussId() {
		return bussId;
	}

	public void setBussId(String bussId) {
		this.bussId = bussId;
	}

	public Date getExpTime() {
		return expTime;
	}

	public void setExpTime(Date expTime) {
		this.expTime = expTime;
	}

	public String getExpExplain() {
		return expExplain;
	}

	public void setExpExplain(String expExplain) {
		this.expExplain = expExplain;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	
}
