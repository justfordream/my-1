package com.sfpay.ews.dto.sypay;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 顺手付系统的页面显示
 * @author 627247
 * 2014-06-20
 */
public class WarnSypayPageDTO extends WarnOnePageDetailDTO {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 支付业务流水号
	 */
	private String payBusinessNo;
	
	/**
	 * 对应核心会员系统中会员编号
	 */
	private Long memberNo;
	
	/**
	 * 会员号 取商户信息中的会员号
	 */
	private Long merchantMemberNo;
	
	/**
	 * RECHARE(充值), DIRECT_PAY(即时支付), ANONY_NETBANK_PAY(网银支付), PREAUTHPAY(预扣款), CONFIRM_PREAUTHPAY(预扣款确认), CANCEL_PREAUTHPAY(预扣款撤销), TRANSFER(转账), WITHDRAW(提现), VERIFICATION(打款验证), NETBANK_PAY_REFUND(网银支付退款), BALANCE_PAY_REFUND(余额支付退款), PREAUTHPAY_REFUND(预扣款退款)
	 */
	private String businessType;
	
	/**
	 * 交易金额
	 */
	private Long amount;
	
	/**
	 * 币种 
	 */
	private String ccy;
	
	/**
	 * 状态: INIT未支付、TRADING交易进行中、SUCCESS成功、FAILURE失败
	 */
	private String status;
	
	/**
	 * 交易开始时间
	 */
	private String beginTime;
	
	/**
	 * 交易结束时间
	 */
	private String endTime;

	public String getPayBusinessNo() {
		return payBusinessNo;
	}

	public void setPayBusinessNo(String payBusinessNo) {
		this.payBusinessNo = payBusinessNo;
	}

	public Long getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(Long memberNo) {
		this.memberNo = memberNo;
	}

	public Long getMerchantMemberNo() {
		return merchantMemberNo;
	}

	public void setMerchantMemberNo(Long merchantMemberNo) {
		this.merchantMemberNo = merchantMemberNo;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
