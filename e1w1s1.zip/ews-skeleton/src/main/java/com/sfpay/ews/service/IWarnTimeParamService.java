package com.sfpay.ews.service;

import com.sfpay.ews.dto.WarnTimeParamDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 应用在查询某个时间范围内部的开始时间和结束时间；
 * @author 575740
 * 2014-05-26
 */
public interface IWarnTimeParamService {
	/**
	 * 
	 * @param qryDate 查询的某个日期
	 * @param scopeMinute  查询某个时间范围，与当前时间的分秒比较; 返回如：18:18:00
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO  getSomeMinuteBeforeCurrent(String qryDate, float scopeMinute) throws ServiceException;
	
	/**
	 * 
	 * @param qryDate 查询的某个日期
	 * @param scopeMinute 查询某个时间范围，与当前时间的分秒比较;
	 * @param endMinute 截止与当前时间几分钟的数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO  getSomeMinuteVsEndBeforeCurrent(String qryDate, float scopeMinute, float endMinute)  throws ServiceException;
	
	/**
	 * 根据参数组合获取查询时间范围，将赋值qryDate、endTime、endTimeMore
	 * @param qryDate 查询日期
	 * @param endTime qryDate结束的时间
	 * @param endTimeMore qryDate结束时间多一点的时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO  getTimeScopeWithMore(String qryDate, String endTime, String endTimeMore)  throws ServiceException;
	
	/**
	 *  
	 * @param qryDate 查询的某个日期 如 2014-6-10 00:00:00
	 * @param endMinute 截止与当前时间几分钟的数量;
	 * @return  返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO getTimeDateVsEndByMinute(String qryDate, float endMinute) throws ServiceException;
	
	/**
	 * 
	 * @param qryDate 查询的某个日期 如 2014-6-10 00:00:00
	 * @param beginTime 参数
	 * @param endMinute 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO getTimeDateBeforeCurrent(String qryDate, String beginTime, float endMinute) throws ServiceException;
	
	/**
	 * 查询的某个日期beginTime小时之前到endTime小时之前的资料
	 * @param qryDate 参数
	 * @param beginTime 参数
	 * @param endTime 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO getSomeHourVsBeforeCurrent(String qryDate, float beginTime, float endTime) throws ServiceException;
	
	/**
	 * 查询的某个日期beginTime到endTime之间的资料
	 * @param qryDate 参数
	 * @param beginTime 参数
	 * @param endTime 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO getSomeTimeBeforeCurrent(String qryDate, String paramTime, String beginTime, String endTime) throws ServiceException;
	
	/**
	 * 
	 * 方法：
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @param paramTime 参数
	 * @param beginTime 参数
	 * @param endTime  参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnTimeParamDTO getSomeTimeHourBeforeCurrent(String qryDate, String paramTime, String beginTime, String endTime) throws ServiceException;
	
	/**
	 * 每天一小时调度一次
	 * @return 返回值 
	 */
	public String getOneHourBeforeCurrent();
	
	/**
	 * 每天调度一次
	 * @return 返回值
	 */
	public String getOneDayBeforeCurrent();
	
	/**
	 * 每周调度一次，星期一早上2点调度
	 * @return 返回值
	 */
	public String getOneWeekBeforeCurrent();
	
	
}
