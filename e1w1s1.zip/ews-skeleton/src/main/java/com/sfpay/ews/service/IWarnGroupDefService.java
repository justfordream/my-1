package com.sfpay.ews.service;

import java.util.List;

import com.sfpay.ews.dto.WarnGroupDefDTO;
import com.sfpay.ews.dto.WarnGroupVsIndexDTO;
import com.sfpay.ews.dto.WarnIndexDefDTO;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 群组管理接口
 * 
 * @author 321566 张泽豪
 *
 * 2014-4-21 下午12:29:42
 */
public interface IWarnGroupDefService {
	
	/**
	 * 新增或者修改一个群组记录
	 * @param defDTO
	 * @throws ServiceException 自定义异常
	 */
	public void saveOrUpdateWarnGroupDef(WarnGroupDefDTO defDTO) throws ServiceException;
	
	/**
	 * 分页查询群组
	 * @param defDTO 群组对象
	 * @param index 页索引
	 * @param size 页大小
	 * @return 分页数据
	 * @throws ServiceException 自定义异常
	 */
	public IPage<WarnGroupDefDTO> queryWarnGroupDefByPage(WarnGroupDefDTO defDTO,int index,int size) throws ServiceException;
	
	/**
	 * 根据群组编号查询群组记录
	 * @param groupNo 群组编号
	 * @return 返回记录
	 * @throws ServiceException 自定义异常
	 */
	public WarnGroupDefDTO queryWarnGroupDefByGroupNo(String groupNo) throws ServiceException;
	
	/**
	 * 
	 * 方法：新增群组和指标的关联
	 * 方法说明：
	 *
	 * @param groupNo 群组编号
	 * @param groupIndexDTOs 群组指标实体
	 * @throws ServiceException 自定义异常
	 */
	public void saveWarnGroupVsIndex(String groupNo,List<WarnGroupVsIndexDTO> groupIndexDTOs) throws ServiceException;
	
	/**
	 * 查询所有群组记录
	 * @return 返回记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnGroupDefDTO> querytAllWarnGroupDef() throws ServiceException;
	
	/**
	 * 根据群组编号查询已授权指标
	 * @param groupNo 群组编号
	 * @return 返回记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnIndexDefDTO> queryAuthIndexByGroupNo(String groupNo) throws ServiceException;
	
	/**
	 * 根据群组编号查询未授权指标
	 * @param groupNo 群组编号
	 * @return 返回记录
	 * @throws ServiceException 自定义异常
	 */
	public List<WarnIndexDefDTO> queryUnAuthIndexByGroupNo(String groupNo) throws ServiceException;
	
	
}
