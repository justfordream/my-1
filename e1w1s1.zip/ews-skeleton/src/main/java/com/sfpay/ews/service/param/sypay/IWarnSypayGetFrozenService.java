package com.sfpay.ews.service.param.sypay;

import java.util.List;

import com.sfpay.ews.dto.sypay.WarnSypayFrozenDTO;
/**
 * 
 *	接口：指标SFPR0043~SFPR0049的数据读取
 *	接口描述：
 *
 * @author 544772
 * @version 2015年4月17日 下午2:06:31
 */
public interface IWarnSypayGetFrozenService {

	/**
	 * 
	 * 方法：SFPR0043 注册手机号与银行卡预留手机号不一致，未冻结账户中近【3】天转账（转出，包含发红包）次数累计达到【4】次且转账总额大于等于【600】（剔除理财,排除内部员工）
	 * 方法说明：
	 *
	 * @param paramTime 时间跨度，单位为天
	 * @param tmParam 次数阀值
	 * @param amtParam 金额阀值，单位为分
	 * @return 预警冻结对象
	 */
	public List<WarnSypayFrozenDTO> getTeleNotEqualAmountOver(String paramTime,String tmParam,String amtParam);
	
	/**
	 * 
	 * 方法：SFPR0044 注册手机号与银行卡预留手机号一致，未冻结账户中近【3】天转账（转出，包含发红包）次数累计达到【5】次且转账总额大于等于【800】（剔除理财） 
	 * 方法说明：
	 *
	 * @param paramTime 时间跨度，单位为天
	 * @param tmParam 次数阀值
	 * @param amtParam 金额阀值，单位为元
	 * @return 预警冻结对象
	 */
	public List<WarnSypayFrozenDTO> getTeleEqualAmountOver(String paramTime,String tmParam,String amtParam);
	
	/**
	 * 
	 * 方法：SFPR0045 注册手机号与银行卡预留手机号不一致，未冻结账户中存量客户中近【3】天转账（转入，包含收红包）次数累计【4】次且转入总金额大于等于【600】（剔除理财,排除内部员工）
	 * 方法说明：
	 *
	 * @param paramTime 时间跨度，单位为天
	 * @param tmParam 次数阀值
	 * @param amtParam 金额阀值，单位为元
	 * @return  预警冻结对象
	 */
	public List<WarnSypayFrozenDTO> getTeleNotEqualAmountOverStockConsum(String paramTime,String tmParam,String amtParam);
	
	/**
	 * 
	 * 方法：SFPR0046 注册手机号与银行卡预留手机号一致，未冻结账户中存量客户中近【3】天转账（转入，包含收红包）次数累计【5】次且转入总金额大于等于【800】（剔除理财,排除内部员工）
	 * 方法说明：
	 *
	 * @param paramTime 时间跨度，单位为天
	 * @param tmParam 次数阀值
	 * @param amtParam 金额阀值，单位为分
	 * @return 预警冻结对象
	 */
	public List<WarnSypayFrozenDTO> getTeleEqualAmountOverStockConsum(String paramTime,String tmParam,String amtParam );
	/**
	 * 
	 * 方法：SFPR0047 未冻结账户中，近【3】天充话费次数【4】次且话费充值总额大于【240】元。（排除顺丰金充话费，排除内部员工）
	 * 方法说明：
	 *
	 * @param paramTime 时间跨度，单位为天 
	 * @param tmParam 次数阀值
	 * @param amtParam 金额阀值，单位为分
	 * @return 预警冻结对象
	 */
	public List<WarnSypayFrozenDTO> getPayPhoneBillOver(String paramTime,String tmParam,String amtParam);
	
	/**
	 * 
	 * 方法：SFPR0048 优选购物单笔金额大于等于【1000】元，脚本需要提供交易时间。排除内部员工
	 * 方法说明：
	 *
	 * @param paramTimeMins 时间跨度，单位为分钟
	 * @param amtParam 金额阀值，单位为分
	 * @return 预警冻结对象
	 */
	public List<WarnSypayFrozenDTO> getPaySfbuyBillOver(String paramTimeMins,String amtParam);
	/**
	 * 
	 * 方法：SFPR0049 优选购物【12】个小时交易金额大于等于【1000】元，脚本需要提供交易时间
	 * 方法说明：
	 *
	 * @param paramTimeHours 时间跨度，单位为小时
	 * @param amtParam 金额阀值，单位为分
	 * @return 预警冻结对象
	 */
	public List<WarnSypayFrozenDTO> getPaySfbuyTotalBillOver(String paramTimeHours,String amtParam);

	
	
}
