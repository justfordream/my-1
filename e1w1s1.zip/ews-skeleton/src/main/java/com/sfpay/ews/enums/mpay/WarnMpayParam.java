package com.sfpay.ews.enums.mpay;

/**
 * 手机支付的参数;
 * @author 575740
 *
 */
public enum WarnMpayParam {
	/**
	 * A1:一段时间交易收单的记录
	 */
	MPAYALLNUM,
	/**
	 * A2: 一段时间交易收单成功的记录
	 */
	MPAYSUCCESSNUM
}
