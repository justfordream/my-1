package com.sfpay.ews.service.param.coreaccount;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 核心账户系统预警的参数获取;
 * @author 575740
 * 2014-05-23
 */
public interface IWarnGetCoreAccountParamService {

	/**
	 * 查询一个工作时间内没有账户流水号的记录数
	 * @param qryDate 查询的开始时间
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return
	 * @throws ServiceException
	 */
	public long getAccountZeroNum(String qryDate,String qryBeginTime,String qryEndTime) throws ServiceException;
		
}
