package com.sfpay.ews.service.param.iss;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 理赔统付（ISS）预警监测任务调度；
 * @author 700316
 * 2014-12-31
 */
public interface IWarnCallIssRuleService extends IWarnCallDayRuleService {
	
}
