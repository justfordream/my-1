package com.sfpay.ews.service;

import java.util.Map;

import com.sfpay.ews.dto.WarnIndexDefDTO;
import com.sfpay.ews.dto.WarnOnePageDTO;
import com.sfpay.ews.dto.WarnOnePageQryDTO;
import com.sfpay.ews.dto.WarnOnePageDetailDTO;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月16日 上午10:31:59
 */
public interface IWarnOnePageService {
	
	/**
	 * 方法说明：监控预警OnePage页面
	 * 不查询明细资料，只把MS的数据
	 * @param onepageqry 参数
	 * @param index 参数
	 * @param size 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public IPage<WarnOnePageDTO> queryWarnMsData(WarnOnePageQryDTO onepageqry, int index, int size) throws ServiceException;
	
	/**
	 * 仅查询MS的信息;
	 * @param warnNo 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnOnePageDTO queryMsDataOnlyByWarnNo(String warnNo) throws ServiceException;
	
	/**
	 * 方法说明:点页面中一个告警编号，查看该告警编号的明细时候;
	 * 因此，如果明细过多，也是查询明细的前20笔记录;
	 * @return  返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnOnePageDTO queryMsDataByWarnNo(String warnNo) throws ServiceException;
	
	/**
	 * 根据一个违反规则查找业务明细的资料;
	 * 查询某个业务明细的资料;
	 * @param warnSource 参数
	 * @param warnNo  参数
	 * @param index 参数
	 * @param size 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public IPage<WarnOnePageDetailDTO> queryWarnSystemDetailById(String warnSource,String warnNo, int index, int size) throws ServiceException;
	
	/**
	 * 
	 * 方法：保存一个规则与这个规则的明细资料；这里的明细是所有的资料;返回一个保存的预警编号;
	 * 方法说明：
	 *
	 * @param warnOnePageDTO 参数对象
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public String saveWarnMsAndTbData(WarnOnePageDTO warnOnePageDTO) throws ServiceException;
	
	/**
	 * 更改一个告警编号的处理意见;
	 * @param warnNo 告警编号
	 * @param DealResult 处理意见
	 * @param EmpId 操作人员;
	 * @throws ServiceException 自定义异常
	 */
	public void updateWarnMsDealResult(String warnNo,String dealResult,String empId)  throws ServiceException;
	
	
	/**
	 * 将某个编号的资料设置不显示;
	 * @param warnNo 参数
	 * @param isDealing 是否删除，N 未删除  Y 删除，不显示
	 * @param EmpId 参数
	 * @throws ServiceException 自定义异常
	 */
	public void dealWarnDataNgShow(String warnNo,String isDealing,String empId)  throws ServiceException;
	
	/**
	 * 根据Drools返回的指标，与指标说明，保存一个告警主表的资料;
	 * @param warnIndexDefDTO 指标对应的资料;
	 * @param droolsRltMsg 参数
	 * @param qryDate 参数
	 * @param warnIndexDefMap  保存指标代码对应的DTO，传入参数;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public String saveWarnMsOnlyByDroolsCode(WarnIndexDefDTO warnIndexDefDTO,String droolsRltMsg,String qryDate,Map<String,WarnIndexDefDTO> warnIndexDefMap) throws ServiceException;
	
}
