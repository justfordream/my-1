package com.sfpay.ews.dto.cod;

import java.util.Date;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * COD预警监测的资料，在明细中显示；
 * @author 575740
 * 
 */
public class WarnCodPageDTO  extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * COD账单编号
	 */
	private String codBillNo;
	
	/**
	 * 付款金额
	 */
	private Long payAmt;
	
	/**
	 * 汇款方式：银企直连：BANK_DIRECT
	 */
	private String payMethod;
	
	/**
	 * 付款申请时间
	 */
	private Date payApplyTime;
	
	/**
	 * 付款申请人：人工操作为：操作人员工号，系统生成为：SYS
	 */
	private String payApplyPerson;
 
    /**
     * 支付状态：付款中(PAYING),成功(SUCCESS),失败(FAIL)
     */
    private String payStatus;
    
    /**
     * 付款申请单号
     */
    private String payApplyOrderNo;
    
    /**
     * 要求付款日
     */
    private Date claimPayTime;
    
    /**
     * 创建时间
     */
    private Date createdTime;
    
    /**
     * 外部交易业务唯一订单号(
     */
    private String outBussinessNo;

	public String getOutBussinessNo() {
		return outBussinessNo;
	}

	public void setOutBussinessNo(String outBussinessNo) {
		this.outBussinessNo = outBussinessNo;
	}

	public String getCodBillNo() {
		return codBillNo;
	}

	public void setCodBillNo(String codBillNo) {
		this.codBillNo = codBillNo;
	}

	public Long getPayAmt() {
		return payAmt;
	}

	public void setPayAmt(Long payAmt) {
		this.payAmt = payAmt;
	}

	public String getPayMethod() {
		return payMethod;
	}

	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}

	public Date getPayApplyTime() {
		return payApplyTime;
	}

	public void setPayApplyTime(Date payApplyTime) {
		this.payApplyTime = payApplyTime;
	}

	public String getPayApplyPerson() {
		return payApplyPerson;
	}

	public void setPayApplyPerson(String payApplyPerson) {
		this.payApplyPerson = payApplyPerson;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getPayApplyOrderNo() {
		return payApplyOrderNo;
	}

	public void setPayApplyOrderNo(String payApplyOrderNo) {
		this.payApplyOrderNo = payApplyOrderNo;
	}

	public Date getClaimPayTime() {
		return claimPayTime;
	}

	public void setClaimPayTime(Date claimPayTime) {
		this.claimPayTime = claimPayTime;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	} 
	
	

}
