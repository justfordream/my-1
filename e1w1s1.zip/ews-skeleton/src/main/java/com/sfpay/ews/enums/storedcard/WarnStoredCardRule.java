package com.sfpay.ews.enums.storedcard;

/**
 * 储值卡系统的规则;
 * @author 575740
 * 2014-05-23
 */
public enum WarnStoredCardRule {
	/**
	 * 储值卡中交易状态为进行中的记录笔数 =< 5笔
	 */
	STOREDCARD0001,
	/**
	 * 储值卡中交易状态为进行中的记录笔数 >5笔
	 */
	STOREDCARD0002,
	/**
	 * 储值卡某段时间内的交易失败率
	 */
	STOREDCARD0003,
	/**
	 * 巴枪和订单之间通讯异常
	 */
	STOREDCARD0004,
	/**
	 *  发送消费公款部分，每天判断WAYBILL_TO_BIL中TRANS_DATE在T-1数据=0的情况
	 */
	STOREDCARD0005
}
