package com.sfpay.ews.dto.sfgom;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 安心购系统的页面显示
 * @author 627247
 * 2014-06-20
 */
public class WarnSfgomPageDTO extends WarnOnePageDetailDTO {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 订单编号
	 */
	private String orderNo;
	
	/**
	 * 纠纷状态:01(等待卖家处理);02(卖家已处理);03(达成和解);04(退款退货);05(退款关闭);06（卖家申请和解，等待买家处理）
	 */
	private String status;
	
	/**
	 * 投诉类型:01(产品质量);02(和承诺不符);03(无理由退货);04(其它)
	 */
	private String complainType;
	
	/**
	 * 处理方式:01(退货退款);02(退款不退货);03(已协商解决)
	 */
	private String processMode;
	
	/**
	 * 会员编号
	 */
	private Long memberNo;
	
	/**
	 * 处理时间
	 */
	private String processDate;
	
	/**
	 * 纠纷金额
	 */
	private Long disputeAmount;
	
	/**
	 * 退货运单号
	 */
	private String returnLogisticsNo;
	
	/**
	 * 创建时间
	 */
	private String createDate;

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComplainType() {
		return complainType;
	}

	public void setComplainType(String complainType) {
		this.complainType = complainType;
	}

	public String getProcessMode() {
		return processMode;
	}

	public void setProcessMode(String processMode) {
		this.processMode = processMode;
	}

	public Long getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(Long memberNo) {
		this.memberNo = memberNo;
	}

	public Long getDisputeAmount() {
		return disputeAmount;
	}

	public void setDisputeAmount(Long disputeAmount) {
		this.disputeAmount = disputeAmount;
	}

	public String getReturnLogisticsNo() {
		return returnLogisticsNo;
	}

	public void setReturnLogisticsNo(String returnLogisticsNo) {
		this.returnLogisticsNo = returnLogisticsNo;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

}
