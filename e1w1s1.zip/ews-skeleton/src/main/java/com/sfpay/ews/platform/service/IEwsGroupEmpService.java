package com.sfpay.ews.platform.service;

import java.util.List;

import com.sfpay.ews.platform.domain.EwsGroupEmp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 预警通知接口
 * 
 * @author 321566
 *
 */
public interface IEwsGroupEmpService {
	
	/**
	 * 插入预警通知记录
	 * @param emp 预警通知记录对象
	 * @throws ServiceException 自定义异常
	 */
	public void addEwsGroupEmp(EwsGroupEmp emp) throws ServiceException;
	
	/**
	 * 更新预警通知记录
	 * @param emp 预警通知记录对象
	 * @throws ServiceException 自定义异常
	 */
	public void updateEwsGroupEmp(EwsGroupEmp emp) throws ServiceException;
	
	/**
	 * 分页查询预警记录
	 * @param emp 预警通知记录对象
	 * @param index 页索引
	 * @param size 页大小
	 * @return 分页预警记录
	 * @throws ServiceException 自定义异常
	 */
	public IPage<EwsGroupEmp> queryEwsGroupEmpByPage(EwsGroupEmp emp,int index,int size) throws ServiceException;
	
	/**
	 * 根据工号查询预警记录
	 * @param empId 工号
	 * @return 预警记录
	 * @throws ServiceException 自定义异常
	 */
	public EwsGroupEmp queryEwsGroupEmpByEmpId(String empId) throws ServiceException;
	
	/**
	 * 根据指标代码找出对应的有效人员;
	 * @param indexNo 指标代码
	 * @return 预警记录集合
	 * @throws ServiceException 自定义异常
	 */
	public List<EwsGroupEmp> queryNotifyEmpByIndexNo(String indexNo)  throws ServiceException;

}
