package com.sfpay.ews.enums;

public enum WarnProperty {
	/**
	 * 预警
	 */
	WARNING,
	
	/**
	 * 错误
	 */
	ERROR
}
