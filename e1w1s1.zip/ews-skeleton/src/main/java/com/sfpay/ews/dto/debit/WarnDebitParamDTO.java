package com.sfpay.ews.dto.debit;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 公款代扣指标参数
 * @author 627247
 * 2014-06-18
 */
public class WarnDebitParamDTO extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 指标一交易总数
	 */
	private long indexOneTradeAllNum;
	/**
	 * 指标一返回数
	 */
	private long indexOnesucReturnNum;
	/**
	 * 指标一阀值
	 */
	private float indexOneThreshold;
	
	/**
	 * 指标二交易总数
	 */
	private long indexTwoTradeAllNum;
	
	/**
	 * 指标三交易总数
	 */
	private long indexThreeTradeAllNum;
	/**
	 * 指标三交易失败数
	 */
	private long indexThreeUnSucNum;
	/**
	 * 指标三阀值
	 */
	private float indexThreeThreshold;
	
	/**
	 * 指标四交易总数
	 */
	private long indexFourTradeAllNum;
	/**
	 * 指标四异常数
	 */
	private long indexFourAbnormalNum;
	/**
	 * 指标四阀值
	 */
	private float indexFourThreshold;
	
	/**
	 * 资料来源异常数
	 */
	private long docSourceAbnormalNum;
	
	/**
	 * DEBIT0006发送总笔数
	 */
	private long indexSixTradeAllNum;
	
	/**
	 * DEBIT0006未返回笔数
	 */
	private long indexSixUnSucReturnNum;
	
	/**
	 * DEBIT0007发送总笔数
	 */
	private long indexSevenTradeAllNum;
	
	/**
	 * DEBIT0007未返回笔数
	 */
	private long indexSevenUnSucReturnNum;
	
	/**
	 * DEBIT0008发送总笔数
	 */
	private long indexEightTradeAllNum;
	
	/**
	 * DEBIT0008未返回笔数
	 */
	private long indexEightUnSucReturnNum;
	
	/**
	 * DEBIT0012未发送给通道的数据
	 */
	private long unSendingToChannelNum;
	
	/**
	 * DEBIT0013发送给快钱不成功数
	 */
	private long indexTHirUnSucSenToEasyMoneyNum;
	
	/**
	 * DEBIT0014发送给通联不成功数
	 */
	private long indexFourteenUnSucSenToTongLianNum;
		
	/**
	 * DEBIT0009发送总笔数
	 */
	private long indexNineTradeAllNum;
	
	/**
	 *  DEBIT0009未返回笔数
	 */
	private long indexNineUnSucReturnNum;
	
	/**
	 * DEBIT0010快钱通道扣款总数
	 */
	private long indexTenTradeAllNum;
	
	/**
	 * DEBIT0010快钱通道扣款失败数
	 */
	private long indexTenFailureNum;
	
	/**
	 * 指标DEBIT0010阀值
	 */
	private float indexTenThreshold;
	
	/**
	 * DEBIT0011通联通道扣款总数
	 */
	private long indexElevenTradeAllNum;
	
	/**
	 * DEBIT0011通联通道扣款失败数
	 */
	private long indexElevenFailureNum;
	
	/**
	 * 指标DEBIT0011阀值
	 */
	private float indexElevenThreshold;

	public long getIndexOneTradeAllNum() {
		return indexOneTradeAllNum;
	}

	public void setIndexOneTradeAllNum(long indexOneTradeAllNum) {
		this.indexOneTradeAllNum = indexOneTradeAllNum;
	}

	public long getIndexOnesucReturnNum() {
		return indexOnesucReturnNum;
	}

	public void setIndexOnesucReturnNum(long indexOnesucReturnNum) {
		this.indexOnesucReturnNum = indexOnesucReturnNum;
	}

	public float getIndexOneThreshold() {
		return indexOneThreshold;
	}

	public void setIndexOneThreshold(float indexOneThreshold) {
		this.indexOneThreshold = indexOneThreshold;
	}

	public long getIndexTwoTradeAllNum() {
		return indexTwoTradeAllNum;
	}

	public void setIndexTwoTradeAllNum(long indexTwoTradeAllNum) {
		this.indexTwoTradeAllNum = indexTwoTradeAllNum;
	}

	public long getIndexThreeTradeAllNum() {
		return indexThreeTradeAllNum;
	}

	public void setIndexThreeTradeAllNum(long indexThreeTradeAllNum) {
		this.indexThreeTradeAllNum = indexThreeTradeAllNum;
	}

	public long getIndexThreeUnSucNum() {
		return indexThreeUnSucNum;
	}

	public void setIndexThreeUnSucNum(long indexThreeUnSucNum) {
		this.indexThreeUnSucNum = indexThreeUnSucNum;
	}

	public float getIndexThreeThreshold() {
		return indexThreeThreshold;
	}

	public void setIndexThreeThreshold(float indexThreeThreshold) {
		this.indexThreeThreshold = indexThreeThreshold;
	}

	public long getIndexFourTradeAllNum() {
		return indexFourTradeAllNum;
	}

	public void setIndexFourTradeAllNum(long indexFourTradeAllNum) {
		this.indexFourTradeAllNum = indexFourTradeAllNum;
	}

	public long getIndexFourAbnormalNum() {
		return indexFourAbnormalNum;
	}

	public void setIndexFourAbnormalNum(long indexFourAbnormalNum) {
		this.indexFourAbnormalNum = indexFourAbnormalNum;
	}

	public float getIndexFourThreshold() {
		return indexFourThreshold;
	}

	public void setIndexFourThreshold(float indexFourThreshold) {
		this.indexFourThreshold = indexFourThreshold;
	}

	public long getDocSourceAbnormalNum() {
		return docSourceAbnormalNum;
	}

	public void setDocSourceAbnormalNum(long docSourceAbnormalNum) {
		this.docSourceAbnormalNum = docSourceAbnormalNum;
	}

	public long getIndexSixTradeAllNum() {
		return indexSixTradeAllNum;
	}

	public void setIndexSixTradeAllNum(long indexSixTradeAllNum) {
		this.indexSixTradeAllNum = indexSixTradeAllNum;
	}

	public long getIndexSixUnSucReturnNum() {
		return indexSixUnSucReturnNum;
	}

	public void setIndexSixUnSucReturnNum(long indexSixUnSucReturnNum) {
		this.indexSixUnSucReturnNum = indexSixUnSucReturnNum;
	}

	public long getIndexSevenTradeAllNum() {
		return indexSevenTradeAllNum;
	}

	public void setIndexSevenTradeAllNum(long indexSevenTradeAllNum) {
		this.indexSevenTradeAllNum = indexSevenTradeAllNum;
	}

	public long getIndexSevenUnSucReturnNum() {
		return indexSevenUnSucReturnNum;
	}

	public void setIndexSevenUnSucReturnNum(long indexSevenUnSucReturnNum) {
		this.indexSevenUnSucReturnNum = indexSevenUnSucReturnNum;
	}

	public long getIndexEightTradeAllNum() {
		return indexEightTradeAllNum;
	}

	public void setIndexEightTradeAllNum(long indexEightTradeAllNum) {
		this.indexEightTradeAllNum = indexEightTradeAllNum;
	}

	public long getIndexEightUnSucReturnNum() {
		return indexEightUnSucReturnNum;
	}

	public void setIndexEightUnSucReturnNum(long indexEightUnSucReturnNum) {
		this.indexEightUnSucReturnNum = indexEightUnSucReturnNum;
	}

	public long getUnSendingToChannelNum() {
		return unSendingToChannelNum;
	}

	public void setUnSendingToChannelNum(long unSendingToChannelNum) {
		this.unSendingToChannelNum = unSendingToChannelNum;
	}

	public long getIndexTHirUnSucSenToEasyMoneyNum() {
		return indexTHirUnSucSenToEasyMoneyNum;
	}

	public void setIndexTHirUnSucSenToEasyMoneyNum(
			long indexTHirUnSucSenToEasyMoneyNum) {
		this.indexTHirUnSucSenToEasyMoneyNum = indexTHirUnSucSenToEasyMoneyNum;
	}

	public long getIndexFourteenUnSucSenToTongLianNum() {
		return indexFourteenUnSucSenToTongLianNum;
	}

	public void setIndexFourteenUnSucSenToTongLianNum(
			long indexFourteenUnSucSenToTongLianNum) {
		this.indexFourteenUnSucSenToTongLianNum = indexFourteenUnSucSenToTongLianNum;
	}

	public long getIndexNineTradeAllNum() {
		return indexNineTradeAllNum;
	}

	public void setIndexNineTradeAllNum(long indexNineTradeAllNum) {
		this.indexNineTradeAllNum = indexNineTradeAllNum;
	}

	public long getIndexNineUnSucReturnNum() {
		return indexNineUnSucReturnNum;
	}

	public void setIndexNineUnSucReturnNum(long indexNineUnSucReturnNum) {
		this.indexNineUnSucReturnNum = indexNineUnSucReturnNum;
	}

	public long getIndexTenTradeAllNum() {
		return indexTenTradeAllNum;
	}

	public void setIndexTenTradeAllNum(long indexTenTradeAllNum) {
		this.indexTenTradeAllNum = indexTenTradeAllNum;
	}

	public long getIndexTenFailureNum() {
		return indexTenFailureNum;
	}

	public void setIndexTenFailureNum(long indexTenFailureNum) {
		this.indexTenFailureNum = indexTenFailureNum;
	}

	public float getIndexTenThreshold() {
		return indexTenThreshold;
	}

	public void setIndexTenThreshold(float indexTenThreshold) {
		this.indexTenThreshold = indexTenThreshold;
	}

	public long getIndexElevenTradeAllNum() {
		return indexElevenTradeAllNum;
	}

	public void setIndexElevenTradeAllNum(long indexElevenTradeAllNum) {
		this.indexElevenTradeAllNum = indexElevenTradeAllNum;
	}

	public long getIndexElevenFailureNum() {
		return indexElevenFailureNum;
	}

	public void setIndexElevenFailureNum(long indexElevenFailureNum) {
		this.indexElevenFailureNum = indexElevenFailureNum;
	}

	public float getIndexElevenThreshold() {
		return indexElevenThreshold;
	}

	public void setIndexElevenThreshold(float indexElevenThreshold) {
		this.indexElevenThreshold = indexElevenThreshold;
	}

	
	
}
