package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

public class EwsEmpGroupRefer extends BaseEntity {
	private static final long serialVersionUID = -292782172206608177L;
	// 人员ID
	private String empId;
	// 人员姓名
	private String empName;
	// 群组编号
	private String groupNo;
	// 是否邮件通知
	private String isMailNotify;
	// 是否短信通知
	private String isSmsNotify;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;
	// 邮箱地址
	private String email;
	// 手机号
	private String mobile;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getIsMailNotify() {
		return isMailNotify;
	}

	public void setIsMailNotify(String isMailNotify) {
		this.isMailNotify = isMailNotify;
	}

	public String getIsSmsNotify() {
		return isSmsNotify;
	}

	public void setIsSmsNotify(String isSmsNotify) {
		this.isSmsNotify = isSmsNotify;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
