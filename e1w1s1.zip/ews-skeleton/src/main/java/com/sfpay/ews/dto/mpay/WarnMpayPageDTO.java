package com.sfpay.ews.dto.mpay;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 银企B2C预警监测的资料，在明细中显示；
 * @author 575740
 *  
 */
public class WarnMpayPageDTO extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 业务流水号
	 */
	private String bussinessNo;
	
	/**
	 * 商户订单号
	 */
	private String merOrderNo;
	
	/**
	 * 交易金额
	 */
	private Long tradeAmt;
	
	/**
	 * 状态
	 */
	private String status;
	
	/**
	 * 接受商户时间
	 */
	private String tradeRecvTime;
	
	
	/**
	 * 开始时间
	 */
	private String tradeBeginTime;
	
	/**
	 * 结束时间
	 */
	private String tradeEndTime;
	

	public String getBussinessNo() {
		return bussinessNo;
	}

	public void setBussinessNo(String bussinessNo) {
		this.bussinessNo = bussinessNo;
	}

	public String getMerOrderNo() {
		return merOrderNo;
	}

	public void setMerOrderNo(String merOrderNo) {
		this.merOrderNo = merOrderNo;
	}

	public Long getTradeAmt() {
		return tradeAmt;
	}

	public void setTradeAmt(Long tradeAmt) {
		this.tradeAmt = tradeAmt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTradeBeginTime() {
		return tradeBeginTime;
	}

	public void setTradeBeginTime(String tradeBeginTime) {
		this.tradeBeginTime = tradeBeginTime;
	}

	public String getTradeEndTime() {
		return tradeEndTime;
	}

	public void setTradeEndTime(String tradeEndTime) {
		this.tradeEndTime = tradeEndTime;
	}	
	
	public String getTradeRecvTime() {
		return tradeRecvTime;
	}

	public void setTradeRecvTime(String tradeRecvTime) {
		this.tradeRecvTime = tradeRecvTime;
	}

	
}
