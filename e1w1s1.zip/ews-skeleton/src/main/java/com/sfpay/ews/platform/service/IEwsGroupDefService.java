package com.sfpay.ews.platform.service;

import java.util.List;



import com.sfpay.ews.platform.domain.EwsGroupDef;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 
 *	类：群组维护
 *	类描述：群组维护
 *
 * @author 544772
 * @version 2015年4月8日 上午11:25:54
 */
public interface IEwsGroupDefService {

	/**
	 * 
	 * 方法：新增预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef 指标群组实体
	 */
	public void addEwsGroupDef(EwsGroupDef ewsGroupDef);
	
	/**
	 * 
	 * 方法：更新预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef 指标群组实体
	 */
	public void updateEwsGroupDef(EwsGroupDef ewsGroupDef);
	
	/**
	 * 
	 * 方法：删除预警群组
	 * 方法说明：
	 *
	 * @param groupNo 群组编号
	 */
	public void delEwsGroupDef(String groupNo);
	
	/**
	 * 
	 * 方法：通过主键查询预警群组
	 * 方法说明：
	 *
	 * @param groupNo 群组编号
	 * @return 群组对象
	 */
	public EwsGroupDef queryByGroupNo(String groupNo);
	
	/**
	 * 
	 * 方法：通过参数查询预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef 群组对象
	 * @return 群组记录
	 */
	public List<EwsGroupDef> queryEwsGroupDefByParam(EwsGroupDef ewsGroupDef);
	
	/**
	 * 
	 * 方法：通过参数分页查询预警群组
	 * 方法说明：
	 *
	 * @param ewsGroupDef 群组对象
	 * @param start rownum start
	 * @param end rownum end
	 * @return 分页群组记录
	 */
	public IPage<EwsGroupDef> queryEwsGroupDefByOrderPage(EwsGroupDef ewsGroupDef,int start,int end);
	
	
	/**
	 * 查询所有群组记录
	 * 
	 * @return 分页群组记录
	 */
	public List<EwsGroupDef> querytAllEwsGroupDef();
}
