package com.sfpay.ews.enums.acq;

/**
 *  银企付款的参数;
 * @author 575740
 *
 */
public enum WarnAcqParam {
	/**
	 * A1:  ACQ银企付款一段时间内出现实付金额大于应付金额记录统计
	 */
	PAYOUTMORENUM,
	/**
	 * A1: 银企直联一段时间出现的状态为UNKOWN及超过配置时间的记录
	 */
	BATCHUNKOWNNUM,
	/**
	 * A1: 银企直联已受理并且超过指定配置时间未得到结果的记录
	 */
	BATCHRECUNDONUM
}
