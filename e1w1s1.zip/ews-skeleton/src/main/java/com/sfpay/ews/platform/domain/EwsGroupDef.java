package com.sfpay.ews.platform.domain;

import java.util.Date;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * 类说明：预警群组实体
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-19
 */
public class EwsGroupDef extends BaseEntity {

	private static final long serialVersionUID = 4125982810897657644L;

	private String groupNo;

	private String groupName;

	private String groupExplain;

	private String isValid;

	private String remark;

	private String createId;

	private Date createTime;

	private String updateId;

	private Date updateTime;

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupExplain() {
		return groupExplain;
	}

	public void setGroupExplain(String groupExplain) {
		this.groupExplain = groupExplain;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
