package com.sfpay.ews.enums;

public enum WarnType {
	/**
	 * 事前
	 */
	BEFORE,
	/**
	 * 事中
	 */
	DURING,
	
	/**
	 * 事后
	 */
	AFTER
}
