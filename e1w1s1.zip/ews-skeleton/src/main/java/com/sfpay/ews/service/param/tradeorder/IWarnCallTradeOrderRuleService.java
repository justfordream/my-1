package com.sfpay.ews.service.param.tradeorder;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 核心订单系统预警的任务调度
 * @author 575740
 * 2014-05-23
 */
public interface IWarnCallTradeOrderRuleService extends IWarnCallDayRuleService {

	/**
	 * 增加一个调度任务，O2A 和 O2B的资料;
	 */
	public void timeToWarnCallOtoAbRule();
	
	/**
	 * 增加以空格调度任务，消费，转账，提现等交易超过设置时间30分钟未成功的记录
	 */
	public void timeToWarnCallOverTimeRule();
	
}
