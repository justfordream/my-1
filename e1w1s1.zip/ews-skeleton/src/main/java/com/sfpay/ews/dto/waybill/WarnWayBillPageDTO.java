package com.sfpay.ews.dto.waybill;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

public class WarnWayBillPageDTO extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 交易订单号

	 */
	private String tradeNo;
	
	/**
	 * 交易运单号
	 */
	private String expressSn;
	
	/**
	 * 运单号
	 */
	private String wayBillNo; 
	
	/**
	 * 交易类型
	 */
	private String tradeType; 
	
	/**
	 * 交易金额
	 */
	private String tradeAmt; 
	
	/**
	 * 支付状态
	 */
	private String tradeStatus; 
	
	/**
	 * 客户号
	 */
	private String payNo; 
	

	/**
	 * 业务类型
	 */
	private String tradeSource; 
	
	/**
	 * 交易时间
	 */
	private String tradeTime;
	
	
	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getTradeNo() {
		return tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}

	public String getExpressSn() {
		return expressSn;
	}

	public void setExpressSn(String expressSn) {
		this.expressSn = expressSn;
	}

	public String getWayBillNo() {
		return wayBillNo;
	}

	public void setWayBillNo(String wayBillNo) {
		this.wayBillNo = wayBillNo;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getTradeAmt() {
		return tradeAmt;
	}

	public void setTradeAmt(String tradeAmt) {
		this.tradeAmt = tradeAmt;
	}

	public String getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getTradeSource() {
		return tradeSource;
	}

	public void setTradeSource(String tradeSource) {
		this.tradeSource = tradeSource;
	}


}
