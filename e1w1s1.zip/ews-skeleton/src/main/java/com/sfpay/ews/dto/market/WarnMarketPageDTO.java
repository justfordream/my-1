package com.sfpay.ews.dto.market;

import java.util.Date;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 
 *	类：营销系统风险预警监控显示页面的资料;
 *	类描述：继承WarnOnePageDetailDTO的一些属性;
 *
 * @author 575740
 * @version 2015年4月15日 下午6:38:05
 */
public class WarnMarketPageDTO  extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 卡号
	 */
	private String cardNo;
	
	/**
	 * 业务流水号(订单号)
	 */
	private String businessSn;
		

	/**
	 * 营销奖励值
	 */
	private Long batchAwardValue;
	
	/**
	 * 积分期数
	 */
	private Integer payTimes;
	
	/**
	 * 人工审核状态
	 */
	private String status;
	
	/**
	 * 场景
	 */
	private String scene;
	
	/**
	 * 审核人员 
	 */
	private String auditor;
	
	/**
	 * 审核时间
	 */
	private Date auditTime;
	
	/**
	 * 发送奖励值
	 */
	private Long awardValue;
	
	/**
	 * 最后赠送时间;
	 */
	private Date lastTime;
	
	/**
	 * 活动名称
	 */
	private String activeName;

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public Long getBatchAwardValue() {
		return batchAwardValue;
	}

	public void setBatchAwardValue(Long batchAwardValue) {
		this.batchAwardValue = batchAwardValue;
	}

	public Integer getPayTimes() {
		return payTimes;
	}

	public void setPayTimes(Integer payTimes) {
		this.payTimes = payTimes;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getScene() {
		return scene;
	}

	public void setScene(String scene) {
		this.scene = scene;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public Date getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	public Long getAwardValue() {
		return awardValue;
	}

	public void setAwardValue(Long awardValue) {
		this.awardValue = awardValue;
	}

	public Date getLastTime() {
		return lastTime;
	}

	public void setLastTime(Date lastTime) {
		this.lastTime = lastTime;
	}

	public String getActiveName() {
		return activeName;
	}

	public void setActiveName(String activeName) {
		this.activeName = activeName;
	}	

	public String getBusinessSn() {
		return businessSn;
	}

	public void setBusinessSn(String businessSn) {
		this.businessSn = businessSn;
	}

}
