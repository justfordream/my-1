package com.sfpay.ews.dto.pas;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 *垫付货款系统风险预警监控指标 
 * @author 575740
 * 2014-06-17 
 *
 */
public class WarnPasParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 每小时的运单资料;
	 */
	private long hourBillNum;
	
	/**
	 * 指标二：当日的同步COD数量
	 */
	private long todayBillNum;
	
	/**
	 * 指标二：昨日的同步COD数量
	 */
	private long ydayBillNum;
	
	/**
	 * 指标二：当日与昨日增加的比率
	 */
	private float todayAddPer;
	
	/**
	 * 指标二：平均的增长比率;
	 */
	private float avgAddPer;
	
	/**
	 * 查询的是几日内的资料;
	 */
	private float dayNumPer;
	

	/**
	 * 指标二：增加的阀值;
	 */
	private float thresholdPer;
	
	/**
	 * 指标三：重复付款的阀值;
	 */
	private long repeatNum;
	/**
	 * 指标四：垫付放款符合放款的记录数
	 */
	private long lendingNum;
	/**
	 * 指标四：银企放款的记录数
	 */
	private long payoutNum;
	/**
	 * 指标五：垫付放款符合放款的记录金额汇总
	 */
	private long lendingAmt;
	/**
	 * 指标五：银企放款的记录金额汇总
	 */
	private long payoutAmt;
	
	/**
	 * 指标六: 昨日对账的垫付订单
	 */
	private long ydayOrderNum;
	/**
	 * 指标六: 昨日对账的小订单
	 */
	private long ydayTradeNum;
	/**
	 * 指标六: 今日对账的垫付订单
	 */
	private long todayOrderNum;
	/**
	 * 指标六: 今日对账的小订单
	 */
	private long todayTradeNum;
	
	/**
	 * 指标七:订单申请记录中的重复运单
	 */
	private long busWayBillNum;	
	
	/**
	 * 指标七:订单表中的重复运单
	 */
	private long orderWayBillNum;
	
	/**
	 * 指标八:非收派员巴枪版COD对其核销成功且未抵扣PAS的对应账单异常笔数
	 */
	private long pasVsCodNotBarNum;
	
	/**
	 * 指标九:收派员巴枪版COD对其核销成功且未抵扣PAS的对应账单异常笔数
	 */
	private long pasVsCodBarNum;
	
	/**
	 * 指标十:所有未回款的垫付运单的总金额、所有处于“待结算”或“结算中”的账单的线下回款金额之和不等于付总欠款
	 */
	private long businessAmtNum;
	
	/**
	 * 指标十二（PAS0012）:检查回款记录是否都已记账，如果未记账，需手工确认记账。此属性为未记账的回款笔数
	 */
	private long unAccountNum;
	
	/**
	 * 指标十一（PAS0011）:散单二次放款调度任务执行后“风控暂停”状态订单笔数
	 */
	private long hhtSuspendLendingRiskNum;
	
	/**
	 * 指标十七（PAS0017）:非散单二次放款调度任务执行后“风控暂停”状态订单笔数
	 */
	private long notHhtSuspendLendingRiskNum;
	
	/**
	 * 指标十三（PAS0013）:风控系统未给垫付货款系统反馈(标准版)中规则结果,本属性记录垫付接收到的次数，为0时异常
	 */
	private long notHhtNotifyPasTimes;
	
	/**
	 * 指标十四（PAS0014）:风控系统未给垫付货款系统反馈(巴枪版)中规则结果,本属性记录垫付接收到的次数，为0时异常
	 */
	private long hhtNotifyPasTimes;
	
	/**
	 * 指标十五（PAS0015）:风控系统人工处理反馈系统接口异常的监控预警，本属性记录风控未将人工审核结果成功通知到垫付的笔数
	 */
	private long failNotifyPasNum;
	
	/**
	 * 指标十八（PAS0018）:监控银企放款超时，本属性记录还未放款成功的放款单笔数
	 */
	private long unLendingNum;
	
	/**
	 * 风控指标RM_PAS0001:当天散单垫付放款前监控未完成系统跑批，等于0时告警
	 */
	private long finishHhtRuleLogNum;
	
	/**
	 * 指标十九（PAS0019）:监控垫付与订单对账是否正常，本属性记录垫付与订单的对账的异常情况，如果异常笔数>0，则异常。
	 */
	private long unMatchPasNum;
	
	/**
	 * 指标二十（PAS0020）：监控垫付和CBIL对账异常
	 * add by yurongjie 2014-12-16
	 */
	private long pasCbilReconExceptionNum;
	
	/**
	 * 指标二十三（PAS0023）：监控垫付回款勾稽异常
	 * add by xiongwei7 2014-12-17
	 */
	private long pasRepayExceptionNum;
	
	public long getPasCbilReconExceptionNum() {
		return pasCbilReconExceptionNum;
	}

	public void setPasCbilReconExceptionNum(long pasCbilReconExceptionNum) {
		this.pasCbilReconExceptionNum = pasCbilReconExceptionNum;
	}

	public long getPasSyncCustomerNum() {
		return pasSyncCustomerNum;
	}

	public void setPasSyncCustomerNum(long pasSyncCustomerNum) {
		this.pasSyncCustomerNum = pasSyncCustomerNum;
	}

	/**
	 * 指标二十一（PAS0021）：监控垫付发送客户信息到CBIL异常
	 * add by yurongjie 2014-12-16
	 */
	private long pasSyncCustomerNum;
	
	/**
	 * 指标二十二（PAS0022）：监控是否有异常的未见回单记录
	 * add by yurongjie 2014-12-18
	 */
	private long pasWaybillExceptionNum;
	
    public long getPasWaybillExceptionNum() {
		return pasWaybillExceptionNum;
	}

	public void setPasWaybillExceptionNum(long pasWaybillExceptionNum) {
		this.pasWaybillExceptionNum = pasWaybillExceptionNum;
	}

	private long feeRemitExceptionNum;

	public long getBusinessAmtNum() {
		return businessAmtNum;
	}

	public void setBusinessAmtNum(long businessAmtNum) {
		this.businessAmtNum = businessAmtNum;
	}

	public long getPasVsCodNotBarNum() {
		return pasVsCodNotBarNum;
	}

	public void setPasVsCodNotBarNum(long pasVsCodNotBarNum) {
		this.pasVsCodNotBarNum = pasVsCodNotBarNum;
	}

	public long getPasVsCodBarNum() {
		return pasVsCodBarNum;
	}

	public void setPasVsCodBarNum(long pasVsCodBarNum) {
		this.pasVsCodBarNum = pasVsCodBarNum;
	}



	public long getHourBillNum() {
		return hourBillNum;
	}

	public void setHourBillNum(long hourBillNum) {
		this.hourBillNum = hourBillNum;
	}

	public long getTodayBillNum() {
		return todayBillNum;
	}

	public void setTodayBillNum(long todayBillNum) {
		this.todayBillNum = todayBillNum;
	}

	public long getYdayBillNum() {
		return ydayBillNum;
	}

	public void setYdayBillNum(long ydayBillNum) {
		this.ydayBillNum = ydayBillNum;
	}

	public float getTodayAddPer() {
		return todayAddPer;
	}

	public void setTodayAddPer(float todayAddPer) {
		this.todayAddPer = todayAddPer;
	}

	public float getAvgAddPer() {
		return avgAddPer;
	}

	public void setAvgAddPer(float avgAddPer) {
		this.avgAddPer = avgAddPer;
	}

	public float getDayNumPer() {
		return dayNumPer;
	}

	public void setDayNumPer(float dayNumPer) {
		this.dayNumPer = dayNumPer;
	}

	public float getThresholdPer() {
		return thresholdPer;
	}

	public void setThresholdPer(float thresholdPer) {
		this.thresholdPer = thresholdPer;
	}

	public long getRepeatNum() {
		return repeatNum;
	}

	public void setRepeatNum(long repeatNum) {
		this.repeatNum = repeatNum;
	}

	public long getLendingNum() {
		return lendingNum;
	}

	public void setLendingNum(long lendingNum) {
		this.lendingNum = lendingNum;
	}

	public long getPayoutNum() {
		return payoutNum;
	}

	public void setPayoutNum(long payoutNum) {
		this.payoutNum = payoutNum;
	}

	public long getLendingAmt() {
		return lendingAmt;
	}

	public void setLendingAmt(long lendingAmt) {
		this.lendingAmt = lendingAmt;
	}

	public long getPayoutAmt() {
		return payoutAmt;
	}

	public void setPayoutAmt(long payoutAmt) {
		this.payoutAmt = payoutAmt;
	}

	public long getYdayOrderNum() {
		return ydayOrderNum;
	}

	public void setYdayOrderNum(long ydayOrderNum) {
		this.ydayOrderNum = ydayOrderNum;
	}

	public long getYdayTradeNum() {
		return ydayTradeNum;
	}

	public void setYdayTradeNum(long ydayTradeNum) {
		this.ydayTradeNum = ydayTradeNum;
	}

	public long getTodayOrderNum() {
		return todayOrderNum;
	}

	public void setTodayOrderNum(long todayOrderNum) {
		this.todayOrderNum = todayOrderNum;
	}

	public long getTodayTradeNum() {
		return todayTradeNum;
	}

	public void setTodayTradeNum(long todayTradeNum) {
		this.todayTradeNum = todayTradeNum;
	}

	public long getBusWayBillNum() {
		return busWayBillNum;
	}

	public void setBusWayBillNum(long busWayBillNum) {
		this.busWayBillNum = busWayBillNum;
	}

	public long getOrderWayBillNum() {
		return orderWayBillNum;
	}

	public void setOrderWayBillNum(long orderWayBillNum) {
		this.orderWayBillNum = orderWayBillNum;
	}

	public long getUnAccountNum() {
		return unAccountNum;
	}

	public void setUnAccountNum(long unAccountNum) {
		this.unAccountNum = unAccountNum;
	}

	public long getHhtSuspendLendingRiskNum() {
		return hhtSuspendLendingRiskNum;
	}

	public void setHhtSuspendLendingRiskNum(long hhtSuspendLendingRiskNum) {
		this.hhtSuspendLendingRiskNum = hhtSuspendLendingRiskNum;
	}

	public long getNotHhtSuspendLendingRiskNum() {
		return notHhtSuspendLendingRiskNum;
	}

	public void setNotHhtSuspendLendingRiskNum(long notHhtSuspendLendingRiskNum) {
		this.notHhtSuspendLendingRiskNum = notHhtSuspendLendingRiskNum;
	}

	public long getNotHhtNotifyPasTimes() {
		return notHhtNotifyPasTimes;
	}

	public void setNotHhtNotifyPasTimes(long notHhtNotifyPasTimes) {
		this.notHhtNotifyPasTimes = notHhtNotifyPasTimes;
	}

	public long getHhtNotifyPasTimes() {
		return hhtNotifyPasTimes;
	}

	public void setHhtNotifyPasTimes(long hhtNotifyPasTimes) {
		this.hhtNotifyPasTimes = hhtNotifyPasTimes;
	}

	public long getFailNotifyPasNum() {
		return failNotifyPasNum;
	}

	public void setFailNotifyPasNum(long failNotifyPasNum) {
		this.failNotifyPasNum = failNotifyPasNum;
	}

	public long getUnLendingNum() {
		return unLendingNum;
	}

	public void setUnLendingNum(long unLendingNum) {
		this.unLendingNum = unLendingNum;
	}
	
	public long getFinishHhtRuleLogNum() {
		return finishHhtRuleLogNum;
	}

	public void setFinishHhtRuleLogNum(long finishHhtRuleLogNum) {
		this.finishHhtRuleLogNum = finishHhtRuleLogNum;
	}

	public long getUnMatchPasNum() {
		return unMatchPasNum;
	}

	public void setUnMatchPasNum(long unMatchPasNum) {
		this.unMatchPasNum = unMatchPasNum;
	}

	public long getFeeRemitExceptionNum() {
		return feeRemitExceptionNum;
	}

	public void setFeeRemitExceptionNum(long feeRemitExceptionNum) {
		this.feeRemitExceptionNum = feeRemitExceptionNum;
	}

	public long getPasRepayExceptionNum() {
		return pasRepayExceptionNum;
	}

	public void setPasRepayExceptionNum(long pasRepayExceptionNum) {
		this.pasRepayExceptionNum = pasRepayExceptionNum;
	}

			
}
