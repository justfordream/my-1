package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 预警群组与指标映射表实体
 * EWS_GROUP_INDEX
 * @author 625288
 *
 */
public class EwsGroupIndex extends BaseEntity{

	private static final long serialVersionUID = -6595464270067517528L;

	private String groupNo;
	
	private String warnIndexNo;
	
	private String createId;
	
	private Date createTime;

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		return "WarnGroupVsIndex [groupNo=" + groupNo + ", warnIndexNo="
				+ warnIndexNo + ", createId=" + createId + ", createTime="
				+ createTime + "]";
	}
	
}
