/**
 * 
 */
package com.sfpay.ews.platform.service;

import java.util.List;
import java.util.Set;

import com.sfpay.ews.platform.domain.EwsIndexSql;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 类说明：告警指标SQL的服务接口
 *
 * 类描述：告警指标SQL的服务接口
 * @author 625288
 *
 * 2015-3-3
 */
public interface IEwsIndexSqlService {
	/**
	 * 通过指标编号查找对应的SQL
	 * @return SQL集合
	 */
	public List<EwsIndexSql> queryEwsIndexSqlByWarnNo(String warnIndexNo);
	
	/**
	 * 通过指标编号和SQL键查找预警指标SQL对象
	 * @param warnIndexNo  指标编号
	 * @param sqlKey SQL键
	 * @return 预警指标SQL对象
	 */
	public EwsIndexSql queryByWarnIndexNoAndSqlKey(String warnIndexNo, String sqlKey);
	
	/**
	 * 新增预警指标SQL
	 * @param ewsIndexSql
	 */
	public void addEwsIndexSql(EwsIndexSql ewsIndexSql);
	
	/**
	 * 删除预警指标SQL
	 * @param id 主键
	 */
	public void deleteEwsIndexSql(long id);
	
	/**
	 * 通过id查询
	 * @param id 主键
	 * @return 指标SQL对象
	 */
	public EwsIndexSql queryById(long id);
	
	/**
	 * 更新预警指标SQL
	 * @param ewsIndexSql 指标SQL对象
	 */
	public void updateEwsIndexSql(EwsIndexSql ewsIndexSql);
	
	/**
	 * 查询在TABLE_NAME列中出现过的所有表名
	 * @return 所有表名
	 */
	public Set<String> queryAllTableName();
	
	/**
	 * 分页查询指标
	 * 
	 * @param ewsIndexSql 指标SQL对象
	 * @param index 页索引
	 * @param size 页大小
	 * @return 分页指标对象
	 * @throws ServiceException 自定义异常
	 */
	public IPage<EwsIndexSql> queryByPage(EwsIndexSql ewsIndexSql, int index, int size)
			throws ServiceException;
}
