package com.sfpay.ews.platform.util;

/**
 * 
 *	类：预警系统常量设置
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月22日 下午1:50:41
 */
public class EwsConstantsUtil {
	//预警阶段
	public static String WARN_STAGE="WARN_STAGE";
	//预警类别
	public static String WARN_CLASS_CODE="WARN_CLASS_CODE";
	//预警来源
	public static String WARN_SOURCE="WARN_SOURCE";
	//预警等级
	public static String WARN_LEVEL="WARN_LEVEL";
	//预警性质
	public static String WARN_PROPERTY="WARN_PROPERTY";
	//操作状态
	public static String OPR_STATUS = "OPR_STATUS";
}

