package com.sfpay.ews.service.param.eleaccount;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 电子账户系统预警的任务调度
 * @author 575740
 * 2014-05-23
 */
public interface IWarnCallEleAccountRuleService extends IWarnCallDayRuleService {
	/**
	 * 什么也不做;
	 */

}
