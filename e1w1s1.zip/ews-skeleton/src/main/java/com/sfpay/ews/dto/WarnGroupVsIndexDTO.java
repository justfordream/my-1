package com.sfpay.ews.dto;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 群组指标关联对象
 * 
 * @author 321566 张泽豪
 *
 * 2014-4-17 下午6:53:21
 */
public class WarnGroupVsIndexDTO  extends BaseEntity {

	private static final long serialVersionUID = -7202978825553119173L;
	
	private String groupNo;
	
	private String warnIndexNo;
	
	private String createId;
	
	private Date createTime;

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		return "WarnGroupVsIndexDTO [groupNo=" + groupNo + ", warnIndexNo="
				+ warnIndexNo + ", createId=" + createId + ", createTime="
				+ createTime + "]";
	}
	
}
