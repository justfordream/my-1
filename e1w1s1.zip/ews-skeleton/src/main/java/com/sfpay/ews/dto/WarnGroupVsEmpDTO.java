package com.sfpay.ews.dto;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:33:51
 */
public class WarnGroupVsEmpDTO  extends BaseEntity {
	private static final long serialVersionUID = -5150254353815728066L;

	private String empId;
	
	private String empName;
	
	private String empMail;
	
	private String empMobile;
	
	private String groupNoList;
	
	private String remark;
	
	private String isMailNotify;
	
	private String isSmsNotify;
	
	private String createId;
	
	private Date createTime;
	
	private String updateId;
	
	private Date updateTime;
	
	private String selected;
	
	private String flag;
	
	/**
	 * 是否有效;
	 */
	private String isValid;

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpMail() {
		return empMail;
	}

	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}

	public String getEmpMobile() {
		return empMobile;
	}

	public void setEmpMobile(String empMobile) {
		this.empMobile = empMobile;
	}

	public String getGroupNoList() {
		return groupNoList;
	}

	public void setGroupNoList(String groupNoList) {
		this.groupNoList = groupNoList;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIsMailNotify() {
		return isMailNotify;
	}

	public void setIsMailNotify(String isMailNotify) {
		this.isMailNotify = isMailNotify;
	}


	public String getIsSmsNotify() {
		return isSmsNotify;
	}

	public void setIsSmsNotify(String isSmsNotify) {
		this.isSmsNotify = isSmsNotify;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getSelected() {
		return selected;
	}

	public void setSelected(String selected) {
		this.selected = selected;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return "WarnGroupVsEmpDTO [empId=" + empId + ", empName=" + empName
				+ ", empMail=" + empMail + ", empMobile=" + empMobile
				+ ", groupNoList=" + groupNoList + ", remark=" + remark
				+ ", isMailNotify=" + isMailNotify + ", isSmsNotify="
				+ isSmsNotify + ", createId=" + createId + ", createTime="
				+ createTime + ", updateId=" + updateId + ", updateTime="
				+ updateTime + ", selected=" + selected + ", flag=" + flag
				+ "]";
	}
	
}
