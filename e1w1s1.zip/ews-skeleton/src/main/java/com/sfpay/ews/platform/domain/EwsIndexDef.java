/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 预警指标定义实体 EWS_INDEX_DEF
 * 
 * @author 625288
 * 
 */
public class EwsIndexDef extends BaseEntity {
	private static final long serialVersionUID = -644952184212012606L;
	// 指标编号
	private String warnIndexNo;
	// 指标名称
	private String warnIndexName;
	// 预警来源,如COD，营销
	private String warnSource;
	// 实效代码
	private String effectCode;
	// 预警类型 事后 BEFORE，事中 DURING，事后 AFTER
	private String warnStage;
	// 预警性质: 预警 WARNING,错误 ERROR
	private String warnProperty;
	// 是否使用
	private String isValid;
	// 指标邮件标题模板中可以使用占位符，即${param1}，其中的占位符参数必须是结果集或SQL参数集中存在的。还可以使用${SYSDATE}和${指标编号.DROOLS}来输出数据库日期和指标对应的Drools输出。
	// 标题模板不能使用loop和endloop等关键字
	private String mailTitleTemplate;
	// 指标邮件正文模板中可以使用占位符，即${param1}，其中的占位符参数必须是结果集或SQL参数集中存在的。还可以使用${SYSDATE}和${指标编号.DROOLS}来输出数据库日期和指标对应的Drools输出。
	// 其中，预定义的模板关键字如下：
	// loop和endloop：关键字之间的内容将被循环，循环次数由结果集的行数决定，目前只支持使用一次loop和一次endloop
	// loopbody：系统使用的关键字，模板中应该避免出现该字符串 rownum：行号，只能在loop和endloop之间使用
	private String mailContextTemplate;
	// 规则模板
	private String ruleTemplate;
	// 基于Quartz的时间表达式
	private String cronExpress;
	// 运行状态，用来标记一个调度任务是否正在执行 STOP:没有执行, RUNNING:运行中
	private String runStatus;
	// 调度状态 CLOSE:关闭, START:开启
	private String status;
	// 手动操作标记 主要用于通过数据库脚本来更新指标调度信息,只能为空或者UPDATE、ADD、DELETE、PAUSE、RECOVERY
	private String oprFlag;
	// 备注
	private String remark;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	/**
	 * 以下是非持久化属性
	 */
	// 实效名称
	private String effectName;
	// 实效时间
	private long effectTime;
	// 预警阶段名称
	private String warnStageName;
	// 预警类别代码
	private String warnClassCode;
	// 预警类别名称
	private String warnClassName;
	// 风险等级
	private String warnLevel;
	// 风险等级名称
	private String warnLevelName;
	// 预警来源名称
	private String warnSourceName;
	// 预警性质名称
	private String warnPropertyName;

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexName() {
		return warnIndexName;
	}

	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public String getWarnProperty() {
		return warnProperty;
	}

	public void setWarnProperty(String warnProperty) {
		this.warnProperty = warnProperty;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getMailTitleTemplate() {
		return mailTitleTemplate;
	}

	public void setMailTitleTemplate(String mailTitleTemplate) {
		this.mailTitleTemplate = mailTitleTemplate;
	}

	public String getMailContextTemplate() {
		return mailContextTemplate;
	}

	public void setMailContextTemplate(String mailContextTemplate) {
		this.mailContextTemplate = mailContextTemplate;
	}

	public String getRuleTemplate() {
		return ruleTemplate;
	}

	public void setRuleTemplate(String ruleTemplate) {
		this.ruleTemplate = ruleTemplate;
	}

	public String getCronExpress() {
		return cronExpress;
	}

	public void setCronExpress(String cronExpress) {
		this.cronExpress = cronExpress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getEffectCode() {
		return effectCode;
	}

	public void setEffectCode(String effectCode) {
		this.effectCode = effectCode;
	}

	public String getOprFlag() {
		return oprFlag;
	}

	public void setOprFlag(String oprFlag) {
		this.oprFlag = oprFlag;
	}

	public String getEffectName() {
		return effectName;
	}

	public void setEffectName(String effectName) {
		this.effectName = effectName;
	}

	public long getEffectTime() {
		return effectTime;
	}

	public void setEffectTime(long effectTime) {
		this.effectTime = effectTime;
	}

	public String getWarnClassCode() {
		return warnClassCode;
	}

	public void setWarnClassCode(String warnClassCode) {
		this.warnClassCode = warnClassCode;
	}

	public String getWarnClassName() {
		return warnClassName;
	}

	public void setWarnClassName(String warnClassName) {
		this.warnClassName = warnClassName;
	}

	public String getWarnLevel() {
		return warnLevel;
	}

	public void setWarnLevel(String warnLevel) {
		this.warnLevel = warnLevel;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getWarnSourceName() {
		return warnSourceName;
	}

	public void setWarnSourceName(String warnSourceName) {
		this.warnSourceName = warnSourceName;
	}

	public String getWarnStageName() {
		return warnStageName;
	}

	public void setWarnStageName(String warnStageName) {
		this.warnStageName = warnStageName;
	}

	public String getWarnPropertyName() {
		return warnPropertyName;
	}

	public void setWarnPropertyName(String warnPropertyName) {
		this.warnPropertyName = warnPropertyName;
	}

	public String getWarnLevelName() {
		return warnLevelName;
	}

	public void setWarnLevelName(String warnLevelName) {
		this.warnLevelName = warnLevelName;
	}

	public String getRunStatus() {
		return runStatus;
	}

	public void setRunStatus(String runStatus) {
		this.runStatus = runStatus;
	}

	public String getWarnStage() {
		return warnStage;
	}

	public void setWarnStage(String warnStage) {
		this.warnStage = warnStage;
	}
}
