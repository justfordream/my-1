package com.sfpay.ews.service.param.storedcard;

import com.sfpay.ews.dto.storedcard.WarnStoredCardPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 储值卡系统预警的参数获取;
 * @author 575740
 *
 */
public interface IWarnGetStoredCardParamService {
	
	/**
	 * 查询储值卡中交易状态为进行中的记录笔数 
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return
	 * @throws ServiceException
	 */
	public long getTradingNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 查询储值卡中某段时间内的交易总数
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return
	 * @throws ServiceException
	 */
	public long getTradeAllNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 查询储值卡中某段时间内的交易成功总数 查询某个时间范围，与当前时间的分秒比较; 截止与当前时间几分钟的数量;
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return
	 * @throws ServiceException
	 */
	public long getTradeSucNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	

	/**
	 * 查询储值卡中某段时间内的交易数量为0的记录
	 * @param qryBeginTime 查询的某个日期开始时间
	 * @param qryEndTime 查询的某个日期结束时间	
	 * @return
	 * @throws ServiceException
	 */
	public long getTradeZeroNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 查询发送消费公款部分的记录
	 * @param qryDate 查询的某个日期
	 * @return
	 * @throws ServiceException
	 */
	public long getTradeBillNum(String qryDate) throws ServiceException;	
	
		
	/**
	 * 根据ID查询一笔资料;
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public WarnStoredCardPageDTO getOfflineBusinessById(Long id) throws ServiceException;
	
	
	/**
	 * 批量保存某个时间段内进行中的记录数;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param warnNo 告警编号
	 * @param expExpLain	告警说明;
	 * @param warnStoredCardRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return
	 * @throws ServiceException
	 */
	public int saveBatchTradingData(String qryBeginTime,String qryEndTime,String warnNo,String expExpLain,String warnStoredCardRule,long paramRowNum) throws ServiceException;
	
	/**
	 * 批量保存某个时间段内未成功的记录数;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param warnNo 告警编号
	 * @param expExpLain	告警说明;
	 * @param warnStoredCardRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return
	 * @throws ServiceException
	 */
	public int saveBatchUnSuccess(String qryBeginTime,String qryEndTime,String warnNo,String expExpLain,String warnStoredCardRule,long paramRowNum) throws ServiceException;

	
}
