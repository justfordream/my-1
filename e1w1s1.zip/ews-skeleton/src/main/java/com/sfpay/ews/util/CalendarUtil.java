package com.sfpay.ews.util;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class CalendarUtil {
	private static SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
	private Calendar calendar;	
	
	public String getToday(){
		 calendar = Calendar.getInstance();
		return  sf.format(calendar.getTime());
	}
	
	public String getYesday(){
		calendar = Calendar.getInstance();	
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		return  sf.format(calendar.getTime());
	}
	
	public String getFifteenBefore(){
		calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, -14);
		return sf.format(calendar.getTime());
	}
	
	/**
	 * 得到几天前的资料;
	 * @param date
	 * @param nval
	 * @return
	 */
	public String getBeforeNDay(Date date,int nval){
		calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, nval);
		return sf.format(calendar.getTime());
	}

	/**
	 * 提取一个完整日期的时间部分
	 * @param dateStr 格式：yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public String getTimeOfDate(String dateStr) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			Date date = sdf.parse(dateStr);
			sdf = new SimpleDateFormat("HH:mm:ss");
			return sdf.format(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
}
