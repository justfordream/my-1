package com.sfpay.ews.enums.fms;

/**
 * 米兰港(融资平台) 预警监测的规则指标
 * @author 575740
 * 2014-06-19
 */
public enum WarnFmsRule {
	/**
	 * 融通向顺手付支付进行中的记录数
	 */
	FMS0001,
	/**
	 * 融通和顺手付交易订单不匹配的指标(对帐)
	 */
	FMS0002
}
