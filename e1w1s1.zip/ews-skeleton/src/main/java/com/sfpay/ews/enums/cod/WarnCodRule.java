package com.sfpay.ews.enums.cod;

/**
 * COD的规则;
 * @author 575740
 *
 */
public enum WarnCodRule {
	/**
	 * 重复付款记录监控
	 */
	COD0001,	
	/**
	 * 付款申请记录数与应付款记录数监控
	 */
	COD0002,
	/**
	 * 付款申请金额与应付款金额监控
	 */
	COD0003
}
