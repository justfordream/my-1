package com.sfpay.ews.dto.btoc;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * B2C系统风险预警监控指标 
 * @author 575740
 * 2014/05/08 
 *
 */
public class WarnBtocParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 银行渠道;如：易宝,工行;
	 */
	private String bankCodes;

	/**
	 * A1:一段时间交易收单的记录
	 */
	private long colAllNum;
	/**
	 * A2: 一段时间交易收单成功的记录
	 */
	private long colSuccessNum;
	

	/**
	 * A1:一段时间交易收单的记录 
	 */
	private long colSignAllNum;	
	
	/**
	 * A2:一段时间内签名失败率较高的记录
	 */
	private long colSignFailNum;
	
	/**
	 * 某段时间内的交易未成功的阀值;
	 */
	private float unSucThreshold;
	
	/**
	 * 某段时间内的签名失败率的阀值;
	 */
	private float signThreshold;
	
	/**
	 * B2C XXX某段时间的交易总记录数的限定阀值，即A1>=A3的时候判断
	 */
	private long allNumLimit;
	
	
	/**
	 * B2C XXX某段时间的签名总记录数的限定阀值，即A1>=A3的时候判断
	 */
	private long signAllNumLimit;


	public String getBankCodes() {
		return bankCodes;
	}


	public void setBankCodes(String bankCodes) {
		this.bankCodes = bankCodes;
	}


	public long getColAllNum() {
		return colAllNum;
	}


	public void setColAllNum(long colAllNum) {
		this.colAllNum = colAllNum;
	}


	public long getColSuccessNum() {
		return colSuccessNum;
	}


	public void setColSuccessNum(long colSuccessNum) {
		this.colSuccessNum = colSuccessNum;
	}


	public long getColSignAllNum() {
		return colSignAllNum;
	}


	public void setColSignAllNum(long colSignAllNum) {
		this.colSignAllNum = colSignAllNum;
	}


	public long getColSignFailNum() {
		return colSignFailNum;
	}


	public void setColSignFailNum(long colSignFailNum) {
		this.colSignFailNum = colSignFailNum;
	}


	public float getUnSucThreshold() {
		return unSucThreshold;
	}


	public void setUnSucThreshold(float unSucThreshold) {
		this.unSucThreshold = unSucThreshold;
	}


	public float getSignThreshold() {
		return signThreshold;
	}


	public void setSignThreshold(float signThreshold) {
		this.signThreshold = signThreshold;
	}


	public long getAllNumLimit() {
		return allNumLimit;
	}


	public void setAllNumLimit(long allNumLimit) {
		this.allNumLimit = allNumLimit;
	}


	public long getSignAllNumLimit() {
		return signAllNumLimit;
	}


	public void setSignAllNumLimit(long signAllNumLimit) {
		this.signAllNumLimit = signAllNumLimit;
	}
	
}
