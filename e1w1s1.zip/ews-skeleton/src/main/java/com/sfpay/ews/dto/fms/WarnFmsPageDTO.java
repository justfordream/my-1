package com.sfpay.ews.dto.fms;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;


/**
 * 米兰港(融资平台) 预警监测的资料，在明细中显示；
 * @author 575740
 * 2014-06-19
 */
public class WarnFmsPageDTO  extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 操作批次号
	 */
	private Long batchNo;
	
	/**
	 * 操作流水号
	 */
	private Long operationNo;
	
	/**
	 * 发起时间
	 */
	private String operateTime;
	
	/**
	 * 返回时间
	 */
	private String returnTime;
	
	/**
	 * 操作状态	
	 */
	private String status;
	
	/***
	 * 支付金额
	 */
	private Long payMoney;
	
	/**
	 * 资金支付对象类型;
	 */
	private String payObj;

	public Long getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(Long batchNo) {
		this.batchNo = batchNo;
	}

	public Long getOperationNo() {
		return operationNo;
	}

	public void setOperationNo(Long operationNo) {
		this.operationNo = operationNo;
	}

	public String getOperateTime() {
		return operateTime;
	}

	public void setOperateTime(String operateTime) {
		this.operateTime = operateTime;
	}

	public String getReturnTime() {
		return returnTime;
	}

	public void setReturnTime(String returnTime) {
		this.returnTime = returnTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(Long payMoney) {
		this.payMoney = payMoney;
	}

	public String getPayObj() {
		return payObj;
	}

	public void setPayObj(String payObj) {
		this.payObj = payObj;
	}
	
	
}
