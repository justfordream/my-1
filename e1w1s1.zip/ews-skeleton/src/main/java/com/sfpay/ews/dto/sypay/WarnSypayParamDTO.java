package com.sfpay.ews.dto.sypay;

import java.util.List;

import com.sfpay.ews.dto.WarnMemberDTO;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 顺手付指标参数
 * @author 627247
 * 2014-06-18
 */
public class WarnSypayParamDTO extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 顺手付和小订单的提前对账不一致数
	 */
	private long inconsistentTradeNum;
	
	/**
	 * 网银支付长时间未付款的记录数
	 */
	private long longTimeNoPayNum;
	
	/**
	 * 网银支付长时间未付款，有多长
	 */
	private float longTimeHowLong;
	
	/**
	 * 某段时间内支付的总数量
	 */
	private long tradeAllNum;
	
	/**
	 * 某段时间内支付的失败数量
	 */
	private long tradeUnSucNum;
	
	/**
	 * 某段时间内的交易失败率的阀值;
	 */
	private float unSucThreshold;
	
	/**
	 * 指定时间内发生连续交易的会员数
	 */
	private long continuousTradeMemberNum;
	
	/**
	 * 多少分钟内发生连续交易
	 */
	private long continuousHowLong;
	
	/**
	 * 账户余额为负的账户数
	 */
	private long minusAccountNum;
	
	/**
	 * 顺手付与银企预对账不一致数
	 */
	private long inconsistentTradeForYqNum;
	
	/**
	 * 已领取、已拆开、过期已退款的小红包累计金额大于红包批次小红包总金额记录数
	 * 
	 * */
	private long receivedRedBagAmountOverSendedTotalNum;
	/**
	 * 已领取、已拆开、过期已退款的小红包累计个数大于红包批次小红包总个数记录数
	 * 
	 * */
	private long receivedRedBagNumOverSendedTotalNum;
	/**
	 *小红包累计金额不等于大红包总金额记录数
	 * 
	 * */
	private long smallRedBagNotEqualBigRedBag;
	
	/**
	 * 一个红包批次一个会员领取多次的红包数目
	 * 
	 * */
	private long oneMemGetRedBagServalTimes;
	/**
	 * 一个红包金额大于10000的红包数目
	 * 
	 * */
	private long oneRedBagAmountOverTenThousand;
	/**
	 *一个会员所发红包金额大于20万数目
	 * 
	 * */
	private long oneMemSendRedBagOverTwoHunThousand;
	
	/**
	 * 【1】小时内【理财申购】累计金额≥【10000】RMB
	 */
	private List<WarnMemberDTO> purchaseSumAmtWarnList;

	public long getInconsistentTradeNum() {
		return inconsistentTradeNum;
	}

	public void setInconsistentTradeNum(long inconsistentTradeNum) {
		this.inconsistentTradeNum = inconsistentTradeNum;
	}

	public long getLongTimeNoPayNum() {
		return longTimeNoPayNum;
	}

	public void setLongTimeNoPayNum(long longTimeNoPayNum) {
		this.longTimeNoPayNum = longTimeNoPayNum;
	}

	public float getLongTimeHowLong() {
		return longTimeHowLong;
	}

	public void setLongTimeHowLong(float longTimeHowLong) {
		this.longTimeHowLong = longTimeHowLong;
	}

	public long getTradeAllNum() {
		return tradeAllNum;
	}

	public void setTradeAllNum(long tradeAllNum) {
		this.tradeAllNum = tradeAllNum;
	}

	public long getTradeUnSucNum() {
		return tradeUnSucNum;
	}

	public void setTradeUnSucNum(long tradeUnSucNum) {
		this.tradeUnSucNum = tradeUnSucNum;
	}

	public float getUnSucThreshold() {
		return unSucThreshold;
	}

	public void setUnSucThreshold(float unSucThreshold) {
		this.unSucThreshold = unSucThreshold;
	}

	public long getContinuousTradeMemberNum() {
		return continuousTradeMemberNum;
	}

	public void setContinuousTradeMemberNum(long continuousTradeMemberNum) {
		this.continuousTradeMemberNum = continuousTradeMemberNum;
	}

	public long getContinuousHowLong() {
		return continuousHowLong;
	}

	public void setContinuousHowLong(long continuousHowLong) {
		this.continuousHowLong = continuousHowLong;
	}

	public long getMinusAccountNum() {
		return minusAccountNum;
	}

	public void setMinusAccountNum(long minusAccountNum) {
		this.minusAccountNum = minusAccountNum;
	}

	public long getInconsistentTradeForYqNum() {
		return inconsistentTradeForYqNum;
	}

	public void setInconsistentTradeForYqNum(long inconsistentTradeForYqNum) {
		this.inconsistentTradeForYqNum = inconsistentTradeForYqNum;
	}

	public long getReceivedRedBagAmountOverSendedTotalNum() {
		return receivedRedBagAmountOverSendedTotalNum;
	}

	public void setReceivedRedBagAmountOverSendedTotalNum(
			long receivedRedBagAmountOverSendedTotalNum) {
		this.receivedRedBagAmountOverSendedTotalNum = receivedRedBagAmountOverSendedTotalNum;
	}

	public long getReceivedRedBagNumOverSendedTotalNum() {
		return receivedRedBagNumOverSendedTotalNum;
	}

	public void setReceivedRedBagNumOverSendedTotalNum(
			long receivedRedBagNumOverSendedTotalNum) {
		this.receivedRedBagNumOverSendedTotalNum = receivedRedBagNumOverSendedTotalNum;
	}

	public long getSmallRedBagNotEqualBigRedBag() {
		return smallRedBagNotEqualBigRedBag;
	}

	public void setSmallRedBagNotEqualBigRedBag(long smallRedBagNotEqualBigRedBag) {
		this.smallRedBagNotEqualBigRedBag = smallRedBagNotEqualBigRedBag;
	}

	public long getOneMemGetRedBagServalTimes() {
		return oneMemGetRedBagServalTimes;
	}

	public void setOneMemGetRedBagServalTimes(long oneMemGetRedBagServalTimes) {
		this.oneMemGetRedBagServalTimes = oneMemGetRedBagServalTimes;
	}

	public long getOneRedBagAmountOverTenThousand() {
		return oneRedBagAmountOverTenThousand;
	}

	public void setOneRedBagAmountOverTenThousand(
			long oneRedBagAmountOverTenThousand) {
		this.oneRedBagAmountOverTenThousand = oneRedBagAmountOverTenThousand;
	}

	public long getOneMemSendRedBagOverTwoHunThousand() {
		return oneMemSendRedBagOverTwoHunThousand;
	}

	public void setOneMemSendRedBagOverTwoHunThousand(
			long oneMemSendRedBagOverTwoHunThousand) {
		this.oneMemSendRedBagOverTwoHunThousand = oneMemSendRedBagOverTwoHunThousand;
	}

	public List<WarnMemberDTO> getPurchaseSumAmtWarnList() {
		return purchaseSumAmtWarnList;
	}

	public void setPurchaseSumAmtWarnList(List<WarnMemberDTO> purchaseSumAmtWarnList) {
		this.purchaseSumAmtWarnList = purchaseSumAmtWarnList;
	}

}
