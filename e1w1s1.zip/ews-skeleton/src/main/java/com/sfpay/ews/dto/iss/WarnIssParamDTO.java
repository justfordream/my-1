package com.sfpay.ews.dto.iss;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：理赔统付（ISS）,监控指标参数DTO
 *	类描述：
 *
 * @author 700316
 * @version 2015-1-4 上午10:17:28
 */
public class WarnIssParamDTO extends BaseEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7036103815708988367L;

	/**
	 * 指标二（ISS0002）:ISS付款申请记录数
	 */
	private long issPayRecordNum;
	
	/**
	 * 指标二（ISS0002）:ACQ应付款记录数
	 */
	private long acqToBePayedRecordNum;
	
	/**
	 * 指标一（ISS0001）:ISS付款申请记录表当天 “发送中”记录集合有重复编号记录数
	 */
	private long issPayDuplicateNum;
	
	/**
	 * 指标一（ISS0001）:收单ACQ中外部付款信息表ISS来源记录集合存在外部交易订单编号记录数
	 */
	private long acqRecDuplicateNum;
	
	/**
	 * 指标三（ISS0003）:ISS付款申请记录 金额合计
	 */
	private long issPayTotalAmt;
	
	/**
	 * 指标三（ISS0003）:ACQ应付款记录金额合计
	 */
	private long acqToBePayedTotalAmt;
	
	/**
	 * 监控日期
	 */
	private String queryDate;

	public String getQueryDate() {
		return queryDate;
	}

	public void setQueryDate(String queryDate) {
		this.queryDate = queryDate;
	}

	public long getIssPayTotalAmt() {
		return issPayTotalAmt;
	}

	public void setIssPayTotalAmt(long issPayTotalAmt) {
		this.issPayTotalAmt = issPayTotalAmt;
	}
	
	public long getAcqToBePayedTotalAmt() {
		return acqToBePayedTotalAmt;
	}

	public void setAcqToBePayedTotalAmt(long acqToBePayedTotalAmt) {
		this.acqToBePayedTotalAmt = acqToBePayedTotalAmt;
	}

	public long getIssPayRecordNum() {
		return issPayRecordNum;
	}

	public void setIssPayRecordNum(long issPayRecordNum) {
		this.issPayRecordNum = issPayRecordNum;
	}

	public long getAcqToBePayedRecordNum() {
		return acqToBePayedRecordNum;
	}

	public void setAcqToBePayedRecordNum(long acqToBePayedRecordNum) {
		this.acqToBePayedRecordNum = acqToBePayedRecordNum;
	}

	public long getIssPayDuplicateNum() {
		return issPayDuplicateNum;
	}

	public void setIssPayDuplicateNum(long issPayDuplicateNum) {
		this.issPayDuplicateNum = issPayDuplicateNum;
	}
	
	public long getAcqRecDuplicateNum() {
		return acqRecDuplicateNum;
	}

	public void setAcqRecDuplicateNum(long acqRecDuplicateNum) {
		this.acqRecDuplicateNum = acqRecDuplicateNum;
	}
}
