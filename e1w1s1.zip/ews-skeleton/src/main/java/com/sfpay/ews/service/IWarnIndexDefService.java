package com.sfpay.ews.service;

import java.util.List;

import com.sfpay.ews.dto.WarnIndexDefDTO;
import com.sfpay.ews.dto.WarnOnePageDTO;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 指标定义的接口
 * @author 575740
 *
 */
public interface IWarnIndexDefService {

	/**
	 * 根据编号查找一个预警指标
	 * @param indexNo
	 * @param isValid 是否有效 Y 有效， N 无效
	 * @return
	 * @throws ServiceException
	 */
	public WarnIndexDefDTO queryWarnIndexDefByWarnIndexNo(String warnIndexNo,String isValid) throws ServiceException;
	
	/**
	 * 新增或者修改一个指标
	 * @param indexDef
	 * @throws ServiceException
	 */
	public void saveOrUpdateWarnIndexDef(WarnIndexDefDTO indexDef) throws ServiceException;
	
	/**
	 * 分页查询指标
	 * @param indexDef
	 * @param index
	 * @param size
	 * @return
	 * @throws ServiceException
	 */
	public IPage<WarnIndexDefDTO> queryWarnIndexDefByPage(WarnIndexDefDTO indexDef,int index,int size) throws ServiceException;
	
	/**
	 * 根据指标编号查询指标
	 * @param indexNo
	 * @return
	 * @throws ServiceException
	 */
	public WarnIndexDefDTO queryWarnIndexDefByIndexNo(String indexNo) throws ServiceException;
	
	/**
	 * 复制属性资料;
	 * @param warnIndexDefDTO
	 * @param warnOnePageDTO
	 */
	public void copyIndexDefDtoToOnePageDto(WarnIndexDefDTO warnIndexDefDTO,WarnOnePageDTO warnOnePageDTO);
	
	/**
	 * 查询所有的指标有效预警来源
	 * @return
	 */
	public List<String> queryAllIndexWarnSource();
	
	/**
	 * 根据预警来源查询所有有效指标
	 * @param warnSource
	 * @return
	 */
	public List<WarnIndexDefDTO> queryIndexDefByWarnSource(String warnSource);
	
}
