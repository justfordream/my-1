package com.sfpay.ews.enums.coreaccount;

/**
 * 核心账户系统的规则;
 * @author 575740
 * 2014-05-23
 */
public enum WarnCoreAccountRule {
	/**
	 * 一个工作时间内没有账户流水号的记录数
	 */
	COREACCOUNT0001
}
