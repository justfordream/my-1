package com.sfpay.ews.service.param.debit;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 公款代扣调度执行服务
 * @author 627247
 * 2014-06-18
 */
public interface IWarnCallDebitRuleService extends IWarnCallDayRuleService {

	/**
	 * 公款代扣每天一次的调度 21:00，指标二：DEBIT0002
	 */
	public void timeToWarnCallOnceRule();
	
	/**
	 * 公款代扣每4小时一次的调度 00:00-24:00，指标：DEBIT0006,DEBIT0007,DEBIT0008,DEBIT0009
	 */
	public void timeToWarnCallFourHourRule();
	
	/**
	 * 公款代扣每6小时一次的调度 08:00-24:00，指标：DEBIT00010,DEBIT0011
	 */
	public void timeToWarnCallSixHourRule();
	
	/**
	 * 公款代扣每1个小时一次的调度 10:00-24:00，指标：DEBIT00013,DEBIT0014
	 */
	public void timeToWarnCallOneHourRule();
}
