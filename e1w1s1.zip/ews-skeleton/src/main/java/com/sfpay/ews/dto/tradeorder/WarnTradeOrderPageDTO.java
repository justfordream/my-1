package com.sfpay.ews.dto.tradeorder;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 核心订单系统的页面显示
 * @author 575740
 * 2014-05-23
 */
public class WarnTradeOrderPageDTO extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 交易订单编号
	 */
	private String orderNo;
	
	/**
	 * 业务流水号
	 */
	private String businessSn;
	
	/**
	 * 订单类型(消费、充值、转账、提现、退款、撤销、赠送、销卡)
	 */
	private String orderType;
	
	/**
	 * 订单金额
	 */
	private Long orderAmt;
	
	/**
	 * 订单状态(进行中、成功、失败)
	 */
	private String orderStatus;
	
	/**
	 * 网银充值、现金充值、现金充值撤销、汇款充值、转账到虚户、付款到银行、提现、线下业务消费、线下业务消费退款、储值卡销卡、B2C收款、B2C退款、赠送业务、赠送业务退款等
	 */
	private String businessType;
	
	/**
	 * 交易开始时间
	 */
	private String beginTime;
	
	/**
	 * 交易结束时间
	 */
	private String endTime;
	

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getBusinessSn() {
		return businessSn;
	}

	public void setBusinessSn(String businessSn) {
		this.businessSn = businessSn;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Long getOrderAmt() {
		return orderAmt;
	}

	public void setOrderAmt(Long orderAmt) {
		this.orderAmt = orderAmt;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
}
