package com.sfpay.ews.dto;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:34:15
 */
public class WarnIndexParamDTO  extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 参数编号
	 */
	private String paramNo;
	
	/**
	 * 参数名称
	 */
	private String paramName;
	
	/**
	 * 参数的设置值
	 */
	private String paramVal;
	
	/**
	 * 参数值的单位
	 */
	private String paramUnit;
	
	/**
	 * 预警来源
	 */
	private String warnSource;
	
	/**
	 * 指标编号
	 */
	private String warnIndexNo;
	
	/**
	 * 指标名称
	 */
	private String warnIndexName;
	
	/**
	 * 备注
	 */
	private String remark;

	/**
	 * 是否使用
	 */
	private String isValid;
	
	/**
	 * 创建人员
	 */
	private String createId;
	
	/**
	 * 更新人员
	 */
	private String updateId;
	
	/**
	 * 创建时间
	 */
	private String createTime;
	
	/**
	 * 更新时间
	 */
	private String updateTime;
	
	
	private Date createTime2;
	
	
	private Date updateTime2;
	
	private String flag;
	
	private String paramOtherNo;

	
	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Date getCreateTime2() {
		return createTime2;
	}

	public void setCreateTime2(Date createTime2) {
		this.createTime2 = createTime2;
	}

	public Date getUpdateTime2() {
		return updateTime2;
	}

	public void setUpdateTime2(Date updateTime2) {
		this.updateTime2 = updateTime2;
	}

	public String getParamNo() {
		return paramNo;
	}

	public void setParamNo(String paramNo) {
		this.paramNo = paramNo;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamVal() {
		return paramVal;
	}

	public void setParamVal(String paramVal) {
		this.paramVal = paramVal;
	}

	public String getParamUnit() {
		return paramUnit;
	}

	public void setParamUnit(String paramUnit) {
		this.paramUnit = paramUnit;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexName() {
		return warnIndexName;
	}

	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public String toString() {
		return "WarnIndexParamDTO [paramNo=" + paramNo + ", paramName="
				+ paramName + ", paramVal=" + paramVal + ", paramUnit="
				+ paramUnit + ", warnSource=" + warnSource + ", warnIndexNo="
				+ warnIndexNo + ", warnIndexName=" + warnIndexName
				+ ", remark=" + remark + ", isValid=" + isValid + ", createId="
				+ createId + ", updateId=" + updateId + ", createTime="
				+ createTime + ", updateTime=" + updateTime + ", createTime2="
				+ createTime2 + ", updateTime2=" + updateTime2 + "]";
	}

	public String getParamOtherNo() {
		return paramOtherNo;
	}

	public void setParamOtherNo(String paramOtherNo) {
		this.paramOtherNo = paramOtherNo;
	}
	
}
