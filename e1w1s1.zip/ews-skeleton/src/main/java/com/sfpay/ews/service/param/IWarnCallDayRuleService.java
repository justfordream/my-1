package com.sfpay.ews.service.param;

import java.util.Date;

import com.sfpay.framework.base.exception.ServiceException;
/**
 * 预警服务的调用,按照日来实现，公共接口
 * @author 575740
 *
 */
public interface IWarnCallDayRuleService {
	
	/**
	 * 调度任务，如：COD的预警
	 */
	public void timeToWarnCallDayRule();
	
	/**
	 * 方法说明：<br> 某一天的诸如：COD预警;
	 * @param execDate
	 * @param flag  接口的参数，可自定义其他服务
	 * @throws ServiceException
	 */
	public void doTask(Date execDate,String flag) throws ServiceException;
	
}
