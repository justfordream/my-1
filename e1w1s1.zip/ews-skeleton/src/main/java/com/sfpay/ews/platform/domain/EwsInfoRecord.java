/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Date;

/**
 * 类说明：预警信息记录表
 * 
 * 类描述：
 * 
 * @author 625288
 * 
 *         2015-3-24
 */
public class EwsInfoRecord implements Serializable {
	/**  */
	private static final long serialVersionUID = -3456246407129470138L;
	/**  */
	// 预警记录编号
	private String id;
	// 指标编号
	private String warnIndexNo;
	// 预警分类 资金类 通道类 系统类 业务类
	private String warnClassCode;
	// 预警分类名称
	private String warnClassName;
	// 预警阶段 事后 BEFORE，事中 DURING，事后 AFTER
	private String warnStage;
	// 预警阶段名称
	private String warnStageName;
	// 预警来源,如COD，营销
	private String warnSource;
	// 预警来源名称
	private String warnSourceName;
	// 风险等级
	private String warnLevel;
	// 风险等级名称
	private String warnLevelName;
	// 信息内容
	private String infoContext;
	// 备注
	private String remark;
	// 监控日期
	private Date monitorDate;
	// 预警异常日期
	private Date warnDate;
	// 操作失效日期
	private Long effectTime;

	private Long overEffectTime;
	// 处理状态
	private String oprStatus;

	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	/**
	 * 非预警信息记录表所有字段
	 */
	// 监控时间起
	private Date warnStartDate;
	// 监控时间止
	private Date warnEndDate;
	// 处理结果说明
	private String oprResult;
	// 处理次数
	private String oprTimes;
	// 预警详细结果数
	private String detailRecordCount;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnClassCode() {
		return warnClassCode;
	}

	public void setWarnClassCode(String warnClassCode) {
		this.warnClassCode = warnClassCode;
	}

	public String getWarnStage() {
		return warnStage;
	}

	public void setWarnStage(String warnStage) {
		this.warnStage = warnStage;
	}

	public String getWarnStageName() {
		return warnStageName;
	}

	public void setWarnStageName(String warnStageName) {
		this.warnStageName = warnStageName;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public String getInfoContext() {
		return infoContext;
	}

	public void setInfoContext(String infoContext) {
		this.infoContext = infoContext;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getMonitorDate() {
		return monitorDate;
	}

	public void setMonitorDate(Date monitorDate) {
		this.monitorDate = monitorDate;
	}

	public Date getWarnDate() {
		return warnDate;
	}

	public void setWarnDate(Date warnDate) {
		this.warnDate = warnDate;
	}

	public String getOprStatus() {
		return oprStatus;
	}

	public void setOprStatus(String oprStatus) {
		this.oprStatus = oprStatus;
	}

	public String getOprResult() {
		return oprResult;
	}

	public void setOprResult(String oprResult) {
		this.oprResult = oprResult;
	}

	public String getOprTimes() {
		return oprTimes;
	}

	public void setOprTimes(String oprTimes) {
		this.oprTimes = oprTimes;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getWarnLevel() {
		return warnLevel;
	}

	public void setWarnLevel(String warnLevel) {
		this.warnLevel = warnLevel;
	}

	public String getWarnLevelName() {
		return warnLevelName;
	}

	public void setWarnLevelName(String warnLevelName) {
		this.warnLevelName = warnLevelName;
	}

	public String getWarnClassName() {
		return warnClassName;
	}

	public void setWarnClassName(String warnClassName) {
		this.warnClassName = warnClassName;
	}

	public Long getEffectTime() {
		return effectTime;
	}

	public void setEffectTime(Long effectTime) {
		this.effectTime = effectTime;
	}

	public Long getOverEffectTime() {
		return overEffectTime;
	}

	public void setOverEffectTime(Long overEffectTime) {
		this.overEffectTime = overEffectTime;
	}

	public String getWarnSourceName() {
		return warnSourceName;
	}

	public void setWarnSourceName(String warnSourceName) {
		this.warnSourceName = warnSourceName;
	}

	public Date getWarnStartDate() {
		return warnStartDate;
	}

	public void setWarnStartDate(Date warnStartDate) {
		this.warnStartDate = warnStartDate;
	}

	public Date getWarnEndDate() {
		return warnEndDate;
	}

	public void setWarnEndDate(Date warnEndDate) {
		this.warnEndDate = warnEndDate;
	}

	public String getDetailRecordCount() {
		return detailRecordCount;
	}

	public void setDetailRecordCount(String detailRecordCount) {
		this.detailRecordCount = detailRecordCount;
	}

	/**
	 * 输出实体的所有字段值
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuilder buf = new StringBuilder();
		Method[] methods = this.getClass().getMethods();
		boolean isFirst = true;
		for (int i = 0, n = methods.length; i < n; i++) {
			try {
				Method method = methods[i];
				if ((method.getModifiers() & Modifier.PUBLIC) == 1
						&& method.getDeclaringClass() != Object.class
						&& (method.getParameterTypes() == null || method.getParameterTypes().length == 0)) {
					String methodName = method.getName();
					String property = null;
					if (methodName.startsWith("get")) {
						property = methodName.substring(3, 4).toLowerCase() + methodName.substring(4);
					} else if (methodName.startsWith("is")) {
						property = methodName.substring(2, 3).toLowerCase() + methodName.substring(3);
					}
					if (property != null) {
						Object value = method.invoke(this, new Object[0]);
						if (isFirst)
							isFirst = false;
						else
							buf.append(",");
						buf.append(property);
						buf.append(":");
						if (value instanceof String)
							buf.append("\"");
						buf.append(value);
						if (value instanceof String)
							buf.append("\"");
					}
				}
			} catch (Exception e) {
				// ignore
			}
		}
		return "{" + buf.toString() + "}";
	}

}
