package com.sfpay.ews.dto;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:35:15
 */
public class WarnOnePageQryDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 预警日期（开始）
	 */
	private String warnDateS;
	
	/**
	 * 预警日期（结束）
	 */
	private String warnDateE;
	
	/**
	 * 是否处理;
	 */
	private String isDealing;
	
	/**
	 * 预警来源
	 */
	private String warnSource; 	
	
	/**
	 * 风险等级
	 */
	private String warnLevel;
	
	/**
	 * 
	 */
	private String warnIndexNo;

	/**
	 * 登陆人的Id
	 */
	private String empId;
	

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getIsDealing() {
		return isDealing;
	}

	public void setIsDealing(String isDealing) {
		this.isDealing = isDealing;
	}

	public String getWarnDateS() {
		return warnDateS;
	}

	public void setWarnDateS(String warnDateS) {
		this.warnDateS = warnDateS;
	}

	public String getWarnDateE() {
		return warnDateE;
	}

	public void setWarnDateE(String warnDateE) {
		this.warnDateE = warnDateE;
	}


	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public String getWarnLevel() {
		return warnLevel;
	}

	public void setWarnLevel(String warnLevel) {
		this.warnLevel = warnLevel;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}	
	
}
