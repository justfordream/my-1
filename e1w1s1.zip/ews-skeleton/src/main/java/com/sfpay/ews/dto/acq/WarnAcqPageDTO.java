package com.sfpay.ews.dto.acq;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 银企预警监测的资料，在明细中显示；
 * @author 575740
 * 
 */
public class WarnAcqPageDTO  extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 付款编号
	 */
	private String payOutNo;
	
	/**
	 * 外部单号
	 */
	private String tradeOutNo;
	
	/**
	 * 系统来源
	 */
	private String systemSource;
	
	/**
	 * 外部业务流水号
	 */
	private String tradeOutBussinessNo;
	
	/**
	 * 开始时间
	 */
	private String beginTime;
	
	/**
	 * 结束时间
	 */
	private String endTime;
	
	/**
	 * 批次号
	 */
	private String batchCode;
	
	/**
	 * 金额
	 */
	private Long amt;
	
	/**
	 * 状态
	 */
	private String status;
	
	/**
	 * 发送时间
	 */
	private String payBatchDate;
	
	/**
	 * 复核时间
	 */
	private String secCheckDate;
	

	public String getPayOutNo() {
		return payOutNo;
	}

	public void setPayOutNo(String payOutNo) {
		this.payOutNo = payOutNo;
	}

	public String getTradeOutNo() {
		return tradeOutNo;
	}

	public void setTradeOutNo(String tradeOutNo) {
		this.tradeOutNo = tradeOutNo;
	}

	public String getSystemSource() {
		return systemSource;
	}

	public void setSystemSource(String systemSource) {
		this.systemSource = systemSource;
	}

	public String getTradeOutBussinessNo() {
		return tradeOutBussinessNo;
	}

	public void setTradeOutBussinessNo(String tradeOutBussinessNo) {
		this.tradeOutBussinessNo = tradeOutBussinessNo;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getBatchCode() {
		return batchCode;
	}

	public void setBatchCode(String batchCode) {
		this.batchCode = batchCode;
	}

	public Long getAmt() {
		return amt;
	}

	public void setAmt(Long amt) {
		this.amt = amt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPayBatchDate() {
		return payBatchDate;
	}

	public void setPayBatchDate(String payBatchDate) {
		this.payBatchDate = payBatchDate;
	}

	public String getSecCheckDate() {
		return secCheckDate;
	}

	public void setSecCheckDate(String secCheckDate) {
		this.secCheckDate = secCheckDate;
	}
	

}
