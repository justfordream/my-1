package com.sfpay.ews.dto;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:34:45
 */
public class WarnMemberDTO {

	/**
	 * 会员号
	 */
	private String memberNo;
	
	/**
	 * 规则代码
	 */
	private String ruleCode;
	
	/**
	 * 规则名称
	 */
	private String ruleName;
	
	/**
	 * 会员名称
	 */
	private String memberName;
	
	public String getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}

	public String getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	
}
