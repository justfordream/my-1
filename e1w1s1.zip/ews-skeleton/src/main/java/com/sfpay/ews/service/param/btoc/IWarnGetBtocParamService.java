package com.sfpay.ews.service.param.btoc;

import com.sfpay.ews.dto.btoc.WarnBtocPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * B2C预警参数的获取服务;
 * @author 575740
 * 2014-05-09
 */
public interface IWarnGetBtocParamService {
	
	/**
	 * 规则一:A1:一段时间交易收单的记录
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColAllNum(String qryDate,float paramDay) throws ServiceException;
	
	
	/**
	 * 规则一:A2: 一段时间交易收单成功的记录
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColSuccessNum(String qryDate,float paramDay) throws ServiceException;
	
	/**
	 * 规则一:A1:一段时间交易收单的记录(按照渠道 B2C, 银行区分)
	 * @param qryBeginTime 开始时间，如：查询1小时范围内
	 * @param qryEndTime   结束时间
	 * @param channelCode 参数
	 * @param bankCodes 以IN 'ICBC','' 等资料处理;
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColBankAllNum(String qryBeginTime,String qryEndTime,String channelCode,String bankCodes) throws ServiceException;
	
	
	/**
	 * 规则一:A2: 一段时间交易收单成功的记录(按照渠道 B2C, 银行区分)
	 * @param qryBeginTime 开始时间，如：查询1小时范围内
	 * @param qryEndTime   结束时间
	 * @param channelCode 参数
	 * @param bankCodes 以IN 'ICBC','' 等资料处理;
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColBankSuccessNum(String qryBeginTime,String qryEndTime,String channelCode,String bankCodes) throws ServiceException;
	
	
	
	/**
	 * 规则二:A1:一段时间交易收单的记录
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColSignAllNum(String qryDate,float paramDay) throws ServiceException;
	
	/**
	 * 规则二: A2:一段时间内签名失败率较高的记录
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColSignFailNum(String qryDate,float paramDay) throws ServiceException;
	
	/**
	 * 规则二:A1:一段时间交易收单的记录(按照渠道 B2C, 银行区分)
	 * @param qryBeginTime 开始时间，如：查询1小时范围内
	 * @param qryEndTime   结束时间
	 * @param channelCode 参数
	 * @param bankCodes 以IN 'ICBC','' 等资料处理;
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColBankSignAllNum(String qryBeginTime,String qryEndTime,String channelCode,String bankCodes) throws ServiceException;
	
	/**
	 * 规则二: A2:一段时间内签名失败率较高的记录(按照渠道 B2C, 银行区分)
	 * @param qryBeginTime 开始时间，如：查询1小时范围内
	 * @param qryEndTime   结束时间
	 * @param channelCode  参数
	 * @param bankCodes 以IN 'ICBC','' 等资料处理;
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getColBankSignFailNum(String qryBeginTime,String qryEndTime,String channelCode,String bankCodes) throws ServiceException;
	
	
	/**
	 * 根据dm_acq.collect_info的id获取该行资料，id存储于ews_warning_tb的buss_id;
	 * @param id 参数
	 * @return 返回对象
	 * @throws ServiceException 自定义异常 
	 */
	public WarnBtocPageDTO getCollectInfoById(long id)throws ServiceException;
	
	/**
	 * 批量保存：规则一：2.4.1  监控指标(事中)一段时间交易失败率较高指标
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnBtocRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常 
	 */
	public int saveBatchUnColSuccess(String qryDate,float paramDay,String warnNo,String expExpLain,String warnBtocRule,long paramRowNum) throws ServiceException;
	
	/**
	 * 批量保存：规则二： 2.4.2 监控指标(事中)一段时间内签名失败率较高指标 
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnBtocRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常 
	 */
	public int saveBatchColSignFail(String qryDate,float paramDay,String warnNo,String expExpLain,String warnBtocRule,long paramRowNum) throws ServiceException;
	
	/**
	 * 批量保存：规则一：2.4.1  监控指标(事中)一段时间交易失败率较高指标
	 * @param qryBeginTime 开始时间，如：查询1小时范围内
	 * @param qryEndTime   结束时间
	 * @param channelCode 参数
	 * @param bankCodes 以IN 'ICBC','' 等资料处理;
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnBtocRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常 
	 */
	public int saveBatchBankUnColSuccess(String qryBeginTime,String qryEndTime,String channelCode,String bankCodes,String warnNo,String expExpLain,String warnBtocRule,long paramRowNum) throws ServiceException;
	
	/**
	 * 批量保存：规则二： 2.4.2 监控指标(事中)一段时间内签名失败率较高指标 
	 * @param qryBeginTime 开始时间，如：查询1小时范围内
	 * @param qryEndTime   结束时间
	 * @param channelCode  参数
	 * @param bankCodes 以IN 'ICBC','' 等资料处理;
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnBtocRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常 
	 */
	public int saveBatchBankColSignFail(String qryBeginTime,String qryEndTime,String channelCode,String bankCodes,String warnNo,String expExpLain,String warnBtocRule,long paramRowNum) throws ServiceException;
	
	
}
