package com.sfpay.ews.dto.sypay;

public class RmSypayWarnDTO {
	// 序列
	private Long id;
	// 会员号
	private String memberNo;
	// 中规则代码
	private String warnIndexNo;
	// 中规则名称
	private String warnIndexName;
	// 会员名称
	private String memberName;
	private String loginName;
	// 告警时间 yyyy-mm-dd hh24:mi:ss
	private String warnTime;
	// 预警信息ID
	private String infoRecordId;
	// 状态 待审核：告警的默认状态 -  PENDING_AUDIT（默认） 无风险：风控的审核结果 - NO_RISK 冻结：风控的审核结果和预警自动冻结 - FREEZE
	private String status;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getWarnIndexNo() {
		return warnIndexNo;
	}
	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}
	public String getWarnIndexName() {
		return warnIndexName;
	}
	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getWarnTime() {
		return warnTime;
	}
	public void setWarnTime(String warnTime) {
		this.warnTime = warnTime;
	}
	public String getInfoRecordId() {
		return infoRecordId;
	}
	public void setInfoRecordId(String infoRecordId) {
		this.infoRecordId = infoRecordId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
