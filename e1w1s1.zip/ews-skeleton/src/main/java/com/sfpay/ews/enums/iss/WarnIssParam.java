package com.sfpay.ews.enums.iss;

/**
 * Description: 理赔统付监控预警JOB调度相关参数
 * @author 700316
 *
 */
public enum WarnIssParam {
	/**
	 * 理赔统付,每天一次的调度（1:00,13:00）
	 * 
	 */
	DAY
	
}
