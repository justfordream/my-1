/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 预警指标参数表实体
 * 
 * @author 625288
 * 
 */
public class EwsIndexParam extends BaseEntity {
	private static final long serialVersionUID = 3357100102532951328L;

	// 参数名称
	private String paramName;
	// 参数的设置值
	private String paramVal;
	// 参数值的单位
	private String paramUnit;
	// 指标编号
	private String warnIndexNo;
	// 备注
	private String remark;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamVal() {
		return paramVal;
	}

	public void setParamVal(String paramVal) {
		this.paramVal = paramVal;
	}

	public String getParamUnit() {
		return paramUnit;
	}

	public void setParamUnit(String paramUnit) {
		this.paramUnit = paramUnit;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
