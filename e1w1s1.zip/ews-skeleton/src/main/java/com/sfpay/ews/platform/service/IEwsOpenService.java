/**
 * 
 */
package com.sfpay.ews.platform.service;

import java.util.List;
import java.util.Map;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：监控预警提供给外部的数据库表操作接口
 *
 * 类描述：这些表必须在EWS_INDEX_SQL表中TABLE_NAME有定义。
 * @author 625288
 *
 * 2015-4-3
 */
public interface IEwsOpenService {
	/**
	 * 更新表数据
	 * @param tableName 表名，不能为空
	 * @param updateColumnMap 更新的列字段的Map，key为列名，value为要更新的值，不可为空
	 * @param whereMap 更新条件，可以为空
	 * @return 更新记录数
	 * @throws ServiceException 自定义异常
	 */

	public int updateData(String tableName, Map<String, Object> updateColumnMap, 
			Map<String, Object> whereMap) throws ServiceException;
	
	/**
	 * 批量更新表数据
	 * @param tableName 表名，不能为空
	 * @param updateColumnMap 更新的列字段的Map，key为列名，value为要更新的值，不可为空
	 * @param whereMapList 更新条件列表，即多个更新条件，可以为空
	 * @return 更新记录数
	 * @throws ServiceException 自定义异常
	 */
	public int updateMultiData(String tableName, Map<String, Object> updateColumnMap, 
			List<Map<String, Object>> whereMapList) throws ServiceException;
}
