package com.sfpay.ews.service.param.btoc;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;
/**
 * B2C预警调用的获取服务;
 * @author 575740
 * 2014-05-09
 */
public interface IWarnCallBtocRuleService extends IWarnCallDayRuleService {
	/**
	 * 什么也不做;
	 */
}
