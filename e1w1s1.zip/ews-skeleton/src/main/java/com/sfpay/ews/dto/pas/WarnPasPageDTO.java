package com.sfpay.ews.dto.pas;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 垫付货款 预警监测的资料，在明细中显示；
 * @author 575740
 * 2014-06-17
 */
public class WarnPasPageDTO extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * COD卡号
	 */
	private String codNo;
	
	/**
	 * 提现申请号
	 */
	private String lendingNo;
	
	/**
	 * 付款编号
	 */
	private String payoutNo;
	
	/**
	 * 提现金额
	 */
	private Long lendingAmt;
	
	/**
	 * 提现时间;
	 */
	private String lendingTime;
	

	/**
	 * 状态
	 */
	private String lendingStatus;
	

	public String getCodNo() {
		return codNo;
	}

	public void setCodNo(String codNo) {
		this.codNo = codNo;
	}

	public String getLendingNo() {
		return lendingNo;
	}

	public void setLendingNo(String lendingNo) {
		this.lendingNo = lendingNo;
	}

	public String getPayoutNo() {
		return payoutNo;
	}

	public void setPayoutNo(String payoutNo) {
		this.payoutNo = payoutNo;
	}

	public Long getLendingAmt() {
		return lendingAmt;
	}

	public void setLendingAmt(Long lendingAmt) {
		this.lendingAmt = lendingAmt;
	}

	public String getLendingStatus() {
		return lendingStatus;
	}

	public void setLendingStatus(String lendingStatus) {
		this.lendingStatus = lendingStatus;
	}
	
	public String getLendingTime() {
		return lendingTime;
	}

	public void setLendingTime(String lendingTime) {
		this.lendingTime = lendingTime;
	}

}
