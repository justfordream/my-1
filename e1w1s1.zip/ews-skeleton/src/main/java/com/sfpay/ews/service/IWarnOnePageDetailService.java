package com.sfpay.ews.service;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 接口说明：
 *     针对不同的系统warnSource，对不同系统的明细获取，获取不同的实现，
 *     所以该接口的实现怎对不同系统较多;
 * @author 575740
 *
 */
public interface IWarnOnePageDetailService {
	/**
	 * 工厂方法: 根据warnSource来获取；
	 * 返回的WarnOnePageDetailDTO是个父类，有明细有继承;
	 * @param warnNo 告警编号
	 * @param warnSource 系统来源
	 * @param bussId 系统的业务ID;
	 * @param remark 备注，作为代码编写使用
	 * @return
	 * @throws ServiceException
	 */
	public WarnOnePageDetailDTO queryOnePageDetailBySource(String warnNo,String warnSource,String bussId,String remark) throws ServiceException;
	
	
}
