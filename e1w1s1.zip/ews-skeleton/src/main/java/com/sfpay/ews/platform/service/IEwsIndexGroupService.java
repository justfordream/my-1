/**
 * 
 */
package com.sfpay.ews.platform.service;

import java.util.List;

import com.sfpay.ews.platform.domain.EwsIndexGroup;

/**
 * 类说明：预警指标组服务接口
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
public interface IEwsIndexGroupService {
	/**
	 * 查询所有的预警指标组
	 * @return 预警指标组集合
	 */
	public List<EwsIndexGroup> queryAllEwsIndexGroup();
	
	/**
	 * 根据预警组编号查询预警指标组
	 * @param groupNo 预警组编号
	 * @return 预警指标组
	 */
	public EwsIndexGroup queryEwsIndexGroupByGroupNo(String groupNo);
}
