package com.sfpay.ews.service.param.acq;

import com.sfpay.ews.dto.acq.WarnAcqPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * Acq预警参数的获取服务;
 * @author 575740
 * 2014-05-09
 */
public interface IWarnGetAcqParamService {
	
	/**
	 * 2.3.1  银企付款一段时间内出现实付金额大于应付金额记录统计  
	 * @param qryDate 查询时间
	 * @param paramDay 时间参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPayOutMoreNum(String qryDate,float paramDay) throws ServiceException;
	
	/**
	 * 2.3.2  银企直联一段时间出现的状态为UNKOWN及超过配置时间的记录  
	 * @param qryDate 查询时间
	 * @param paramDay 时间参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getBatchUnkowNum(String qryDate,float paramDay) throws ServiceException;
	
	/**
	 * 2.3.3  银企直联已受理并且超过指定配置时间未得到结果的记录
	 * @param qryDate 查询时间
	 * @param paramDay 时间参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getBatchRecUndoNum(String qryDate,float paramDay) throws ServiceException;
	
	
	/**
	 * 根据dm_acq.payout_info的id获取该行资料，id存储于ews_warning_tb的buss_id;
	 * @param id dm_acq.payout_info的id
	 * @return  返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnAcqPageDTO getPayOutInfoById(long id) throws  ServiceException;
	
	/**
	 * 根据dm_acq.batch_info的id获取该行资料，id存储于ews_warning_tb的buss_id;
	 * @param id dm_acq.batch_info的id
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnAcqPageDTO getBatchInfoById(long id) throws  ServiceException;
	
	/**
	 * 批量保存：2.3.1  银企直联已受理并且超过指定配置时间未得到结果的记录
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnAcqRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchPayOutMore(String qryDate,float paramDay,String warnNo,String expExpLain,String warnAcqRule,long paramRowNum) throws ServiceException;
	
	
	/**
	 * 批量保存：2.3.2  银企付款一段时间内出现实付金额大于应付金额记录
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnAcqRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchUnkowData(String qryDate,float paramDay,String warnNo,String expExpLain,String warnAcqRule,long paramRowNum) throws ServiceException;
	
	/**
	 * 批量保存：2.3.3  银企直联一段时间出现的状态为UNKOWN及超过配置时间的记录
	 * @param qryDate 参数
	 * @param paramDay 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnAcqRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchRecUndoData(String qryDate,float paramDay,String warnNo,String expExpLain,String warnAcqRule,long paramRowNum) throws ServiceException;
	
	
	/**
	 * 以上是 二期的三个指标。
	 * 以下是四期的五个指标;
	 */
	
	/**
	 * 指标：ACQ0004 银企重复付款的资料记录数 0-24点，每2分钟监控  
	 * 
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param paramSecond 多长时间范围内(秒) 两分钟  120;
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public Long getSedRepeatNum(String qryBeginTime,String qryEndTime,Long paramSecond) throws ServiceException;
	
	/**
	 * 指标：ACQ005  某段时间银企外部交易订单号或外部交易业务唯一订单号重复 每小时运行一次;
	 *  外部交易订单号
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public Long getOutNoRepeatNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 指标：ACQ005  某段时间银企外部交易订单号或外部交易业务唯一订单号重复 每小时运行一次;
	 * 外部交易业务唯一订单号 
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public Long getOutBsnRepeatNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	
	/**
	 * 指标：ACQ006  某段时间内银企抵扣金额较大（为负数）的记录数每小时运行一次;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @param tdMoneyAmt 金额负数的阀值  比如 -1000000 表示 10000元;
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public Long getNegHourNum(String qryBeginTime,String qryEndTime,Long tdMoneyAmt) throws ServiceException;
	
	/**
	 * 指标：ACQ007  某段时间内银企抵扣（为负数）的总记录数  每小时运行一次,累计计算0-12,0-14的记录数;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public Long getNegSumNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 指标：ACQ008  银企某段时间内手工录入审核重复记录数;
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public Long getOmsRepeatNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * 指标：ACQ0004 银企重复付款的资料记录数 0-24点，每2分钟监控  
	 * 如果有资料，就批量保存;
	 * @param qryBeginTime 参数
	 * @param qryEndTime 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnPasRule 参数
	 * @param paramRowNum 参数
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchSedRepeatData(String qryBeginTime,String qryEndTime,Long paramSecond,String warnNo,String expExpLain,String warnAcqRule,long paramRowNum) throws ServiceException;
	
	/**
	 * 指标：ACQ005  某段时间银企外部交易订单号或外部交易业务唯一订单号重复 每小时运行一次;
	 * @param qryBeginTime  参数
	 * @param qryEndTime 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnAcqRule 参数
	 * @param paramRowNum 参数
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchOutRepeatData(String qryBeginTime,String qryEndTime,String warnNo,String expExpLain,String warnAcqRule,long paramRowNum) throws ServiceException;
	
	/**
	 * ACQ006  某段时间内银企抵扣金额较大（为负数）的记录数每小时运行一次;
	 * @param qryBeginTime 参数
	 * @param qryEndTime 参数
	 * @param tdMoneyAmt 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnAcqRule 参数
	 * @param paramRowNum 参数
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchNegHourData(String qryBeginTime,String qryEndTime,Long tdMoneyAmt,String warnNo,String expExpLain,String warnAcqRule,long paramRowNum) throws ServiceException;
	
	
	/**
	 * 指标：ACQ008  银企某段时间内手工录入审核重复记录数;
	 * @param qryBeginTime 参数
	 * @param qryEndTime 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnAcqRule 参数
	 * @param paramRowNum 参数
	 * @return 记录数
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchOmsRepeatData(String qryBeginTime,String qryEndTime,String warnNo,String expExpLain,String warnAcqRule,long paramRowNum) throws ServiceException;
	
}
