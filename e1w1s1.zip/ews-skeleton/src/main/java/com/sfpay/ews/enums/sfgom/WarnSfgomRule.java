package com.sfpay.ews.enums.sfgom;

/**
 * 安心购指标
 * @author 627247
 * 2014-06-19
 */
public enum WarnSfgomRule {
	/**
	 * 昨日收货时间已过期，但未自动确认收货的纠纷期订单数量
	 */
	SFGOM0001,
	/**
	 * 昨日买家处理纠纷已过期，但未自动处理的纠纷期订单
	 */
	SFGOM0002,
	/**
	 * 昨日商家处理纠纷已过期，但未自动处理的纠纷期订单
	 */
	SFGOM0003,
	/**
	 * 昨日保障期已过期，但未自动结束保障期的订单
	 */
	SFGOM0004,
}
