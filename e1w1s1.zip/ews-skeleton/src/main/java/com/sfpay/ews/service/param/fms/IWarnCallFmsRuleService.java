package com.sfpay.ews.service.param.fms;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 米兰港(融资平台) 预警监测任务调度；
 * @author 575740
 * 2014-06-19
 */
public interface IWarnCallFmsRuleService  extends IWarnCallDayRuleService {

	/**
	 * 因每天执行一次，什么也不做;
	 */
}
