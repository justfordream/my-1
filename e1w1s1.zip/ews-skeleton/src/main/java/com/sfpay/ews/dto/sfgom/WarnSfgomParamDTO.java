package com.sfpay.ews.dto.sfgom;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 安心购指标参数
 * @author 627247
 * 2014-06-19
 */
public class WarnSfgomParamDTO extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 昨日收货时间已过期，但未自动确认收货的纠纷期订单数量
	 */
	private long indexOneTradeNum;
	/**
	 * 指标一阀值
	 */
	private long indexOneThreshold;
	
	/**
	 * 昨日买家处理纠纷已过期，但未自动处理的纠纷期订单
	 */
	private long indexTwoTradeNum;
	/**
	 * 指标二阀值
	 */
	private long indexTwoThreshold;
	
	/**
	 * 昨日商家处理纠纷已过期，但未自动处理的纠纷期订单
	 */
	private long indexThreeTradeNum;
	/**
	 * 指标三阀值
	 */
	private long indexThreeThreshold;
	
	/**
	 * 昨日保障期已过期，但未自动结束保障期的订单
	 */
	private long indexFourTradeNum;
	/**
	 * 指标四阀值
	 */
	private long indexFourThreshold;
	
	public long getIndexOneTradeNum() {
		return indexOneTradeNum;
	}
	public void setIndexOneTradeNum(long indexOneTradeNum) {
		this.indexOneTradeNum = indexOneTradeNum;
	}
	public long getIndexOneThreshold() {
		return indexOneThreshold;
	}
	public void setIndexOneThreshold(long indexOneThreshold) {
		this.indexOneThreshold = indexOneThreshold;
	}
	public long getIndexTwoTradeNum() {
		return indexTwoTradeNum;
	}
	public void setIndexTwoTradeNum(long indexTwoTradeNum) {
		this.indexTwoTradeNum = indexTwoTradeNum;
	}
	public long getIndexTwoThreshold() {
		return indexTwoThreshold;
	}
	public void setIndexTwoThreshold(long indexTwoThreshold) {
		this.indexTwoThreshold = indexTwoThreshold;
	}
	public long getIndexThreeTradeNum() {
		return indexThreeTradeNum;
	}
	public void setIndexThreeTradeNum(long indexThreeTradeNum) {
		this.indexThreeTradeNum = indexThreeTradeNum;
	}
	public long getIndexThreeThreshold() {
		return indexThreeThreshold;
	}
	public void setIndexThreeThreshold(long indexThreeThreshold) {
		this.indexThreeThreshold = indexThreeThreshold;
	}
	public long getIndexFourTradeNum() {
		return indexFourTradeNum;
	}
	public void setIndexFourTradeNum(long indexFourTradeNum) {
		this.indexFourTradeNum = indexFourTradeNum;
	}
	public long getIndexFourThreshold() {
		return indexFourThreshold;
	}
	public void setIndexFourThreshold(long indexFourThreshold) {
		this.indexFourThreshold = indexFourThreshold;
	}
	
}
