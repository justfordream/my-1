package com.sfpay.ews.dto;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 应用在查询某个时间范围内部的开始时间和结束时间；
 * @author 575740
 *
 */
public class WarnTimeParamDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 某个时间范围的开始时间
	 */
	private String beginTime;
	
	/**
	 * 某个时间范围的结束时间
	 */
	private String endTime;
	
	/**
	 * 某个时间范围比结束时间多一点的时间，如多5分钟、10分钟等
	 */
	private String endTimeMore;
	
	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getEndTimeMore() {
		return endTimeMore;
	}

	public void setEndTimeMore(String endTimeMore) {
		this.endTimeMore = endTimeMore;
	}

}
