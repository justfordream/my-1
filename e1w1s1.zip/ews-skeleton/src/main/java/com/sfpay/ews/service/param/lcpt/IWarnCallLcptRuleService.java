package com.sfpay.ews.service.param.lcpt;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

public interface IWarnCallLcptRuleService extends IWarnCallDayRuleService{
	/**
	 * 每小时调度一次 指标7,8,9,10,11,12 (00:00-24:00)
	 */
	public void timeToWarnCallByHour();
	
	
}
