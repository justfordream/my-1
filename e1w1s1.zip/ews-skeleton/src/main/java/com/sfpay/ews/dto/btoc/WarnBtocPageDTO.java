package com.sfpay.ews.dto.btoc;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 银企B2C预警监测的资料，在明细中显示；
 * @author 575740
 * 
 */
public class WarnBtocPageDTO  extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 收单编号
	 */
	private String collectNo;
	
	/**
	 * 银行请求流水号
	 */
	private String reqBankSn;
	
	/**
	 * 金额
	 */
	private Long amt;
	
	/**
	 * 状态
	 */
	private String status;
	
	/**
	 * 开始时间
	 */
	private String beginTime;
	
	/**
	 * 结束时间
	 */
	private String endTime;
	
	/**
	 * 渠道编码
	 */
	private String channelCode;
	
	/**
	 * 银行代码;
	 */
	private String bankCode;

	public String getCollectNo() {
		return collectNo;
	}

	public void setCollectNo(String collectNo) {
		this.collectNo = collectNo;
	}

	public String getReqBankSn() {
		return reqBankSn;
	}

	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}

	public Long getAmt() {
		return amt;
	}

	public void setAmt(Long amt) {
		this.amt = amt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	
	
}
