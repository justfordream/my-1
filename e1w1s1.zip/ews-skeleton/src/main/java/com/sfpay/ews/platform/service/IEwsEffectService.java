/**
 * 
 */
package com.sfpay.ews.platform.service;
import com.sfpay.ews.platform.domain.EwsEffect;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 类说明：预警实效表服务接口
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-26
 */
public interface IEwsEffectService {
	/**
	 * 通过实效代码查询实效对象
	 * @param effectCode 时效代码
	 * @return 时效对象
	 */
	public EwsEffect queryByEffectCode(String effectCode);
	
	/**
	 * 通过实效代码查询实效对象
	 * @param effectCode 时效代码
	 * @return 时效对象
	 */
	public EwsEffect queryByWarnClassAndWarnLevel(String warnClassCode, String warnLevel);
	
	/**
	 * 通过ID查询
	 * @param id 时效记录主键
	 * @return 时效对象
	 */
	public EwsEffect queryById(long id);
	
	/**
	 * 新增预警实效
	 * @param ewsEffect 时效对象
	 */
	public void addEwsEffect(EwsEffect ewsEffect);
	
	/**
	 * 更新预警实效
	 * @param ewsEffect 时效对象
	 */
	public void updateEwsEffect(EwsEffect ewsEffect);
	
	/**
	 * 删除预警实效
	 * @param id 时效主键
	 */
	public void deleteEwsEffect(long id);
	
	/**
	 * 
	 * 方法：分页查询预警时效记录
	 * 方法说明：
	 *
	 * @param ewsEffect 时效对象
	 * @param index 页索引
	 * @param size 页大小
	 * @return 分页数据
	 */
	public IPage<EwsEffect> selectEwsEffectByPage(EwsEffect ewsEffect,int index,int size);
	
	
}
