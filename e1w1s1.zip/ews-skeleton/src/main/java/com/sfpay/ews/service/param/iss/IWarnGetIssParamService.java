package com.sfpay.ews.service.param.iss;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * Description:
 * @author 700316
 *
 */
public interface IWarnGetIssParamService {
	/**
	 * add by yurongjie 2014-12-31 
	 * 指标二（ISS0002）:监控指标(事前)-付款申请记录数与应付款记录数等值
	 * 查询:ISS付款申请记录数 
	 * @param qryDate
	 */
	public Long getIssPayRecordNum(String qryDate) throws ServiceException;
	
	/**
	 * add by yurongjie 2014-12-31
	 * 指标二（ISS0002）:监控指标(事前)-付款申请记录数与应付款记录数等值
	 * 查询:ACQ应付款记录数
	 * @param qryDate
	 */
	public Long getAcqToBePayedRecordNum(String qryDate) throws ServiceException;
	
	/**
	 * add by yurongjie 2014-12-31 
	 * 指标一（ISS0001）:监控指标(事前)-重复付款记录监控
	 * 查询:ISS付款申请记录表当天 “发送中”记录集合有重复编号记录数
	 * @param qryDate
	 */
	public Long getIssPayDuplicateNum(String qryDate) throws ServiceException;
	
	/**
	 * add by yurongjie 2014-12-31 
	 * 指标一（ISS0001）:监控指标(事前)-重复付款记录监控
	 * 查询:收单ACQ 中外部付款信息表ISS来源记录集合存在外部交易订单编号,记录数
	 * @param qryDate
	 */
	public Long getAcqRecDuplicateNum(String qryDate) throws ServiceException;
	
	/**
	 * add by yurongjie 2014-1-4 
	 * 指标三（ISS0003）:对比ISS和ACQ付款申请的金额合计是否相符
	 * 查询:ISS付款申请记录 金额合计
	 * @param qryDate
	 */
	public Long getIssPayTotalAmt(String qryDate) throws ServiceException;
	
	/**
	 * add by yurongjie 2014-1-4 
	 * 指标三（ISS0003）:对比ISS和ACQ付款申请的金额合计是否相符
	 * 查询:ACQ应付款记录金额合计
	 * @param qryDate
	 */
	public Long getAcqToBePayedTotalAmt(String qryDate) throws ServiceException;
}
