/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：预警指标组表实体Bean
 * 
 * 类描述：
 * 
 * @author 625288
 * 
 *         2015-3-11
 */
public class EwsIndexGroup extends BaseEntity {
	private static final long serialVersionUID = 2952253250770044249L;
	// 组编号
	private String warnIndexGroupNo;
	// 组名称
	private String warnIndexGroupName;
	// 组来源
	private String warnIndexGroupSource;
	// 指标邮件标题模板中可以使用占位符，即${param1}，其中的参数必须是【指标SQL】的结果集或参数集中存在的。
	private String mailTitleTemplate;
	// 指标邮件正文模板中可以使用占位符，即${param1}，其中的参数必须是【指标SQL】的结果集或参数集中存在的。 其中，预定义的关键字如下：
	// rownum：行号 loop和endloop：关键字之间的内容将被循环，循环次数由结果集的行数决定，目前只支持使用一次loop和一次endloop
	// loopbody：系统使用的关键字，模板中应该避免出现该字符串
	private String mailContextTemplate;
	// 基于Quartz的时间表达式
	private String cronExpress;
	// stop 未开始 working 正在执行中
	private String status;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	public String getWarnIndexGroupNo() {
		return warnIndexGroupNo;
	}

	public void setWarnIndexGroupNo(String warnIndexGroupNo) {
		this.warnIndexGroupNo = warnIndexGroupNo;
	}

	public String getWarnIndexGroupName() {
		return warnIndexGroupName;
	}

	public void setWarnIndexGroupName(String warnIndexGroupName) {
		this.warnIndexGroupName = warnIndexGroupName;
	}

	public String getMailTitleTemplate() {
		return mailTitleTemplate;
	}

	public void setMailTitleTemplate(String mailTitleTemplate) {
		this.mailTitleTemplate = mailTitleTemplate;
	}

	public String getMailContextTemplate() {
		return mailContextTemplate;
	}

	public void setMailContextTemplate(String mailContextTemplate) {
		this.mailContextTemplate = mailContextTemplate;
	}

	public String getCronExpress() {
		return cronExpress;
	}

	public void setCronExpress(String cronExpress) {
		this.cronExpress = cronExpress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getWarnIndexGroupSource() {
		return warnIndexGroupSource;
	}

	public void setWarnIndexGroupSource(String warnIndexGroupSource) {
		this.warnIndexGroupSource = warnIndexGroupSource;
	}
}
