package com.sfpay.ews.enums.waybill;

/**
 * 运单预警参数
 * @author 575740
 *
 */
public enum WarnWayBillParam {
	
	/**
	 * A1:昨日交易成功的总运单数
	 */
	TRADEWAYBILLNUM,
	/**
	 * 	A2:昨日交易成功但未在同步表漏抽的运单数
	 */
	TRADMISSINGNUM,
	/**
	 * A3:昨日交易成功已在同步表但未从资科同步的运单数
	 */
	TRADEUNSYSNCNUM,
	/**
	 * A2: XXX日仍存在未同步抄写的运单XXXX笔
	 */
	SYNCWAYBILLNUM
}
