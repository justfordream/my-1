package com.sfpay.ews.dto.cod;

import java.util.List;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * COD系统风险预警监控指标 
 * @author 575740
 * 2014/04/18 
 *
 */
public class WarnCodParamDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * =========================
	 * 监控指标(事前)-重复付款记录监控
	 * 预警阀值  A1  or  A2  or  A3  or  A4  > 0 
	 * 
	 * =========================
	 */
	
	/**
	 * COD付款申请记录表当天“付款中”记录集合有重复编号
	 */
	private Long payingRepeatNum;
	
	/**
	 * COD付款申请记录表当天“付款中”记录集合有重复的记录编号的集合；
	 */
	private List<WarnCodPageDTO> payingRepeatList;
	

	/**
	 * COD付款申请记录表“已付款”记录集合存在付款中的记录编号的数量，
	 * 是List<String>的资料；
	 */
	private Long paySucExitNum;
	
	/**
	 * COD付款申请记录表“已付款”记录集合存在付款中的记录编号
	 */
	private List<WarnCodPageDTO> paySucExitList;
	
	/**
	 * 收单ACQ 中外部付款信息表COD来源记录集合存在外部交易订单编号
	 * PAYOUT_INFO,系统来源PAY_STATUS=’COD’,记录集合；
	 */
	private Long acqExitNum;
	
	/**
	 * 收单ACQ 中外部付款信息表COD来源记录集合存在外部交易订单编号
	 */
	private List<WarnCodPageDTO> acqExitList;
	
	/**
	 * 收单ACQ 中外部付款信息表COD来源记录集合
	 */
	private Long acqOutExitNum;
	
	/**
	 * 收单ACQ 中外部付款信息表COD来源记录集合
	 */
	private List<WarnCodPageDTO> acqOutExitList;
	
	/**
	 * =========================
	 * 监控指标(事前)-付款申请记录数与应付款记录数等值指标
	 * 预警阀值  A1  <>  B1
	 * 
	 * =========================
	 */
	
	/**
	 * COD付款申请记录表“付款中”记录数
	 */
	private Long payingRecordNum;
	
	/**
	 * 收单ACQ外部付款信息表“应付款”记录数
	 */
	private Long tradeRecordNum;
	
	/**
	 * =========================
	 * 2.2.3	监控指标(事前)-付款申请金额与应付款金额等值 
	 * 预警阀值  A1  <>  B1
	 * 
	 * =========================
	 */
	
	/**
	 * COD付款申请记录表当天“付款中”记录金额合计
	 */
	private Long payingMoneyNum;
	
	/**
	 * 收单ACQ外部付款信息表应付记录金额合计
	 */
	private Long tradeMoneyNum;

	public Long getPayingRepeatNum() {
		return payingRepeatNum;
	}

	public void setPayingRepeatNum(Long payingRepeatNum) {
		this.payingRepeatNum = payingRepeatNum;
	}

	public Long getPaySucExitNum() {
		return paySucExitNum;
	}

	public void setPaySucExitNum(Long paySucExitNum) {
		this.paySucExitNum = paySucExitNum;
	}

	public Long getAcqExitNum() {
		return acqExitNum;
	}

	public void setAcqExitNum(Long acqExitNum) {
		this.acqExitNum = acqExitNum;
	}

	public Long getAcqOutExitNum() {
		return acqOutExitNum;
	}

	public void setAcqOutExitNum(Long acqOutExitNum) {
		this.acqOutExitNum = acqOutExitNum;
	}


	public Long getPayingRecordNum() {
		return payingRecordNum;
	}

	public void setPayingRecordNum(Long payingRecordNum) {
		this.payingRecordNum = payingRecordNum;
	}

	public Long getTradeRecordNum() {
		return tradeRecordNum;
	}

	public void setTradeRecordNum(Long tradeRecordNum) {
		this.tradeRecordNum = tradeRecordNum;
	}

	public Long getPayingMoneyNum() {
		return payingMoneyNum;
	}

	public void setPayingMoneyNum(Long payingMoneyNum) {
		this.payingMoneyNum = payingMoneyNum;
	}

	public Long getTradeMoneyNum() {
		return tradeMoneyNum;
	}

	public void setTradeMoneyNum(Long tradeMoneyNum) {
		this.tradeMoneyNum = tradeMoneyNum;
	}

	public List<WarnCodPageDTO> getPayingRepeatList() {
		return payingRepeatList;
	}

	public void setPayingRepeatList(List<WarnCodPageDTO> payingRepeatList) {
		this.payingRepeatList = payingRepeatList;
	}

	public List<WarnCodPageDTO> getPaySucExitList() {
		return paySucExitList;
	}

	public void setPaySucExitList(List<WarnCodPageDTO> paySucExitList) {
		this.paySucExitList = paySucExitList;
	}

	public List<WarnCodPageDTO> getAcqExitList() {
		return acqExitList;
	}

	public void setAcqExitList(List<WarnCodPageDTO> acqExitList) {
		this.acqExitList = acqExitList;
	}

	public List<WarnCodPageDTO> getAcqOutExitList() {
		return acqOutExitList;
	}

	public void setAcqOutExitList(List<WarnCodPageDTO> acqOutExitList) {
		this.acqOutExitList = acqOutExitList;
	}

	
}
