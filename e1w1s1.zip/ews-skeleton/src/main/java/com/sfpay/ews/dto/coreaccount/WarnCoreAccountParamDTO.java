package com.sfpay.ews.dto.coreaccount;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 核心账户系统的指标参数；
 * @author 575740
 *
 */
public class WarnCoreAccountParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 流水号的记录数
	 */
	private long accountZeroNum;

	public long getAccountZeroNum() {
		return accountZeroNum;
	}

	public void setAccountZeroNum(long accountZeroNum) {
		this.accountZeroNum = accountZeroNum;
	}
	

}
