package com.sfpay.ews.service.param.pas;

import com.sfpay.ews.dto.pas.WarnPasPageDTO;
import com.sfpay.ews.dto.pas.WarnPasParamDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 垫付货款的参数获取
 * @author 575740
 * 2014-06-17
 */
public interface IWarnGetPasParamService {

	/**
	 * 0 -24点 每小时一次 监控正常工作时间垫付同步运单是否有资料
	 * @param qryBeginTime 开始时间
	 * @param qryEndTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getHourBillNum(String qryBeginTime,String qryEndTime) throws ServiceException;
	
	/**
	 * COD运单同步波动比率 ,存储四个数据;昨日，当日的同步数量;昨日，7日内的比率;
	 * @param qryDate 参数
	 * @param qryPerDay 参数
	 * @param qryTime 查询的昨日与当日时间点
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnPasParamDTO getCodPerValue(String qryDate,Float qryPerDay,String qryTime) throws ServiceException;
	
	/**
	 * 指标三：是否在银企中有重复记录;
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getRepeatNum(String qryDate) throws ServiceException;
	
	/**
	 * 指标四：昨日和当日的记录数
	 * @param qryDate 参数
	 * @return  返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getLendingNum(String qryDate) throws ServiceException;
	

	/**
	 * 指标四：昨日和当日的记录数
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPayoutNum(String qryDate) throws ServiceException;
		
	/**
	 * 
	 * 方法：指标五：垫付放款符合放款的记录金额汇总
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getlendingAmt(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：指标五：银企放款的记录金额汇总
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getpayoutAmt(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：指标六: 昨日对账的垫付订单
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getYdayOrderNum(String qryDate) throws ServiceException;

	/**
	 * 
	 * 方法：指标六: 昨日对账的小订单
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getYdayTradeNum(String qryDate) throws ServiceException;

	/**
	 * 
	 * 方法：指标六: 今日对账的垫付订单
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getTodayOrderNum(String qryDate) throws ServiceException;

	/**
	 * 
	 * 方法：指标六: 今日对账的小订单
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getTodayTradeNum(String qryDate) throws ServiceException;
	/**
	 * 指标七:订单申请记录中的重复运单
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getBusWayBillNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：  指标七:订单表中的重复运单
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getOrderWayBillNum(String qryDate) throws ServiceException;
	
	/**
	 * 根据一个ID获取资料;
	 * @param id 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnPasPageDTO getLendingDataById(Long id) throws ServiceException;
	
	/**
	 * 批量保存在银企中重复的记录
	 * @param qryDate 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnPasRule 参数
	 * @param paramRowNum 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchRepeat(String qryDate,String warnNo,String expExpLain,String warnPasRule,long paramRowNum) throws ServiceException;
	
	/**
	 *  ************** 0715 PAS 新增的指标 **************
	 *  
	 */
	
	/**	 
	 * 非收派员巴枪版COD对其核销成功且未抵扣PAS的对应账单异常笔数
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPasVsCodNotBar(String qryDate) throws ServiceException;
	
	/**
	 * 查看巴枪版本的PAS与COD的资料;
	 * 收派员巴枪版COD对其核销成功且未抵扣PAS的对应账单异常笔数
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPasVsCodBar(String qryDate) throws ServiceException;
	
	
	/**
	 * WAYBILL_PAYMENT_TOTAL  计算的运单欠款总额
       PRINCIPAL_TOTAL  垫付系统记录的用户欠款总额
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getBusinessAmtNum(String qryDate) throws ServiceException;	
	
	/**
	 * 批量保存在银企中重复的记录
	 * @param qryDate 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnPasRule 参数
	 * @param paramRowNum 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchNotBar(String qryDate,String warnNo,String expExpLain,String warnPasRule,long paramRowNum) throws ServiceException;

	/**
	 * 批量保存在银企中重复的记录
	 * @param qryDate 参数
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnPasRule 参数
	 * @param paramRowNum 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchBar(String qryDate,String warnNo,String expExpLain,String warnPasRule,long paramRowNum) throws ServiceException;

	/**
	 * 根据一个ID获取资料;
	 * @param id 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnPasPageDTO getCodBillInfoDataById(Long id) throws ServiceException;

	/**
	 * 
	 * 方法：指标十二（PAS0012）:检查回款记录是否都已记账，如果未记账，需手工确认记账。此方法返回未记账的回款笔数
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getUnAccountNum(String qryDate) throws ServiceException;
	
	
	/**
	 * 
	 * 方法： 指标十一（PAS0011）:获取散单二次放款调度任务执行后“风控暂停”状态订单笔数
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getHhtSuspendLendingRiskNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：指标十一（PAS0017）:获取非散单二次放款调度任务执行后“风控暂停”状态订单笔数
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getNotHhtSuspendLendingRiskNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：指标十三（PAS0013）:风控系统未给垫付货款系统反馈(标准版)中规则结果,本方法返回垫付接收到的次数，为0时异常
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getNotHhtNotifyPasTimes(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：指标十四（PAS0014）:风控系统未给垫付货款系统反馈(巴枪版)中规则结果,本方法返回垫付接收到的次数，为0时异常
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getHhtNotifyPasTimes(String qryDate) throws ServiceException;
	
	
	/**
	 * 
	 * 方法： 指标十五（PAS0015）:风控系统人工处理反馈系统接口异常的监控预警，方法返回风控未将人工审核结果成功通知到垫付的笔数
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getFailNotifyPasNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：指标十八（PAS0018）:监控银企放款超时，方法返回还未放款成功的放款单笔数
	 * 方法说明：
	 *
	 * @param qryDate 日期
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getUnLendingNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：风控指标RM_PAS0001:当天散单垫付放款前监控未完成系统跑批，等于0时告警
	 * 方法说明：
	 *
	 * @return 返回值
	 */
	public Long getFinishHhtRuleLogNum();
	
	/**
	 * 
	 * 方法：指标十九（PAS0019）:监控垫付与订单系统对账异常
	 * 方法说明：
	 *
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	Long getUnMatchPasNum() throws ServiceException;
	
	/**
	 * 
	 * 方法：指标二十四(PAS0024):监控费用减免勾稽异常的笔数
	 * 方法说明：
	 *
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getFeeRemitExceptionNum() throws ServiceException;
	

	/**
	 * 
	 * 方法：指标二十（PAS0020）:监控垫付和CBIL对账异常，方法返回对账异常数
	 * 方法说明：
	 *
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPasCbilReconExceptionNum() throws ServiceException;
	
	/**
	 * add by yurongjie 2014-12-16 
	 * 
	 */
	/**
	 * 
	 * 方法：指标二十一（PAS0021）:监控垫付发送客户信息到CBIL异常
	 * 方法说明：
	 *
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPasSyncCustomerNum() throws ServiceException;
	
	/**
	 * 
	 * 方法：指标二十一（PAS0022）:监控是否有异常的未见回单记录
	 * 方法说明：
	 *
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPasWaybillExceptionNum() throws ServiceException;
	

	/**
	 * 
	 * 方法：指标二十一（PAS0023）:监控垫付回款勾稽异常
	 * 方法说明：
	 *
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPasRepayExceptionNum() throws ServiceException;
	
}
