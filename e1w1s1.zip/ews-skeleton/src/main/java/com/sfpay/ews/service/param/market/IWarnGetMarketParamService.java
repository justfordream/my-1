package com.sfpay.ews.service.param.market;

import com.sfpay.ews.dto.market.WarnMarketPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 营销预警需要的参数;
 * @author 575740
 *
 */
public interface IWarnGetMarketParamService {

	/**
	 * 2.1.1	  监控指标(事前)-待审核与待赠送笔数（自动及人工）等值
	 * 预警阀值  A1+A2+A3+A4 <> B1+B2+B3+B4
		(A1+A2+A3+A4 < B1+B2+B3+B4 系统进行拦截) 
	 */		

	/**
	 * 如果规则一违反，查看是否有订单号不在待赠送的结果中,并进行保存;
	 * @param qryDate 参数
	 * @param warnNo  参数
	 * @param expExpLain 参数
	 * @param warnMarketRule 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchAward(String qryDate,String warnNo,String expExpLain,String warnMarketRule,long paramRowNum) throws ServiceException;
	
	
	/**
	 * 
	 * 方法：如果规则一违反，查看是否有订单号不在待赠送的结果的明细数量;
	 * 方法说明：
	 *
	 * @param qryDate 查询日期
	 * @return 明细数量
	 * @throws ServiceException 自定义异常
	 */
	public  Long getBatchAwardNum(String qryDate) throws ServiceException;
	
	/**
	 * A1: 待审核： 人工审核通过记录数 
	 * @param qryDate 查询日期
	 * @return 待审核： 人工审核通过记录数 
	 * @throws ServiceException 自定义异常
	 */
	public  Long getWaitEmpSignRecordNum(String qryDate) throws ServiceException;
	
	
	/**
	 *  A2: 待审核： 人工导入记审核通过记录数
	 * @param qryDate 查询日期
	 * @return 待审核： 人工导入记审核通过记录数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getWaitEmpImportRecordNum(String qryDate) throws ServiceException;
	
	
	/**
	 *  A3: 待审核： 统计营销审核通过记录数
	 * @param qryDate 查询日期
	 * @return 待审核： 统计营销审核通过记录数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getWaitStaticRecordNum(String qryDate) throws ServiceException;
	
	/**
	 *  A4: 待审核： 自动审核通过记录数
	 * @param qryDate 查询日期
	 * @return 待审核： 自动审核通过记录数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getWaitAutoBatchRecordNum(String qryDate) throws ServiceException;
	
	/**
	 *  B1: 待赠送：人工审核通过记录数
	 * @param qryDate 查询日期
	 * @return 待赠送：人工审核通过记录数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getAwardEmpSignRecordNum(String qryDate) throws ServiceException;
	
	/**
	 *  B2: 待赠送：人工导入记审核通过记录数
	 * @param qryDate 查询日期
	 * @return 待赠送：人工导入记审核通过记录数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getAwardEmpImportRecordNum(String qryDate) throws ServiceException;
	
	/**
	 *  B3: 待赠送：统计营销审核通过记录数
	 * @param qryDate 查询日期
	 * @return 待赠送：统计营销审核通过记录数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getAwardStaticRecordNum(String qryDate) throws ServiceException;

	/**
	 *  B4: 待赠送：自动审核通过记录数
	 * @param qryDate 查询日期
	 * @return 待赠送：自动审核通过记录数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getAwardAutoBatchRecordNum(String qryDate) throws ServiceException;

	

	/**
	 * 2.1.2	 监控指标(事前)-待审核与待赠送正数积分总额（自动及人工）等值
	 * 预警阀值  A1+A2+A3+A4 <> B1+B2+B3+B4
		(A1+A2+A3+A4 < B1+B2+B3+B4 系统进行拦截)
		正数 positive number 负数 Negative

	 */
	
	/**
	 * 
	 * 方法：A1: 待审核： 人工审核通过积分正数 
	 * 方法说明：
	 *
	 * @param qryDate 查询日期
	 * @return 待审核： 人工审核通过积分正数 
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPempSignScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：A2: 待审核： 人工导入记审核通过积分正数 
	 * 方法说明：
	 *
	 * @param qryDate 查询日期
	 * @return 待审核： 人工导入记审核通过积分正数 
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPempImportScoreNum(String qryDate) throws ServiceException;	
	
	/**
	 * 
	 * 方法：A3: 待审核： 统计营销审核通过积分正数 
	 * 方法说明：
	 *
	 * @param qryDate 查询日期
	 * @return  待审核： 统计营销审核通过积分正数 
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPstaticScoreNum(String qryDate) throws ServiceException;	
	
	/**
	 * 
	 * 方法： A4: 待审核： 自动审核通过积分正数
	 * 方法说明：
	 *
	 * @param qryDate 查询日期
	 * @return 待审核： 自动审核通过积分正数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPautoBatchScoreNum(String qryDate) throws ServiceException;	
	
	/**
	 * 
	 * 方法：B1: 待赠送：人工审核通过积分正数
	 * 方法说明：
	 *
	 * @param qryDate 查询日期
	 * @return 待赠送：人工审核通过积分正数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPawardEmpSignScoreNum(String qryDate) throws ServiceException;	

	/**
	 * 
	 * 方法： B2: 待赠送：人工导入记审核通过积分正数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待赠送：人工导入记审核通过积分正数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPawardEmpImportScoreNum(String qryDate) throws ServiceException;	

	/**
	 * 
	 * 方法：B3: 待赠送：统计营销审核通过积分正数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待赠送：统计营销审核通过积分正数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPawardStaticScoreNum(String qryDate) throws ServiceException;	

	/**
	 * 
	 * 方法：B4: 待赠送：自动审核通过积分
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待赠送：自动审核通过积分
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPawardAutoBatchScoreNum(String qryDate) throws ServiceException;

	
	/**
	 * 2.1.3	  监控指标(事前)-待审核与待赠送负数积分总额（自动及人工）等值
	 * 正数 positive number 负数 Negative
	 */
	
	/**
	 * 
	 * 方法：A1: 待审核： 人工审核通过积分负数 
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待审核： 人工审核通过积分负数 
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNempSignScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法： A2: 待审核： 人工导入记审核通过积分负数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待审核： 人工导入记审核通过积分负数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNempImportScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：A3: 待审核： 统计营销审核通过积分负数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待审核： 统计营销审核通过积分负数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNstaticScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：A4: 待审核： 自动审核通过积分负数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return A4: 待审核： 自动审核通过积分负数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNautoBatchScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：B1: 待赠送：人工审核通过积分负数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待赠送：人工审核通过积分负数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNawardEmpSignScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法： B2: 待赠送：人工导入记审核通过积分负数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待赠送：人工导入记审核通过积分负数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNawardEmpImportScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：B3: 待赠送：统计营销审核通过积分负数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待赠送：统计营销审核通过积分负数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNawardStaticScoreNum(String qryDate) throws ServiceException;

	/**
	 * 
	 * 方法：B4: 待赠送：自动审核通过积分负数
	 * 方法说明：
	 *
	 * @param qryDate 查询时间
	 * @return 待赠送：自动审核通过积分负数
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNawardAutoBatchScoreNum(String qryDate) throws ServiceException;

	
	/**
	 * 2.1.4	 监控指标(事后)-待赠送与赠送后笔数等值
	 * 预警阀值  A1 <> B1 
	（Already_time =1 只代表营销成功，存在A1 > B1 少送预警A1 < B1 拦截 ）

	 */
	
	/**
	 * 
	 * 方法：A1: 待赠送记录数
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @param cancelHour 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public  Long getWaitGiveRecordNum(String qryDate,float cancelHour) throws ServiceException;
	
	/**
	 * 
	 * 方法：B1: 订单系统赠送积分记录笔数: 实际赠送笔数;
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 实际赠送笔数;
	 * @throws ServiceException 自定义异常
	 */
	public  Long getRealGiveRecordNum(String qryDate) throws ServiceException;

	/**
	 * 2.1.5	 监控指标(事后)-待赠送与赠送后积分正数等值
	 * 预警阀值  A1 <> B1 
		（Already_time =1 只代表营销成功， 存在A1 > B1 少送预警A1 < B1 拦截 ）
	 */

	/**
	 * 
	 * 方法：A1: 待赠送积分正数 
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @param cancelHour 参数
	 * @return 待赠送积分正数 
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPwaitGiveScoreNum(String qryDate,float cancelHour) throws ServiceException;
	

	/**
	 * 
	 * 方法：B1: 订单系统赠送积分正数
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public  Long getPrealGiveScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 2.1.6	 监控指标(事后)-待赠送与赠送后积分负数等值
	 * 预警阀值  A1 <> B1 
		（Already_time =1 只代表营销成功，存在A1 > B1 少送预警,A1 < B1 拦截 ）
	 */
	
	/**
	 * 
	 * 方法：A1: 待赠送积分负数 
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @param cancelHour 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNwaitGiveScoreNum(String qryDate,float cancelHour)  throws ServiceException;
	
	/**
	 * 
	 * 方法：B1: 订单系统赠送积分负数:
	 * 方法说明：
	 *
	 * @param qryDate 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public  Long getNrealGiveScoreNum(String qryDate) throws ServiceException;
	
	/**
	 * 
	 * 方法：根据mkt_batch_result的ID查找资料;
	 * 方法说明：
	 *
	 * @param batchId 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnMarketPageDTO getMarketDataById(long batchId)  throws ServiceException;
	
	
}
