/**
 * 
 */
package com.sfpay.ews.platform.sch.service;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.framework.base.exception.ServiceException;


/**
 * 类说明：监控预警调度器服务接口
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-10
 */
public interface IEwsSchedulerService {
	/**
	 * 刷新监控预警信息
	 */
	public void refreshEwsIndexDefSchInfo();
	
	/**
	 * 定时扫描指标定义表来更新指标调度信息
	 */
	public void schedulerUpdateEwsIndexDef();
	
	/**
	 * 
	 * 方法：新增一个指标调度信息
	 * 方法说明：
	 *
	 * @param ewsIndexDef	指标对象
	 * @throws ServiceException 自定义异常
	 */
	public void addEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException;
	
	/**
	 * 
	 * 方法：删除一个指标调度信息
	 * 方法说明：
	 *
	 * @param ewsIndexDef 指标对象
	 * @throws ServiceException 自定义异常
	 */
	
	public void deleteEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException;
	
	/**
	 * 
	 * 方法： 更新一个指标调度信息
	 * 方法说明：
	 * 
	 * @param ewsIndexDef 指标对象
	 * @throws ServiceException 自定义异常
	 */
	public void updateEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException;
	
	/**
	 * 
	 * 方法：暂停一个指标
	 * 方法说明：
	 *
	 * @param ewsIndexDef 指标对象
	 * @throws ServiceException 自定义异常
	 */
	public void pauseEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException;
	
	/**
	 * 
	 * 方法：恢复一个被暂停的指标
	 * 方法说明：
	 *
	 * @param ewsIndexDef 指标对象
	 * @throws ServiceException 自定义异常
	 */
	public void recoveryEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException;
}
