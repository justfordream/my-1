package com.sfpay.ews.platform.domain;

import java.util.Date;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * 类说明：预警群组和通知人员映射表实体
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-19
 */

public class EwsGroupEmp extends BaseEntity {

	private static final long serialVersionUID = 8470679799450198677L;

	private String empId;

	private String empName;

	private String empMail;

	private String empMobile;

	private String groupNoList;

	private String remark;

	private String isMailNotify;

	private String isSmsNotify;

	private String createId;

	private Date createTime;

	private String updateId;

	private Date updateTime;

	private String isValid;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpMail() {
		return empMail;
	}

	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}

	public String getEmpMobile() {
		return empMobile;
	}

	public void setEmpMobile(String empMobile) {
		this.empMobile = empMobile;
	}

	public String getGroupNoList() {
		return groupNoList;
	}

	public void setGroupNoList(String groupNoList) {
		this.groupNoList = groupNoList;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIsMailNotify() {
		return isMailNotify;
	}

	public void setIsMailNotify(String isMailNotify) {
		this.isMailNotify = isMailNotify;
	}

	public String getIsSmsNotify() {
		return isSmsNotify;
	}

	public void setIsSmsNotify(String isSmsNotify) {
		this.isSmsNotify = isSmsNotify;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
}
