package com.sfpay.ews.dto.debit;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;

/**
 * 公款代扣系统的页面显示
 * @author 627247
 * 2014-06-20
 */
public class WarnDebitPageDTO extends WarnOnePageDetailDTO {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 协议号 关联代扣个人银行信息表
	 */
	private String contractNo;
	
	/**
	 * 商户号 关联代扣商户信息表
	 */
	private String merNo;
	
	/**
	 * 商户代扣请求时间
	 */
	private String merReqTime;
	
	/**
	 * 代扣金额 分为单位
	 */
	private Long amt;
	
	/**
	 * 交易币种 RMB人民币
	 */
	private String ccy;
	
	/**
	 * 处理状态(INIT初始录入、BANKBATCH生成银行批次、DOING正在扣款、RECEIVED扣款已受理、SUCCESS扣款成功、FAILURE扣款失败)
	 */
	private String status;
	
	/**
	 * 银行代扣请求时间
	 */
	private String bankReqTime;
	
	/**
	 * 收派员工号
	 */
	private String deliverNo;

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getMerNo() {
		return merNo;
	}

	public void setMerNo(String merNo) {
		this.merNo = merNo;
	}

	public Long getAmt() {
		return amt;
	}

	public void setAmt(Long amt) {
		this.amt = amt;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDeliverNo() {
		return deliverNo;
	}

	public void setDeliverNo(String deliverNo) {
		this.deliverNo = deliverNo;
	}

	public String getMerReqTime() {
		return merReqTime;
	}

	public void setMerReqTime(String merReqTime) {
		this.merReqTime = merReqTime;
	}

	public String getBankReqTime() {
		return bankReqTime;
	}

	public void setBankReqTime(String bankReqTime) {
		this.bankReqTime = bankReqTime;
	}
	
}
