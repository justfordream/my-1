package com.sfpay.ews.service.param.acq;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * Acq预警调用的获取服务;
 * @author 575740
 * 2014-05-09
 */
public interface IWarnCallAcqRuleService extends IWarnCallDayRuleService {
	/**
	 * 什么也不做;
	 */
	/**
	 * 每小时调度一次，指标一;00:00-24:00
	 */
	public void timeToWarnCallByHour();
	/**
	 * 按照分钟调用 ;银企重复付款的资料记录数  ，0-24点，每2分钟监控 排除COD的外来资料;
	 */
	public void timeToWarnCallByMinute();
	
}
