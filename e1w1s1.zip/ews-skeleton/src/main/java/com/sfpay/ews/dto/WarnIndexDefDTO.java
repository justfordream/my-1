package com.sfpay.ews.dto;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 指标对象
 * @author 321566 张泽豪
 *
 * 2014-4-17 下午7:39:08
 */
public class WarnIndexDefDTO extends BaseEntity {
	
	private static final long serialVersionUID = 3922082547093843490L;

	private String warnIndexNo;
	
	private String warnIndexName;
	
	private String warnSource;
	
	private String warnType;
	
	private String warnProperty;
	
	private String warnCycle;
	
	private Integer warnCycleVal;
	
	private String warnResultSource;
	
	private String warnLevel;
	
	private String isValid;
	
	private String remark;
	
	private String createId;
	
	private Date createTime;
	
	private String updateId;
	
	private Date updateTime;
	
	private String flag;
	
	private String isMailNotify;
	
	private String isSmsNotify;

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexName() {
		return warnIndexName;
	}

	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}

	public String getWarnType() {
		return warnType;
	}

	public void setWarnType(String warnType) {
		this.warnType = warnType;
	}

	public String getWarnProperty() {
		return warnProperty;
	}

	public void setWarnProperty(String warnProperty) {
		this.warnProperty = warnProperty;
	}

	public String getWarnCycle() {
		return warnCycle;
	}

	public void setWarnCycle(String warnCycle) {
		this.warnCycle = warnCycle;
	}

	public Integer getWarnCycleVal() {
		return warnCycleVal;
	}

	public void setWarnCycleVal(Integer warnCycleVal) {
		this.warnCycleVal = warnCycleVal;
	}

	public String getWarnResultSource() {
		return warnResultSource;
	}

	public void setWarnResultSource(String warnResultSource) {
		this.warnResultSource = warnResultSource;
	}

	public String getWarnLevel() {
		return warnLevel;
	}

	public void setWarnLevel(String warnLevel) {
		this.warnLevel = warnLevel;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getIsMailNotify() {
		return isMailNotify;
	}

	public void setIsMailNotify(String isMailNotify) {
		this.isMailNotify = isMailNotify;
	}

	public String getIsSmsNotify() {
		return isSmsNotify;
	}

	public void setIsSmsNotify(String isSmsNotify) {
		this.isSmsNotify = isSmsNotify;
	}

	@Override
	public String toString() {
		return "WarnIndexDefDTO [warnIndexNo=" + warnIndexNo
				+ ", warnIndexName=" + warnIndexName + ", warnSource="
				+ warnSource + ", warnType=" + warnType + ", warnProperty="
				+ warnProperty + ", warnCycle=" + warnCycle + ", warnCycleVal="
				+ warnCycleVal + ", warnResultSource=" + warnResultSource
				+ ", warnLevel=" + warnLevel + ", isValid=" + isValid
				+ ", remark=" + remark + ", createId=" + createId
				+ ", createTime=" + createTime + ", updateId=" + updateId
				+ ", updateTime=" + updateTime + ", flag=" + flag
				+ ", isMailNotify=" + isMailNotify + ", isSmsNotify="
				+ isSmsNotify + "]";
	}

}
