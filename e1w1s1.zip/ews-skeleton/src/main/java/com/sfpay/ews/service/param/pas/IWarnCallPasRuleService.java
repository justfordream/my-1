package com.sfpay.ews.service.param.pas;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 垫付货款的任务调度
 * @author 575740
 * 2014-06-17
 */
public interface IWarnCallPasRuleService extends IWarnCallDayRuleService {

	/**
	 * 每小时调度一次，指标一;00:00-24:00
	 */
	public void timeToWarnCallByHour();
	/**
	 * 指标二：约定每天8:30执行波动率;
	 */
	public void timeToWarnCallAgreeHour();
	
	/**
	 * 指标8：非收派员巴枪版COD对其核销成功且未抵扣PAS的对应账单异常笔数
	 * 每天09:00 -- 17:00 , 每两个小时一次
	 */
	public void timeToWarnCallTwoHour();
	
	/**
	 * 指标8：收派员巴枪版COD对其核销成功且未抵扣PAS的对应账单异常笔数
	 *  每天两次，上午09:00 ，下午15:00
	 */
	public void timeToWarnCallTwice();
	
	/**
	 * 约定每天上午10:00执行;
	 */
	public void timeToWarnCallAgreeHour1();
	
	/**
	 * 约定每天下午14:00执行;
	 */
	public void timeToWarnCallAgreeHour2();
	
	/**
	 * 约定每天下午17:00执行;
	 */
	public void timeToWarnCallAgreeHour3();
	
	/**
	 * 约定每天上午11:00执行;
	 */
	public void timeToWarnCallAgreeHour4();
	
	/**
	 * 约定每天下午15:00执行;
	 */
	public void timeToWarnCallAgreeHour5();
	
	/**
	 * 约定每天15:00、16:00、17:00、18:00执行;
	 */
	public void timeToWarnCallAgreeHour6();
	
	/**
	 * add by yurongjie 2014-12-16 PAS新增调度任务：约定每天16:00执行
	 * 监控垫付和cbil对账异常
	 */
	public void timeToWarnCallAgreeHour7();
	
	/**
	 * add by yurongjie 2014-12-18 PAS新增调度任务：约定每天11:30执行
	 * 监控是否有异常的未见回单记录
	 */
	public void timeToWarnCallAgreeHour8();
	
}
