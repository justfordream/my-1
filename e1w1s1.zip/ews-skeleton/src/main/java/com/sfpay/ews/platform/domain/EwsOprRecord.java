/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：预警操作记录表
 * 
 * 类描述：
 * 
 * @author 625288
 * 
 *         2015-3-24
 */
public class EwsOprRecord extends BaseEntity {
	private static final long serialVersionUID = -4033137573894646181L;
	// 预警信息记录ID
	private String warnInfoRecordId;
	// 处理日期
	private Date operDate;
	// 处理人员ID
	private String operId;
	// 处理说明
	private String operDesc;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	public String getWarnInfoRecordId() {
		return warnInfoRecordId;
	}

	public void setWarnInfoRecordId(String warnInfoRecordId) {
		this.warnInfoRecordId = warnInfoRecordId;
	}

	public Date getOperDate() {
		return operDate;
	}

	public void setOperDate(Date operDate) {
		this.operDate = operDate;
	}

	public String getOperId() {
		return operId;
	}

	public void setOperId(String operId) {
		this.operId = operId;
	}

	public String getOperDesc() {
		return operDesc;
	}

	public void setOperDesc(String operDesc) {
		this.operDesc = operDesc;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
