package com.sfpay.ews.enums.cod;

public enum WarnCodParam {
	/**
	 * A1: COD付款申请记录表当天“付款中”记录集合有重复数
	 */
	PAYINGREPEATNUM,
	/**
	 * A2: COD付款申请记录表“已付款”记录集合存在付款中的记录
	 */
	PAYSUCEXITNUM,
	/**
	 * A3: 收单ACQ 中外部付款信息表COD来源记录集合存在外部交易订单编号数量
	 */
	ACQEXITNUM,
	/**
	 * A4: 收单ACQ 中外部付款信息表COD来源记录集合汇总数量
	 */
	ACQOUTEXITNUM,
	/**
	 * A1: COD付款申请记录表“付款中”记录数
	 */
	PAYINGRECORDNUM,
	/**
	 * B1: 收单ACQ外部付款信息表“应付款”记录数
	 */
	TRADERECORDNUM,
	/**
	 * A1: COD付款申请记录表当天“付款中”记录金额合计
	 */
	PAYINGMONEYNUM,
	/**
	 * B1: 收单ACQ外部付款信息表应付记录金额合计
	 */
	TRADEMONEYNUM
	
}
