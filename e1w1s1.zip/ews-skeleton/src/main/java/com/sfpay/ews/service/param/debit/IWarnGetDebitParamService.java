package com.sfpay.ews.service.param.debit;

import com.sfpay.ews.dto.debit.WarnDebitPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 公款代扣系统的指标参数服务 接口
 * 
 * @author 627247 2014-06-18
 */
public interface IWarnGetDebitParamService {

	/**
	 * 获取指标一交易总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return  交易总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexOneTradeAllNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标一返回数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexOnesucReturnNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标二交易总数
	 *  
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 交易总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexTwoTradeAllNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标三交易总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 交易总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexThreeTradeAllNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标三交易失败数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return  交易失败数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexThreeUnSucNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标四交易总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 交易总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexFourTradeAllNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标四异常数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 异常数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexFourAbnormalNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取资料来源异常数
	 * 
	 * @param qryDate 日期
	 * @return 资料来源异常数
	 * @throws ServiceException 自定义异常
	 */
	public long getDocSourceAbnormalNum(String qryDate) throws ServiceException;

	/**
	 * 批量保存资料来源异常数;
	 * 
	 * @param qryDate 开始日期
	 * @param warnNo 告警编号
	 * @param expExpLain 告警说明;
	 * @param warnDebitRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return  资料来源异常数
	 * @throws ServiceException 自定义异常
	 */
	public int saveDocSourceAbnormalDetails(String qryDate, String warnNo,
			String expExpLain, String warnDebitRule, long paramRowNum)
			throws ServiceException;

	/**
	 * 根据ID查询一笔资料;
	 * 
	 * @param id 主键
	 * @return 详细数据
	 * @throws ServiceException 自定义异常
	 */
	public WarnDebitPageDTO getDebitMerDetailById(Long id)
			throws ServiceException;
	
	/**
	 * 获取指标六发送总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 发送总数
	 * @throws ServiceException 自定义异常
	 */ 
	public long getIndexSixTradeAllNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标六未返回总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 未返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexSixUnSucReturnNum(String beginTime, String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标七发送总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 发送总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexSevenTradeAllNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标七未返回总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 未返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexSevenUnSucReturnNum(String beginTime, String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标八发送总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 发送总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexEightTradeAllNum(String beginTime, String endTime)
			throws ServiceException;

	/**
	 * 获取指标八未返回总数
	 * 
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 未返回总数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexEightUnSucReturnNum(String beginTime, String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标九发送总笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 总笔数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexNineTradeAllNum(String beginTime, String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标九未返回笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException
	 */
	public long getIndexNineUnSucReturnNum(String beginTime, String endTime)
			throws ServiceException;
	/**
	 * 获取指标十二未发送给通道的数据
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException
	 */
	public long getUnSendingToChannelNum(String beginTime,String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标十三发送给快钱不成功的数据
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException
	 */
	public long getUnSendingToEasyMoneyNum(String beginTime,String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标十四 发送给通联不成功的数据
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException
	 */
	public long getUnSendingToTongLianNum(String beginTime,String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标十快钱扣款总笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 快钱扣款总笔数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexTenTradeAllNum(String beginTime, String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标十快钱扣款失败笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 快钱扣款失败笔数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexTenFailureNum(String beginTime, String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标十一通联扣款总笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 通联扣款总笔数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexElevenTradeAllNum(String beginTime, String endTime)
			throws ServiceException;
	
	/**
	 * 获取指标十一通联扣款失败笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 通联扣款失败笔数
	 * @throws ServiceException 自定义异常
	 */
	public long getIndexElevenFailureNum(String beginTime, String endTime)
			throws ServiceException;
	
}
