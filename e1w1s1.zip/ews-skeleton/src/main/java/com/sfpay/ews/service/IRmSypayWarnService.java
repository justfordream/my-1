package com.sfpay.ews.service;

import com.sfpay.ews.dto.sypay.RmSypayWarnDTO;

/**
 * 
 *	类：风控预警详情维护
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月20日 下午5:12:55
 */
public interface IRmSypayWarnService {

	/**
	 * 
	 * 方法：新增风控预警详情数据
	 * 方法说明：
	 *
	 * @param rmSypayWarnDTO 风控预警详细对象
	 */
	public void addRmSypayWarn(RmSypayWarnDTO rmSypayWarnDTO);
	
	/**
	 * 
	 * 方法：更新风控预警详情数据状态
	 * 方法说明：
	 *
	 * @param id 主键
	 * @param status 风控预警详细对象
	 */
	public void updateRmSypayWarnStatusById(String id,String status);
	
}
