package com.sfpay.ews.enums.lcpt;

/**
 * 理财平台指标
 * @author 592831
 *2014-12-30
 */

public enum WarnLcptRule {

	/**
	 * 普通赎回支付订单失败
	 */
	LCPT0007,
	/**
	 * 快速赎回支付订单失败
	 */
	LCPT0008,
	/**
	 * 异常订单
	 */
	LCPT0009,
	/**
	 * 快速赎回未当天到账
	 */
	LCPT0010,
	/**
	 * 相同客户重复赎回
	 */
	LCPT0011,
	/**
	 * 相同客户重复申购
	 */
	LCPT0012,
	/**
	 * 业务订单-支付订单金额不符
	 */
	LCPT0013,
	/**
	 * 业务订单-支付订单笔数不符
	 */
	LCPT0014
	
}
