package com.sfpay.ews.enums.waybill;

/**
 * 运单的规则;
 * @author 575740
 *
 */
public enum WarnWayBillRule {
	/**
	 *  运单漏抽XXXX笔，既交易数据中状态为交易成功的运单数据未在运单数据中存在
	 */
	DATASYNC0001,
	/**
	 * XXX日仍存在未同步抄写的运单XXXX笔
	 */
	DATASYNC0002
}
