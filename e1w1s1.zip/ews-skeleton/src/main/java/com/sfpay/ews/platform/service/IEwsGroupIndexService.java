package com.sfpay.ews.platform.service;

import com.sfpay.ews.platform.domain.EwsGroupIndex;


/**
 * 群组管理接口
 * 
 * @author 321566 张泽豪
 * 
 *         2014-4-21 下午12:29:42
 */
public interface IEwsGroupIndexService {

	/**
	 * 新增一个群组指标映射
	 * @param ewsGroupIndex
	 */
	public void addEwsGroupIndex(EwsGroupIndex ewsGroupIndex);

	/**
	 * 查询一个群组指标映射
	 * @param groupNo 群组编号
	 * @param warnIndexNo 指标编号
	 * @return 指标群组
	 */
	public EwsGroupIndex queryEwsGroupIndex(String groupNo, String warnIndexNo);
	
}
