package com.sfpay.ews.platform.sch.service;


/**
 * 
 * 类说明：预警指标组任务服务接口
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
public interface IEwsGroupTaskService {

	/**
	 * 执行指标组任务
	 * @param ewsIndexGroupNo
	 */
	
	public void doTask(String ewsIndexGroupNo);
	
}
