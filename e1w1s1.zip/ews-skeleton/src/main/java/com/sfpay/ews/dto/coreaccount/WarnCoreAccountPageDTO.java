package com.sfpay.ews.dto.coreaccount;

import com.sfpay.ews.dto.WarnOnePageDetailDTO;


/**
 * 核心账户的系统页面显示
 * @author 575740
 * 2014-05-23
 */
public class WarnCoreAccountPageDTO extends WarnOnePageDetailDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 因该指标查询的是没有记录的，故不显示页面; 
	 */

}
