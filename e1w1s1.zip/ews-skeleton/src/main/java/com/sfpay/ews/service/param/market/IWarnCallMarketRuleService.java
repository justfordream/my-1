package com.sfpay.ews.service.param.market;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

public interface IWarnCallMarketRuleService extends IWarnCallDayRuleService {
	/**
	 * 什么也不做;继承一个日调度的服务;
	 */
}
