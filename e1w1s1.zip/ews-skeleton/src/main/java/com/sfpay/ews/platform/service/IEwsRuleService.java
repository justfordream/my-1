/**
 * 
 */
package com.sfpay.ews.platform.service;

import java.util.List;

import com.sfpay.ews.platform.domain.EwsRule;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 类说明：预警规则服务接口
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-25
 */
public interface IEwsRuleService {
	/**
	 * 通过指标编号查找预警规则
	 * @param ewsIndexNo 指标编号
	 * @return 预警规则集合
	 */
	public List<EwsRule> queryByEwsIndexNo(String ewsIndexNo);
	
	/**
	 * 通过指标编号查找被标记为结果的预警规则
	 * @param ewsIndexNo 指标编号
	 * @return 预警规则对象
	 */
	public EwsRule queryResultEwsRule(String ewsIndexNo);
	
	/**
	 * 通过ID来查询预警规则
	 * @param id ID
	 * @return 预警规则对象
	 */
	public EwsRule queryById(long id);
	
	/**
	 * 新增一个预警规则
	 * @param ewsRule 预警规则对象
	 */
	public void addEwsRule(EwsRule ewsRule);
	
	/**
	 * 更新一个预警规则
	 * @param ewsRule 预警规则对象
	 */
	public void updateEwsRule(EwsRule ewsRule);
	
	/**
	 * 删除一个预警规则
	 * @param id 预警规则ID
	 */
	public void deleteEwsRule(long id);
	
	/**
	 * 通过指标编号和参数名称查询
	 * @param warnIndexNo 指标编号
	 * @param paramName 参数名称
	 * @return 预警规则对象
	 */
	public EwsRule queryByIndexNoAndParamName(String warnIndexNo, 
			String paramName);
	
	/**
	 * 指标规则分页查询
	 * @param ewsRule 预警规则对象
	 * @param index 页索引
	 * @param size 页大小
	 * @return 分页预警规则
	 * @throws ServiceException 自定义异常
	 */
	public IPage<EwsRule> queryByPage(EwsRule ewsRule, int index, int size)
			throws ServiceException;
}
