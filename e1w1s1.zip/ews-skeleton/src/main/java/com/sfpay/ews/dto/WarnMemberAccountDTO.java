package com.sfpay.ews.dto;

import java.util.Date;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:34:31
 */
public class WarnMemberAccountDTO {
	/**
	 * 注册手机号
	 */
	private String loginName;

	/**
	 * 绑定银行卡手机号
	 */
	private String bankMobile;
	
	/**
	 * 绑定会员号
	 */
	private String memberNo;
	
	/**
	 * 实名等级
	 */
	private String authLevel;
	
	/**
	 * 证件类型
	 */
	private String certTypeCode;
	
	/**
	 * 证件号码
	 */
	private String certNo;
	
	/**
	 * 注册时间
	 */
	private Date createTime;
	
	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getBankMobile() {
		return bankMobile;
	}

	public void setBankMobile(String bankMobile) {
		this.bankMobile = bankMobile;
	}

	public String getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}

	public String getAuthLevel() {
		return authLevel;
	}

	public void setAuthLevel(String authLevel) {
		this.authLevel = authLevel;
	}

	public String getCertTypeCode() {
		return certTypeCode;
	}

	public void setCertTypeCode(String certTypeCode) {
		this.certTypeCode = certTypeCode;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
}
