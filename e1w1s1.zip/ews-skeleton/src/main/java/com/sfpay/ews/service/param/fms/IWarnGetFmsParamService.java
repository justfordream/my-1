package com.sfpay.ews.service.param.fms;

import com.sfpay.ews.dto.fms.WarnFmsPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 米兰港(融资平台) 预警监测 参数接口
 * @author 575740
 * 2014-06-19
 */
public interface IWarnGetFmsParamService {

	/**
	 * 指标一:融通向顺手付支付进行中的记录数
	 * @param qryDate
	 * @return
	 * @throws ServiceException
	 */
	public Long getDoingNum(String qryDate) throws ServiceException;
	

	/**
	 * 指标二:融资平台系统融通与顺手付系统交易对账不匹配记录数
	 * @param beginTime 开始时间
	 * @param endTime   结束时间;
	 * @param endTimeMore 结束时间较长;
	 * @return
	 * @throws ServiceException
	 */
	public Long getFmsToPayNum(String beginTime, String endTime, String endTimeMore) throws ServiceException;
	
	/**
	 * 根据ID找出融资的资料，针对指标一；
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public WarnFmsPageDTO getFundDetailByNo(Long operationNo) throws ServiceException;
	
	/**
	 * 指标一:融通向顺手付支付进行中的记录数,批量保存
	 * @param qryDate
	 * @param warnNo
	 * @param expExpLain
	 * @param warnFinRule
	 * @param paramRowNum
	 * @return
	 * @throws ServiceException
	 */
	public int saveBatchDoningData(String qryDate,String warnNo,String expExpLain,String warnFmsRule,long paramRowNum) throws ServiceException;
}
