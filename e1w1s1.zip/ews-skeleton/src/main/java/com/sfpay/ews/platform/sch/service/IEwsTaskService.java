package com.sfpay.ews.platform.sch.service;

import java.util.List;
import java.util.Map;

import com.sfpay.ews.platform.domain.EwsIndexDef;


/**
 * 
 * 类说明：预警指标任务服务接口
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
public interface IEwsTaskService {
	/**
	 * 执行指标任务
	 * @param warnIndexNo
	 */
	public void doTask(String warnIndexNo);
	
	/**
	 * 执行预警指标SQL
	 * 由预警指标组任务调用
	 * @param warnIndexDef
	 * @param warnIndexGroupParamMap 告警指标组参数Map，可以覆盖告警指标的参数
	 * @return
	 */
	public Map<String, List<Map<String, Object>>> executorSql(EwsIndexDef ewsIndexDef, 
			Map<String, Object> warnIndexGroupParamMap);
	
	/**
	 * 调用drools服务
	 * @param warnIndexDef
	 * @param sendDroolsDataMap
	 * @return
	 */
/*	public String executorDrools(EwsIndexDef ewsIndexDef, 
			final Map<String, List<Map<String, Object>>> totalDataMap);*/
	
	/**
	 * 执行预警规则
	 * @param warnIndexDef
	 * @param totalDataMap
	 * @return 返回的字符串如果是“”，表示没有中规则，否则表示中了规则
	 */
	public String executorRule(EwsIndexDef warnIndexDef, 
			final Map<String, List<Map<String, Object>>> totalDataMap);
	
}
