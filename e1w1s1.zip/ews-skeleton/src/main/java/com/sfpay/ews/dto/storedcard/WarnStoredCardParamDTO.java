package com.sfpay.ews.dto.storedcard;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 储值卡系统的指标参数；
 * @author 575740
 *
 */
public class WarnStoredCardParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 交易进行中的记录数
	 */
	private long tradingNum;
	
	/**
	 * 某段时间的交易总数
	 */
	private long tradeAllNum;
	
	/**
	 * 某段时间的交易成功总数
	 */
	private long tradeSucNum;
	
	/**
	 * 某段时间的交易为0的数量;
	 */
	private long tradeZeroNum;
	
	/**
	 * 发送消费公款部分的记录数;	
	 */
	private long tradeBillNum;
	
	/**
	 * 储值卡某段时间内的交易失败率的阀值;
	 */
	private float failThreshold;
	

	public float getFailThreshold() {
		return failThreshold;
	}

	public void setFailThreshold(float failThreshold) {
		this.failThreshold = failThreshold;
	}

	public long getTradingNum() {
		return tradingNum;
	}

	public void setTradingNum(long tradingNum) {
		this.tradingNum = tradingNum;
	}

	public long getTradeAllNum() {
		return tradeAllNum;
	}

	public void setTradeAllNum(long tradeAllNum) {
		this.tradeAllNum = tradeAllNum;
	}

	public long getTradeSucNum() {
		return tradeSucNum;
	}

	public void setTradeSucNum(long tradeSucNum) {
		this.tradeSucNum = tradeSucNum;
	}

	public long getTradeZeroNum() {
		return tradeZeroNum;
	}

	public void setTradeZeroNum(long tradeZeroNum) {
		this.tradeZeroNum = tradeZeroNum;
	}

	public long getTradeBillNum() {
		return tradeBillNum;
	}

	public void setTradeBillNum(long tradeBillNum) {
		this.tradeBillNum = tradeBillNum;
	}

}
