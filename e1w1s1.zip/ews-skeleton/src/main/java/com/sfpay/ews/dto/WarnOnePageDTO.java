package com.sfpay.ews.dto;


import java.util.List;
import com.sfpay.framework.base.entity.BaseEntity;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 
 *	类：
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月15日 下午6:35:00
 */
public class WarnOnePageDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	/**
	 * 预警编号
	 */
	private String warnNo; 
	/**
	 * 预警日期
	 */
	private String warnIndexNo; 	
	
	/**
	 * 指标编号
	 */
	private String warnIndexName; 	
	/**
	 * 指标名称
	 */
	private String warnDate; 	
	
	/**
	 * 预警来源
	 */
	private String warnSource; 
	/**
	 * 预警来源名称
	 */
	private String warnSourceName; 


	/**
	 * 预警类别
	 */
	private String warnType; 
	/**
	 * 预警周期
	 */
	private String warnCycle; 
	
	/**
	 * 预警周期值;
	 */
	private Integer warnCycleVal;
	

	/**
	 * 预警性质
	 */
	private String warnProperty; 
	
	/**
	 * 本次预警时间
	 */
	private String warnTime;
	
	/**
	 * 预警指标说明
	 */
	private String warnExplain;
	
	/**
	 * 风险等级
	 */
	private String warnLevel;
	
	
	/**
	 * 处理状态
	 */
	private String isDealing;
	
	
	/**
	 * 处理结果说明
	 */
	private String warnDealResult;
	
	/**
	 * 创建时间
	 */
	private String remark;


	/**
	 * 创建时间
	 */
	private String createTime;
	
	/**
	 * 更新人员
	 */
	private String updateId;
	
	/**
	 * 更新时间
	 */
	private String updateTime;
	
	/**
	 * 获取明细的资料,可以做保存的时候使用;
	 */
	private List<WarnOnePageDetailDTO>  allDetailList;
	
	/**
	 * 获取明细的资料，每次查出一部分;
	 */
	private IPage<WarnOnePageDetailDTO>  qryPageDetailList;
	


	public IPage<WarnOnePageDetailDTO> getQryPageDetailList() {
		return qryPageDetailList;
	}

	public void setQryPageDetailList(IPage<WarnOnePageDetailDTO> qryPageDetailList) {
		this.qryPageDetailList = qryPageDetailList;
	}

	
	public List<WarnOnePageDetailDTO> getAllDetailList() {
		return allDetailList;
	}

	public void setAllDetailList(List<WarnOnePageDetailDTO> allDetailList) {
		this.allDetailList = allDetailList;
	}

	public String getWarnDate() {
		return warnDate;
	}

	public void setWarnDate(String warnDate) {
		this.warnDate = warnDate;
	}


	public String getWarnCycle() {
		return warnCycle;
	}

	public void setWarnCycle(String warnCycle) {
		this.warnCycle = warnCycle;
	}

	
	public String getWarnType() {
		return warnType;
	}

	public void setWarnType(String warnType) {
		this.warnType = warnType;
	}

	public String getWarnProperty() {
		return warnProperty;
	}

	public void setWarnProperty(String warnProperty) {
		this.warnProperty = warnProperty;
	}

	public String getWarnTime() {
		return warnTime;
	}

	public void setWarnTime(String warnTime) {
		this.warnTime = warnTime;
	}

	public String getWarnExplain() {
		return warnExplain;
	}

	public void setWarnExplain(String warnExplain) {
		this.warnExplain = warnExplain;
	}

	public String getWarnLevel() {
		return warnLevel;
	}

	public void setWarnLevel(String warnLevel) {
		this.warnLevel = warnLevel;
	}
	
	public String getWarnNo() {
		return warnNo;
	}

	public void setWarnNo(String warnNo) {
		this.warnNo = warnNo;
	}

	public String getWarnIndexNo() {
		return warnIndexNo;
	}

	public void setWarnIndexNo(String warnIndexNo) {
		this.warnIndexNo = warnIndexNo;
	}

	public String getWarnIndexName() {
		return warnIndexName;
	}

	public void setWarnIndexName(String warnIndexName) {
		this.warnIndexName = warnIndexName;
	}

	public String getWarnSource() {
		return warnSource;
	}

	public void setWarnSource(String warnSource) {
		this.warnSource = warnSource;
	}



	public String getWarnDealResult() {
		return warnDealResult;
	}

	public void setWarnDealResult(String warnDealResult) {
		this.warnDealResult = warnDealResult;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}	
	
	public String getIsDealing() {
		return isDealing;
	}

	public void setIsDealing(String isDealing) {
		this.isDealing = isDealing;
	}

	public Integer getWarnCycleVal() {
		return warnCycleVal;
	}

	public void setWarnCycleVal(Integer warnCycleVal) {
		this.warnCycleVal = warnCycleVal;
	}

	public String getWarnSourceName() {
		return warnSourceName;
	}

	public void setWarnSourceName(String warnSourceName) {
		this.warnSourceName = warnSourceName;
	}
}
