package com.sfpay.ews.enums.eleaccount;

/**
 * 电子账户系统的规则;
 * @author 575740
 * 2014-05-23
 */
public enum WarnEleAccountRule {
	/**
	 * 电子账户中交易状态为进行中的记录笔数 =< 5笔
	 */
	ELEACCOUNT0001,
	/**
	 * 电子账户中交易状态为进行中的记录笔数 >5笔
	 */
	ELEACCOUNT0002,
	/**
	 * 电子账户某段时间内的交易失败率
	 */
	ELEACCOUNT0003,
}
