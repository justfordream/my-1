/**
 * 
 */
package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：预警实效表实体
 * 
 * 类描述：
 * 
 * @author 625288
 * 
 *         2015-3-26
 */
public class EwsEffect extends BaseEntity {
	private static final long serialVersionUID = 726679435675011272L;
	// 实效代码
	private String effectCode;
	// 实效名称
	private String effectName;
	// 处理时效时间,单位秒
	private Long effectTime;
	// 超时处理时效时间,单位秒
	private Long overEffectTime;
	// 预警类别代码
	private String warnClassCode;
	// 预警类别名称
	private String warnClassName;
	// 风险等级
	private String warnLevel;
	// 风险等级名称
	private String warnLevelName;
	// 级别阀值
	private String thresholdLevel;
	// 备注
	private String remark;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;

	public String getEffectCode() {
		return effectCode;
	}

	public void setEffectCode(String effectCode) {
		this.effectCode = effectCode;
	}

	public String getEffectName() {
		return effectName;
	}

	public void setEffectName(String effectName) {
		this.effectName = effectName;
	}

	public Long getEffectTime() {
		return effectTime;
	}

	public void setEffectTime(Long effectTime) {
		this.effectTime = effectTime;
	}

	public Long getOverEffectTime() {
		return overEffectTime;
	}

	public void setOverEffectTime(Long overEffectTime) {
		this.overEffectTime = overEffectTime;
	}

	public String getWarnClassCode() {
		return warnClassCode;
	}

	public void setWarnClassCode(String warnClassCode) {
		this.warnClassCode = warnClassCode;
	}

	public String getWarnLevel() {
		return warnLevel;
	}

	public void setWarnLevel(String warnLevel) {
		this.warnLevel = warnLevel;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getThresholdLevel() {
		return thresholdLevel;
	}

	public void setThresholdLevel(String thresholdLevel) {
		this.thresholdLevel = thresholdLevel;
	}

	public String getWarnClassName() {
		return warnClassName;
	}

	public void setWarnClassName(String warnClassName) {
		this.warnClassName = warnClassName;
	}

	public String getWarnLevelName() {
		return warnLevelName;
	}

	public void setWarnLevelName(String warnLevelName) {
		this.warnLevelName = warnLevelName;
	}
}
