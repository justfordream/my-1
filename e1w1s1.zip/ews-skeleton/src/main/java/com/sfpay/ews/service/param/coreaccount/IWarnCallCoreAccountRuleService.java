package com.sfpay.ews.service.param.coreaccount;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;

/**
 * 核心账户系统预警的任务调度
 * @author 575740
 * 2014-05-23
 */
public interface IWarnCallCoreAccountRuleService extends IWarnCallDayRuleService {
	/**
	 * 什么也不做;
	 */

}
