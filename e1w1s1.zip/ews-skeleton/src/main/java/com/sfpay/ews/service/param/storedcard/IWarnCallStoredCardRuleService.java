package com.sfpay.ews.service.param.storedcard;

import com.sfpay.ews.service.param.IWarnCallDayRuleService;


/**
 * 储值卡系统预警的任务调度
 * @author 575740
 * 2014-05-23
 */
public interface IWarnCallStoredCardRuleService extends IWarnCallDayRuleService {

	/**
	 * 增加一个调度任务，发送消费公款部分是否异常，每天凌晨1:30左右运行;
	 */
	public void timeToWarnCallBillRule();
	
	/**
	 * 每30分钟调度一次，指标四;08:00-22:00
	 */
	public void timeToWarnCallHalfHour();
}
