package com.sfpay.ews.service;

import com.sfpay.ews.dto.WarnCalRltLogDTO;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;


/**
 * 日志记录业务接口
 * 
 * @author 321566 张泽豪
 *
 * 2014-5-8 下午3:59:21
 */
public interface IWarnLogService {
	
	/**
	 * 分页查询日志记录
	 * @param log
	 * @param index
	 * @param size
	 * @return
	 * @throws ServiceException
	 */
	public IPage<WarnCalRltLogDTO> queryWarnCalRltLogByPage(WarnCalRltLogDTO log,int index,int size) throws ServiceException;
	
	/**
	 * 根据id查询日志记录
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public WarnCalRltLogDTO queryCalRltLogById(long id) throws ServiceException;
	
}
