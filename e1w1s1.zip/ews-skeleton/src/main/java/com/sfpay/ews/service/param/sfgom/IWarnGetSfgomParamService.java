package com.sfpay.ews.service.param.sfgom;

import com.sfpay.ews.dto.sfgom.WarnSfgomPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 安心购系统的指标参数服务 接口
 * @author 627247
 * 2014-06-19
 */
public interface IWarnGetSfgomParamService {
	
	/**
	 * 获取昨日收货时间已过期，但未自动确认收货的纠纷期订单数量
	 * @param qryDate
	 * @return
	 * @throws ServiceException
	 */
	public long getIndexOneTradeNum(String qryDate) throws ServiceException;
	
	/**
	 * 获取昨日买家处理纠纷已过期，但未自动处理的纠纷期订单
	 * @param qryDate
	 * @return
	 * @throws ServiceException
	 */
	public long getIndexTwoTradeNum(String qryDate) throws ServiceException;
	
	/**
	 * 获取昨日商家处理纠纷已过期，但未自动处理的纠纷期订单
	 * @param qryDate
	 * @return
	 * @throws ServiceException
	 */
	public long getIndexThreeTradeNum(String qryDate) throws ServiceException;
	
	/**
	 * 获取昨日保障期已过期，但未自动结束保障期的订单
	 * @param qryDate
	 * @return
	 * @throws ServiceException
	 */
	public long getIndexFourTradeNum(String qryDate) throws ServiceException;
	
	/**
	 * 批量保存昨日收货时间已过期，但未自动确认收货的纠纷期订单数量
	 * 
	 * @param qryDate 开始日期
	 * @param warnNo 告警编号
	 * @param expExpLain 告警说明;
	 * @param warnSfgomRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return
	 * @throws ServiceException
	 */
	public int saveIndexOneDetails(String qryDate, String warnNo,
			String expExpLain, String warnSfgomRule, long paramRowNum)
			throws ServiceException;
	
	/**
	 * 批量保存昨日买家处理纠纷已过期，但未自动处理的纠纷期订单
	 * 
	 * @param qryDate 开始日期
	 * @param warnNo 告警编号
	 * @param expExpLain 告警说明;
	 * @param warnSfgomRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return
	 * @throws ServiceException
	 */
	public int saveIndexTwoDetails(String qryDate, String warnNo,
			String expExpLain, String warnSfgomRule, long paramRowNum)
			throws ServiceException;
	
	/**
	 * 批量保存昨日商家处理纠纷已过期，但未自动处理的纠纷期订单
	 * 
	 * @param qryDate 开始日期
	 * @param warnNo 告警编号
	 * @param expExpLain 告警说明;
	 * @param warnSfgomRule 违反规则
	 * @param paramRowNum 建议10笔;
	 * @return
	 * @throws ServiceException
	 */
	public int saveIndexThreeDetails(String qryDate, String warnNo,
			String expExpLain, String warnSfgomRule, long paramRowNum)
			throws ServiceException;

	/**
	 * 根据ID查询一笔资料;
	 * 
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public WarnSfgomPageDTO getLogisticsOrderInfoById(Long id)
			throws ServiceException;
	
}
