package com.sfpay.ews.platform.service;

import java.util.List;
import com.sfpay.ews.platform.domain.EwsParam;

/**
 * 对预警参数表进行维护
 *
 *
 * @author 544772
 * @version 2015年3月26日 上午11:01:26
 */
public interface IEwsParamService {
	/**
	 * 新增预警参数数据
	 * 
	 * @param ewsParam 预警参数实体
	 */
	public void addEwsParam(EwsParam ewsParam);
	
	/**
	 * 更新预警参数数据
	 * 
	 * @param ewsParam 预警参数实体
	 */
	public void updateEwsParam(EwsParam ewsParam);
	
	/**
	 * 删除预警参数记录
	 * 
	 * @param id 预警记录主键
	 */
	public void delEwsParam(String id);
	
	/**
	 * 通过主键查询预警参数记录
	 * 
	 * @param id 预警记录主键
	 */
	public EwsParam queryById(String id);
	
	/**
	 * 查询所有预警参数记录
	 * 
	 * @return 预警参数记录
	 */
	public List<EwsParam> queryAll();
	
	/**
	 * 通过参数对象查询预警参数记录
	 * 
	 * @param ewsParam 预警实体
	 * @return 预警记录
	 */
	public List<EwsParam> queryEwsParamByParam(EwsParam ewsParam);
	
	/**
	 * 不排序直接分页
	 * 
	 * @param start 起
	 * @param end 止
	 * @return 预警记录
	 */
	public List<EwsParam> queryEwsParamByPage(int start,int end);
	
	/**
	 * 排序+分页
	 * 
	 * @param start 起
	 * @param end 止
	 * @return 预警记录
	 */
	public List<EwsParam> queryEwsParamByOrderPage(int start,int end);
	
	/**
	 * 通过所属类别代码查询所有类型
	 * 
	 * @param paramTypeName	所属类别代码
	 * @return 预警记录
	 */
	public List<EwsParam> queryAllTypesByParamTypeCode(String paramTypeCode);
	
	
	/**
	 * 
	 * 方法：通过参数参数代码和参数类型代码查询预警参数记录
	 * 方法说明：通过参数参数代码和参数类型代码查询预警参数记录
	 *
	 * @param paramCode 参数代码
	 * @param paramTypeCode 参数类型代码
	 * @return 预警实体
	 */
	public EwsParam queryEwsParamByParamCodeAndTypeCode(String paramCode,String paramTypeCode);
	
}
