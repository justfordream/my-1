package com.sfpay.ews.dto.market;

import java.util.List;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 营销系统风险预警监控指标 
 *  
 * @author 575740
 *
 */
public class WarnMarketParamDTO  extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * 2.1.1	  监控指标(事前)-待审核与待赠送笔数（自动及人工）等值
	 * 预警阀值  A1+A2+A3+A4 <> B1+B2+B3+B4
		(A1+A2+A3+A4 < B1+B2+B3+B4 系统进行拦截) 
	 */
	
	/**
	 * 如果规则一违反，查看是否有订单号不在待赠送的结果中;
	 */
	private List<WarnMarketPageDTO> batchAwardList;
	
	

	/**
	 * A1: 待审核： 人工审核通过记录数 
	 */
	private Long waitEmpSignRecordNum;
	
	/**
	 * A2: 待审核： 人工导入记审核通过记录数
	 */
	private Long waitEmpImportRecordNum;
	
	/**
	 * A3: 待审核： 统计营销审核通过记录数
	 */
	private Long waitStaticRecordNum;
	
	/**
	 * A4: 待审核： 自动审核通过记录数
	 */
	private Long waitAutoBatchRecordNum;
	
	/**
	 * B1: 待赠送：人工审核通过记录数
	 */
	private Long  awardEmpSignRecordNum;
	
	/**
	 * B2: 待赠送：人工导入记审核通过记录数
	 */
	private Long awardEmpImportRecordNum;
	
	/**
	 * B3: 待赠送：统计营销审核通过记录数
	 */
	private Long awardStaticRecordNum;
	
	/**
	 * B4: 待赠送：自动审核通过记录数
	 */
	private Long awardAutoBatchRecordNum;
	
	
	/**
	 * 2.1.2	 监控指标(事前)-待审核与待赠送正数积分总额（自动及人工）等值
	 * 预警阀值  A1+A2+A3+A4 <> B1+B2+B3+B4
		(A1+A2+A3+A4 < B1+B2+B3+B4 系统进行拦截)
		正数 positive number 负数 Negative

	 */
	
	/**
	 * A1: 待审核： 人工审核通过积分正数 
	 */
	private Long pempSignScoreNum;
	
	/**
	 * A2: 待审核： 人工导入记审核通过积分正数
	 */
	private Long pempImportScoreNum;
	
	/**
	 * A3: 待审核： 统计营销审核通过积分正数
	 */
	private Long pstaticScoreNum;
	
	/**
	 * A4: 待审核： 自动审核通过积分正数
	 */
	private Long pautoBatchScoreNum;
	
	
	/**
	 * B1: 待赠送：人工审核通过积分正数
	 */
	private Long  pawardEmpSignScoreNum;
	
	/**
	 * B2: 待赠送：人工导入记审核通过积分正数
	 */
	private Long pawardEmpImportScoreNum;
	
	/**
	 * B3: 待赠送：统计营销审核通过积分正数
	 */
	private Long pawardStaticScoreNum;
	
	/**
	 * B4: 待赠送：自动审核通过积分
	 */
	private Long pawardAutoBatchScoreNum;
	
	
	
	/**
	 * 2.1.3	  监控指标(事前)-待审核与待赠送负数积分总额（自动及人工）等值
	 * 正数 positive number 负数 Negative
	 */
	
	/**
	 * A1: 待审核： 人工审核通过积分负数 
	 */
	private Long nempSignScoreNum;
	
	/**
	 * A2: 待审核： 人工导入记审核通过积分负数
	 */
	private Long nempImportScoreNum;
	
	/**
	 * A3: 待审核： 统计营销审核通过积分负数
	 */
	private Long nstaticScoreNum;
	
	/**
	 * A4: 待审核： 自动审核通过积分负数
	 */
	private Long nautoBatchScoreNum;
	
	
	/**
	 * B1: 待赠送：人工审核通过积分负数
	 */
	private Long  nawardEmpSignScoreNum;
	
	/**
	 * B2: 待赠送：人工导入记审核通过积分负数
	 */
	private Long nawardEmpImportScoreNum;
	
	/**
	 * B3: 待赠送：统计营销审核通过积分负数
	 */
	private Long nawardStaticScoreNum;
	
	/**
	 * B4: 待赠送：自动审核通过积分负数
	 */
	private Long nawardAutoBatchScoreNum;
	
	/**
	 * 2.1.4	 监控指标(事后)-待赠送与赠送后笔数等值
	 * 预警阀值  A1 <> B1 
	（Already_time =1 只代表营销成功，存在A1 > B1 少送预警A1 < B1 拦截 ）

	 */
	
	/**
	 * A1: 待赠送记录数
	 * Before 
	 */
	private Long waitGiveRecordNum;
	
	/**
	 * B1: 订单系统赠送积分记录笔数: 实际赠送笔数;
	 */
	private Long realGiveRecordNum;
	
	
	/**
	 * 2.1.5	 监控指标(事后)-待赠送与赠送后积分正数等值
	 * 预警阀值  A1 <> B1 
		（Already_time =1 只代表营销成功， 存在A1 > B1 少送预警A1 < B1 拦截 ）
	 */
	
	/**
	 * A1: 待赠送积分正数 
	 */
	private Long pwaitGiveScoreNum;
	
	
	/**
	 * B1: 订单系统赠送积分正数:
	 */
	private Long prealGiveScoreNum;
	
	
	/**
	 * 2.1.6	 监控指标(事后)-待赠送与赠送后积分负数等值
	 * 预警阀值  A1 <> B1 
		（Already_time =1 只代表营销成功，存在A1 > B1 少送预警,A1 < B1 拦截 ）
	 */
	/**
	 * A1: 待赠送积分负数 
	 */
	private Long nwaitGiveScoreNum;
	
	
	/**
	 * B1: 订单系统赠送积分负数:
	 */
	private Long nrealGiveScoreNum;


	public List<WarnMarketPageDTO> getBatchAwardList() {
		return batchAwardList;
	}


	public void setBatchAwardList(List<WarnMarketPageDTO> batchAwardList) {
		this.batchAwardList = batchAwardList;
	}


	public Long getWaitEmpSignRecordNum() {
		return waitEmpSignRecordNum;
	}


	public void setWaitEmpSignRecordNum(Long waitEmpSignRecordNum) {
		this.waitEmpSignRecordNum = waitEmpSignRecordNum;
	}


	public Long getWaitEmpImportRecordNum() {
		return waitEmpImportRecordNum;
	}


	public void setWaitEmpImportRecordNum(Long waitEmpImportRecordNum) {
		this.waitEmpImportRecordNum = waitEmpImportRecordNum;
	}


	public Long getWaitStaticRecordNum() {
		return waitStaticRecordNum;
	}


	public void setWaitStaticRecordNum(Long waitStaticRecordNum) {
		this.waitStaticRecordNum = waitStaticRecordNum;
	}


	public Long getWaitAutoBatchRecordNum() {
		return waitAutoBatchRecordNum;
	}


	public void setWaitAutoBatchRecordNum(Long waitAutoBatchRecordNum) {
		this.waitAutoBatchRecordNum = waitAutoBatchRecordNum;
	}


	public Long getAwardEmpSignRecordNum() {
		return awardEmpSignRecordNum;
	}


	public void setAwardEmpSignRecordNum(Long awardEmpSignRecordNum) {
		this.awardEmpSignRecordNum = awardEmpSignRecordNum;
	}


	public Long getAwardEmpImportRecordNum() {
		return awardEmpImportRecordNum;
	}


	public void setAwardEmpImportRecordNum(Long awardEmpImportRecordNum) {
		this.awardEmpImportRecordNum = awardEmpImportRecordNum;
	}


	public Long getAwardStaticRecordNum() {
		return awardStaticRecordNum;
	}


	public void setAwardStaticRecordNum(Long awardStaticRecordNum) {
		this.awardStaticRecordNum = awardStaticRecordNum;
	}


	public Long getAwardAutoBatchRecordNum() {
		return awardAutoBatchRecordNum;
	}


	public void setAwardAutoBatchRecordNum(Long awardAutoBatchRecordNum) {
		this.awardAutoBatchRecordNum = awardAutoBatchRecordNum;
	}


	public Long getPempSignScoreNum() {
		return pempSignScoreNum;
	}


	public void setPempSignScoreNum(Long pempSignScoreNum) {
		this.pempSignScoreNum = pempSignScoreNum;
	}


	public Long getPempImportScoreNum() {
		return pempImportScoreNum;
	}


	public void setPempImportScoreNum(Long pempImportScoreNum) {
		this.pempImportScoreNum = pempImportScoreNum;
	}


	public Long getPstaticScoreNum() {
		return pstaticScoreNum;
	}


	public void setPstaticScoreNum(Long pstaticScoreNum) {
		this.pstaticScoreNum = pstaticScoreNum;
	}


	public Long getPautoBatchScoreNum() {
		return pautoBatchScoreNum;
	}


	public void setPautoBatchScoreNum(Long pautoBatchScoreNum) {
		this.pautoBatchScoreNum = pautoBatchScoreNum;
	}


	public Long getPawardEmpSignScoreNum() {
		return pawardEmpSignScoreNum;
	}


	public void setPawardEmpSignScoreNum(Long pawardEmpSignScoreNum) {
		this.pawardEmpSignScoreNum = pawardEmpSignScoreNum;
	}


	public Long getPawardEmpImportScoreNum() {
		return pawardEmpImportScoreNum;
	}


	public void setPawardEmpImportScoreNum(Long pawardEmpImportScoreNum) {
		this.pawardEmpImportScoreNum = pawardEmpImportScoreNum;
	}


	public Long getPawardStaticScoreNum() {
		return pawardStaticScoreNum;
	}


	public void setPawardStaticScoreNum(Long pawardStaticScoreNum) {
		this.pawardStaticScoreNum = pawardStaticScoreNum;
	}


	public Long getPawardAutoBatchScoreNum() {
		return pawardAutoBatchScoreNum;
	}


	public void setPawardAutoBatchScoreNum(Long pawardAutoBatchScoreNum) {
		this.pawardAutoBatchScoreNum = pawardAutoBatchScoreNum;
	}


	public Long getNempSignScoreNum() {
		return nempSignScoreNum;
	}


	public void setNempSignScoreNum(Long nempSignScoreNum) {
		this.nempSignScoreNum = nempSignScoreNum;
	}


	public Long getNempImportScoreNum() {
		return nempImportScoreNum;
	}


	public void setNempImportScoreNum(Long nempImportScoreNum) {
		this.nempImportScoreNum = nempImportScoreNum;
	}


	public Long getNstaticScoreNum() {
		return nstaticScoreNum;
	}


	public void setNstaticScoreNum(Long nstaticScoreNum) {
		this.nstaticScoreNum = nstaticScoreNum;
	}


	public Long getNautoBatchScoreNum() {
		return nautoBatchScoreNum;
	}


	public void setNautoBatchScoreNum(Long nautoBatchScoreNum) {
		this.nautoBatchScoreNum = nautoBatchScoreNum;
	}


	public Long getNawardEmpSignScoreNum() {
		return nawardEmpSignScoreNum;
	}


	public void setNawardEmpSignScoreNum(Long nawardEmpSignScoreNum) {
		this.nawardEmpSignScoreNum = nawardEmpSignScoreNum;
	}


	public Long getNawardEmpImportScoreNum() {
		return nawardEmpImportScoreNum;
	}


	public void setNawardEmpImportScoreNum(Long nawardEmpImportScoreNum) {
		this.nawardEmpImportScoreNum = nawardEmpImportScoreNum;
	}


	public Long getNawardStaticScoreNum() {
		return nawardStaticScoreNum;
	}


	public void setNawardStaticScoreNum(Long nawardStaticScoreNum) {
		this.nawardStaticScoreNum = nawardStaticScoreNum;
	}


	public Long getNawardAutoBatchScoreNum() {
		return nawardAutoBatchScoreNum;
	}


	public void setNawardAutoBatchScoreNum(Long nawardAutoBatchScoreNum) {
		this.nawardAutoBatchScoreNum = nawardAutoBatchScoreNum;
	}


	public Long getWaitGiveRecordNum() {
		return waitGiveRecordNum;
	}


	public void setWaitGiveRecordNum(Long waitGiveRecordNum) {
		this.waitGiveRecordNum = waitGiveRecordNum;
	}


	public Long getRealGiveRecordNum() {
		return realGiveRecordNum;
	}


	public void setRealGiveRecordNum(Long realGiveRecordNum) {
		this.realGiveRecordNum = realGiveRecordNum;
	}


	public Long getPwaitGiveScoreNum() {
		return pwaitGiveScoreNum;
	}


	public void setPwaitGiveScoreNum(Long pwaitGiveScoreNum) {
		this.pwaitGiveScoreNum = pwaitGiveScoreNum;
	}


	public Long getPrealGiveScoreNum() {
		return prealGiveScoreNum;
	}


	public void setPrealGiveScoreNum(Long prealGiveScoreNum) {
		this.prealGiveScoreNum = prealGiveScoreNum;
	}


	public Long getNwaitGiveScoreNum() {
		return nwaitGiveScoreNum;
	}


	public void setNwaitGiveScoreNum(Long nwaitGiveScoreNum) {
		this.nwaitGiveScoreNum = nwaitGiveScoreNum;
	}


	public Long getNrealGiveScoreNum() {
		return nrealGiveScoreNum;
	}


	public void setNrealGiveScoreNum(Long nrealGiveScoreNum) {
		this.nrealGiveScoreNum = nrealGiveScoreNum;
	}

	
}
