package com.sfpay.ews.dto.tradeorder;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 核心订单系统的指标参数；
 * @author 575740
 * 2014-05-23
 */
public class WarnTradeOrderParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 某段时间的交易总数
	 */
	private long tradeAllNum;
	
	/**
	 * 某段时间的交易成功总数
	 */
	private long tradeSucNum;
	
	/**
	 * 消费，转账，提现等交易超过设置时间30分钟未成功的记录
	 */
	private long tradeOverTimeNum;
	
	/**
	 * O2A对账中账目不平的记录数
	 */
	private long tradeOtoAccountNum;
	
	/**
	 * 新订单系统交易异常:某段时间的交易为0的数量;
	 */
	private long tradeZeroNum;
	
	/**
	 * O2B对账中账目不平的记录数
	 */
	private long tradeOtoBillNum;
	
	/**
	 * 某段时间内的交易失败率的阀值;
	 */
	private float unSucThreshold;
	
	
	public float getUnSucThreshold() {
		return unSucThreshold;
	}

	public void setUnSucThreshold(float unSucThreshold) {
		this.unSucThreshold = unSucThreshold;
	}

	public long getTradeAllNum() {
		return tradeAllNum;
	}

	public void setTradeAllNum(long tradeAllNum) {
		this.tradeAllNum = tradeAllNum;
	}

	public long getTradeSucNum() {
		return tradeSucNum;
	}

	public void setTradeSucNum(long tradeSucNum) {
		this.tradeSucNum = tradeSucNum;
	}

	public long getTradeOverTimeNum() {
		return tradeOverTimeNum;
	}

	public void setTradeOverTimeNum(long tradeOverTimeNum) {
		this.tradeOverTimeNum = tradeOverTimeNum;
	}

	public long getTradeOtoAccountNum() {
		return tradeOtoAccountNum;
	}

	public void setTradeOtoAccountNum(long tradeOtoAccountNum) {
		this.tradeOtoAccountNum = tradeOtoAccountNum;
	}

	public long getTradeZeroNum() {
		return tradeZeroNum;
	}

	public void setTradeZeroNum(long tradeZeroNum) {
		this.tradeZeroNum = tradeZeroNum;
	}

	public long getTradeOtoBillNum() {
		return tradeOtoBillNum;
	}

	public void setTradeOtoBillNum(long tradeOtoBillNum) {
		this.tradeOtoBillNum = tradeOtoBillNum;
	}

	

}
