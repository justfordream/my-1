package com.sfpay.ews.platform.service;

import java.util.List;
import com.sfpay.ews.platform.domain.EwsOprRecord;

public interface IEwsOprRecordService {
	/**
	 * 
	 * 方法：增加操作记录
	 * 方法说明：
	 *
	 * @param ewsOprRecord 操作记录对象
	 */
	public void addEwsOprRecord(EwsOprRecord ewsOprRecord);
	
	/**
	 * 
	 * 方法：更新操作记录
	 * 方法说明：
	 *
	 * @param ewsOprRecord 操作记录对象
	 */
	public void updateEwsOprRecord(EwsOprRecord ewsOprRecord);
	
	/**
	 * 
	 * 方法：通过主键ID删除操作记录
	 * 方法说明：
	 *
	 * @param id 主键ID
	 */
	public void delEwsOprRecord(String id);
	
	/**
	 * 
	 * 方法：通过主键ID查询操作记录
	 * 方法说明：
	 *
	 * @param id 主键ID
	 * @return 操作记录对象
	 */
	public EwsOprRecord queryById(String id);
	
	/**
	 * 
	 * 方法：通过指标记录编号查询操作记录
	 * 方法说明：
	 *
	 * @param warnInfoRecordId 指标记录ID
	 * @return 操作记录对象集合
	 */
	public List<EwsOprRecord> queryEwsOprRecordByWarnInfoRecordId(String warnInfoRecordId);
}
