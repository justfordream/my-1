package com.sfpay.ews.dto.acq;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * ACQ系统风险预警监控指标 
 * @author 575740
 * 2014/05/08 
 *
 */
public class WarnAcqParamDTO extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 2.3.1  银企付款一段时间内出现实付金额大于应付金额记录统计  
	 */
	private long payOutMoreNum;
	

	/**
	 * 2.3.2  银企直联一段时间出现的状态为UNKOWN及超过配置时间的记录  
	 */
	private long batchUnkowNum;	
	
	/**
	 * 2.3.3  银企直联已受理并且超过指定配置时间未得到结果的记录
	 */
	private long batchRecUndoNum;
	
	/**
	 * 以上是 二期的三个指标。
	 * 以下是四期的五个指标;
	 */
	
	/**
	 * 指标四：重复付款的阀值;120秒一次  ,分钟级别的资料;
	 */
	private long sedRepeatNum;
	
	/**
	 * 多少秒内的数量;
	 */
	private long secondParam;	


	/**
	 * 指标五：某段时间银企外部交易订单号或外部交易业务唯一订单号重复;
	 * 外部交易订单号;
	 */
	private long outNoRepeatNum;
	/**
	 * 指标五：某段时间银企外部交易订单号或外部交易业务唯一订单号重复;
	 * 外部交易业务唯一订单号;
	 */
	private long outBsnRepeatNum;
	
	/**
	 * 指标六：某段时间内银企抵扣金额较大（为负数）的记录数 0-24点，每小时一次	 
	 */
	private long negHourNum;
	
	/**
	 * 指标六：某段时间内银企抵扣金额较大（为负数）的记录数 0-24点，每小时一次
	 * 小与于负数的金额;
	 */
	private long thresholdNeghour;
	


	/**
	 * 指标七：某段时间内银企抵扣（为负数）的总记录数 累计计算0-12,0-14的记录数
	 * 为负数的总记录数;
	 */
	private long negSumNum;
	
	/**
	 * 指标七：某段时间内银企抵扣（为负数）的总记录数 累计计算0-12,0-14的记录数
	 * 设置总负数如果大于该阀值则报警;
	 */
	private long thresholdNegSum;
	
	/**
	 * 指标八：银企某段时间内手工录入审核重复记录数
	 * 0-24点，每小时一次
	 */
	private long omsRepeatNum;

	public long getPayOutMoreNum() {
		return payOutMoreNum;
	}

	public void setPayOutMoreNum(long payOutMoreNum) {
		this.payOutMoreNum = payOutMoreNum;
	}

	public long getBatchUnkowNum() {
		return batchUnkowNum;
	}

	public void setBatchUnkowNum(long batchUnkowNum) {
		this.batchUnkowNum = batchUnkowNum;
	}

	public long getBatchRecUndoNum() {
		return batchRecUndoNum;
	}

	public void setBatchRecUndoNum(long batchRecUndoNum) {
		this.batchRecUndoNum = batchRecUndoNum;
	}

	public long getSedRepeatNum() {
		return sedRepeatNum;
	}

	public void setSedRepeatNum(long sedRepeatNum) {
		this.sedRepeatNum = sedRepeatNum;
	}

	public long getSecondParam() {
		return secondParam;
	}

	public void setSecondParam(long secondParam) {
		this.secondParam = secondParam;
	}

	public long getOutNoRepeatNum() {
		return outNoRepeatNum;
	}

	public void setOutNoRepeatNum(long outNoRepeatNum) {
		this.outNoRepeatNum = outNoRepeatNum;
	}

	public long getOutBsnRepeatNum() {
		return outBsnRepeatNum;
	}

	public void setOutBsnRepeatNum(long outBsnRepeatNum) {
		this.outBsnRepeatNum = outBsnRepeatNum;
	}

	public long getNegHourNum() {
		return negHourNum;
	}

	public void setNegHourNum(long negHourNum) {
		this.negHourNum = negHourNum;
	}

	public long getThresholdNeghour() {
		return thresholdNeghour;
	}

	public void setThresholdNeghour(long thresholdNeghour) {
		this.thresholdNeghour = thresholdNeghour;
	}

	public long getNegSumNum() {
		return negSumNum;
	}

	public void setNegSumNum(long negSumNum) {
		this.negSumNum = negSumNum;
	}

	public long getThresholdNegSum() {
		return thresholdNegSum;
	}

	public void setThresholdNegSum(long thresholdNegSum) {
		this.thresholdNegSum = thresholdNegSum;
	}

	public long getOmsRepeatNum() {
		return omsRepeatNum;
	}

	public void setOmsRepeatNum(long omsRepeatNum) {
		this.omsRepeatNum = omsRepeatNum;
	}
	
}
