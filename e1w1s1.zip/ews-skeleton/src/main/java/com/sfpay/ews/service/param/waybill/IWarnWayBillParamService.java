package com.sfpay.ews.service.param.waybill;

import com.sfpay.ews.dto.waybill.WarnWayBillPageDTO;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 运单预警的参数获取;
 * @author 575740
 * create: 2014-04-23
 */
public interface IWarnWayBillParamService {

	/**
	 * A1:昨日交易成功的总运单数
	 * @param qryDate 查询时间
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long  getTradeWayBillNum(String qryDate) throws ServiceException;	
	
	/**
	 * A2:昨日交易成功但未在同步表漏抽的运单数
	 * @param qryDate 查询时间
	 * @param paramDay，与同步表一段时间比较，设置天数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long  getTradeMissingNum(String qryDate,float paramDay) throws ServiceException;
	
	/**
	 * A3:昨日交易成功已在同步表但未从资科同步的运单数
	 * @param qryDate 查询时间
	 * @param paramDay，与同步表一段时间比较，设置天数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long  getTradeUnSysNcNum(String qryDate,float paramDay) throws ServiceException;	
	
	
	  
	/**
	 *  N天前运单未同步的明细的数量，因该该获取的运单较多，直接求数量;
	 * @param qryDate 查询时间
	 * @param paramDay 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long  getNgSyncWayBillNoNum(String qryDate,float paramDay) throws ServiceException;
	
	
	/**
	 * 查找交易表rm_trade中的运单List;
	 * @param tradeNo 参数
	 * @param trade_status 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnWayBillPageDTO getTradeExpressNoByTradeNo(String tradeNo,String trade_status) throws ServiceException;
	
	/**
	 * 查找运单 datasync.exp_pre_waybill_tb的运单号信息; 
	 * @param wayBillNo 参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnWayBillPageDTO getWayBillDataByWayBillNo(String wayBillNo) throws ServiceException;
	
	/**
	 * 查找交易表rm_trade中的运单资料;
	 * @param tradeNo  参数
	 * @param trade_status  参数
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public WarnWayBillPageDTO getTradeExpressById(Long id) throws ServiceException;
	
	/**
	 * 查找运单 datasync.exp_pre_waybill_tb的运单号资料 
	 * @param id  参数
	 * @return 返回值 
	 * @throws ServiceException 自定义异常
	 */
	public WarnWayBillPageDTO getWayBillDataByWayBillId(Long id) throws ServiceException;
	

	
	/**
	 * 昨日批量保存漏掉在运单明细
	 * @param qryDate 查询时间
	 * @param paramDay 查询几天之前的资料;
	 * @param warnNo  参数
	 * @param expExpLain  参数
	 * @param warnMpayRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchMissWayBillNo(String qryDate,float paramDay,String warnNo,String expExpLain,String warnWayBillRule ,long paramRowNum) throws ServiceException;
	
	
	/**
	 *  N天前运单未同步的明细的数量====批量保存；
	 * @param qryDate 查询时间
	 * @param paramDay 查询几天之前的资料;
	 * @param warnNo 参数
	 * @param expExpLain 参数
	 * @param warnMpayRule 参数
	 * @param paramRowNum 设置明细插入的批量数量;
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public int saveBatchNgSyncWayBillNo(String qryDate,float paramDay,String warnNo,String expExpLain,String warnWayBillRule,long paramRowNum) throws ServiceException;

	
	
}
