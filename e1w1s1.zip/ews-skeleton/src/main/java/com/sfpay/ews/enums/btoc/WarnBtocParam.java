package com.sfpay.ews.enums.btoc;

/**
 *  B2C的参数;
 * @author 575740
 *
 */
public enum WarnBtocParam {
	/**
	 * 一段时间交易收单的记录
	 */
	COLALLNUM,
	/**
	 * 一段时间交易收单成功的记录
	 */
	COLSUCCESSNUM,
	/**
	 * 一段时间交易收单的记录
	 */
	COLSIGNALLNUM,
	/**
	 * 一段时间内签名失败率较高的记录
	 */
	COLSIGNFAILNUM
}
