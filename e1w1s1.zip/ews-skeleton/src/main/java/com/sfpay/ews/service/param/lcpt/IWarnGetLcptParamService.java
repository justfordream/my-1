package com.sfpay.ews.service.param.lcpt;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 理财平台系统的参数获取
 * @author 592831
 *CreateTime: 2014-12-31
 */
public interface IWarnGetLcptParamService {

	/**
	 * 指标一：LCPT0001  大额赎回订单预警
	 * @param beginTime 开始时间
	 * @param endTime  结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getLargeAmtRedeemNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标二：LCPT0002  申购未支付订单占比
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Float getPurchaseNotPayedNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标三：LCPT0003  开户失败
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getOpenAccountFailedNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标四：LCPT0004  申购失败
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPurchaseFailedNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标五：LCPT0005  普通赎回交易订单失败
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getRedeemTradeFailedNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标六：LCPT0006  快速赎回交易订单失败
	 * @param beginTime 开始时间
	 * @param endTime  结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getSoonRedeemTradeFailedNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标七：LCPT0007  获取普通赎回支付订单失败笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getRedeemPayFailNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标八：LCPT0008 获取快速赎回支付订单失败笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getSoonRedeemPayFailNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标九：LCPT0009 获取异常订单笔数
	 * @param beginTime 开始时间
	 * @param endTime  结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getExceptionTradeOrderNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标十：LCPT0010 获取快速赎回未当天到账笔数
	 * @param beginTime 开始时间
	 * @param endTime  结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getSoonReedemUnAccount(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标十一：LCPT0011   获取秒内相同客户重复赎回【2】笔以上的订单数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getRepeatRedeemNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标十二：LCPT0012 获取秒内相同客户重复申购【2】笔以上的订单数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getRepeatPurchaseNum(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标十三：LCPT0013 获取业务订单-支付订单金额不符的差额
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPayAmtUnMatch(String beginTime,String endTime) throws ServiceException;
	
	/**
	 * 指标十四：LCPT0014 获取业务订单-支付订单笔数不符的笔数
	 * @param beginTime 开始时间
	 * @param endTime 结束时间
	 * @return 返回值
	 * @throws ServiceException 自定义异常
	 */
	public Long getPayCountUnMatchNum(String beginTime,String endTime) throws ServiceException;
}
