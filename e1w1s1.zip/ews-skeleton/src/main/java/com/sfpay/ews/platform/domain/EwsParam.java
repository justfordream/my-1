package com.sfpay.ews.platform.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：预警参数表 预警类型 ：事后 BEFORE，事中 DURING，事后 AFTER 预警分类：资金类 通道类 系统类 业务类 风险等级：L1,L2,L3 预警性质: 预警 WARNING,错误 ERROR
 * 类描述：预警参数表 预警类型 ：事后 BEFORE，事中 DURING，事后 AFTER 预警分类：资金类 通道类 系统类 业务类 风险等级：L1,L2,L3 预警性质: 预警 WARNING,错误 ERROR
 * @author 顺丰攻城狮
 */
public class EwsParam extends BaseEntity {

	/**  */
	private static final long serialVersionUID = 1L;

	// 参数代码
	private String paramCode;
	// 参数名称
	private String paramName;
	// 所属类别代码
	private String paramTypeCode;
	// 所属类别名称
	private String paramTypeName;
	// 备注
	private String remark;
	// 创建人员
	private String createId;
	// 创建时间
	private Date createTime;
	// 更新人员
	private String updateId;
	// 更新时间
	private Date updateTime;
	
	public String getParamCode() {
		return paramCode;
	}
	public void setParamCode(String paramCode) {
		this.paramCode = paramCode;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamTypeCode() {
		return paramTypeCode;
	}
	public void setParamTypeCode(String paramTypeCode) {
		this.paramTypeCode = paramTypeCode;
	}
	public String getParamTypeName() {
		return paramTypeName;
	}
	public void setParamTypeName(String paramTypeName) {
		this.paramTypeName = paramTypeName;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
