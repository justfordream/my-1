package com.sfpay.ews.dto.sypay;

/**
 * 
 *	类：指标SFPR0043到SFPR0049所用
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月17日 上午10:19:28
 */
public class WarnSypayFrozenDTO {
	//个人登录名（）
	private String loginName;
	//个人会员编号
	private String memberNo;
	//个人会员名称
	private String memberName;
	//规则代码
	private String ruleCode;
	//规则名称
	private String ruleName;
	
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getRuleCode() {
		return ruleCode;
	}
	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	
}
