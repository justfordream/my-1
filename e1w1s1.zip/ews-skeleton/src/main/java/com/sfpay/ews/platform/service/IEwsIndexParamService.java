package com.sfpay.ews.platform.service;

import java.util.List;

import com.sfpay.ews.platform.domain.EwsIndexParam;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;

/**
 * 指标参数业务接口
 * 
 * @author 321566 张泽豪
 * 
 *         2014-5-9 上午10:38:45
 */
public interface IEwsIndexParamService {

	/**
	 * 新增一个指标参数
	 * 
	 * @param param  指标参数实体
	 * @throws ServiceException 自定义异常
	 */
	public void addEwsIndexParam(EwsIndexParam param) throws ServiceException;

	/**
	 * 修改一个指标参数
	 * 
	 * @param param 指标参数实体
	 * @throws ServiceException 自定义异常
	 */
	public void updateEwsIndexParam(EwsIndexParam param)
			throws ServiceException;

	/**
	 * 分页查询指标参数
	 * 
	 * @param param 指标参数实体
	 * @param index 页面索引值
	 * @param size 页大小
	 * @return  分页实体
	 * @throws ServiceException 自定义异常
	 */
	public IPage<EwsIndexParam> queryIndexParamByPage(EwsIndexParam param,
			int index, int size) throws ServiceException;

	/**
	 * 根据id查询指标参数
	 * 
	 * @param id 主键
	 * @return 指标参数实体
	 * @throws ServiceException 自定义异常
	 */
	public EwsIndexParam queryWarnIndexParamById(long id)
			throws ServiceException;

	/**
	 * 
	 * 方法：根据ID删除指标参数
	 * 方法说明：
	 *
	 * @param id 主键
	 */
	public void deleteEwsIndexParamById(long id);
	
	/**
	 * 根据指标编号查询参数
	 * 
	 * @param warnIndexNo 指标参数代码
	 * @return 参数记录
	 */
	public List<EwsIndexParam> queryIndexNoParamsByWarnIndexNo(
			String warnIndexNo);
	
	/**
	 * 
	 * 方法：根据指标编号和参数名称查询参数
	 * 方法说明：
	 *
	 * @param warnIndexNo 指标编号
	 * @param paramName 参数名称
	 * @return 参数对象
	 */
	public EwsIndexParam queryByIndexNoAndParamName(String warnIndexNo, String paramName);

}
