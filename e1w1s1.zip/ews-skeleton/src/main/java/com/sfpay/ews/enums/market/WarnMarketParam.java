package com.sfpay.ews.enums.market;

public enum WarnMarketParam {
	/**
	 *****************************
	 *  监控指标(事前)-待审核与待赠送笔数（自动及人工）等值
	 * ***************************
	 */
	
	/**
	 * A1: 待审核： 人工审核通过记录数 
	 */
	WAITEMPSIGNRECORDNUM,
	/**
	 * A2: 待审核： 人工导入记审核通过记录数
	 */
	WAITEMPIMPORTRECORDNUM,
	/**
	 * A3: 待审核： 统计营销审核通过记录数
	 */
	WAITSTATICRECORDNUM,
	/**
	 * A4: 待审核： 自动审核通过记录数
	 */
	WAITAUTOBATCHRECORDNUM,
	/**
	 * B1: 待赠送：人工审核通过记录数
	 */
	AWARDEMPSIGNRECORDNUM,
	/**
	 * B2: 待赠送：人工导入记审核通过记录数
	 */
	AWARDEMPIMPORTRECORDNUM,
	/**
	 * B3: 待赠送：统计营销审核通过记录数
	 */
	AWARDSTATICRECORDNUM,
	/**
	 * B4: 待赠送：自动审核通过记录数
	 */
	AWARDAUTOBATCHRECORDNUM,
	
	/**
	 *****************************
	 *  监控指标(事前)-待审核与待赠送正数积分总额（自动及人工）等值
	 * ***************************
	 */
	
	
	/**
	 * A1: 待审核： 人工审核通过积分正数 
	 */
	PEMPSIGNSCORENUM,
	/**
	 * A2: 待审核： 人工导入记审核通过积分正数
	 */
	PEMPIMPORTSCORENUM,
	/**
	 * A3: 待审核： 统计营销审核通过积分正数
	 */
	PSTATICSCORENUM,
	/**
	 * A4: 待审核： 自动审核通过积分正数
	 */
	PAUTOBATCHSCORENUM,
	/**
	 * B1: 待赠送：人工审核通过积分正数
	 */
	PAWARDEMPSIGNSCORENUM,
	/**
	 * B2: 待赠送：人工导入记审核通过积分正数
	 */
	PAWARDEMPIMPORTSCORENUM,
	/**
	 * B3: 待赠送：统计营销审核通过积分正数
	 */
	PAWARDSTATICSCORENUM,
	/**
	 *B4: 待赠送：自动审核通过积分
	 */
	PAWARDAUTOBATCHSCORENUM,
	
	/**
	 *****************************
	 *  监控指标(事前)-待审核与待赠送负数积分总额（自动及人工）等值
	 * ***************************
	 */
	
	
	/**
	 * A1: 待审核： 人工审核通过积分负数 
	 */
	NEMPSIGNSCORENUM,
	/**
	 * A2: 待审核： 人工导入记审核通过积分负数
	 */
	NEMPIMPORTSCORENUM,
	/**
	 * A3: 待审核： 统计营销审核通过积分负数
	 */
	NSTATICSCORENUM,
	/**
	 * A4: 待审核： 自动审核通过积分负数
	 */
	NAUTOBATCHSCORENUM,
	/**
	 * B1: 待赠送：人工审核通过积分负数
	 */
	NAWARDEMPSIGNSCORENUM,
	/**
	 * B2: 待赠送：人工导入记审核通过积分负数
	 */
	NAWARDEMPIMPORTSCORENUM,
	/**
	 * B3: 待赠送：统计营销审核通过积分负数
	 */
	NAWARDSTATICSCORENUM,
	/**
	 *B4: 待赠送：自动审核通过积分负数
	 */
	NAWARDAUTOBATCHSCORENUM,
	
	
	/**
	 *****************************
	 *  监控指标(事后)-待赠送与赠送后笔数等值
	 * ***************************
	 */
	
	
	/**
	 * A1: 待赠送记录数  
	 */
	WAITGIVERECORDNUM,
	/**
	 * B1: 订单系统赠送积分记录笔数:
	 */
	REALGIVERECORDNUM,
	
	/**
	 *****************************
	 *  监控指标(事后)-待赠送与赠送后积分正数等值
	 * ***************************
	 */
	
	
	/**
	 * A1: 待赠送积分正数 
	 */
	PWAITGIVESCORENUM,
	/**
	 * B1: 订单系统赠送积分正数:
	 */
	PREALGIVESCORENUM,
	
	
	/**
	 *****************************
	 *  监控指标(事后)-待赠送与赠送后积分负数等值
	 * ***************************
	 */	
	
	/**
	 * A1: 待赠送积分负数 
	 */
	NWAITGIVESCORENUM,
	/**   
	 * B1: 订单系统赠送积分负数:
	 */
	NREALGIVESCORENUM
	
}
