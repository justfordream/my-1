package IWarnSypayGetFrozenService;

/**
 * 
 *	类：冻结账户调度接口
 *	类描述：
 *
 * @author 544772
 * @version 2015年4月17日 下午2:46:06
 */
public interface IWarnSypayFrozenRuleService {
	
	/**
	 * 
	 * 方法：一天调度一次，凌晨两点
	 * 方法说明：
	 *
	 */
	public void frozenMemberOnceInDay();
	
	/**
	 * 
	 * 方法：十分钟调度一次
	 * 方法说明：
	 *
	 */
	public void frozenMemberMinus();
	
	/**
	 * 
	 * 方法：一个小时调度一次
	 * 方法说明：
	 *
	 */
	public void frozenMemberHours();

}
