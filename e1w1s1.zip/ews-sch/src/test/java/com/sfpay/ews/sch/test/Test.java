/**
 * 
 */
package com.sfpay.ews.sch.test;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.DirectSchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.simpl.RAMJobStore;
import org.quartz.simpl.SimpleThreadPool;
import org.quartz.spi.JobStore;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.sch.service.job.EwsSchedulerJob;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-7
 */
public class Test {
	public static void main(String[] args) throws SchedulerException, InterruptedException {
//		Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
		
		SimpleThreadPool threadPool = new SimpleThreadPool(10, Thread.NORM_PRIORITY); 
		threadPool.initialize();
		RAMJobStore jobStore = new RAMJobStore();
		jobStore.setMisfireThreshold(1000);
		DirectSchedulerFactory.getInstance().createScheduler("ews-sch-quartz", "ews-sch-quartz-id", threadPool, jobStore);
		Scheduler scheduler = DirectSchedulerFactory.getInstance().getScheduler("ews-sch-quartz");
		
		
		
		JobDetail jobDetail = JobBuilder.newJob(TestJob.class)
			    .withIdentity("test1", "test1")
			    .build();
		
		CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.
				cronSchedule("*/8 * * * * ?");
		
		CronTrigger trigger = TriggerBuilder.newTrigger()
			    .withIdentity("test1", "test1")
			    .withSchedule(scheduleBuilder)
			    .startNow()
			    .build();
		
		scheduler.scheduleJob(jobDetail, trigger);
		
		scheduler.start();
		
		Thread.sleep(20000);
		System.out.println("准备暂停任务！");
		scheduler.pauseJob(new JobKey("test1", "test1"));
		System.out.println("成功暂停任务！");
		
		Thread.sleep(20000);
		
		System.out.println("准备更新任务！");
		Trigger oldTrigger = scheduler.getTrigger(new TriggerKey("test1", "test1"));
		scheduleBuilder = CronScheduleBuilder.
				cronSchedule("*/11 * * * * ?");
		@SuppressWarnings("rawtypes")
		TriggerBuilder tb = oldTrigger.getTriggerBuilder();
		@SuppressWarnings("unchecked")
		Trigger newTrigger = tb.withSchedule(scheduleBuilder).build();
		scheduler.rescheduleJob(new TriggerKey("test1", "test1"), newTrigger);
		System.out.println("成功更新任务！");
		
		Thread.sleep(90000000);
		
	}
}
