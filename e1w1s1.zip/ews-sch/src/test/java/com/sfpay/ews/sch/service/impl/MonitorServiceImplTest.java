package com.sfpay.ews.sch.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.sch.service.IMonitorService;
import com.sfpay.framework.web.test.SpringTestCase;

public class MonitorServiceImplTest extends SpringTestCase {

	@Autowired
	private IMonitorService monitorService;

	@Test
	public void testStart() {
		monitorService.start();
	}

	@Test
	public void testStop() {
		monitorService.stop();
	}

}
