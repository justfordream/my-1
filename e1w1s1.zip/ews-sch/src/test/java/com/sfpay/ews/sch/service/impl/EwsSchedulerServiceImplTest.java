package com.sfpay.ews.sch.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.sch.service.IEwsSchedulerService;
import com.sfpay.framework.web.test.SpringTestCase;

public class EwsSchedulerServiceImplTest extends SpringTestCase {

	@Autowired
	private IEwsSchedulerService ewsSchedulerService;
	
	@Test
	public void testRefreshEwsIndexDefSchInfo() {
		ewsSchedulerService.refreshEwsIndexDefSchInfo();
	}

	@Test
	public void testSchedulerUpdateEwsIndexDef() {
		ewsSchedulerService.schedulerUpdateEwsIndexDef();
	}

	@Test
	public void testAddEwsIndexDefSch() {
		EwsIndexDef ewsIndexDef=new EwsIndexDef();
		try {
			ewsSchedulerService.addEwsIndexDefSch(null);
		} catch (Exception e) {
		}
		try {
			ewsSchedulerService.addEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnIndexNo("TEST");
		try {
			ewsSchedulerService.addEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnSource("TEST");
		try {
			ewsSchedulerService.addEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setCronExpress("0 1 * * * ?");
		try {
			ewsSchedulerService.addEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnIndexNo("TEST0001");
		try {
			ewsSchedulerService.addEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		
	}

	@Test
	public void testDeleteEwsIndexDefSch() {
		EwsIndexDef ewsIndexDef=new EwsIndexDef();
		try {
			ewsSchedulerService.deleteEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnIndexNo("TEST");
		try {
			ewsSchedulerService.deleteEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnSource("TEST");
		try {
			ewsSchedulerService.deleteEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setCronExpress("0 1 * * * ?");
		try {
			ewsSchedulerService.deleteEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnIndexNo("TEST0001");
		try {
			ewsSchedulerService.deleteEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		
	}

	@Test
	public void testUpdateEwsIndexDefSch() {
		EwsIndexDef ewsIndexDef=new EwsIndexDef();
		try {
			ewsSchedulerService.updateEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnIndexNo("TEST");
		try {
			ewsSchedulerService.updateEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnSource("TEST");
		try {
			ewsSchedulerService.updateEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setCronExpress("0 1 * * * ?");
		try {
			ewsSchedulerService.updateEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
		ewsIndexDef.setWarnIndexNo("TEST0001");
		try {
			ewsSchedulerService.updateEwsIndexDefSch(ewsIndexDef);
		} catch (Exception e) {
		}
	}

	@Test
	public void testPauseEwsIndexDefSch() {
		EwsIndexDef ewsIndexDef=new EwsIndexDef();

		ewsIndexDef.setWarnSource("TEST");
		ewsIndexDef.setCronExpress("0 1 * * * ?");
		ewsIndexDef.setWarnIndexNo("TEST0001");

		ewsSchedulerService.pauseEwsIndexDefSch(ewsIndexDef);
	}

	@Test
	public void testRecoveryEwsIndexDefSch() {
		EwsIndexDef ewsIndexDef=new EwsIndexDef();

		ewsIndexDef.setWarnSource("TEST");
		ewsIndexDef.setCronExpress("0 1 * * * ?");
		ewsIndexDef.setWarnIndexNo("TEST0001");

		ewsSchedulerService.recoveryEwsIndexDefSch(ewsIndexDef);
	}

}
