/**
 * 
 */
package com.sfpay.ews.sch.test;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288
 *
 * 2015-4-7
 */
public class TestJob implements Job{

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		int i = 5;
		while(i-- > 0) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("我还没死-" + Thread.currentThread());
		}
		
	}

}
