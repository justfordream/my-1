/**
 * 
 */
package com.sfpay.ews.sch.listener;

import javax.servlet.ServletContextEvent;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoaderListener;

/**
 * 类说明：监控预警的上下文加载监听器
 *
 * 类描述：
 * @author manzhizhen
 *
 * 2015年3月1日
 */
public class SfpayEwsContextLoaderListener extends ContextLoaderListener {
	private static ApplicationContext context;
	/**
	 * 从数据库加载指标的调度信息
	 */
	@Override
	public void contextInitialized(ServletContextEvent event) {
		super.initWebApplicationContext(event.getServletContext());
	
		context = getCurrentWebApplicationContext();
	}
	
	/**
	 * 获取Spring容器中的对象
	 * @return
	 */
	public static Object getBean(String beanName) {
		if(context == null) {
			return null;
		}
		
		return context.getBean(beanName);
	}

}
