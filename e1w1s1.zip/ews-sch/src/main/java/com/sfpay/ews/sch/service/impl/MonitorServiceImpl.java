/**
 * 
 */
package com.sfpay.ews.sch.service.impl;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sfpay.ews.platform.sch.service.IEwsSchedulerService;
import com.sfpay.ews.sch.service.IMonitorService;



/**
 * 类说明：监控服务类
 *
 * 类描述：一个监控预警只需要一个监控服务实例，用单独的线程来更新监控预警数据
 * @author 625288
 *
 * 2015-3-2
 */
@Service("monitorService")
public class MonitorServiceImpl implements IMonitorService{
	@Autowired
	private IEwsSchedulerService ewsSchedulerService;
	
	// 刷新时间间隔，单位毫秒
	@Value("${MONITOR_TIME}")
	private long monitorTime;
	
	private Thread monitorThread;
	
	// 监控线程状态
	private boolean open;
	
	private Logger logger = LoggerFactory.getLogger(MonitorServiceImpl.class);
	
	public MonitorServiceImpl() {
		monitorThread = new Thread(new MonitorTask());
	}
	
	@PostConstruct
	@Override
	public synchronized void start() {
		logger.info("准备启动定时刷新监控预警调度信息线程... ...");
		
		if(monitorThread == null) {
			logger.error("监控线程为空，开启失败！！");
			throw new IllegalStateException("监控线程为空，无法开启");
		}
		
		// 设置成守护线程
		monitorThread.setDaemon(true);
		monitorThread.start();
		open = true;
		
		logger.info("成功启动定时刷新监控预警调度信息线程");
	}

	@PreDestroy
	@Override
	public synchronized void stop() {
		logger.info("监控线程正在关闭... ...");
		
		if(monitorThread == null) {
			logger.error("监控线程为空，关闭失败！！");
			throw new IllegalStateException("监控线程为空，无法关闭！");
		}
		
		monitorThread.interrupt();
		open = false;
		
		logger.info("监控线程关闭结束.");
		
	}
	
	/**
	 * 
	 * 类说明：监控线程类
	 *
	 * 类描述：监控线程类
	 * @author 625288
	 *
	 * 2015-3-2
	 */
	class MonitorTask implements Runnable {

		@Override
		public void run() {
			logger.info("MonitorTask 开始运行... ...");
			
			while(true) {
				if(!open) {
					logger.info("监控预警MonitorTask线程响应关闭");
					break;
				}
				
				ewsSchedulerService.schedulerUpdateEwsIndexDef();
				
				try {
					Thread.sleep(monitorTime);
				} catch (InterruptedException e) {
					logger.info("监控预警MonitorTask线程响应中断");
					break;
				}
			}
			
			logger.info("MonitorTask 运行结束.");
		}
		
	}
}
