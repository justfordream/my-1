/**
 * 
 */
package com.sfpay.ews.sch.service.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.sch.service.IEwsTaskService;
import com.sfpay.ews.sch.listener.SfpayEwsContextLoaderListener;

/**
 * 类说明：预警指标调度任务类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-10
 */
public class EwsSchedulerJob implements Job{
	
	private Logger logger = LoggerFactory.getLogger(EwsSchedulerJob.class);
	
	@Override
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		String warnIndexNo = (String) jobExecutionContext.getJobDetail().
				getJobDataMap().get(EwsIndexDef.class.getSimpleName());
		try {
			((IEwsTaskService) SfpayEwsContextLoaderListener.getBean("ewsTaskService")).
				doTask(warnIndexNo);
		} catch (Exception e) {
			logger.error("执行监控预警指标{}任务出错:", warnIndexNo, e);
		}
	}
}
