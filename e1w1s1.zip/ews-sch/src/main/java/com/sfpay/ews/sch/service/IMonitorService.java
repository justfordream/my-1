/**
 * 
 */
package com.sfpay.ews.sch.service;

/**
 * 类说明：监控预警定时刷新指标信息类
 *
 * 类描述：监控预警定时刷新指标信息类
 * @author 625288
 *
 * 2015-3-2
 */
public interface IMonitorService {
	/**
	 * 开启监控线程
	 */
	public void start();
	
	/**
	 * 关闭监控线程
	 */
	public void stop();
}
