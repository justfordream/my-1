/**
 * 
 */
package com.sfpay.ews.sch.service.impl;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.lang3.StringUtils;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.ews.platform.domain.EwsIndexDef;
import com.sfpay.ews.platform.domain.EwsIndexGroup;
import com.sfpay.ews.platform.sch.service.IEwsSchedulerService;
import com.sfpay.ews.platform.service.IEwsIndexDefService;
import com.sfpay.ews.platform.service.IEwsIndexGroupReferService;
import com.sfpay.ews.platform.service.IEwsIndexGroupService;
import com.sfpay.ews.sch.service.job.EwsGroupSchedulerJob;
import com.sfpay.ews.sch.service.job.EwsSchedulerJob;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：预警指标调度服务类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-10
 */
@HessianExporter
@Service("ewsSchedulerService")
public class EwsSchedulerServiceImpl implements IEwsSchedulerService {
	// 调度器
	private Scheduler scheduler;
	@Autowired
	private IEwsIndexGroupReferService ewsIndexGroupReferService;
	@Autowired
	private IEwsIndexGroupService ewsIndexGroupService;
	@Autowired
	private IEwsIndexDefService ewsIndexDefService;
	
	private final static String DEFAULT_GROUP = "EWS_GROUP";
	
	private Logger logger = LoggerFactory.getLogger(EwsSchedulerServiceImpl.class);
	
	/**
	 * 从数据库(EWS_INDEX_DEF)加载最新的指标信息
	 */
	@PostConstruct
	@Override
	public synchronized void refreshEwsIndexDefSchInfo() {
		try {
			if(scheduler == null) {
				logger.info("开始创建调度管理器... ...");
				scheduler = StdSchedulerFactory.getDefaultScheduler();
				logger.info("创建调度管理器成功！");
				scheduler.start();
				logger.info("调度管理器成功启动！");
			}
			
			// 移除所有调度任务
			List<String> jobGroupArray = scheduler.getJobGroupNames();
			if(jobGroupArray != null) {
				for(String jobGroupName : jobGroupArray) {
					for(JobKey jobKey : scheduler.getJobKeys(GroupMatcher.jobGroupEquals(jobGroupName))) {
						scheduler.deleteJob(jobKey);
					}
				}
			}
			
			logger.info("准备从数据库中加载最新的指标信息... ...");
			// 查询所有（新）预警指标信息
			List<EwsIndexDef> ewsIndexDefList = ewsIndexDefService.queryAllIndexDef();
			int indexSuccessNum = 0, indexFailNum = 0, groupSuccessNum = 0, groupFailNum = 0;
			
			if(ewsIndexDefList != null && !ewsIndexDefList.isEmpty()) {
				logger.info("从数据库中查询出【{}】条预警指标.", ewsIndexDefList.size());
				
				for(EwsIndexDef ewsIndexDef : ewsIndexDefList) {
					try {
						addEwsIndexDefSch(ewsIndexDef);
						indexSuccessNum++;
						
					} catch (Exception e) {
						indexFailNum++;
						logger.error("添加指标【{}】到调度管理器异常：", ewsIndexDef.getWarnIndexNo(), e);
					}
				}
			} 
			
			// 查询所有预警指标组信息
			Map<String, List<String>> referMap = ewsIndexGroupReferService.queryAllRefer();
			EwsIndexGroup ewsIndexGroup = null;
			if(!referMap.isEmpty()) {
				logger.info("从数据库中查询出【{}】个预警指标组.", referMap.size());
				
				for(String groupNo : referMap.keySet()) {
					ewsIndexGroup = ewsIndexGroupService.queryEwsIndexGroupByGroupNo(groupNo);
					if(ewsIndexGroup == null) {
						logger.error("设置预警指标组的定时任务失败，无效的预警指标组编号：{}", groupNo);
						continue ;
					}
					
					JobDetail jobDetail = createEwsIndexGroupJobDetail(ewsIndexGroup);
					CronTrigger cronTrigger = null;
					try {
						cronTrigger = createEwsIndexGroupCronTrigger(ewsIndexGroup);
						
					} catch (ParseException e) {
						logger.error("设置指标组调度作业【{}】的CronExpress【{}】失败：", 
								new Object[]{ewsIndexGroup.getWarnIndexGroupNo(), ewsIndexGroup.getCronExpress(), e});
						continue ;
					}
					
					try {
						scheduler.scheduleJob(jobDetail, cronTrigger);
						groupSuccessNum++;
						logger.info("成功添加指标组【{}】到调度管理器.", ewsIndexGroup.getWarnIndexGroupNo());
						
					} catch (Exception e) {
						groupFailNum++;
						logger.error("添加预警指标组【{}】到调度管理器异常：", ewsIndexGroup.getWarnIndexGroupNo(), e);
					}
				}
			}
			
			logger.info("成功添加【{}】条指标调度任务，失败【{}】条！", indexSuccessNum, indexFailNum);
			logger.info("成功添加【{}】条指标组调度任务，失败【{}】条！", groupSuccessNum, groupFailNum);
			logger.info("从数据库中加载最新的指调度标信息完毕。");
			
		} catch (Exception e) {
			logger.error("刷新或启动监控预警定时任务失败：", e);
		}
	}
	
	@Override
	public void schedulerUpdateEwsIndexDef() {
		logger.info("schedulerUpdateEwsIndexDef 定时扫描指标定义开始... ...");
		List<EwsIndexDef> ewsIndexDefList = ewsIndexDefService.queryAllIndexDef();
		if(ewsIndexDefList == null || ewsIndexDefList.isEmpty()) {
			logger.info("schedulerUpdateEwsIndexDef 查询到的指标定义为空，更新调度结束.");
			return ;
		}
		
		for(EwsIndexDef ewsIndexDef : ewsIndexDefList) {
			// 对非法指标、老指标和没有操作标记的指标进行跳过
			if(!"Y".equals(ewsIndexDef.getIsValid()) || StringUtils.isBlank(ewsIndexDef.getCronExpress()) || 
					StringUtils.isBlank(ewsIndexDef.getOprFlag())) {
				continue ;
			}
			
			if("UPDATE".equals(ewsIndexDef.getOprFlag())) {
				logger.info("schedulerUpdateEwsIndexDef 准备【更新】指标【{}】调度信息... ...", 
						ewsIndexDef.getWarnIndexNo());
				try {
					updateEwsIndexDefSch(ewsIndexDef);
					logger.info("schedulerUpdateEwsIndexDef 成功【更新】指标【{}】调度信息", 
							ewsIndexDef.getWarnIndexNo());
				} catch (Exception e) {
					logger.error("schedulerUpdateEwsIndexDef 【更新】指标【{}】调度信息异常:", 
							ewsIndexDef.getWarnIndexNo(), e);
				}
				
			} else if("ADD".equals(ewsIndexDef.getOprFlag())) {
				logger.info("schedulerUpdateEwsIndexDef 准备【新增】指标【{}】调度信息... ...", 
						ewsIndexDef.getWarnIndexNo());
				try {
					addEwsIndexDefSch(ewsIndexDef);
					logger.info("schedulerUpdateEwsIndexDef 成功【新增】指标【{}】调度信息", 
							ewsIndexDef.getWarnIndexNo());
				} catch (Exception e) {
					logger.error("schedulerUpdateEwsIndexDef 【新增】指标【{}】调度信息异常:", 
							ewsIndexDef.getWarnIndexNo(), e);
				}
				
			} else if("DELETE".equals(ewsIndexDef.getOprFlag())) {
				logger.info("schedulerUpdateEwsIndexDef 准备【删除】指标【{}】调度信息... ...", 
						ewsIndexDef.getWarnIndexNo());
				try {
					deleteEwsIndexDefSch(ewsIndexDef);
					logger.info("schedulerUpdateEwsIndexDef 成功【删除】指标【{}】调度信息", 
							ewsIndexDef.getWarnIndexNo());
				} catch (Exception e) {
					logger.error("schedulerUpdateEwsIndexDef 【删除】指标【{}】调度信息异常:", 
							ewsIndexDef.getWarnIndexNo(), e);
				}
				
			} else if("PAUSE".equals(ewsIndexDef.getOprFlag())) {
				logger.info("schedulerUpdateEwsIndexDef 准备【暂停】指标【{}】调度信息... ...", 
						ewsIndexDef.getWarnIndexNo());
				try {
					pauseEwsIndexDefSch(ewsIndexDef);
					logger.info("schedulerUpdateEwsIndexDef 成功【暂停】指标【{}】调度信息", 
							ewsIndexDef.getWarnIndexNo());
				} catch (Exception e) {
					logger.error("schedulerUpdateEwsIndexDef 【暂停】指标【{}】调度信息异常:", 
							ewsIndexDef.getWarnIndexNo(), e);
				}
				
			} else if("RECOVERY".equals(ewsIndexDef.getOprFlag())) {
				logger.info("schedulerUpdateEwsIndexDef 准备【恢复】指标【{}】调度信息... ...", 
						ewsIndexDef.getWarnIndexNo());
				try {
					recoveryEwsIndexDefSch(ewsIndexDef);
					logger.info("schedulerUpdateEwsIndexDef 成功【恢复】指标【{}】调度信息", 
							ewsIndexDef.getWarnIndexNo());
				} catch (Exception e) {
					logger.error("schedulerUpdateEwsIndexDef 【恢复】指标【{}】调度信息异常:", 
							ewsIndexDef.getWarnIndexNo(), e);
				}
				
			} else {
				logger.error("schedulerUpdateEwsIndexDef 指标【{}】无效的操作标记【{}】", 
						ewsIndexDef.getWarnIndexNo(), ewsIndexDef.getOprFlag());
			}
			
			try {
				ewsIndexDef.setOprFlag("");
				ewsIndexDefService.updateEwsIndexDef(ewsIndexDef);
			} catch (Exception e) {
				logger.error("指标【{}】操作标记清除异常:", ewsIndexDef.getWarnIndexNo(), e);
			}
		}
	}
	
	/**
	 * 新增一个指标调度信息
	 * @param ewsIndexDef
	 */
	@Override
	public void addEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException {
		checkEwsIndexDef(ewsIndexDef);
		
		logger.info("准备新增指标【{}】调度任务... ...", ewsIndexDef.getWarnIndexNo());
		
		String jobName = ewsIndexDef.getWarnIndexNo();
		try {
			if(jobIsExists(jobName)) {
				logger.error("新增指标调度信息失败，调度作业【{}】已经存在！", jobName);
				throw new ServiceException(String.format("新增指标调度信息失败，调度作业【%s】已经存在！", jobName));
			}
			
			// 创建JobDetail
			JobDetail jobDetail = createEwsIndexDefJobDetail(ewsIndexDef);
			// 创建CronTrigger
			CronTrigger cronTrigger = createEwsIndexDefCronTrigger(ewsIndexDef);
			
			scheduler.scheduleJob(jobDetail, cronTrigger);
			if("CLOSE".equals(ewsIndexDef.getStatus())) {
				logger.info("指标【{}】状态为CLOSE，添加完调度器后还需要暂停该调度器.", ewsIndexDef.getWarnIndexNo());
				scheduler.pauseJob(new JobKey(ewsIndexDef.getWarnIndexNo(), DEFAULT_GROUP));
				logger.info("指标【{}】调度器已经被暂停.", ewsIndexDef.getWarnIndexNo());
			}
			
			logger.info("新增指标【{}】调度任务成功！", ewsIndexDef.getWarnIndexNo());
			
		} catch (SchedulerException e) {
			logger.error("检查调度作业【{}】是否存在异常：", new Object[]{jobName, e});
			throw new ServiceException(String.format("新增指标调度信息失败，调度作业【%s】是否存在检查异常!", 
					jobName));
			
		} catch (ParseException e) {
			logger.error("设置指标调度作业【{}】的CronExpress【{}】失败：", 
					new Object[]{jobName, ewsIndexDef.getCronExpress(), e});
			throw new ServiceException(String.format("设置指标调度作业【%s】调度周期表达式【%s】异常!", 
					new Object[]{jobName, ewsIndexDef.getCronExpress()}));
		} catch (Exception e) {
			logger.error("新增指标调度作业【{}】异常：", new Object[]{jobName, e});
			throw new ServiceException(String.format("新增指标调度作业【%s:%s】异常", new Object[]{DEFAULT_GROUP, jobName}));
		}
	}
	
	/**
	 * 删除一个指标调度信息
	 * @param ewsIndexDef
	 */
	@Override
	public void deleteEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException {
		checkEwsIndexDef(ewsIndexDef);
		
		checkIndexExists(ewsIndexDef);
		
		logger.info("准备删除指标【{}】调度任务... ...", ewsIndexDef.getWarnIndexNo());
		
		String jobName = ewsIndexDef.getWarnIndexNo();
		try {
			if(!jobIsExists(jobName)) {
				logger.warn("无需删除指标调度信息，调度作业【{}】不存在！", jobName);
//				throw new ServiceException(String.format("删除指标调度信息失败，调度作业【%s:%s】不存在！", 
//						new Object[]{triggerGroupName, triggerName}));
				return ;
			}
			
			scheduler.deleteJob(new JobKey(jobName, DEFAULT_GROUP));
			
			logger.info("删除指标【{}】调度任务成功！", ewsIndexDef.getWarnIndexNo());
			
		} catch (SchedulerException e) {
			logger.error("检查调度作业【{}】是否存在异常：", new Object[]{ jobName, e});
			throw new ServiceException(String.format("删除指标调度信息失败，调度作业【%s】是否存在检查异常!", 
					jobName));
			
		} catch (Exception e) {
			logger.error("删除指标调度作业【{}】异常：", new Object[]{jobName, e});
			throw new ServiceException(String.format("删除指标调度作业【%s】异常", jobName));
		}
	}
	
	/**
	 * 更新一个指标调度信息
	 * @param ewsIndexDef
	 */
	@Override
	public void updateEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException {
		checkEwsIndexDef(ewsIndexDef);
		
		checkIndexExists(ewsIndexDef);
		
		logger.info("准备更新指标【{}】调度任务... ...", ewsIndexDef.getWarnIndexNo());
		
		String jobName = ewsIndexDef.getWarnIndexNo();
		try {
			if(!jobIsExists(jobName)) {
				logger.error("更新指标调度信息失败，调度作业【{}】不存在！", jobName);
				throw new ServiceException(String.format("删除指标调度信息失败，调度作业【%s】不存在！", 
						jobName));
			}
			
			// Trigger和Job的名称和组名都一样
			Trigger oldTrigger = scheduler.getTrigger(new TriggerKey(jobName, DEFAULT_GROUP));
			
			CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.
					cronSchedule(ewsIndexDef.getCronExpress());
			@SuppressWarnings("rawtypes")
			TriggerBuilder tb = oldTrigger.getTriggerBuilder();
			@SuppressWarnings("unchecked")
			Trigger newTrigger = tb.withSchedule(scheduleBuilder).build();

			// 更新调度任务
			scheduler.rescheduleJob(oldTrigger.getKey(), newTrigger);
			logger.info("成功更新指标【{}】调度器.", ewsIndexDef.getWarnIndexNo());
			if("CLOSE".equals(ewsIndexDef.getStatus())) {
				logger.info("指标【{}】状态为CLOSE，更新完调度器后还需要暂停该调度器.", ewsIndexDef.getWarnIndexNo());
				scheduler.pauseJob(new JobKey(ewsIndexDef.getWarnIndexNo(), DEFAULT_GROUP));
				logger.info("指标【{}】调度器已经被暂停.", ewsIndexDef.getWarnIndexNo());
			}
			
			logger.info("更新指标【{}】调度任务成功！", ewsIndexDef.getWarnIndexNo());
			
		} catch (SchedulerException e) {
			logger.error("检查调度作业【{}】是否存在异常：", new Object[]{jobName, e});
			throw new ServiceException(String.format("更新指标调度信息失败，调度作业【%s】是否存在检查异常!", 
					jobName));
			
		} catch (Exception e) {
			logger.error("更新指标调度作业【{}】异常：", new Object[]{jobName, e});
			throw new ServiceException(String.format("更新指标调度作业【%s】异常", jobName));
		}
	}
	
	/**
	 * 暂停一个指标
	 * @param ewsIndexDef
	 */
	@Override
	public void pauseEwsIndexDefSch(EwsIndexDef ewsIndexDef) throws ServiceException{
		checkEwsIndexDef(ewsIndexDef);
		
		checkIndexExists(ewsIndexDef);
		
		logger.info("准备暂停指标【{}】调度任务... ...", ewsIndexDef.getWarnIndexNo());
		try {
			scheduler.pauseJob(new JobKey(ewsIndexDef.getWarnIndexNo(), DEFAULT_GROUP));
			logger.info("成功暂停指标【{}】调度器.", ewsIndexDef.getWarnIndexNo());
			
			// 将指标调度状态设置成CLOSE
			ewsIndexDefService.updateIndexSchStatus(ewsIndexDef.getWarnIndexNo(), "CLOSE");
			logger.info("成功将指标【{}】调度状态设置成CLOSE.", ewsIndexDef.getWarnIndexNo());
			
			logger.info("暂停指标【{}】调度任务完成！", ewsIndexDef.getWarnIndexNo());
		} catch (Exception e) {
			logger.error("暂停指标调度作业【{}】异常：", new Object[]{ewsIndexDef.getWarnIndexNo(), e});
			throw new ServiceException(String.format("暂停指标调度作业【%s】异常：", ewsIndexDef.getWarnIndexNo()));
		}
	}
	
	/**
	 * 恢复一个被暂停的指标
	 * @param ewsIndexDef
	 */
	public void recoveryEwsIndexDefSch(EwsIndexDef ewsIndexDef) {
		checkEwsIndexDef(ewsIndexDef);
		
		checkIndexExists(ewsIndexDef);
		
		logger.info("准备恢复一个被暂停的指标【{}】调度任务... ...", ewsIndexDef.getWarnIndexNo());
		try {
//			CronTrigger trigger = createEwsIndexDefCronTrigger(ewsIndexDef);
//			scheduler.rescheduleJob(new TriggerKey(ewsIndexDef.getWarnIndexNo(), DEFAULT_GROUP), trigger);
			scheduler.resumeJob(new JobKey(ewsIndexDef.getWarnIndexNo(), DEFAULT_GROUP));
			logger.info("成功开启指标【{}】调度器.", ewsIndexDef.getWarnIndexNo());
			
			// 将指标调度状态设置成START
			ewsIndexDefService.updateIndexSchStatus(ewsIndexDef.getWarnIndexNo(), "START");
			logger.info("成功将指标【{}】调度状态设置成START.", ewsIndexDef.getWarnIndexNo());
			
			logger.info("恢复指标【{}】调度任务完成！", ewsIndexDef.getWarnIndexNo());
		} catch (Exception e) {
			logger.error("恢复指标调度作业【{}】异常：", new Object[]{ewsIndexDef.getWarnIndexNo(), e});
			throw new ServiceException(String.format("恢复指标调度作业【%s】异常：", ewsIndexDef.getWarnIndexNo()));
		}
	}
	
	/**
	 * 为预警指标创建JobDetail对象
	 * @param ewsIndexDef
	 * @return
	 */
	private JobDetail createEwsIndexDefJobDetail(EwsIndexDef ewsIndexDef) {
		JobDetail jobDetail = JobBuilder.newJob(EwsSchedulerJob.class)
			    .withIdentity(ewsIndexDef.getWarnIndexNo(), DEFAULT_GROUP)
			    .usingJobData(EwsIndexDef.class.getSimpleName(), ewsIndexDef.getWarnIndexNo())
			    .build();
		
		return jobDetail;
	}
	
	/**
	 * 为预警指标创建CronTrigger对象
	 * @param ewsIndexDef
	 * @return
	 * @throws ParseException 
	 */
	private CronTrigger createEwsIndexDefCronTrigger(EwsIndexDef ewsIndexDef) throws ParseException {
		CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.
				cronSchedule(ewsIndexDef.getCronExpress());
		
		CronTrigger trigger = TriggerBuilder.newTrigger()
			    .withIdentity(ewsIndexDef.getWarnIndexNo(), DEFAULT_GROUP)
			    .withSchedule(scheduleBuilder)
			    .startNow()
			    .build();
		
		return trigger;
	}
	
	/**
	 * 为预警指标组创建JobDetail对象
	 * @param ewsIndexGroup
	 * @return
	 */
	private JobDetail createEwsIndexGroupJobDetail(EwsIndexGroup ewsIndexGroup) {
		JobDetail jobDetail = JobBuilder.newJob(EwsGroupSchedulerJob.class)
			    .withIdentity(ewsIndexGroup.getWarnIndexGroupNo(), DEFAULT_GROUP)
			    .usingJobData(EwsIndexGroup.class.getSimpleName(), DEFAULT_GROUP)
			    .build();
		
		return jobDetail;
	}
	
	/**
	 * 为预警指标组创建CronTrigger对象
	 * @param ewsIndexGroup
	 * @return
	 * @throws ParseException 
	 */
	private CronTrigger createEwsIndexGroupCronTrigger(EwsIndexGroup ewsIndexGroup) throws ParseException {
		CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.
				cronSchedule(ewsIndexGroup.getCronExpress());
		
		CronTrigger trigger = TriggerBuilder.newTrigger()
			    .withIdentity(ewsIndexGroup.getWarnIndexGroupNo(), DEFAULT_GROUP)
			    .withSchedule(scheduleBuilder)
			    .startNow()
			    .build();
		
		return trigger;
	}
	
	
	/**
	 * 检查某个Job是否存在
	 * @param jobName
	 * @param groupName
	 * @return
	 * @throws SchedulerException 
	 */
	private boolean jobIsExists(String jobName) throws SchedulerException {
		return scheduler.checkExists(new JobKey(jobName, DEFAULT_GROUP));
	}
	
	/**
	 * 检查指标定义对象是否符合规范
	 * @param ewsIndexDef
	 */
	private void checkEwsIndexDef(EwsIndexDef ewsIndexDef) {
		if(scheduler == null) {
			logger.error("调度系统还未启动，删除指标调度信息失败！");
			throw new ServiceException("调度系统还未启动，删除指标调度信息失败！");
		}
		
		if(ewsIndexDef == null) {
			logger.error("checkEwsIndexDef:指标对象不能为空！");
			throw new ServiceException("指标对象不能为空！");
		}
		
		if(StringUtils.isBlank(ewsIndexDef.getWarnIndexNo())) {
			logger.error("checkEwsIndexDef:指标编号不能为空！");
			throw new ServiceException("指标编号不能为空！");
		}
		
		if(StringUtils.isBlank(ewsIndexDef.getWarnSource())) {
			logger.error("checkEwsIndexDef:指标来源不能为空！");
			throw new ServiceException("指标来源不能为空！");
		}
		
		if(StringUtils.isBlank(ewsIndexDef.getCronExpress())) {
			logger.error("checkEwsIndexDef:指标调度周期表达式不能为空！");
			throw new ServiceException("指标调度周期表达式不能为空！");
		}
		
	}
	
	/**
	 * 检查预警指标是否存在
	 * @param ewsIndexDef
	 */
	private void checkIndexExists(EwsIndexDef ewsIndexDef) {
		if(ewsIndexDefService.queryByWarnIndexNo(ewsIndexDef.getWarnIndexNo()) == null) {
			logger.error("checkEwsIndexDef:指标编号【{}】不存在！", ewsIndexDef.getWarnIndexNo());
			throw new ServiceException(String.format("指标编号【%s】不存在", ewsIndexDef.getWarnIndexNo()));
		}
	}
	
	/**
	 * 退出时将所有指标的调度任务的运行状态修改成：STOP
	 */
	@PreDestroy
	public void resetJobRunStatus() {
		try {
			ewsIndexDefService.updateAllIndexSchRunStatusToStop();
			logger.info("退出时成功将所有指标的调度任务的运行状态修改成【STOP】");
		} catch (Exception e) {
			logger.error("退出时将所有指标的调度任务的运行状态修改成【STOP】异常：", e);
		}
	}
	
}
