/**
 * 
 */
package com.sfpay.ews.sch.service.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ews.platform.domain.EwsIndexGroup;
import com.sfpay.ews.platform.sch.service.IEwsGroupTaskService;
import com.sfpay.ews.sch.listener.SfpayEwsContextLoaderListener;

/**
 * 类说明：预警指标组调度任务类
 *
 * 类描述：
 * @author 625288
 *
 * 2015-3-11
 */
public class EwsGroupSchedulerJob implements Job{
	
	private Logger logger = LoggerFactory.getLogger(EwsGroupSchedulerJob.class);

	@Override
	public void execute(JobExecutionContext jobExecutionContext)
			throws JobExecutionException {
		String ewsIndexGroupNo = (String) jobExecutionContext.getJobDetail().
				getJobDataMap().get(EwsIndexGroup.class.getSimpleName());
		try {
			((IEwsGroupTaskService) SfpayEwsContextLoaderListener.getBean("ewsGroupTaskService")).
				doTask(ewsIndexGroupNo);
		} catch (Exception e) {
			logger.error("执行监控预警指标组{}任务出错:", ewsIndexGroupNo, e);
		}
		
	}

}
