--顺手付新增红包调度任务每4小时一次（08:00-16:00）
insert into dm_sch.SCH_JOB (job_code, job_name, invoke_service_name, execute_remote_service, execute_remote_service_method, cronexpression, type, status, predict_time, is_alone_start, sys_code, remark, create_id, CREATE_TIME, update_id, UPDATE_TIME,IS_SINGLETON)
values ('invokeSypayRedBagFourHourJob', '顺手付新增红包调度任务每4小时一次（08:00-16:00）', 'ewsServiceInvoke', 'ewsTimeJobServiceImpl', 'invokeSypayRedBagFourHourJob', '0 0 08-16/4 * * ?', 'BUSINESS_TASK', 'START', 1800000, '1', 'ewsServiceInvoke', null, '593702',sysdate, null, null,'1');

--顺手付新增红包调度任务每天定时任务（08:40）
insert into dm_sch.SCH_JOB (job_code, job_name, invoke_service_name, execute_remote_service, execute_remote_service_method, cronexpression, type, status, predict_time, is_alone_start, sys_code, remark, create_id, CREATE_TIME, update_id, UPDATE_TIME,IS_SINGLETON)
values ('invokeSypayRedBagDayJob', '顺手付新增红包调度任务每天定时任务（08:40）', 'ewsServiceInvoke', 'ewsTimeJobServiceImpl', 'invokeSypayRedBagDayJob', '0 40 8 * * ?', 'BUSINESS_TASK', 'START', 1800000, '1', 'ewsServiceInvoke', null, '593702',sysdate, null, null,'1');

--理赔统付ISS每天2次的调度(1:00;13:00)
insert into dm_sch.SCH_JOB (JOB_CODE, JOB_NAME, INVOKE_SERVICE_NAME, EXECUTE_REMOTE_SERVICE, EXECUTE_REMOTE_SERVICE_METHOD, CRONEXPRESSION, TYPE, STATUS, PREDICT_TIME, IS_ALONE_START, SYS_CODE, REMARK, CREATE_ID, CREATE_TIME, UPDATE_ID, UPDATE_TIME,IS_SINGLETON)
values ('invokeIssDayJob', '理赔统付ISS每天2次的调度(1:00;13:00)', 'ewsServiceInvoke', 'ewsTimeJobServiceImpl', 'invokeIssDayJob', '0 0 1,13 * * ?', 'BUSINESS_TASK', 'START', 1800000, '1', 'ewsServiceInvoke', null, '700316', sysdate,  null, null,'1');

--理财平台新增调度任务每小时一次
insert into dm_sch.SCH_JOB
  (job_code,job_name,invoke_service_name,execute_remote_service,execute_remote_service_method,cronexpression,type,
   status, predict_time,is_alone_start,sys_code,remark,create_id,CREATE_TIME,update_id,UPDATE_TIME,IS_SINGLETON)
values
  ('invokeLcptHourJob','理财平台LCPT每小时一次的调度(00:00-24:00)','ewsServiceInvoke','ewsTimeJobServiceImpl',
   'invokeLcptHourJob','0 10 0-23/1 * * ?','BUSINESS_TASK',
   'START',1800000,'1','ewsServiceInvoke',null,'592831',sysdate,null,null,'1');
   
--理财平台新增调度任务每天一次
insert into dm_sch.SCH_JOB
  (job_code,job_name,invoke_service_name,execute_remote_service,execute_remote_service_method,cronexpression,type,
   status, predict_time,is_alone_start,sys_code,remark,create_id,CREATE_TIME,update_id,UPDATE_TIME,IS_SINGLETON)
values
  ('invokeLcptAgreeTimeJob','理财平台LCPT每天一次的调度(02:00)','ewsServiceInvoke','ewsTimeJobServiceImpl',
   'invokeLcptAgreeTimeJob','0 0 1 * * ?','BUSINESS_TASK',
   'START',1800000,'1','ewsServiceInvoke',null,'592831',sysdate,null,null,'1');   
   
commit;