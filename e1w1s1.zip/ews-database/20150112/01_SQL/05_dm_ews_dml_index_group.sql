--顺手付红包指标 SYPAY0007
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SYPAY0007', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'SYPAY0007', '000000', sysdate);  
--顺手付红包指标 SYPAY0008
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SYPAY0008', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'SYPAY0008', '000000', sysdate);  
--顺手付红包指标 SYPAY0009
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SYPAY0009', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'SYPAY0009', '000000', sysdate);  
--顺手付红包指标 SYPAY0010
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SYPAY0010', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'SYPAY0010', '000000', sysdate);  
--顺手付红包指标 SYPAY0011
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SYPAY0011', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'SYPAY0011', '000000', sysdate);  
--顺手付红包指标 SYPAY0012
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SYPAY0012', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'SYPAY0012', '000000', sysdate);  
  
--配置理财平台指标LCPT0001告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0001', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0001', '000000', sysdate);  
--配置理财平台指标LCPT0002告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0002', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0002', '000000', sysdate);   
--配置理财平台指标LCPT0003告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0003', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0003', '000000', sysdate);  
--配置理财平台指标LCPT0004告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0004', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0004', '000000', sysdate);  
--配置理财平台指标LCPT0005告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0005', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0005', '000000', sysdate);   
--配置理财平台指标LCPT0006告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0006', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0006', '000000', sysdate);  
--配置理财平台指标LCPT0007告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0007', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0007', '000000', sysdate);  
--配置理财平台指标LCPT0008告警群组
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0008', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0008', '000000', sysdate);  
--配置理财平台指标LCPT0009告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0009', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0009', '000000', sysdate);  
--配置理财平台指标LCPT0010告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0010', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0010', '000000', sysdate);  
--配置理财平台指标LCPT0011告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0011', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0011', '000000', sysdate);  
--配置理财平台指标LCPT0012告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0012', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0012', '000000', sysdate);  
--配置理财平台指标LCPT0013告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0013', '000000', sysdate);
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0013', '000000', sysdate); 
--配置理财平台指标LCPT0014告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'LCPT_GROUP', 'LCPT0014', '000000', sysdate);  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'LCPT0014', '000000', sysdate);   
  

--配置理赔统付指标ISS0001告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ISS_GROUP', 'ISS0001', '000000', sysdate);  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'ISS0001', '000000', sysdate);   
--配置理赔统付指标ISS0002告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ISS_GROUP', 'ISS0002', '000000', sysdate);  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'ISS0002', '000000', sysdate);
--配置理赔统付指标ISS0003告警群组  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ISS_GROUP', 'ISS0003', '000000', sysdate);  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'ISS0003', '000000', sysdate);   

commit;  