update ews_index_param t set t.param_val = '00:00:00' where t.param_no = 'BEGINTIME' and t.warn_index_no = 'LCPT0010';
update ews_index_param t set t.param_val = '23:59:59' where t.param_no = 'ENDTIME' and t.warn_index_no = 'LCPT0010';
update ews_index_param t set t.param_val = '24' where t.param_no = 'QRYTIME' and t.warn_index_no = 'LCPT0010';

commit;