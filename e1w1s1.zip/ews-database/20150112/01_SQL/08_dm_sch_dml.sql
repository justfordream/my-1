--顺手付新增红包调度任务每4小时一次，调度时间调整
update dm_sch.SCH_JOB t
   set t.cronexpression = '0 0 8-16/4 * * ?',
       t.update_id = '700316', 
       t.update_time = sysdate
 where t.job_code = 'invokeSypayRedBagFourHourJob';
 
--理财平台LCPT每天一次的调度时间调整
update dm_sch.SCH_JOB t
   set t.cronexpression = '0 0 2 * * ?',
       t.update_id = '700316', 
       t.update_time = sysdate
 where t.job_code = 'invokeLcptAgreeTimeJob'; 
 
--理赔统付ISS每天3次的调度(13:00/17:00/21:00)
update dm_sch.SCH_JOB t
   set t.job_name = '理赔统付ISS每天3次的调度(13:00/17:00/21:00)',
       t.cronexpression = '0 0 13,17,21 * * ?',
       t.update_id = '700316', 
       t.update_time = sysdate
 where t.job_code = 'invokeIssDayJob'; 
 
commit; 