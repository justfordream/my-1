﻿--垫付指标22监控方案优化，表DM_PAS.SYS_PARAM授权
grant select on DM_PAS.SYS_PARAM to dm_ews;

--顺手付新增指标方案，表dm_sypay.re_batch，dm_sypay.re_detail授权
grant select on dm_sypay.re_batch to dm_ews;
grant select on dm_sypay.re_detail to dm_ews;

--理赔统付新增指标方案，表：DM_ISS.ISS_REQUEST，DM_ACQ.PAYOUT_INFO，DM_ISS.PAY_REQUEST授权
grant select on DM_ISS.ISS_REQUEST to dm_ews;
grant select on DM_ACQ.PAYOUT_INFO to dm_ews;
grant select on DM_ISS.PAY_REQUEST to dm_ews;

--理财平台新增指标方案，相关表授权
grant select on dm_sypay.PAY_BUSINESS to dm_ews;
grant select on dm_lcpt.FUND_SIGN to dm_ews;
grant select on dm_lcpt.FUND_TRADE_ORDER to dm_ews;
grant select on dm_lcpt.PAYMENT_DETAIL to dm_ews;
grant select on dm_lcpt.SYS_PARAM to dm_ews;
grant select on dm_lcpt.EXCEPTION_ORDER to dm_ews;
