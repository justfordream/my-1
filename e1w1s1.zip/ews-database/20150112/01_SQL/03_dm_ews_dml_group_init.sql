--新增理财平台告警群组                           
insert into ews_group_def
  (group_no,group_name,group_explain,is_valid,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT_GROUP','理财平台群组','理财平台群组','Y','','000000',sysdate,'','');
  
--新增理赔统付告警群组                           
insert into ews_group_def
  (group_no,group_name,group_explain,is_valid,remark,create_id,create_time,update_id,update_time)
values
  ('ISS_GROUP','理赔统付群组','理赔统付群组','Y','','000000',sysdate,'','');  
  
commit;  