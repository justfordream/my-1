--增加顺手付红包指标定义7
insert into ews_index_def
  (warn_index_no, warn_index_name, warn_source, warn_type, warn_property, warn_cycle, warn_cycle_val, warn_result_source, warn_level, is_valid, is_mail_notify, is_sms_notify, remark, create_id, create_time, update_id, update_time)
values
  ('SYPAY0007', '监控已领取、已拆开、过期已退款的小红包累计金额大于红包批次小红包总金额异常', 'SYPAY', 'AFTER', 'WARNING', 'HOUR', 4, 'B', 'L1', 'Y', 'Y', 'Y', '', '000000', sysdate, '', '');

--增加顺手付红包指标定义8
insert into ews_index_def
  (warn_index_no, warn_index_name, warn_source, warn_type, warn_property, warn_cycle, warn_cycle_val, warn_result_source, warn_level, is_valid, is_mail_notify, is_sms_notify, remark, create_id, create_time, update_id, update_time)
values
  ('SYPAY0008', '监控已领取、已拆开、过期已退款的小红包累计个数大于红包批次小红包总个数异常', 'SYPAY', 'AFTER', 'WARNING', 'HOUR', 4, 'B', 'L1', 'Y', 'Y', 'Y', '', '000000', sysdate, '', '');
--增加顺手付红包指标定义9
insert into ews_index_def
  (warn_index_no, warn_index_name, warn_source, warn_type, warn_property, warn_cycle, warn_cycle_val, warn_result_source, warn_level, is_valid, is_mail_notify, is_sms_notify, remark, create_id, create_time, update_id, update_time)
values
  ('SYPAY0009', '监控红包批次抢完后小红包累计金额不等于大红包总金额异常', 'SYPAY', 'AFTER', 'WARNING', 'DAY', 1, 'B', 'L1', 'Y', 'Y', 'Y', '', '000000', sysdate, '', '');
--增加顺手付红包指标定义10
insert into ews_index_def
  (warn_index_no, warn_index_name, warn_source, warn_type, warn_property, warn_cycle, warn_cycle_val, warn_result_source, warn_level, is_valid, is_mail_notify, is_sms_notify, remark, create_id, create_time, update_id, update_time)
values
  ('SYPAY0010', '监控一个红包批次一个会员领取多次红包的异常', 'SYPAY', 'AFTER', 'WARNING', 'DAY', 1, 'B', 'L3', 'Y', 'Y', 'Y', '', '000000', sysdate, '', '');
--增加顺手付红包指标定义11
insert into ews_index_def
  (warn_index_no, warn_index_name, warn_source, warn_type, warn_property, warn_cycle, warn_cycle_val, warn_result_source, warn_level, is_valid, is_mail_notify, is_sms_notify, remark, create_id, create_time, update_id, update_time)
values
  ('SYPAY0011', '监控是否存在单个1万元以上的红包的异常', 'SYPAY', 'AFTER', 'WARNING', 'DAY', 1, 'B', 'L5', 'Y', 'Y', 'Y', '', '000000', sysdate, '', '');
--增加顺手付红包指标定义12
insert into ews_index_def
  (warn_index_no, warn_index_name, warn_source, warn_type, warn_property, warn_cycle, warn_cycle_val, warn_result_source, warn_level, is_valid, is_mail_notify, is_sms_notify, remark, create_id, create_time, update_id, update_time)
values
  ('SYPAY0012', '监控一个人一天发的红包累计金额超过20万元的异常', 'SYPAY', 'AFTER', 'WARNING', 'DAY', 1, 'B', 'L5', 'Y', 'Y', 'Y', '', '000000', sysdate, '', '');


--新增指标LCPT0001
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0001','大额赎回订单','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');
--新增指标LCPT0002
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0002','申购未支付订单占比','LCPT','AFTER','WARNING','DAY',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');   
--新增指标LCPT0003
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0003','开户失败','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');  
--新增指标LCPT0004
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0004','申购失败','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');  
--新增指标LCPT0005
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0005','普通赎回交易订单失败','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');  
--新增指标LCPT0006
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0006','快速赎回交易订单失败','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');   
--新增指标LCPT0007
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0007','普通赎回支付订单失败','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');
--新增指标LCPT0008
 insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0008','快速赎回支付订单失败','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'',''); 
--新增指标LCPT0009
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0009','理财平台异常订单','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'',''); 
--新增指标LCPT0010
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0010','快速赎回未当天到账','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');
--新增指标LCPT0011
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0011','相同客户重复赎回','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');
--新增指标LCPT0012
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0012','相同客户重复申购','LCPT','AFTER','WARNING','HOUR',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');
--新增指标LCPT0013
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0013','业务订单-支付订单金额不符','LCPT','AFTER','WARNING','DAY',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');
--新增指标LCPT0014
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('LCPT0014','业务订单-支付订单笔数不符','LCPT','AFTER','WARNING','DAY',
   1,'B','L1','Y','Y','N','','000000',sysdate,'','');
   
--新增指标ISS0001
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('ISS0001','监控指标(事前)-重复付款记录监控','ISS','AFTER','WARNING','DAY',
   2,'B','L1','Y','Y','N','','000000',sysdate,'',''); 
--新增指标ISS0002
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('ISS0002','监控指标(事前)-付款申请记录数与应付款记录数等值指标','ISS','AFTER','WARNING','DAY',
   2,'B','L1','Y','Y','N','','000000',sysdate,'','');   
--新增指标ISS0003
insert into ews_index_def
  (warn_index_no,warn_index_name,warn_source,warn_type,warn_property,warn_cycle,
   warn_cycle_val,warn_result_source,warn_level,is_valid,is_mail_notify,
   is_sms_notify,remark,create_id,create_time,update_id,update_time)
values
  ('ISS0003','监控指标(事前)-付款申请金额与应付款金额等值（含抵扣）','ISS','AFTER','WARNING','DAY',
   2,'B','L1','Y','Y','N','','000000',sysdate,'',''); 

commit;   
