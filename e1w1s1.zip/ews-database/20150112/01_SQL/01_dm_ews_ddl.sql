--create table ews_error_log
create table ews_error_log 
(
   ID                   NUMBER(16)   not null,
   warn_source          VARCHAR2(50) not null,
   warn_index_no        VARCHAR2(50),
   remark               VARCHAR2(3000),
   creator              VARCHAR2(50),
   create_time          DATE,
   constraint PK_ews_error_log primary key (ID)
);

comment on table ews_error_log is
'ews监控预警错误日志表';

comment on column ews_error_log.ID is
'主键ID';

comment on column ews_error_log.warn_source is
'预警来源';

comment on column ews_error_log.warn_index_no is
'预警指标编号';

comment on column ews_error_log.remark is
'错误描述信息';

comment on column ews_error_log.creator is
'创建人';

comment on column ews_error_log.create_time is
'创建时间';

--create index
create index IDX_EWS_ERROR_LOG_WARN_SOURCE on ews_error_log (warn_source) tablespace EWS_IDX_TS1;

-- Create sequence 
create sequence SEQ_EWS_ERROR_LOG_INDEX
minvalue 1
maxvalue 9999999999999999
start with 1
increment by 1
cache 50;