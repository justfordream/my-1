--补充授权
grant select on dm_sypay.pay_business to dm_ews;
grant select on dm_sypay.pay_trade to dm_ews;
grant select on dm_sypay.withdraw_apply to dm_ews;
grant select on dm_sypay.recharge_order to dm_ews;
grant select on dm_sypay.batch_business to dm_ews;
grant select on dm_fms.t_fund_batch to dm_ews;
grant select on dm_fms.t_fund_detail to dm_ews;
