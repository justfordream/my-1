--理财平台指标LCPT0001新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标一查询时间参数', '1', '小时', 'LCPT', 'LCPT0001', '大额赎回订单', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0001新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标一查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0001', '大额赎回订单', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0001新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标一查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0001', '大额赎回订单', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0002新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标二查询时间参数', '24', '小时', 'LCPT', 'LCPT0002', '申购未支付订单占比', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0002新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标二查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0002', '申购未支付订单占比', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0002新增阀值参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'INDEXTWOTHRESHOLD', 'Lcpt指标二查询阀值', '40', '', 'LCPT', 'LCPT0002', '申购未支付订单占比', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0002新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标二查询结束时间', '23:59:59', '', 'LCPT', 'LCPT0002', '申购未支付订单占比', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0003新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标三查询时间参数', '1', '小时', 'LCPT', 'LCPT0003', '开户失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0003新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标三查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0003', '开户失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0003新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标三查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0003', '开户失败', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0004新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标四查询时间参数', '1', '小时', 'LCPT', 'LCPT0004', '申购失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0004新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标四查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0004', '申购失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0004新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标四查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0004', '申购失败', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0005新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标五查询时间参数', '1', '小时', 'LCPT', 'LCPT0005', '普通赎回交易订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0005新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标五查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0005', '普通赎回交易订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0005新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标五查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0005', '普通赎回交易订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0006新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标六查询时间参数', '1', '小时', 'LCPT', 'LCPT0006', '快速赎回交易订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0006新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标六查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0006', '快速赎回交易订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0006新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标六查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0006', '快速赎回交易订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0007新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标七查询时间参数', '1', '小时', 'LCPT', 'LCPT0007', '普通赎回支付订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0007新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标七查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0007', '普通赎回支付订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0007新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标七查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0007', '普通赎回支付订单失败', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0008新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标八查询时间参数', '1', '小时', 'LCPT', 'LCPT0008', '快速赎回支付订单失败', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0008新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标八查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0008', '快速赎回支付订单失败', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0008新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标八查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0008', '快速赎回支付订单失败', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0009新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标九查询时间参数', '1', '小时', 'LCPT', 'LCPT0009', '异常订单', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0009新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标九查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0009', '异常订单', '', 'Y', '000000', sysdate, '', '');
 
--理财平台指标LCPT0009新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标九查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0009', '异常订单', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0010新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标十查询时间参数', '1', '小时', 'LCPT', 'LCPT0010', '快速赎回未当天到账', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0010新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标十查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0010', '快速赎回未当天到账', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0010新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标十查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0010', '快速赎回未当天到账', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0011新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标十一查询时间参数', '1', '小时', 'LCPT', 'LCPT0011', '相同客户重复赎回', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0011新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标十一查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0011', '相同客户重复赎回', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0011新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标十一查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0011', '相同客户重复赎回', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0012新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标十二查询时间参数', '1', '小时', 'LCPT', 'LCPT0012', '相同客户重复申购', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0012新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标十二查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0012', '相同客户重复申购', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0012新增查询结束时间参数
  insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标十二查询结束时间', '00:59:59', '', 'LCPT', 'LCPT0012', '相同客户重复申购', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0013新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标十三查询时间参数', '24', '小时', 'LCPT', 'LCPT0013', '业务订单-支付订单金额不符', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0013新增查询开始时间参数
  insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标十三查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0013', '业务订单-支付订单金额不符', '', 'Y', '000000', sysdate, '', '');

--理财平台指标LCPT0013新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标十三查询结束时间', '23:59:59', '', 'LCPT', 'LCPT0013', '业务订单-支付订单金额不符', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0014新增查询时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'QRYTIME', 'Lcpt指标十四查询时间参数', '24', '小时', 'LCPT', 'LCPT0014', '业务订单-支付订单笔数不符', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0014新增查询开始时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'BEGINTIME', 'Lcpt指标十四查询开始时间', '00:00:00', '', 'LCPT', 'LCPT0014', '业务订单-支付订单笔数不符不符', '', 'Y', '000000', sysdate, '', '');
  
--理财平台指标LCPT0014新增查询结束时间参数
insert into ews_index_param
  (id, param_no, param_name, param_val, param_unit, warn_source, warn_index_no, warn_index_name, remark, is_valid, create_id, create_time, update_id, update_time)
values
  (SEQ_EWS_INDEX_PARAM.NEXTVAL, 'ENDTIME', 'Lcpt指标十四查询结束时间', '23:59:59', '', 'LCPT', 'LCPT0014', '业务订单-支付订单笔数不符', '', 'Y', '000000', sysdate, '', '');
  
  commit;
  
