--˳�ָ�ָ�� SFPR0001
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0001', '000000', sysdate);
--˳�ָ�ָ�� SFPR0002
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0002', '000000', sysdate);
--˳�ָ�ָ�� SFPR0003
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0004', '000000', sysdate);
--˳�ָ�ָ�� SFPR0004
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0005', '000000', sysdate);
--˳�ָ�ָ�� SFPR0006
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0006', '000000', sysdate);
--˳�ָ�ָ�� SFPR0007
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0007', '000000', sysdate);
--˳�ָ�ָ�� SFPR0008
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0008', '000000', sysdate);
--˳�ָ�ָ�� SFPR0011
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0011', '000000', sysdate);
--˳�ָ�ָ�� SFPR0012
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0012', '000000', sysdate);
--˳�ָ�ָ�� SFPR0024
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0024', '000000', sysdate);
--˳�ָ�ָ�� SFPR0025
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0025', '000000', sysdate);
--˳�ָ�ָ�� SFPR0026
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0026', '000000', sysdate);
--˳�ָ�ָ�� SFPR0027
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0027', '000000', sysdate);
--˳�ָ�ָ�� SFPR0028
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0028', '000000', sysdate);
--˳�ָ�ָ�� SFPR0029
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0029', '000000', sysdate);
--˳�ָ�ָ�� SFPR0030
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0030', '000000', sysdate);
--˳�ָ�ָ�� SFPR0031
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'SYPAY_GROUP', 'SFPR0031', '000000', sysdate);
--------------------------------------------------------------------------------------
--˳�ָ�ָ�� SFPR0001
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0001', '000000', sysdate);
--˳�ָ�ָ�� SFPR0002
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0002', '000000', sysdate);
--˳�ָ�ָ�� SFPR0003
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0004', '000000', sysdate);
--˳�ָ�ָ�� SFPR0004
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0005', '000000', sysdate);
--˳�ָ�ָ�� SFPR0006
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0006', '000000', sysdate);
--˳�ָ�ָ�� SFPR0007
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0007', '000000', sysdate);
--˳�ָ�ָ�� SFPR0008
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0008', '000000', sysdate);
--˳�ָ�ָ�� SFPR0011
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0011', '000000', sysdate);
--˳�ָ�ָ�� SFPR0012
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0012', '000000', sysdate);
--˳�ָ�ָ�� SFPR0024
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0024', '000000', sysdate);
--˳�ָ�ָ�� SFPR0025
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0025', '000000', sysdate);
--˳�ָ�ָ�� SFPR0026
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0026', '000000', sysdate);
--˳�ָ�ָ�� SFPR0027
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0027', '000000', sysdate);
--˳�ָ�ָ�� SFPR0028
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0028', '000000', sysdate);
--˳�ָ�ָ�� SFPR0029
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0029', '000000', sysdate);
--˳�ָ�ָ�� SFPR0030
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0030', '000000', sysdate);
--˳�ָ�ָ�� SFPR0031
INSERT INTO dm_ews.ews_group_index (id, group_no, warn_index_no, create_id, create_time)
VALUES (seq_ews_group_index.nextval, 'ALL_GROUP', 'SFPR0031', '000000', sysdate);

COMMIT;