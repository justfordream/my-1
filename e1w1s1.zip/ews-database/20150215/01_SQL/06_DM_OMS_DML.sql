update dm_oms.um_permis t set t.permis_code = 'ews_info:emp_index_export'where t.id=18001010;

update dm_oms.um_permis t set t.permis_code = 'ews_info:emp_param_export'where t.id=18001011;

commit;