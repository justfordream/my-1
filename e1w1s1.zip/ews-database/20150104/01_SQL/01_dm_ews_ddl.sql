--EWS_WARNING_MS表字段warn_deal_result扩容
alter table DM_EWS.EWS_WARNING_MS modify warn_deal_result varchar2(2000);