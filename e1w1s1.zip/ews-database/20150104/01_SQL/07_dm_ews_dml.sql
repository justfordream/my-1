--���ô��۹���ָ��DEBIT0006�澯Ⱥ��
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0006', '000000', sysdate);
  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0006', '000000', sysdate);  
 
--���ô��۹���ָ��DEBIT0007�澯Ⱥ��
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0007', '000000', sysdate);
  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0007', '000000', sysdate);  
  
--���ô��۹���ָ��DEBIT0008�澯Ⱥ��  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0008', '000000', sysdate);
  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0008', '000000', sysdate);  
  
--���ô��۹���ָ��DEBIT0009�澯Ⱥ��  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0009', '000000', sysdate);
  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0009', '000000', sysdate);  
  
    
--���ô��۹���ָ��DEBIT0010�澯Ⱥ��  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0010', '000000', sysdate);
  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0010', '000000', sysdate);  
    
--���ô��۹���ָ��DEBIT0011�澯Ⱥ��  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0011', '000000', sysdate);
  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0011', '000000', sysdate);  
  
  --���ô��۹���ָ��DEBIT0012�澯Ⱥ��  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0012', '000000', sysdate);
  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0012', '000000', sysdate);  
  
  --���ô��۹���ָ��DEBIT0013�澯Ⱥ��  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0013', '000000', sysdate);
  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0013', '000000', sysdate);  
  
  --���ô��۹���ָ��DEBIT0014�澯Ⱥ��  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'DEBIT_GROUP', 'DEBIT0014', '000000', sysdate);
  
 insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'DEBIT0014', '000000', sysdate);  
  
--���õ渶ָ��PAS0024�澯Ⱥ��
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'PAS_GROUP', 'PAS0024', '000000', sysdate);  
  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (SEQ_EWS_GROUP_INDEX.NEXTVAL, 'ALL_GROUP', 'PAS0024', '000000', sysdate);    
  
--���õ渶����ָ��PAS0019
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'PAS_GROUP', 'PAS0019', '000000', sysdate);
  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'PAS0019', '000000', sysdate);  
  
--���õ渶����ָ��PAS0023
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'PAS_GROUP', 'PAS0023', '000000', sysdate);  
  
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'PAS0023', '000000', sysdate);   
  
--���õ渶����ָ��PAS0020
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'PAS_GROUP', 'PAS0020', '000000', sysdate);
  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'PAS0020', '000000', sysdate);  
  
--���õ渶����ָ��PAS0021
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'PAS_GROUP', 'PAS0021', '000000', sysdate);  

    insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'PAS0021', '000000', sysdate);  
  
--���õ渶����ָ��PAS0022
  insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'PAS_GROUP', 'PAS0022', '000000', sysdate);   
  
insert into ews_group_index
  (id, group_no, warn_index_no, create_id, create_time)
values
  (seq_ews_group_index.nextval, 'ALL_GROUP', 'PAS0022', '000000', sysdate);    

commit;