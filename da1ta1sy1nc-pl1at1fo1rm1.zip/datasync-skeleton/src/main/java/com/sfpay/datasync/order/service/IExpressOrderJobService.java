/**
 * 
 */
package com.sfpay.datasync.order.service;

import java.util.List;

import com.sfpay.datasync.order.domain.ExpressOrderJob;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：全网订单作业管理接口
 *
 * 类描述：全网订单作业管理接口
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IExpressOrderJobService {
	/**
	 * 新增全网订单作业
	 * 
	 * @param expressOrderJob
	 * @throws ServiceException 20031-订单数据插入数据库失败
	 */
	public void addExpressOrderJob(ExpressOrderJob expressOrderJob) throws ServiceException;
	
	/**
	 * 通过ID查询全网订单作业
	 * 
	 * @param expressOrderJob
	 */
	public ExpressOrderJob queryExpressOrderJobById(Long id);
	
	/**
	 * 通过运单号查询全网订单作业
	 * 
	 * @param expressOrderJob
	 */
	public List<ExpressOrderJob> queryExpressOrderJobByWayBillNo(String wayBillNo);
	
	/**
	 * 通过参数查询全网订单作业
	 * 
	 * @param expressOrderJob
	 */
	public List<ExpressOrderJob> queryExpressOrderJobByParam(ExpressOrderJob expressOrderJob);

}
