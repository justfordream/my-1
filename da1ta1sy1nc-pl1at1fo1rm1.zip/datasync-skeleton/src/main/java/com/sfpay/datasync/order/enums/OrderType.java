/**
 * 
 */
package com.sfpay.datasync.order.enums;

/**
 * 类说明：订单类型（来源）
 *
 * 类描述：订单类型（来源）
 * @author 625288 易振强
 * 2014-11-21
 */
public enum OrderType {
	DEFAULT_ORDER_TYPE("52");
	
	private String value;
	private OrderType(String value) {
		this.value = value;
	}
	
	public String toString() {
		return value;
	};
}
