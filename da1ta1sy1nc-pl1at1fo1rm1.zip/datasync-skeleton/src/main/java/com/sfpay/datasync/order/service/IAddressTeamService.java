/**
 * 
 */
package com.sfpay.datasync.order.service;

import com.sfpay.datasync.order.domain.AddressTeam;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：地址单元区域管理接口
 *
 * 类描述：地址单元区域管理接口
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IAddressTeamService {
	/**
	 * 新增地址单元区域
	 * 
	 * @param addressTeam
	 * @throws ServiceException 20036-AddressTeam不能为空 20037-AddressTeam数据校验失败
	 */
	public void addAddressTeam(AddressTeam addressTeam) throws ServiceException;

}
