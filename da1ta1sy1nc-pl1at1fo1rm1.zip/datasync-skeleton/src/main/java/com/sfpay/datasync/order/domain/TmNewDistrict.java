/**
 * 
 */
package com.sfpay.datasync.order.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：区域表实体类
 * 
 * 类描述：区域表实体类
 * 
 * @author 625288 易振强 2014-11-12
 */
public class TmNewDistrict extends BaseEntity {
	// 区域ID
		private Long distId;
		// 区域代码
		private String distCode;
		// 区划中文名称
		private String distCnName;
		// 区划别名
		private String distAlias;
		// 区划英文名称
		private String distEnName;
		// 区划类型编码
		private String typeCode;
		// 区划类型（中文）
		private String distTypeCn;
		// 区划类型（英文）
		private String distTypeEn;
		// 上级区划代码
		private String parentDistCode;
		// 电话区号
		private String phoneAreaCode;
		// 城市代码
		private String distCityCode;
		// 城市邮编
		private String distZipCode;
		// 所属国家
		private String countryCode;
		// 所属省
		private String provinceCode;
		// 所属市
		private String cityCode;
		// 所属县区
		private String areaCode;
		// 人口
		private Long populationCount;
		// 面积
		private Double areaCount;
		// 是否开通:1全境2大部分3小部分4自助5未开通
		private Integer workedStatus;
		// 开通时间
		private Date workedTm;
		// 是否首都
		private Integer capitalStatus;
		// 是否省会
		private Integer provincialStatus;
		// 币种
		private String currencyCode;
		// 时区
		private Integer timeZone;
		// 上级区划ID
		private Long parentDistId;
		// 4位流水号，五级：取上级县区区划编码前7位+4位数流水号
		private Long serialNum4;
		// 六级：C+9位流水号 七级：D+9位流水号
		private Long serialNum9;
		// 生效/失效标记
		private Integer validFlg;
		// 生效日期
		private Date validTm;
		// 创建人工号
		private String createEmpCode;
		// 创建时间
		private Date createdTm;
		// 修改人工号
		private String modifiedEmpCode;
		// 修改时间
		private Date modifiedTm;

	private static final long serialVersionUID = 3951150936020696804L;

	public Long getDistId() {
		return distId;
	}

	public void setDistId(Long distId) {
		this.distId = distId;
	}

	public String getDistCode() {
		return distCode;
	}

	public void setDistCode(String distCode) {
		this.distCode = distCode;
	}

	public String getDistCnName() {
		return distCnName;
	}

	public void setDistCnName(String distCnName) {
		this.distCnName = distCnName;
	}

	public String getDistAlias() {
		return distAlias;
	}

	public void setDistAlias(String distAlias) {
		this.distAlias = distAlias;
	}

	public String getDistEnName() {
		return distEnName;
	}

	public void setDistEnName(String distEnName) {
		this.distEnName = distEnName;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getDistTypeCn() {
		return distTypeCn;
	}

	public void setDistTypeCn(String distTypeCn) {
		this.distTypeCn = distTypeCn;
	}

	public String getDistTypeEn() {
		return distTypeEn;
	}

	public void setDistTypeEn(String distTypeEn) {
		this.distTypeEn = distTypeEn;
	}

	public String getParentDistCode() {
		return parentDistCode;
	}

	public void setParentDistCode(String parentDistCode) {
		this.parentDistCode = parentDistCode;
	}

	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}

	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}

	public String getDistCityCode() {
		return distCityCode;
	}

	public void setDistCityCode(String distCityCode) {
		this.distCityCode = distCityCode;
	}

	public String getDistZipCode() {
		return distZipCode;
	}

	public void setDistZipCode(String distZipCode) {
		this.distZipCode = distZipCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getProvinceCode() {
		return provinceCode;
	}

	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public Long getPopulationCount() {
		return populationCount;
	}

	public void setPopulationCount(Long populationCount) {
		this.populationCount = populationCount;
	}

	public Double getAreaCount() {
		return areaCount;
	}

	public void setAreaCount(Double areaCount) {
		this.areaCount = areaCount;
	}

	public Integer getWorkedStatus() {
		return workedStatus;
	}

	public void setWorkedStatus(Integer workedStatus) {
		this.workedStatus = workedStatus;
	}

	public Date getWorkedTm() {
		return workedTm;
	}

	public void setWorkedTm(Date workedTm) {
		this.workedTm = workedTm;
	}

	public Integer getCapitalStatus() {
		return capitalStatus;
	}

	public void setCapitalStatus(Integer capitalStatus) {
		this.capitalStatus = capitalStatus;
	}

	public Integer getProvincialStatus() {
		return provincialStatus;
	}

	public void setProvincialStatus(Integer provincialStatus) {
		this.provincialStatus = provincialStatus;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public Integer getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(Integer timeZone) {
		this.timeZone = timeZone;
	}

	public Integer getValidFlg() {
		return validFlg;
	}

	public void setValidFlg(Integer validFlg) {
		this.validFlg = validFlg;
	}

	public Date getCreatedTm() {
		return createdTm;
	}

	public void setCreatedTm(Date createdTm) {
		this.createdTm = createdTm;
	}

	public String getModifiedEmpCode() {
		return modifiedEmpCode;
	}

	public void setModifiedEmpCode(String modifiedEmpCode) {
		this.modifiedEmpCode = modifiedEmpCode;
	}

	public Date getModifiedTm() {
		return modifiedTm;
	}

	public void setModifiedTm(Date modifiedTm) {
		this.modifiedTm = modifiedTm;
	}

	public Date getValidTm() {
		return validTm;
	}

	public void setValidTm(Date validTm) {
		this.validTm = validTm;
	}

	public Long getParentDistId() {
		return parentDistId;
	}

	public void setParentDistId(Long parentDistId) {
		this.parentDistId = parentDistId;
	}

	public Long getSerialNum4() {
		return serialNum4;
	}

	public void setSerialNum4(Long serialNum4) {
		this.serialNum4 = serialNum4;
	}

	public Long getSerialNum9() {
		return serialNum9;
	}

	public void setSerialNum9(Long serialNum9) {
		this.serialNum9 = serialNum9;
	}

	public String getCreateEmpCode() {
		return createEmpCode;
	}

	public void setCreateEmpCode(String createEmpCode) {
		this.createEmpCode = createEmpCode;
	}
}
