/**
 * 包名：com.sfpay.datasync.domain
 * 文件名：BarTrace.java
 * 版本信息：
 * 日期：2014-9-3-上午11:31:28
 * 
 */
package com.sfpay.datasync.waybill.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类名称：BarTraceInfo 类描述： 创建人：313920 熊伟 修改人：313920 熊伟 修改时间：2014-9-3 上午11:31:28 修改备注：
 * 
 * @version 2.0.1
 * 
 */
public class BarTraceInfo extends BaseEntity{
	
	/**
	 * serialVersionUID:TODO（用一句话描述这个变量表示什么）
	 * @since 2.0.1
	 */
	
	private static final long serialVersionUID = 1L;
	//巴枪操作员工号
	private String oprCode;
	//网点对外名称
	private String outsideName;
	//是否已付款
	private String payFlg;
	//电话区号
	private String phoneZone;
	//计划发车时间，有可能为空
	private Date planTime;
	//线路编码,描述中用到
	private String routeCode;
	//半自动化目标地区代码
	private String sapDestZoneCode;
	//半自动化目标地区名称
	private String sapDestZoneName;
	//原寄地扫描时间
	private Date sourceScanTm;
	//异常原因代码
	private String stayWhyCode;
	//异常原因代码描述
	private String stayWhyName;
	//异常原因代码描述
	private String stayWhyNameEn;
	//是否手工录入
	private String uploadTypeInputty;
	//车牌号
	private String vehiclePlate;
	//运单号
	private String waybillNo;
	//计费重量
	private Double weightQty;
	//目的地代码
	private String zoneCode;
	//巴枪操作网点时区差值
	private String zoneGmt;
	//地区名称
	private String zoneName;
	//月结帐号 /便利店编码
	private String accountantCode;
	//巴枪数据来源
	private String autoloading;
	//巴枪扫描格林威治时间
	private Date barScanTm; 
	//巴枪扫描格林威治时间
	private Date barScanTmStd;
	//巴枪上传格林威治时间
	private Date barUploadTm;
	//巴枪上传格林威治时间
	private Date barUploadTmStd;
    //网点城市名称
	private String cityName;
	//所属包或车次
	private String contnrCode;
	//便利店代码
	private String convienienceCode;
	//便利店名称
	private String convienienceStore;
	//收派员
	private String courierCode;
	//派件出仓确认
	private String deliverConfirm;
	//住户市场短信派送时间Tim 2011-08-30
	private Date deliverDateStr;
	//目的地代码
	private String destZoneCode;
	//目的地名称
	private String destZoneName;
	//所在城市
	private String distName;
	//目的地扫描时间
	private Date distScanTm;
	//收派员手机
	private String empMobile;
	//OMP异常原因的显示
	private String exceptionCause;
	//描述中用到的异常状态
	private String exceptionState;
	//扩展附加信息1
	private String extendAttach1;
	//扩展附加信息2
	private String extendAttach2;
	//交接给代理，代理单号
	private String extendAttach3;
	//扩展附加信息4
	private String extendAttach4;
	//扩展附加信息5
	private String extendAttach5;
	//操作描述
	private String note;
	//对象类型
	private String objTypeCode;
	//巴枪操作辅助码
	private String opAttachInfo;
	//巴枪操作码
	private String opCode;
	//巴枪操作名称
	private String opName;
	//是否OMP路由信息
	private String fromOmpflg;

	/**
	 * ��ȡoprCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOprCode() {
		return oprCode;
	}

	/**
	 * ����oprCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOprCode(String value) {
		this.oprCode = value;
	}

	/**
	 * ��ȡoutsideName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOutsideName() {
		return outsideName;
	}

	/**
	 * ����outsideName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOutsideName(String value) {
		this.outsideName = value;
	}

	/**
	 * ��ȡpayFlg���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPayFlg() {
		return payFlg;
	}

	/**
	 * ����payFlg���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPayFlg(String value) {
		this.payFlg = value;
	}

	/**
	 * ��ȡphoneZone���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPhoneZone() {
		return phoneZone;
	}

	/**
	 * ����phoneZone���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPhoneZone(String value) {
		this.phoneZone = value;
	}

	/**
	 * ��ȡplanTime���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getPlanTime() {
		return planTime;
	}

	/**
	 * ����planTime���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setPlanTime(Date value) {
		this.planTime = value;
	}

	/**
	 * ��ȡrouteCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRouteCode() {
		return routeCode;
	}

	/**
	 * ����routeCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRouteCode(String value) {
		this.routeCode = value;
	}

	/**
	 * ��ȡsapDestZoneCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSapDestZoneCode() {
		return sapDestZoneCode;
	}

	/**
	 * ����sapDestZoneCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setSapDestZoneCode(String value) {
		this.sapDestZoneCode = value;
	}

	/**
	 * ��ȡsapDestZoneName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSapDestZoneName() {
		return sapDestZoneName;
	}

	/**
	 * ����sapDestZoneName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setSapDestZoneName(String value) {
		this.sapDestZoneName = value;
	}

	/**
	 * ��ȡsourceScanTm���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getSourceScanTm() {
		return sourceScanTm;
	}

	/**
	 * ����sourceScanTm���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setSourceScanTm(Date value) {
		this.sourceScanTm = value;
	}

	/**
	 * ��ȡstayWhyCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getStayWhyCode() {
		return stayWhyCode;
	}

	/**
	 * ����stayWhyCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setStayWhyCode(String value) {
		this.stayWhyCode = value;
	}

	/**
	 * ��ȡstayWhyName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getStayWhyName() {
		return stayWhyName;
	}

	/**
	 * ����stayWhyName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setStayWhyName(String value) {
		this.stayWhyName = value;
	}

	/**
	 * ��ȡstayWhyNameEn���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getStayWhyNameEn() {
		return stayWhyNameEn;
	}

	/**
	 * ����stayWhyNameEn���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setStayWhyNameEn(String value) {
		this.stayWhyNameEn = value;
	}

	/**
	 * ��ȡuploadTypeInputty���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUploadTypeInputty() {
		return uploadTypeInputty;
	}

	/**
	 * ����uploadTypeInputty���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setUploadTypeInputty(String value) {
		this.uploadTypeInputty = value;
	}

	/**
	 * ��ȡvehiclePlate���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getVehiclePlate() {
		return vehiclePlate;
	}

	/**
	 * ����vehiclePlate���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setVehiclePlate(String value) {
		this.vehiclePlate = value;
	}

	/**
	 * ��ȡwaybillNo���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getWaybillNo() {
		return waybillNo;
	}

	/**
	 * ����waybillNo���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setWaybillNo(String value) {
		this.waybillNo = value;
	}

	/**
	 * ��ȡweightQty���Ե�ֵ��
	 * 
	 * @return possible object is {@link Double }
	 * 
	 */
	public Double getWeightQty() {
		return weightQty;
	}

	/**
	 * ����weightQty���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Double }
	 * 
	 */
	public void setWeightQty(Double value) {
		this.weightQty = value;
	}

	/**
	 * ��ȡzoneCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZoneCode() {
		return zoneCode;
	}

	/**
	 * ����zoneCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setZoneCode(String value) {
		this.zoneCode = value;
	}

	/**
	 * ��ȡzoneGmt���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZoneGmt() {
		return zoneGmt;
	}

	/**
	 * ����zoneGmt���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setZoneGmt(String value) {
		this.zoneGmt = value;
	}

	/**
	 * ��ȡzoneName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getZoneName() {
		return zoneName;
	}

	/**
	 * ����zoneName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setZoneName(String value) {
		this.zoneName = value;
	}

	/**
	 * ��ȡaccountantCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAccountantCode() {
		return accountantCode;
	}

	/**
	 * ����accountantCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAccountantCode(String value) {
		this.accountantCode = value;
	}

	/**
	 * ��ȡautoloading���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAutoloading() {
		return autoloading;
	}

	/**
	 * ����autoloading���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAutoloading(String value) {
		this.autoloading = value;
	}

	/**
	 * ��ȡbarScanTm���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getBarScanTm() {
		return barScanTm;
	}

	/**
	 * ����barScanTm���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setBarScanTm(Date value) {
		this.barScanTm = value;
	}

	/**
	 * ��ȡbarScanTmStd���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getBarScanTmStd() {
		return barScanTmStd;
	}

	/**
	 * ����barScanTmStd���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setBarScanTmStd(Date value) {
		this.barScanTmStd = value;
	}

	/**
	 * ��ȡbarUploadTm���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getBarUploadTm() {
		return barUploadTm;
	}

	/**
	 * ����barUploadTm���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setBarUploadTm(Date value) {
		this.barUploadTm = value;
	}

	/**
	 * ��ȡbarUploadTmStd���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getBarUploadTmStd() {
		return barUploadTmStd;
	}

	/**
	 * ����barUploadTmStd���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setBarUploadTmStd(Date value) {
		this.barUploadTmStd = value;
	}

	/**
	 * ��ȡcityName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * ����cityName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCityName(String value) {
		this.cityName = value;
	}

	/**
	 * ��ȡcontnrCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getContnrCode() {
		return contnrCode;
	}

	/**
	 * ����contnrCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setContnrCode(String value) {
		this.contnrCode = value;
	}

	/**
	 * ��ȡconvienienceCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getConvienienceCode() {
		return convienienceCode;
	}

	/**
	 * ����convienienceCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setConvienienceCode(String value) {
		this.convienienceCode = value;
	}

	/**
	 * ��ȡconvienienceStore���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getConvienienceStore() {
		return convienienceStore;
	}

	/**
	 * ����convienienceStore���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setConvienienceStore(String value) {
		this.convienienceStore = value;
	}

	/**
	 * ��ȡcourierCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCourierCode() {
		return courierCode;
	}

	/**
	 * ����courierCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCourierCode(String value) {
		this.courierCode = value;
	}

	/**
	 * ��ȡdeliverConfirm���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDeliverConfirm() {
		return deliverConfirm;
	}

	/**
	 * ����deliverConfirm���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDeliverConfirm(String value) {
		this.deliverConfirm = value;
	}

	/**
	 * ��ȡdeliverDateStr���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getDeliverDateStr() {
		return deliverDateStr;
	}

	/**
	 * ����deliverDateStr���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setDeliverDateStr(Date value) {
		this.deliverDateStr = value;
	}

	/**
	 * ��ȡdestZoneCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDestZoneCode() {
		return destZoneCode;
	}

	/**
	 * ����destZoneCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDestZoneCode(String value) {
		this.destZoneCode = value;
	}

	/**
	 * ��ȡdestZoneName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDestZoneName() {
		return destZoneName;
	}

	/**
	 * ����destZoneName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDestZoneName(String value) {
		this.destZoneName = value;
	}

	/**
	 * ��ȡdistName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDistName() {
		return distName;
	}

	/**
	 * ����distName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDistName(String value) {
		this.distName = value;
	}

	/**
	 * ��ȡdistScanTm���Ե�ֵ��
	 * 
	 * @return possible object is {@link Date }
	 * 
	 */
	public Date getDistScanTm() {
		return distScanTm;
	}

	/**
	 * ����distScanTm���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link Date }
	 * 
	 */
	public void setDistScanTm(Date value) {
		this.distScanTm = value;
	}

	/**
	 * ��ȡempMobile���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmpMobile() {
		return empMobile;
	}

	/**
	 * ����empMobile���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setEmpMobile(String value) {
		this.empMobile = value;
	}

	/**
	 * ��ȡexceptionCause���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getExceptionCause() {
		return exceptionCause;
	}

	/**
	 * ����exceptionCause���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setExceptionCause(String value) {
		this.exceptionCause = value;
	}

	/**
	 * ��ȡexceptionState���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getExceptionState() {
		return exceptionState;
	}

	/**
	 * ����exceptionState���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setExceptionState(String value) {
		this.exceptionState = value;
	}

	/**
	 * ��ȡextendAttach1���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getExtendAttach1() {
		return extendAttach1;
	}

	/**
	 * ����extendAttach1���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setExtendAttach1(String value) {
		this.extendAttach1 = value;
	}

	/**
	 * ��ȡextendAttach2���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getExtendAttach2() {
		return extendAttach2;
	}

	/**
	 * ����extendAttach2���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setExtendAttach2(String value) {
		this.extendAttach2 = value;
	}

	/**
	 * ��ȡextendAttach3���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getExtendAttach3() {
		return extendAttach3;
	}

	/**
	 * ����extendAttach3���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setExtendAttach3(String value) {
		this.extendAttach3 = value;
	}

	/**
	 * ��ȡextendAttach4���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getExtendAttach4() {
		return extendAttach4;
	}

	/**
	 * ����extendAttach4���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setExtendAttach4(String value) {
		this.extendAttach4 = value;
	}

	/**
	 * ��ȡnote���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getNote() {
		return note;
	}

	/**
	 * ����note���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setNote(String value) {
		this.note = value;
	}

	/**
	 * ��ȡobjTypeCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getObjTypeCode() {
		return objTypeCode;
	}

	/**
	 * ����objTypeCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setObjTypeCode(String value) {
		this.objTypeCode = value;
	}

	/**
	 * ��ȡopAttachInfo���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOpAttachInfo() {
		return opAttachInfo;
	}

	/**
	 * ����opAttachInfo���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOpAttachInfo(String value) {
		this.opAttachInfo = value;
	}

	/**
	 * ��ȡopCode���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOpCode() {
		return opCode;
	}

	/**
	 * ����opCode���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOpCode(String value) {
		this.opCode = value;
	}

	/**
	 * ��ȡopName���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOpName() {
		return opName;
	}

	/**
	 * ����opName���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOpName(String value) {
		this.opName = value;
	}

	/**
	 * ��ȡextendAttach5���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getExtendAttach5() {
		return extendAttach5;
	}

	/**
	 * ����extendAttach5���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setExtendAttach5(String value) {
		this.extendAttach5 = value;
	}

	/**
	 * ��ȡfromOmpflg���Ե�ֵ��
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getFromOmpflg() {
		return fromOmpflg;
	}

	/**
	 * ����fromOmpflg���Ե�ֵ��
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setFromOmpflg(String value) {
		this.fromOmpflg = value;
	}

}
