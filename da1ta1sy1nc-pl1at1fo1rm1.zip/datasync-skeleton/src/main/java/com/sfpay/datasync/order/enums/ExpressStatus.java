/**
 * 
 */
package com.sfpay.datasync.order.enums;

/**
 * 类说明：运单状态枚举
 *
 * 类描述：1.收派员收件  2.运送中 3.派件中 4.客户已签收
 * @author 625288 易振强
 * 2014-11-14
 */
public enum ExpressStatus {
	// 收派员收件
	RECEIPT("1"),
	// 运送中
	TRANSIT("2"),
	// 派件中
//	ASSIGN("3"),
	// 客户已签收
	SIGN("3");
	
	private String value;
	
	ExpressStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return value;
	}
}
