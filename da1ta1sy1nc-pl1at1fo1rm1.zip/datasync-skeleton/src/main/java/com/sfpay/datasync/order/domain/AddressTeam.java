/**
 * 
 */
package com.sfpay.datasync.order.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;
import com.sfpay.framework.common.xml.dom4j.base.XElement;
import com.sfpay.framework.common.xml.dom4j.base.XmlBaseModel;
import com.sfpay.framework.common.xml.dom4j.base.XmlType;

/**
 * 类说明：地址单元区域实体
 * 
 * 类描述：地址单元区域实体
 * 
 * @author 625288 易振强 2014-11-12
 */
@XElement(name = "addressTeam", clazz = AddressTeam.class)
public class AddressTeam extends BaseEntity implements XmlBaseModel{
	// 城市代码;
	@XElement(name = "cityid", type = XmlType.ELEMENT)
	private String cityId;
	// 地址;
	@XElement(name = "address", type = XmlType.ELEMENT)
	private String address;
	// 单元区域;
	@XElement(name = "teamid", type = XmlType.ELEMENT)
	private String teamId;
	// 网点代码;
	@XElement(name = "deptid", type = XmlType.ELEMENT)
	private String deptId;
	// 客户卡号;
	@XElement(name = "custid", type = XmlType.ELEMENT)
	private String custId;
	// 操作类型;
	@XElement(name = "operateType", type = XmlType.ELEMENT)
	private String operateType;
	// 修改时间;
	private Date updateTime;

	private static final long serialVersionUID = 4551840357662023305L;

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTeamId() {
		return teamId;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public boolean hasChildren() {
		return true;
	}

}
