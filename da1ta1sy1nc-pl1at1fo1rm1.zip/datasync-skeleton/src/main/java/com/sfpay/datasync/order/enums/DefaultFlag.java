/**
 * 
 */
package com.sfpay.datasync.order.enums;

/**
 * 类说明：是否联系人（寄件人/收件人）默认地址
 *
 * 类描述：是否联系人（寄件人/收件人）默认地址
 * @author 625288 易振强
 * 2014-11-13
 */
public enum DefaultFlag {
	// 默认
	DEFAULT("1"),
	// 非默认
	NOTDEFAULT("0");
	
	private String value;
	
	DefaultFlag(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return value;
	}
}
