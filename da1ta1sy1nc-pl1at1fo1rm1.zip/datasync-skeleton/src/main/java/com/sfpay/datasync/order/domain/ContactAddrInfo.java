/**
 * 
 */
package com.sfpay.datasync.order.domain;

import java.util.Date;

import com.sfpay.datasync.order.enums.Used;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：联系人（寄件/收件）地址信息实体类
 * 
 * 类描述：联系人（寄件/收件）地址信息实体类
 * 
 * @author 625288 易振强 2014-11-12
 */
public class ContactAddrInfo extends BaseEntity {
	// 会员号（注：手机代理调用必填）;
	private Long memberNo;
	// 客户编码;
	private String custTag;
	// 城市编码，用于回传地址单元区域和订单作业数据时来更新teamId
	private String distCityCode;
	// 省代码（注：手机代理调用必填）;
	private String provinceCode;
	// 市代码（注：手机代理调用必填）;
	private String cityCode;
	// 区县代码（注：手机代理调用必填）;
	private String countyCode;
	// 详细地址（注：手机代理调用必填）;
	private String address;
	// 单元区域;
	private String teamId;
	// 联系电话（地址类别为SENDER时是寄件人联系方式，为RECEIVER时是收件人联系方式，注：手机代理调用必填）;
	private String telphoneNo;
	// 联系人（地址类别为SENDER时是寄件人姓名，为RECEIVER时是收件人姓名，注：手机代理调用必填）;
	private String contacts;
	// 地址类别（SENDER：寄件人地址，RECEIVER：收件人地址，注：手机代理调用必填）;
	private String addressType;
	// 公司名称（地址类别为SENDER时是寄件人公司名称，RECEIVER时是收件人公司名称）;
	private String company;
	// 是否为默认地址(1:默认地址，0：非默认地址，注：手机代理调用必填);
	private String defaultFlag;
	// 有效标志（1：有效，0：无效，默认为有效1）;
	private String isUsed = Used.USED.getValue();
	// 最近更新时间;
	private Date updateTime;
	// 创建时间;
	private Date createTime;

	private static final long serialVersionUID = 7968848115344834925L;

	public Long getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(Long memberNo) {
		this.memberNo = memberNo;
	}

	public String getCustTag() {
		return custTag;
	}

	public void setCustTag(String custTag) {
		this.custTag = custTag;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTeamId() {
		return teamId;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}

	public String getTelphoneNo() {
		return telphoneNo;
	}

	public void setTelphoneNo(String telphoneNo) {
		this.telphoneNo = telphoneNo;
	}

	public String getContacts() {
		return contacts;
	}

	public void setContacts(String contacts) {
		this.contacts = contacts;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getDefaultFlag() {
		return defaultFlag;
	}

	public void setDefaultFlag(String defaultFlag) {
		this.defaultFlag = defaultFlag;
	}

	public String getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(String isUsed) {
		this.isUsed = isUsed;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getProvinceCode() {
		return provinceCode;
	}

	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public String getDistCityCode() {
		return distCityCode;
	}

	public void setDistCityCode(String distCityCode) {
		this.distCityCode = distCityCode;
	}
}
