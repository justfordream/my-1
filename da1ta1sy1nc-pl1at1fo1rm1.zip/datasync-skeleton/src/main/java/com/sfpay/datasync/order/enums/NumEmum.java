/**
 * 
 */
package com.sfpay.datasync.order.enums;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288 易振强
 * 2014-11-21
 */
public enum NumEmum {
	YES("1"),
	NO("0");
	
	private String value;
	private NumEmum(String value) {
		this.value = value;
	}
	
	public String toString() {
		return value;
	};
}
