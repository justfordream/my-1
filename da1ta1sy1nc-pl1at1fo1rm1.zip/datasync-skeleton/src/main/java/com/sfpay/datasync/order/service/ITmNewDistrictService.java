/**
 * 
 */
package com.sfpay.datasync.order.service;

import java.util.List;

import com.sfpay.datasync.order.domain.TmNewDistrict;

/**
 * 类说明：区域查询接口
 *
 * 类描述：	1.	该接口主要服务于手机APP用户下单时寄件和收件地址信息填写
 *			2.	可以通过区域类型来查询出属于该类型的所有区域对象
 *			3.	可以查询某个区域的所有直接下级区域对象
 *
 * @author 625288 易振强
 * 2014-11-12
 */
public interface ITmNewDistrictService {
	/**
	 * 通过区域类型来获取中国的区域列表
	 * 
	 * @param distType
	 * @return
	 */
	public List<TmNewDistrict> queryDistByDistType(String typeCode);
	
	/**
	 * 通过区域代码获取所有直接下级区域
	 * 
	 * @param parentCode 父区域代码
	 * @return
	 */
	public List<TmNewDistrict> queryAllChildrenDist(String parentCode);
	
	/**
	 * 通过区域代码来获取区域对象
	 * 
	 * @param distCode 区域代码
	 * @return
	 */
	public TmNewDistrict queryTmNewDistrictByDistCode(String distCode);
	
	/**
	 * 通过区域ID来获取区域对象
	 * 
	 * @param distId 区域ID
	 * @return
	 */
	public TmNewDistrict queryTmNewDistrictById(Long distId);

}
