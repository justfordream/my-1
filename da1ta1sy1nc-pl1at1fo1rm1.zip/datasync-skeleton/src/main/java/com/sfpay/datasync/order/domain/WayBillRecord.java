/**
 * 
 */
package com.sfpay.datasync.order.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：运单路由信息
 * 
 * 类描述：运单路由信息
 * 
 * @author 625288 易振强 2014-11-14
 */
public class WayBillRecord extends BaseEntity {
	// 当前日期
	private Date date;
	// 当前地址
	private String address;
	// 操作内容
	private String operation;

	private static final long serialVersionUID = -2412231404234095274L;
	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}
}
