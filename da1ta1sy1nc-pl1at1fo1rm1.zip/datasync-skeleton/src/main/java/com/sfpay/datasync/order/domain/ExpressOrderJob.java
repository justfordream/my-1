/**
 * 
 */
package com.sfpay.datasync.order.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;
import com.sfpay.framework.common.xml.dom4j.base.XElement;
import com.sfpay.framework.common.xml.dom4j.base.XmlBaseModel;
import com.sfpay.framework.common.xml.dom4j.base.XmlType;

/**
 * 类说明：全网订单作业实体
 * 
 * 类描述：全网订单作业实体
 * 
 * @author 625288 易振强 2014-11-12
 */
@XElement(name = "synOrderjob", clazz = ExpressOrderJob.class)
public class ExpressOrderJob extends BaseEntity implements XmlBaseModel{
	// 操作类型i,u,d;
	@XElement(name = "operateType", type = XmlType.ELEMENT)
	private String operateType;
	// 作业号;
	@XElement(name = "jobid", type = XmlType.ELEMENT)
	private String jobId;
	// 订单号;
	@XElement(name = "orderid", type = XmlType.ELEMENT)
	private String orderId;
	// 收件员工号;
	@XElement(name = "empid", type = XmlType.ELEMENT)
	private String empId;
	// 收件员手机;
	@XElement(name = "emptel", type = XmlType.ELEMENT)
	private String empTel;
	// 客户卡号;
	@XElement(name = "custid", type = XmlType.ELEMENT)
	private String custId;
	// 订单消息;
	@XElement(name = "msg", type = XmlType.ELEMENT)
	private String msg;
	// 订单发送标识;
	@XElement(name = "flag", type = XmlType.ELEMENT)
	private String flag;
	// 订单下发时间（yyyy-MM-dd HH:mm:ss）;
	@XElement(name = "sendtime", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date sendTime;
	// 订单下到终端时间（yyyy-MM-dd HH:mm:ss）;
	@XElement(name = "disptime", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date dispTime;
	// 收件时间（yyyy-MM-dd HH:mm:ss）;
	@XElement(name = "worktime", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date workTime;
	// 作业备注;
	@XElement(name = "sms_memo", type = XmlType.ELEMENT)
	private String smsMemo;
	// 操作员;	
	@XElement(name = "operator", type = XmlType.ELEMENT)
	private String operator;
	// 作业类别1-5(新追消改转);
	@XElement(name = "sendtype", type = XmlType.ELEMENT)
	private String sendType;
	// 原因代码;
	@XElement(name = "reason", type = XmlType.ELEMENT)
	private String reason;
	// 所属分点部;
	@XElement(name = "deptid", type = XmlType.ELEMENT)
	private String deptId;
	// 收件员终端运营商;
	@XElement(name = "sp", type = XmlType.ELEMENT)
	private String sp;
	// 终端类别;
	@XElement(name = "device", type = XmlType.ELEMENT)
	private String device;
	// hht收件状态0-未上传，1-已上传，3-已下载 ，4-转短信， 5-收件，6-异常收件;
	@XElement(name = "hhtflag", type = XmlType.ELEMENT)
	private String hhtFlag;
	// 呼叫中心作业号;
	@XElement(name = "old_jobid", type = XmlType.ELEMENT)
	private String oldJobId;
	// 客户编码;
	@XElement(name = "custtag", type = XmlType.ELEMENT)
	private String custTag;
	// 订单类型（1）;
	@XElement(name = "ordertype", type = XmlType.ELEMENT)
	private String orderType;
	// 运单号;
	@XElement(name = "bno", type = XmlType.ELEMENT)
	private String bno;
	// 调度系统最近一次自动追单的时间（yyyy-MM-dd HH:mm:ss）;
	@XElement(name = "alerttime", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date alertTime;
	// 追单标记（1-表示调度自动追单 0-其他）;
	@XElement(name = "alertflag", type = XmlType.ELEMENT)
	private String alertFlag;
	// 订单类别(0:普通订单,1:委托订单);
	@XElement(name = "orderclass", type = XmlType.ELEMENT)
	private String orderClass;
	// 备案信息;
	@XElement(name = "schmemo", type = XmlType.ELEMENT)
	private String schmemo;
	// 目的地;
	@XElement(name = "destination", type = XmlType.ELEMENT)
	private String destination;
	// 订单备案;
	@XElement(name = "order_memo", type = XmlType.ELEMENT)
	private String orderMemo;
	// 是否保价 Y-是 N-否
	@XElement(name = "insurance", type = XmlType.ELEMENT)
	private String insurance;
	// 客户电话;
	@XElement(name = "custtel", type = XmlType.ELEMENT)
	private String custTel;
	// 联系人;
	@XElement(name = "contact", type = XmlType.ELEMENT)
	private String contact;
	// 区部代码;
	@XElement(name = "areano", type = XmlType.ELEMENT)
	private String areaNo;
	// 客户类别;
	@XElement(name = "custtype", type = XmlType.ELEMENT)
	private String custType;
	// 公司名称;
	@XElement(name = "compabb", type = XmlType.ELEMENT)
	private String compAbb;
	// 客户地址;
	@XElement(name = "addrabb", type = XmlType.ELEMENT)
	private String addrAbb;
	// 单元区域编码;
	@XElement(name = "teamid", type = XmlType.ELEMENT)
	private String teamId;
	// 货物名称;
	@XElement(name = "cargoname", type = XmlType.ELEMENT)
	private String cargoName;
	// 重量;
	@XElement(name = "weight", type = XmlType.ELEMENT, clazz = Double.class)
	private Double weight;
	// 预约时间(1000=10:00);
	@XElement(name = "booktime", type = XmlType.ELEMENT)
	private String bookTime;
	// 货物类别;
	@XElement(name = "custtype", type = XmlType.ELEMENT)
	private String cargoType;
	// 营销人员工号;
	@XElement(name = "specialMarketing", type = XmlType.ELEMENT)
	private String specialMarketing;
	// 邮政编码;
	@XElement(name = "postcode", type = XmlType.ELEMENT)
	private String postCode;
	// 海关资料;
	@XElement(name = "customhouse", type = XmlType.ELEMENT)
	private String customHouse;
	// 国际件类别（1-国内件 2-国际件）;
	@XElement(name = "intertype", type = XmlType.ELEMENT)
	private String interType;
	// 寄件方类型(b/c);
	@XElement(name = "sender_type", type = XmlType.ELEMENT)
	private String senderType;
	// 最晚上门收件时间(1000=10:00);
	@XElement(name = "lasttime", type = XmlType.ELEMENT)
	private String lastTime;
	// 修改时间（yyyy-MM-dd HH:mm:ss）;
	@XElement(name = "edittime", type = XmlType.ELEMENT)
	private Date editTime;
	// 同步时间（yyyy-MM-dd HH:mm:ss）;
	@XElement(name = "synctime", type = XmlType.ELEMENT)
	private Date syncTime;
	// 创建人;
	private String createName;
	// 创建时间;
	private Date createTime;
	// 修改人;
	private String updateName;
	// 修改时间2;
	private Date updateTime;

	private static final long serialVersionUID = 7387440773143079482L;

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpTel() {
		return empTel;
	}

	public void setEmpTel(String empTel) {
		this.empTel = empTel;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public Date getDispTime() {
		return dispTime;
	}

	public void setDispTime(Date dispTime) {
		this.dispTime = dispTime;
	}

	public Date getWorkTime() {
		return workTime;
	}

	public void setWorkTime(Date workTime) {
		this.workTime = workTime;
	}

	public String getSmsMemo() {
		return smsMemo;
	}

	public void setSmsMemo(String smsMemo) {
		this.smsMemo = smsMemo;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getSendType() {
		return sendType;
	}

	public void setSendType(String sendType) {
		this.sendType = sendType;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getSp() {
		return sp;
	}

	public void setSp(String sp) {
		this.sp = sp;
	}

	public String getDevice() {
		return device;
	}

	public void setDevice(String device) {
		this.device = device;
	}

	public String getHhtFlag() {
		return hhtFlag;
	}

	public void setHhtFlag(String hhtFlag) {
		this.hhtFlag = hhtFlag;
	}

	public String getOldJobId() {
		return oldJobId;
	}

	public void setOldJobId(String oldJobId) {
		this.oldJobId = oldJobId;
	}

	public String getCustTag() {
		return custTag;
	}

	public void setCustTag(String custTag) {
		this.custTag = custTag;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getBno() {
		return bno;
	}

	public void setBno(String bno) {
		this.bno = bno;
	}

	public Date getAlertTime() {
		return alertTime;
	}

	public void setAlertTime(Date alertTime) {
		this.alertTime = alertTime;
	}

	public String getAlertFlag() {
		return alertFlag;
	}

	public void setAlertFlag(String alertFlag) {
		this.alertFlag = alertFlag;
	}

	public String getOrderClass() {
		return orderClass;
	}

	public void setOrderClass(String orderClass) {
		this.orderClass = orderClass;
	}

	public String getSchmemo() {
		return schmemo;
	}

	public void setSchmemo(String schmemo) {
		this.schmemo = schmemo;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getOrderMemo() {
		return orderMemo;
	}

	public void setOrderMemo(String orderMemo) {
		this.orderMemo = orderMemo;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getCustTel() {
		return custTel;
	}

	public void setCustTel(String custTel) {
		this.custTel = custTel;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public void setAreaNo(String areaNo) {
		this.areaNo = areaNo;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getCompAbb() {
		return compAbb;
	}

	public void setCompAbb(String compAbb) {
		this.compAbb = compAbb;
	}

	public String getAddrAbb() {
		return addrAbb;
	}

	public void setAddrAbb(String addrAbb) {
		this.addrAbb = addrAbb;
	}

	public String getTeamId() {
		return teamId;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}

	public String getCargoName() {
		return cargoName;
	}

	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getBookTime() {
		return bookTime;
	}

	public void setBookTime(String bookTime) {
		this.bookTime = bookTime;
	}

	public String getCargoType() {
		return cargoType;
	}

	public void setCargoType(String cargoType) {
		this.cargoType = cargoType;
	}

	public String getSpecialMarketing() {
		return specialMarketing;
	}

	public void setSpecialMarketing(String specialMarketing) {
		this.specialMarketing = specialMarketing;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getCustomHouse() {
		return customHouse;
	}

	public void setCustomHouse(String customHouse) {
		this.customHouse = customHouse;
	}

	public String getInterType() {
		return interType;
	}

	public void setInterType(String interType) {
		this.interType = interType;
	}

	public String getSenderType() {
		return senderType;
	}

	public void setSenderType(String senderType) {
		this.senderType = senderType;
	}

	public String getLastTime() {
		return lastTime;
	}

	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}

	public Date getEditTime() {
		return editTime;
	}

	public void setEditTime(Date editTime) {
		this.editTime = editTime;
	}

	public Date getSyncTime() {
		return syncTime;
	}

	public void setSyncTime(Date syncTime) {
		this.syncTime = syncTime;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public boolean hasChildren() {
		return true;
	}

}
