/**
 * 
 */
package com.sfpay.datasync.constant;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;


/**
 * 类说明：异常信息码
 *
 * 类描述：异常信息码
 * @author 625288 易振强
 * 2014-11-11
 */
public class MsgCode {
	private static Map<String, String> codeMap = null;

	@ReturnMsgCode("下单数据校验失败")
	public static final String EXPRESSORDER_DATA_CHECK_FAIL = "20001";
	
//	@ReturnMsgCode("下单数据插入数据库失败")
//	public static final String EXPRESSORDER_INSERT_FAIL = "20002";
	
	@ReturnMsgCode("下单数据不能为空")
	public static final String EXPRESSORDER_CAN_NOT_EMPTY = "20002";
	
	@ReturnMsgCode("资科调度系统下单响应超时")
	public static final String SF_ORDER_SERVICE_TIMEOUT = "20003";
	
	@ReturnMsgCode("生成订单号失败")
	public static final String ORDER_ID_GENERATION_FAIL = "20016";
	
	@ReturnMsgCode("会员号不能为空")
	public static final String MEMBER_NO_CAN_NOT_EMPTY = "20011";
	
//	@ReturnMsgCode("会员号不存在")
//	public static final String MEMBER_NO_NOT_EXIST = "20013";
	
	@ReturnMsgCode("运单信息的数量size必须大于0")
	public static final String WAYBILL_SIZE_MUST_GREATER_THAN_ZERO = "20012";	
	
	@ReturnMsgCode("ESB运单路由查询失败")
	public static final String ESB_ROUTE_QUERY_FAIL = "20014";	
	
	@ReturnMsgCode("运单号不能为空")
	public static final String WAYBILL_NO_CAN_NOT_EMPTY = "20015";		
	
	@ReturnMsgCode("联系人地址信息数据校验失败")
	public static final String CONTACT_ADDR_INFO_CHECK_FAIL = "20020";	
	
	@ReturnMsgCode("区域代码不存在")
	public static final String DIST_CODE_NOT_EXIST = "20021";	
	
	@ReturnMsgCode("区域ID不存在")
	public static final String DIST_ID_NOT_EXIST = "20028";
	
	@ReturnMsgCode("省代码不存在")
	public static final String PROVINCE_CODE_NOT_EXIST = "20040";
	
	@ReturnMsgCode("市代码不存在")
	public static final String CITY_CODE_NOT_EXIST = "20041";
	
	@ReturnMsgCode("区/县代码不存在")
	public static final String COUNTY_CODE_NOT_EXIST = "20042";
	
	@ReturnMsgCode("联系地址信息ID不存在")
	public static final String CONTACT_ADDR_INFO_ID_NOT_EXIST = "20022";	
	
	@ReturnMsgCode("收件人联系地址信息ID不存在")
	public static final String REC_CONTACT_ADDR_INFO_ID_NOT_EXIST = "20023";
	
	@ReturnMsgCode("联系人地址信息ID不能为空")
	public static final String CONTACT_ADDR_INFO_ID_CAN_NOT_EMPTY = "20029";
	
	@ReturnMsgCode("寄件人联系地址信息ID不存在")
	public static final String SENDER_CONTACT_ADDR_INFO_ID_NOT_EXIST = "20024";
	
	@ReturnMsgCode("地址类型不能为空")
	public static final String ADDRESS_TYPE_CAN_NOT_EMPTY = "20025";	
	
	@ReturnMsgCode("地址类型不正确")
	public static final String ADDRESS_TYPE_ERROR = "20026";
	
	@ReturnMsgCode("联系人地址信息不能为空")
	public static final String CONTACT_ADDR_INFO_CAN_NOT_EMPTY = "20027";
	
	
//	@ReturnMsgCode("订单数据插入数据库失败")
//	public static final String EXPRESSORDERJOB_INSERT_FAIL = "20031";	
	
	@ReturnMsgCode("订单作业数据不能为空")
	public static final String EXPRESSORDERJOB_CAN_NOT_EMPTY = "20031";
	
//	@ReturnMsgCode("地址单元区域数据插入数据库失败")
//	public static final String ADDRESSTEAM_INSERT_FAIL = "20032";
	
	@ReturnMsgCode("订单作业数据校验失败")
	public static final String EXPRESSORDERJOB_CHECK_FAIL = "20032";
	
	@ReturnMsgCode("公司代码BUKRS不能为空")
	public static final String BUKRS_CAN_NOT_EMPTY = "20033";	
	
	@ReturnMsgCode("分页查询index必须大于0")
	public static final String QUERY_PAGE_INDEX_GREATER_THAN_ZERO = "20034";		
	
	@ReturnMsgCode("分页查询size必须大于0")
	public static final String QUERY_PAGE_SIZE_GREATER_THAN_ZERO = "20035";	
	
	@ReturnMsgCode("AddressTeam不能为空")
	public static final String ADDRESS_TEAM_CAN_NOT_EMPTY = "20036";	
	
	@ReturnMsgCode("AddressTeam数据校验失败")
	public static final String ADDRESS_TEAM_CHECK_FAIL = "20037";
	
	@ReturnMsgCode("资科下单调度系统异常")
	public static final String ORDER_SERVICE_EXCEPTION = "20038";
	
	@ReturnMsgCode("快递小哥已经下班啦，请明天再来吧")
	public static final String CAN_NOT_ORDER_EXCEPTION = "20039";
	
	/**
	 * 将 code 转码为中文
	 *
	 * @param code 编码
	 * @return 编码对应的中文信息
	 */
	public static String getValue(String code){
		if (null == codeMap) {
			codeMap = new HashMap<String, String>();
			
			MsgCode con = new MsgCode();
			Field[] fieldArray = con.getClass().getDeclaredFields();
			String value="";
			for(Field field:fieldArray){
				try
				{
					Object cod = field.get(con);
					if(cod!=null){
						ReturnMsgCode cmsg = field.getAnnotation(ReturnMsgCode.class);
						value = cmsg.value();
						
						codeMap.put((String)cod, value);
					}
				} catch (Exception e) {
					codeMap.put(code, code);
				}
			}
		}
		
		return codeMap.get(code);
	}
}
