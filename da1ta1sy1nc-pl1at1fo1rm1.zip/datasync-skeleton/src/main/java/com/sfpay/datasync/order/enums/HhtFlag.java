/**
 * 
 */
package com.sfpay.datasync.order.enums;

/**
 * 类说明：HHT收件状态枚举类
 *
 * 类描述：HHT收件状态枚举类
 * @author 625288 易振强
 * 2014-11-27
 */
public enum HhtFlag {
	// 未上传
	NOTUPLOADED("0"),
	// 已上传
	UPLOADED("1"),
	// 已下载
	DOWNLOAD("3"),
	// 转短信
	SWITCHMSG("4"),
	// 收件
	RECEIVE("5"),
	// 异常收件
	ERRORRCV("6");
	
	
	private String value;
	private HhtFlag(String value) {
		this.value = value;
	}
	
	public String toString() {
		return value;
	};
}
