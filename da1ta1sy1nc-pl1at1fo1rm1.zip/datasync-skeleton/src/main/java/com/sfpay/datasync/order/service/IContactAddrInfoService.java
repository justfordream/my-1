/**
 * 
 */
package com.sfpay.datasync.order.service;

import java.util.List;

import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：联系人（寄件/收件）地址信息服务接口
 *
 * 类描述：如果会员的第一个（寄件或收件）地址需要自动设置成默认地址
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IContactAddrInfoService {
	/**
	 * 新增联系人（寄件人/收件人）地址信息
	 * 注意，如果会员的第一个（寄件或收件）地址需要自动设置成默认地址
	 * @param contactAddrInfo
	 * @return	id主键
	 * @throws ServiceException 20027-联系人地址信息不能为空 20020-联系人地址信息数据校验失败 20040-省代码不存在 20041-市代码不存在 20042-区/县代码不存在
	 * 20021-区域代码不存在  20027-ContactAddrInfo不能为空
	 */
	public Long addContactAddrInfo(ContactAddrInfo contactAddrInfo) throws ServiceException;
	
	/**
	 * 删除联系人（寄件人/收件人）地址信息
	 * 这里只做假删除，将IS_USED设置为0
	 * @param contactAddrInfoId		联系人（寄件人/收件人）地址信息ID
	 * @throws ServiceException 20029-联系人地址信息ID不能为空 20022-联系地址信息ID不存在
	 */
	public void delContactAddrInfo(Long contactAddrInfoId) throws ServiceException;
	
	/**
	 * 删除联系人（寄件人/收件人）地址信息
	 * 这里只做假删除，将IS_USED设置为0
	 * @param contactAddrInfoId		联系人（寄件人/收件人）地址信息ID
	 * @param newDefaultAddrId 		如果删除的是默认寄件人地址，则该参数表示新的默认寄件人地址
	 * @throws ServiceException 20029-联系人地址信息ID不能为空 20022-联系地址信息ID不存在
	 */
	public void delContactAddrInfo(Long contactAddrInfoId, Long newDefaultAddrId) throws ServiceException;
	
	/**
	 * 更新联系人（寄件人/收件人）地址信息
	 * 
	 * @param contactAddrInfo
	 * @throws ServiceException
	 * 20021-区域代码不存在 20024-联系人地址信息ID不存在 20027-联系人地址信息不能为空 20027-联系人地址信息不能为空 
	 * 20020-联系人地址信息数据校验失败 20040-省代码不存在 20041-市代码不存在 20042-区/县代码不存在
	 */
	public void updateAddressInfo(ContactAddrInfo contactAddrInfo) throws ServiceException;
	
	/**
	 * 通过会员号和类型（寄件/收件）来查询联系人地址信息列表
	 * 
	 * @param memberNo
	 * @param addressType 		SENDER-寄件人地址，RECEIVER-收件人地址
	 * @throws ServiceException 20011-会员号不能为空 20025-地址类型不能为空 20026-地址类型不正确
	 */
	public List<ContactAddrInfo> queryAddressInfo(Long memberNo, String addressType) throws ServiceException;
	
	/**
	 * 通过参数来查询联系人地址信息列表
	 * 目前只支持memberNo、addressType、defaultFlag、cityId和address来查询
	 * 
	 * @param contactAddrInfo
	 */
	public List<ContactAddrInfo> queryAddressInfoByParam(ContactAddrInfo contactAddrInfo);
	
	/**
	 * 将该ID的联系人地址信息设置成默认的（寄件或收件）地址
	 * 
	 * @throws ServiceException 20029-联系人地址信息ID不能为空 20022-联系地址信息ID不存在
	 */
	public void setDefaultAddressInfo(Long defaultContactAddrInfoId) throws ServiceException;
	
	/**
	 * 获取某会员的（收件/寄件）默认地址
	 * 
	 * @param memberNo	会员号
	 * @param addressType	默认地址类型  SENDER-寄件人地址，RECEIVER-收件人地址
	 * @return
	 * @throws ServiceException 20011-会员号不能为空 20025-地址类型不能为空 20026-地址类型不正确
	 */
	public ContactAddrInfo queryDefaultAddress(Long memberNo, String addressType) throws ServiceException;
	
	/**
	 * 通过ID来查询联系人（收件/寄件）地址信息
	 * 
	 * @param id
	 * @return
	 */
	public ContactAddrInfo queryContactAddrInfoById(Long id);

}
