/**
 * 
 */
package com.sfpay.datasync.order.service;

import java.util.List;

import com.sfpay.datasync.order.domain.ExpressOrder;
import com.sfpay.datasync.order.domain.ExpressRecord;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：下单服务接口
 *
 * 类描述：下单服务接口
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IExpressOrderService {
	/**
	 * 新增手机APP运单，由手机代理调用
	 * @throws ServiceException 20001-下单数据校验失败 20002-下单数据不能为空 20024-寄件人联系地址信息ID不存在 20023-收件人联系地址信息ID不存在
	 * 20040-省代码不存在 20041-市代码不存在 20042-区/县代码不存在 20038-资科下单调度系统异常
	 * @return
	 */
	public String addExpressOrder(ExpressOrder expressOrder) throws ServiceException;
	
	/**
	 * 通过运单号来获取快件记录
	 * ExpressRecord 对象包含 快递状态、运单号、始发城市及目的城市、下单时间 等信息
	 * 
	 * @param wayBillNo 运单号列表
	 * @return
	 * @throws ServiceException 20014-ESB运单路由查询失败
	 */
	public List<ExpressRecord> queryExpressRecordByWayBillNo(List<String> wayBillNo) throws ServiceException;
	
	/**
	 * 通过ID来查询下单信息
	 * 
	 * @param id
	 * @return
	 */
	public ExpressOrder queryExpressOrderById(Long id);
	
	/**
	 * 通过订单号来查询下单信息
	 * 
	 * @param orderId
	 * @return
	 */
	public ExpressOrder queryExpressOrderByOrderId(String orderId);

}
