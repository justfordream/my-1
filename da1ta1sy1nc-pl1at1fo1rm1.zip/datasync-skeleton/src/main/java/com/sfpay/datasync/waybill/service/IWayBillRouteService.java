/**
 * 包名：com.sfpay.datasync.service
 * 文件名：IEsbService.java
 * 版本信息：
 * 日期：2014-8-12-下午1:41:13
 * 
 */
package com.sfpay.datasync.waybill.service;

import java.util.List;

import com.sfpay.datasync.waybill.domain.BarTraceInfo;
import com.sfpay.datasync.waybill.domain.WayBillRoute;



/**
 * 类名称：IEsbService 类描述： 创建人：313920 熊伟 修改人：313920 熊伟 修改时间：2014-8-12 下午1:41:13
 * 修改备注：
 * 
 * @version 2.0.1
 * 
 */
public interface IWayBillRouteService {
	/**
	 * 方法说明：queryBillStandard 批量查询运单路由(官网路由)
	 * @param waybillNos
	 * @return 
	 * @exception 
	 * @since  2.0.1
	 */
	public List<WayBillRoute> queryBillStandard(List<String> waybillNos);
	
	/**
	 * 方法说明：queryAllBarRecordList批量查询运单路由(全量路由)
	 * @param waybillNos
	 * @return 
	 * @exception 
	 * @since  2.0.1
	 */
	public List<BarTraceInfo> queryAllBarRecordList(List<String> waybillNos);
}
