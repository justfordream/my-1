/**
 * 
 */
package com.sfpay.datasync.order.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：运单信息类
 * 
 * 类描述：主要用于手机APP订单列表展示
 * 
 * @author 625288 易振强 2014-11-12
 */
public class ExpressRecord extends BaseEntity{
	// 运单号
	private String waybillNo;
	// 下单时间
	private Date orderTime;
	// 寄件城市名称
	private String senderCityName;
	// 收件城市名称
	private String recCityName;
	// 1.收派员收件  2.派件中 3.客户已签收
	private String expressStatus;
	// 具体路由信息
	private List<WayBillRecord> wayBillRecordList = 
			new ArrayList<WayBillRecord>();

	private static final long serialVersionUID = -3324608736858752432L;
	
	public String getWaybillNo() {
		return waybillNo;
	}

	public void setWaybillNo(String waybillNo) {
		this.waybillNo = waybillNo;
	}

	public Date getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(Date orderTime) {
		this.orderTime = orderTime;
	}

	public String getSenderCityName() {
		return senderCityName;
	}

	public void setSenderCityName(String senderCityName) {
		this.senderCityName = senderCityName;
	}

	public String getRecCityName() {
		return recCityName;
	}

	public void setRecCityName(String recCityName) {
		this.recCityName = recCityName;
	}

	public String getExpressStatus() {
		return expressStatus;
	}

	public void setExpressStatus(String expressStatus) {
		this.expressStatus = expressStatus;
	}

	public List<WayBillRecord> getWayBillRecordList() {
		return wayBillRecordList;
	}

	public void setWayBillRecordList(List<WayBillRecord> wayBillRecordList) {
		this.wayBillRecordList = wayBillRecordList;
	}
}
