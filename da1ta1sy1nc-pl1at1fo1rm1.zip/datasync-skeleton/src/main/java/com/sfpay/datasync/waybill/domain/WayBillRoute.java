package com.sfpay.datasync.waybill.domain;

import java.util.List;

import com.sfpay.framework.base.entity.BaseEntity;

public class WayBillRoute extends BaseEntity {
	
	private static final long serialVersionUID = 1L;

	private String waybillNo;
	// 所在城市
	private String distName;
	// 签收时间
	private String signinTm;
	// 是否已有回单
	private String receiveBillFlg;
	// 子单信息（集合）
	private String childSet;
	// 子单号
	private String childWaybillNo;
	
	// 寄件城市名称
	private String sourceCityName;
	// 寄件区域代码
	private String sourceZoneCode;
	// 寄件区域名称
	private String sourceZoneName;
	// 寄件人名称
	private String senderName;
	// 寄件人手机
	private String senderMobile;
	// 寄件人电话
	private String senderPhone;
	
	// 收件城市名称
	private String destCityName;
	// 收件区域代码
	private String destZoneCode;
	// 收件区域名称
	private String destZoneName;
	// 签收人名称
	private String subscriberName;
	//收件人手机
	private String receiverMobile;
	// 收件人电话
	private String receiverPhone;
	
	// 寄件时间
	private String sendTm;

	/**
	 * 巴枪操作列表
	 */
	private List<WaybillBarInfo> barList;
	
	public String getSourceZoneCode() {
		return sourceZoneCode;
	}

	public void setSourceZoneCode(String sourceZoneCode) {
		this.sourceZoneCode = sourceZoneCode;
	}

	public String getSourceZoneName() {
		return sourceZoneName;
	}

	public void setSourceZoneName(String sourceZoneName) {
		this.sourceZoneName = sourceZoneName;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getSenderMobile() {
		return senderMobile;
	}

	public void setSenderMobile(String senderMobile) {
		this.senderMobile = senderMobile;
	}

	public String getSenderPhone() {
		return senderPhone;
	}

	public void setSenderPhone(String senderPhone) {
		this.senderPhone = senderPhone;
	}

	public String getDestZoneCode() {
		return destZoneCode;
	}

	public void setDestZoneCode(String destZoneCode) {
		this.destZoneCode = destZoneCode;
	}

	public String getDestZoneName() {
		return destZoneName;
	}

	public void setDestZoneName(String destZoneName) {
		this.destZoneName = destZoneName;
	}

	
	
	public String getReceiverMobile() {
		return receiverMobile;
	}

	public void setReceiverMobile(String receiverMobile) {
		this.receiverMobile = receiverMobile;
	}

	public String getReceiverPhone() {
		return receiverPhone;
	}

	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}

	public String getWaybillNo() {
		return waybillNo;
	}

	public void setWaybillNo(String waybillNo) {
		this.waybillNo = waybillNo;
	}

	public String getDistName() {
		return distName;
	}

	public void setDistName(String distName) {
		this.distName = distName;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public String getSigninTm() {
		return signinTm;
	}

	public void setSigninTm(String signinTm) {
		this.signinTm = signinTm;
	}

	public String getReceiveBillFlg() {
		return receiveBillFlg;
	}

	public void setReceiveBillFlg(String receiveBillFlg) {
		this.receiveBillFlg = receiveBillFlg;
	}

	public String getChildSet() {
		return childSet;
	}

	public void setChildSet(String childSet) {
		this.childSet = childSet;
	}

	public String getChildWaybillNo() {
		return childWaybillNo;
	}

	public void setChildWaybillNo(String childWaybillNo) {
		this.childWaybillNo = childWaybillNo;
	}

	public List<WaybillBarInfo> getBarList() {
		return barList;
	}

	public void setBarList(List<WaybillBarInfo> barList) {
		this.barList = barList;
	}

	public String getSourceCityName() {
		return sourceCityName;
	}

	public void setSourceCityName(String sourceCityName) {
		this.sourceCityName = sourceCityName;
	}

	public String getDestCityName() {
		return destCityName;
	}

	public void setDestCityName(String destCityName) {
		this.destCityName = destCityName;
	}

	public String getSendTm() {
		return sendTm;
	}

	public void setSendTm(String sendTm) {
		this.sendTm = sendTm;
	}
}
