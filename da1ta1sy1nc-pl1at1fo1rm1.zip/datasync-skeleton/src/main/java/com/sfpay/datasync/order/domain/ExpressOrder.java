package com.sfpay.datasync.order.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：下单实体类
 * 
 * 类描述：下单实体类
 * 
 * @author 625288 易振强 2014-11-12
 */
public class ExpressOrder extends BaseEntity {
	// 会员号
	private Long memberNo;
	// 订单号
	private String orderId;
	// 寄件城市代码
	private String areaNo;
	// 网点代码
	private String deptId;
	// 单元区域
	private String teamId;
	// 客户卡号
	private String custId;
	// 客户类型
	private String custType;
	// 寄件联系人
	private String contact;
	// 寄件公司
	private String compAbb;
	// 省名称
	private String provinceName;
	// 市名称
	private String cityName;
	// 县区名称
	private String countyName;
	// 寄件地址
	private String addrAbb;
	// 寄件人电话
	private String custTel;
	// 重量
	private Double weight;
	// 长度
	private Double length;
	// 货物类型
	private String cargoType;
	// 货物名
	private String cargoName;
	// 预约时间
	private String bookTime;
	// 订单类型(来源) 填52，需再确认
	private String orderType;
	// 备注（收派员）
	private String makeup;
	// 备案(客服看)
	private String memo;
	// 操作人
	private String operator;
	// 地址编号
	private String addressNo;
	// 客户编码
	private String custTag;
	// 寄件等级(B/C)
	private String senderType;
	// 到件联系人
	private String dcontanct;
	// 到件人联系电话
	private String dtel;
	// 到件公司
	private String dcompany;
	// 到件地址
	private String daddress;
	// 货物数量
	private Long cargoNumber;
	// 货物件数
	private Long cargoPiece;
	// 保价金额
	private Double insuranceAmount;
	// 付款方式1-寄付 2-到付 3-第三方付
	private String payMethod;
	// 到件城市编码
	private String destinationCode;
	// 付款方月结卡号
	private String monthPayCustId;
	// 是否三合一电子运单 1 三合一 0非三合一
	private String isHhtWayBill;
	// 是否高额理赔用户
	private String isClaims;
	// 风险客户等级
	private String blackType;
	// 币种(RMB)
	private String currencyValue;
	// 目的地
	private String destination;
	// 顺丰优惠券校验码
	private String couponsVerificationCode;
	// 顺丰优惠券号
	private String couponsNo;
	// 顺丰优惠券金额
	private Double couponsAmount;
	// 扩展参数(目前门店使用及自助使用)( * 第0位 运单号, * 第1位 产品类型, * 第2位 产品类型名称, * 第3位 运费, *
	// 如果无值，需使用空字符串""来占位)
	private String orderArgs;
	// 寄件地址ID
	private Long senderAddrId;
	// 收件地址ID
	private Long recAddrId;
	// 创建人
	private String createName;
	// 创建时间
	private Date createTime;
	// 修改人
	private String updateName;
	// 修改时间
	private Date updateTime;

	private static final long serialVersionUID = -9217718407734032166L;

	public Long getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(Long memberNo) {
		this.memberNo = memberNo;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public void setAreaNo(String areaNo) {
		this.areaNo = areaNo;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getTeamId() {
		return teamId;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getCompAbb() {
		return compAbb;
	}

	public void setCompAbb(String compAbb) {
		this.compAbb = compAbb;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCountyName() {
		return countyName;
	}

	public void setCountyName(String countyName) {
		this.countyName = countyName;
	}

	public String getAddrAbb() {
		return addrAbb;
	}

	public void setAddrAbb(String addrAbb) {
		this.addrAbb = addrAbb;
	}

	public String getCustTel() {
		return custTel;
	}

	public void setCustTel(String custTel) {
		this.custTel = custTel;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Double getLength() {
		return length;
	}

	public void setLength(Double length) {
		this.length = length;
	}

	public String getCargoType() {
		return cargoType;
	}

	public void setCargoType(String cargoType) {
		this.cargoType = cargoType;
	}

	public String getCargoName() {
		return cargoName;
	}

	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}

	public String getBookTime() {
		return bookTime;
	}

	public void setBookTime(String bookTime) {
		this.bookTime = bookTime;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getMakeup() {
		return makeup;
	}

	public void setMakeup(String makeup) {
		this.makeup = makeup;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getAddressNo() {
		return addressNo;
	}

	public void setAddressNo(String addressNo) {
		this.addressNo = addressNo;
	}

	public String getCustTag() {
		return custTag;
	}

	public void setCustTag(String custTag) {
		this.custTag = custTag;
	}

	public String getSenderType() {
		return senderType;
	}

	public void setSenderType(String senderType) {
		this.senderType = senderType;
	}

	public String getDcontanct() {
		return dcontanct;
	}

	public void setDcontanct(String dcontanct) {
		this.dcontanct = dcontanct;
	}

	public String getDtel() {
		return dtel;
	}

	public void setDtel(String dtel) {
		this.dtel = dtel;
	}

	public String getDcompany() {
		return dcompany;
	}

	public void setDcompany(String dcompany) {
		this.dcompany = dcompany;
	}

	public String getDaddress() {
		return daddress;
	}

	public void setDaddress(String daddress) {
		this.daddress = daddress;
	}

	public Long getCargoNumber() {
		return cargoNumber;
	}

	public void setCargoNumber(Long cargoNumber) {
		this.cargoNumber = cargoNumber;
	}

	public Long getCargoPiece() {
		return cargoPiece;
	}

	public void setCargoPiece(Long cargoPiece) {
		this.cargoPiece = cargoPiece;
	}

	public Double getInsuranceAmount() {
		return insuranceAmount;
	}

	public void setInsuranceAmount(Double insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}

	public String getPayMethod() {
		return payMethod;
	}

	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}

	public String getDestinationCode() {
		return destinationCode;
	}

	public void setDestinationCode(String destinationCode) {
		this.destinationCode = destinationCode;
	}

	public String getMonthPayCustId() {
		return monthPayCustId;
	}

	public void setMonthPayCustId(String monthPayCustId) {
		this.monthPayCustId = monthPayCustId;
	}

	public String getIsHhtWayBill() {
		return isHhtWayBill;
	}

	public void setIsHhtWayBill(String isHhtWayBill) {
		this.isHhtWayBill = isHhtWayBill;
	}

	public String getIsClaims() {
		return isClaims;
	}

	public void setIsClaims(String isClaims) {
		this.isClaims = isClaims;
	}

	public String getBlackType() {
		return blackType;
	}

	public void setBlackType(String blackType) {
		this.blackType = blackType;
	}

	public String getCurrencyValue() {
		return currencyValue;
	}

	public void setCurrencyValue(String currencyValue) {
		this.currencyValue = currencyValue;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getCouponsNo() {
		return couponsNo;
	}

	public void setCouponsNo(String couponsNo) {
		this.couponsNo = couponsNo;
	}

	public Double getCouponsAmount() {
		return couponsAmount;
	}

	public void setCouponsAmount(Double couponsAmount) {
		this.couponsAmount = couponsAmount;
	}

	public String getOrderArgs() {
		return orderArgs;
	}

	public void setOrderArgs(String orderArgs) {
		this.orderArgs = orderArgs;
	}

	public Long getSenderAddrId() {
		return senderAddrId;
	}

	public void setSenderAddrId(Long senderAddrId) {
		this.senderAddrId = senderAddrId;
	}

	public Long getRecAddrId() {
		return recAddrId;
	}

	public void setRecAddrId(Long recAddrId) {
		this.recAddrId = recAddrId;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getCouponsVerificationCode() {
		return couponsVerificationCode;
	}

	public void setCouponsVerificationCode(String couponsVerificationCode) {
		this.couponsVerificationCode = couponsVerificationCode;
	}
}
