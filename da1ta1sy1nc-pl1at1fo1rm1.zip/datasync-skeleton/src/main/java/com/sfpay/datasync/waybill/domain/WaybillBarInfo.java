package com.sfpay.datasync.waybill.domain;


import com.sfpay.framework.base.entity.BaseEntity;

public class WaybillBarInfo extends BaseEntity {
	/**
	 * serialVersionUID:TODO（用一句话描述这个变量表示什么）
	 * @since 2.0.1
	 */
	
	private static final long serialVersionUID = 1L;
	/**
	 * 扫描日期
	 */
	private String barScanDt;
	/**
	 * 扫描时间
	 */
	private String barScanTm;
	/**
	 * 所在城市
	 */
	private String distName;
	/**
	 * 预计下一网点
	 */
	private String nextDestZone;
	/**
	 * 操作类型
	 */
	private String opCode;
	/**
	 * 巴枪操作说明
	 */
	private String opName;
	/**
	 * 监控记录
	 */
	private String remark;

	public String getBarScanDt() {
		return barScanDt;
	}

	public void setBarScanDt(String barScanDt) {
		this.barScanDt = barScanDt;
	}

	public String getBarScanTm() {
		return barScanTm;
	}

	public void setBarScanTm(String barScanTm) {
		this.barScanTm = barScanTm;
	}

	public String getDistName() {
		return distName;
	}

	public void setDistName(String distName) {
		this.distName = distName;
	}

	public String getNextDestZone() {
		return nextDestZone;
	}

	public void setNextDestZone(String nextDestZone) {
		this.nextDestZone = nextDestZone;
	}

	public String getOpCode() {
		return opCode;
	}

	public void setOpCode(String opCode) {
		this.opCode = opCode;
	}

	public String getOpName() {
		return opName;
	}

	public void setOpName(String opName) {
		this.opName = opName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
