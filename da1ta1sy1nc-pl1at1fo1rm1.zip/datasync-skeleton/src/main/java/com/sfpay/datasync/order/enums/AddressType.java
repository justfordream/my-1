/**
 * 
 */
package com.sfpay.datasync.order.enums;

/**
 * 类说明：联系人（寄件人/收件人）地址信息 是否可用状态枚举
 *
 * 类描述：联系人（寄件人/收件人）地址信息 是否可用状态枚举
 * @author 625288 易振强
 * 2014-11-13
 */
public enum AddressType {
	// 寄件人地址
	SENDER("SENDER"),
	// 收件人地址
	RECEIVER("RECEIVER");
	
	private String value;
	
	AddressType(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return value;
	}
}
