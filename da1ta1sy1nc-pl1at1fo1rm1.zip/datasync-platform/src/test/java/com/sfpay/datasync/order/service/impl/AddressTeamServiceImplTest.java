/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.ArrayList;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.sfpay.datasync.order.domain.AddressTeam;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.service.IAddressTeamService;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.datasync.order.webservice.IOrderService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：地址单元区域Service测试类
 *
 * 类描述：地址单元区域Service测试类
 * @author 625288 易振强
 * 2014-11-24
 */
public class AddressTeamServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IAddressTeamService addressTeamService;
	
	@Autowired
	IOrderService orderServiceClient;
	
	@Test
	public void addAddressTeamTest() {
		try {
			AddressTeam addressTeam = new AddressTeam();
			addressTeam.setOperateType("U");
			addressTeam.setCityId("27");
			addressTeam.setAddress("武昌火车站***路");
			addressTeam.setTeamId("1314");
			addressTeam.setDeptId("020AA");
			addressTeam.setCustId("15013442010");
			addressTeamService.addAddressTeam(addressTeam);
		} catch (ServiceException e) {
		}
		
		try {
			addressTeamService.addAddressTeam(null);
		} catch (ServiceException e) {
		}
		
		try {
			AddressTeam addressTeam = new AddressTeam();
			addressTeamService.addAddressTeam(addressTeam);
		} catch (ServiceException e) {
		}
		
		try {
			AddressTeam addressTeam = new AddressTeam();
			addressTeam.setCityId("1234");
			addressTeamService.addAddressTeam(addressTeam);
		} catch (ServiceException e) {
		}
		
		try {
			AddressTeam addressTeam = new AddressTeam();
			addressTeam.setCityId("1234");
			addressTeam.setAddress("123123");
			addressTeamService.addAddressTeam(addressTeam);
		} catch (ServiceException e) {
		}
		
		try {
			AddressTeam addressTeam = new AddressTeam();
			addressTeam.setCityId("1234");
			addressTeam.setAddress("123123");
			addressTeam.setTeamId("123123");
			addressTeamService.addAddressTeam(addressTeam);
		} catch (ServiceException e) {
		}
		
		try {
			AddressTeam addressTeam = new AddressTeam();
			addressTeam.setCityId("7313");
			addressTeam.setAddress("响石四村15棟701号");
			addressTeam.setTeamId("123123");
			addressTeamService.addAddressTeam(addressTeam);
		} catch (ServiceException e) {
		}
		
		try {
			AddressTeam addressTeam = new AddressTeam();
			addressTeam.setCityId("7313");
			addressTeam.setAddress("响石四村15棟701号");
			addressTeam.setTeamId("123123");
			MockCurrentResult.setMockValue(IContactAddrInfoService.class, "queryAddressInfoByParam", null);
			addressTeamService.addAddressTeam(addressTeam);
			MockCurrentResult.removeMockValue(IContactAddrInfoService.class, "queryAddressInfoByParam");
			MockCurrentResult.setMockValue(IContactAddrInfoService.class, "queryAddressInfoByParam",new ArrayList<ContactAddrInfo>());
			addressTeamService.addAddressTeam(addressTeam);
		} catch (ServiceException e) {
		}
		
		
	}
	
	
	@Test
	public void sendMessage() {
		MQEnvironment.hostname = "10.79.11.156";// 本地IP
		MQEnvironment.port = 1434;
		MQEnvironment.channel = "ADDRESS_SVR_CHL";// 用来通信的通道
		MQEnvironment.CCSID = 1208;
		try {
			MQQueueManager qMgr = new MQQueueManager("QM_ADDRESS");// 队列管理器名称
			int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT
					| MQC.MQOO_INQUIRE;
			MQQueue queue = qMgr.accessQueue("ADDRESS_REV", openOptions, null, null,
					null);
			// 建立连接
			MQMessage msg = new MQMessage();// 要写入队列的消息
			msg.format = MQC.MQFMT_STRING;
			msg.characterSet = MQEnvironment.CCSID;
			msg.encoding = MQEnvironment.CCSID;
			try {

				msg.writeString("123123123123");
			} catch (java.io.IOException ex) {
				System.out.println(ex);
			}

			msg.expiry = -1; // 设置消息用不过期
			for(int i = 0; i < 10; i++) {
				queue.put(msg);// 将消息放入队列
			}
			queue.close();// 关闭队列
			qMgr.disconnect(); // 断开连接
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}
	
}
