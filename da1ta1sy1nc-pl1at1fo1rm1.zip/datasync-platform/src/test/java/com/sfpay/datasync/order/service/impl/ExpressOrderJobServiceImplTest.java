/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.domain.ExpressOrderJob;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.datasync.order.service.IExpressOrderJobService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288 易振强
 * 2014-11-24
 */
public class ExpressOrderJobServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IExpressOrderJobService expressOrderJobService;
	
	@Test
	public void addExpressOrderJobTest() {
		ExpressOrderJob expressOrderJob = new ExpressOrderJob();
		expressOrderJob.setOperateType("U");
		expressOrderJob.setJobId("140904032213017");
		expressOrderJob.setOrderId("DATASYNC2015020815000200000105");
		expressOrderJob.setEmpId("11111111111");
		expressOrderJob.setCustId("0102406462");
		expressOrderJob.setMsg("04057新:054::0102406462:小米通讯技术责任有限公司:警:1206:北京配送中心(天猫):4001005678:::北京配送中心(天猫):寄方付::塔城地区::|");
		expressOrderJob.setSendTime(new Date());
		expressOrderJob.setSendType("1");
		expressOrderJob.setDeptId("551T");
		expressOrderJob.setSp("中国电信");
		expressOrderJob.setDevice("IBM2");
		expressOrderJob.setHhtFlag("5");
		expressOrderJob.setOldJobId("140904032213057");
		expressOrderJob.setOrderType("9");
		expressOrderJob.setOrderClass("0");
		expressOrderJob.setBno("555242497028");
		expressOrderJob.setDestination("地城之光");
		expressOrderJob.setCustTel("4001005678");
		expressOrderJob.setContact("北京配送中心(天猫)");
		expressOrderJob.setAreaNo("A430200000");
		expressOrderJob.setCustType("0");
		expressOrderJob.setCompAbb("阿里巴巴");
		expressOrderJob.setAddrAbb("北京配送中心(天猫)");
		expressOrderJob.setTeamId("755A000101");
		expressOrderJob.setWeight(0d);
		expressOrderJob.setInterType("1");
		expressOrderJob.setLastTime("1206");
		
		try {
		    expressOrderJobService.addExpressOrderJob(expressOrderJob);
			MockCurrentResult.setMockValue(IContactAddrInfoService.class, "queryContactAddrInfoById", null);
			expressOrderJobService.addExpressOrderJob(expressOrderJob);
			MockCurrentResult.removeMockValue(IContactAddrInfoService.class, "queryContactAddrInfoById");
			ContactAddrInfo contactAddrInfo = new ContactAddrInfo();
			contactAddrInfo.setId(100L);
			contactAddrInfo.setProvinceCode("755");
			contactAddrInfo.setCityCode("755");
			contactAddrInfo.setCountyCode("755");
			MockCurrentResult.setMockValue(IContactAddrInfoService.class, "queryContactAddrInfoById", contactAddrInfo);
			expressOrderJobService.addExpressOrderJob(expressOrderJob);
			MockCurrentResult.setMockValue(IContactAddrInfoService.class, "updateAddressInfo", new Exception());
			expressOrderJobService.addExpressOrderJob(expressOrderJob);
		} catch (ServiceException e) {
		}
		
		expressOrderJob.setJobId("140904032213016");
		expressOrderJob.setOrderId("DATASYNC2014120515581700000001");
		expressOrderJob.setBno("688956247833");
		try {
			expressOrderJobService.addExpressOrderJob(expressOrderJob);
		} catch (ServiceException e) {
		}
		
		try {
			ExpressOrderJob expressOrderJob2=null;
			expressOrderJobService.addExpressOrderJob(expressOrderJob2);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob test1=new ExpressOrderJob();
			test1.setAlertFlag("1");
			expressOrderJobService.addExpressOrderJob(test1);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob test2=new ExpressOrderJob();
			test2.setJobId("123");
			test2.setOrderId("2323");
			expressOrderJobService.addExpressOrderJob(test2);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob test3=new ExpressOrderJob();
			test3.setJobId(null);
			test3.setOrderId("DATASYNC2014120515581700000YNF");
			expressOrderJobService.addExpressOrderJob(test3);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob test3=new ExpressOrderJob();
			test3.setJobId("123");
			test3.setOrderId(null);
			expressOrderJobService.addExpressOrderJob(test3);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob test3=new ExpressOrderJob();
			test3.setJobId("123");
			test3.setOrderId("DATASYNC2014120515581700000YNF");
			expressOrderJobService.addExpressOrderJob(test3);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob test3=new ExpressOrderJob();
			test3.setJobId("123");
			test3.setOrderId("SATASYNC2014120515581700000YNF");
			expressOrderJobService.addExpressOrderJob(test3);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob test3=new ExpressOrderJob();
			test3.setJobId("123");
			test3.setOrderId("DATASYNC201412051558000YNF");
			expressOrderJobService.addExpressOrderJob(test3);
		} catch (Exception e) {
		}
		
		
		
	}

	@Test
	public void queryExpressOrderJobByIdTest() {
		try {
			System.out.println(expressOrderJobService.queryExpressOrderJobById(null));
		} catch (Exception e) {
		}		
		System.out.println(expressOrderJobService.queryExpressOrderJobById(2l));
		System.out.println(expressOrderJobService.queryExpressOrderJobById(10l));
	}
	
	@Test
	public void queryExpressOrderJobByWayBillNoTest() {
		System.out.println(expressOrderJobService.queryExpressOrderJobByWayBillNo(""));
		System.out.println(expressOrderJobService.queryExpressOrderJobByWayBillNo("107016619742"));
		System.out.println(expressOrderJobService.queryExpressOrderJobByWayBillNo("966629216961"));
	}
	
	@Test
	public void queryExpressOrderJobByParamTest() {
		try {
			ExpressOrderJob expressOrderJob=null;
			expressOrderJobService.queryExpressOrderJobByParam(expressOrderJob);
		} catch (Exception e) {
		}
		
		try {
			ExpressOrderJob expressOrderJob = new ExpressOrderJob();
			expressOrderJob.setJobId("140904032213057");
			System.out.println(expressOrderJobService.queryExpressOrderJobByParam(expressOrderJob));
			expressOrderJob.setOrderId("DATASYNC2014120515591500000003");
			System.out.println(expressOrderJobService.queryExpressOrderJobByParam(expressOrderJob));
			expressOrderJob.setBno("107016619742");
			System.out.println(expressOrderJobService.queryExpressOrderJobByParam(expressOrderJob));
		} catch (Exception e) {
		}
		
	}
	
	@Test
	public void sendMessage() {
		MQEnvironment.hostname = "10.79.11.156";// 本地IP
		MQEnvironment.port = 1433;
		MQEnvironment.channel = "ORD_SVR_CHL";// 用来通信的通道
		MQEnvironment.CCSID = 1208;
		try {
			MQQueueManager qMgr = new MQQueueManager("QM_ORD");// 队列管理器名称
			int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT
					| MQC.MQOO_INQUIRE;
			MQQueue queue = qMgr.accessQueue("ORD_REV", openOptions, null, null,
					null);
			// 建立连接
			MQMessage msg = new MQMessage();// 要写入队列的消息
			msg.format = MQC.MQFMT_STRING;
			msg.characterSet = MQEnvironment.CCSID;
			msg.encoding = MQEnvironment.CCSID;
			try {

				msg.writeString("123123123123");
			} catch (java.io.IOException ex) {
				System.out.println(ex);
			}

			msg.expiry = -1; // 设置消息用不过期
			for(int i = 0; i < 10; i++) {
				queue.put(msg);// 将消息放入队列
			}
			queue.close();// 关闭队列
			qMgr.disconnect(); // 断开连接
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}
}
