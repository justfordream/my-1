/**
 * 
 */
package com.sfpay.datasync.hht.mq;

import org.junit.Test;
import org.springframework.test.testcase.ClassTransactionalTestCase;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.sfpay.datasync.hht.domain.HHTLogin;
import com.sfpay.framework.common.xml.dom4j.core.XmlParser;

/**
 * 类说明：
 * 
 * 类描述：
 * 
 * @author 625288 易振强 2014-12-8
 */
public class HhtMQTest extends ClassTransactionalTestCase {
	@Test
	public void sendMessage() {
		MQEnvironment.hostname = "10.79.11.156";// 本地IP
		MQEnvironment.port = 1431;
		MQEnvironment.channel = "HHT_SVR_CHL";// 用来通信的通道
		MQEnvironment.CCSID = 1208;
		try {
			MQQueueManager qMgr = new MQQueueManager("QM_HHT");// 队列管理器名称
			int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT
					| MQC.MQOO_INQUIRE;
			MQQueue queue = qMgr.accessQueue("HHT_REV", openOptions, null, null,
					null);
			// 建立连接
			MQMessage msg = new MQMessage();// 要写入队列的消息
			msg.format = MQC.MQFMT_STRING;
			msg.characterSet = MQEnvironment.CCSID;
			msg.encoding = MQEnvironment.CCSID;
			try {
				// hello.format = MQC.MQFMT_STRING;
				// hello.characterSet = 1381;
				HHTLogin hhtLogin = new HHTLogin();
				hhtLogin.setSn("44444444");
				hhtLogin.setDepartmentId("12345678");
				hhtLogin.setEmployeeId("123456");

				msg.writeString(XmlParser.parserFormatModel(hhtLogin));
			} catch (java.io.IOException ex) {
				System.out.println(ex);
			}

			msg.expiry = -1; // 设置消息用不过期
			for(int i = 0; i < 10; i++) {
				queue.put(msg);// 将消息放入队列
			}
			queue.close();// 关闭队列
			qMgr.disconnect(); // 断开连接
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}
}
