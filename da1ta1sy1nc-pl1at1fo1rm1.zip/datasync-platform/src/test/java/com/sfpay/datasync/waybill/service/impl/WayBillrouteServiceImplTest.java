/**
 * 
 */
package com.sfpay.datasync.waybill.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.caucho.hessian.client.HessianProxyFactory;
import com.sfpay.datasync.order.domain.ExpressOrder;
import com.sfpay.datasync.order.service.IExpressOrderService;
import com.sfpay.datasync.waybill.service.IWayBillRouteService;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288 易振强
 * 2014-12-12
 */
public class WayBillrouteServiceImplTest {
	public static void main(String[] args) {
		HessianProxyFactory factory = new HessianProxyFactory();
		IWayBillRouteService wayBillRouteService = null;
		try {
			wayBillRouteService = (IWayBillRouteService) factory.create(IWayBillRouteService.class, 
					"http://10.79.11.156:9097/datasync-platform/hessian/wayBillRouteService");
			List<String> waybillNos = new ArrayList<String>();
			waybillNos.add("755123456789");
			wayBillRouteService.queryAllBarRecordList(waybillNos);
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
