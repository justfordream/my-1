/**
 * 
 */
package com.sfpay.datasync.cms.mq;

import org.junit.Test;
import org.springframework.test.testcase.ClassTransactionalTestCase;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.sfpay.datasync.cms.domain.TMDepartment;
import com.sfpay.framework.common.xml.dom4j.core.XmlParser;

/**
 * 类说明：
 * 
 * 类描述：
 * 
 * @author 625288 易振强 2014-12-8
 */
public class CmsMQTest extends ClassTransactionalTestCase {
	@Test
	public void sendMessage() {
		MQEnvironment.hostname = "10.79.11.156";// 本地IP
		MQEnvironment.port = 1432;
		MQEnvironment.channel = "CMS_SVR_CHL";// 用来通信的通道
		MQEnvironment.CCSID = 1208;
		try {
			MQQueueManager qMgr = new MQQueueManager("QM_CMS");// 队列管理器名称
			int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT
					| MQC.MQOO_INQUIRE;
			MQQueue queue = qMgr.accessQueue("CMS_REV", openOptions, null, null,
					null);
			// 建立连接
			MQMessage msg = new MQMessage();// 要写入队列的消息
			msg.format = MQC.MQFMT_STRING;
			msg.characterSet = MQEnvironment.CCSID;
			msg.encoding = MQEnvironment.CCSID;
			try {
				TMDepartment depart = new TMDepartment();
				depart.setDeptId(111111111l);
				depart.setDivisionCode("11111");
				depart.setAreaCode("7911");
				depart.setHqCode("CN05");
				depart.setTypeCode("jybb02");
				

				msg.writeString(XmlParser.parserFormatModel(depart));
			} catch (java.io.IOException ex) {
				System.out.println(ex);
			}

			msg.expiry = -1; // 设置消息用不过期
			for(int i = 0; i < 10; i++) {
				queue.put(msg);// 将消息放入队列
			}
			queue.close();// 关闭队列
			qMgr.disconnect(); // 断开连接
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}
}
