/**
 * 包名：com.sf.module.esb.util
 * 文件名：Client.java
 * 版本信息：
 * 日期：2014-8-14-上午9:45:06
 * 
 */
package com.sfpay.datasync.waybill.service.impl;

import javax.xml.ws.Holder;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

import com.sfpay.datasync.sap.service.bigfileservice.BigFileServicePortType;
import com.sfpay.datasync.sap.service.bigfileservice.EsbSoapHeaderType;
import com.sfpay.datasync.sap.service.bigfileservice.SBODYType2;
import com.sfpay.datasync.sap.service.bigfileservice.SBODYType5;
import com.sfpay.datasync.sap.service.bigfileservice.SHEADType1;
import com.sfpay.datasync.sap.service.bigfileservice.SHEADType3;

/**
 * 类名称：Client
 * 类描述：
 * 创建人：313920 熊伟
 * 修改人：313920 熊伟
 * 修改时间：2014-8-14 上午9:45:06
 * 修改备注：
 * @version 2.0.1
 * 
 */
public class Client {

	/**
	 * 方法说明：main
	 * @param args 
	 * @exception 
	 * @since  2.0.1
	 */
	public static void main(String[] args) {
	    //创建WebService客户端代理工厂   
	    JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();   
	    //注册WebService接口   
	    factory.setServiceClass(BigFileServicePortType.class);   //找到对应的服务类
	    //设置WebService地址   
	    factory.setAddress("http://10.79.11.156:9097/datasync-platform/ws/BigFileService");
	    BigFileServicePortType port = (BigFileServicePortType)factory.create();   //创建服务类
	    SHEADType1  head= new SHEADType1();
	    SBODYType2 body = new SBODYType2();
	    EsbSoapHeaderType esbSoapHeader15 = new EsbSoapHeaderType();  
	    Holder<SHEADType3> shead1 = new Holder<SHEADType3>();
	    Holder<SBODYType5> sbody1 = new  Holder<SBODYType5>(); 
	    Holder<EsbSoapHeaderType> esbSoapHeader2 = new Holder<EsbSoapHeaderType>();
		//填入业务公共业务头字段
        head.setSYSTEMID("SAP-ECC");
        head.setCOUNTRY("CN");
        head.setPAGEINDEX("1"); 
        head.setPAGENUM("2");
        head.setPAGESIZE("10");
        head.setSEQNO("778899");
        head.setSERVERID("queryAssetsInfo");
        head.setTRANDATE("2013-09-01");
        head.setTRANMODE("0");
        head.setTRANTIMESTAMP("15:30");
        head.setUSERID("123456");
        head.setUSERLANG("Chinese");
        head.setWSID("");
		
        /*	//业务内容body
        body.setDataType("SAPFI_NET_CORP");
        body.setFilePath("/VOL_sftp1/SAP_out/20140813/FI_PVB/");
        body.setFileName("FI_PVB_ECD_20140813162246_052.XML");
        body.setIsZip("1");
	    port.bigFileService(head, body, esbSoapHeader15, shead1, sbody1, esbSoapHeader2);*/
	  
		//业务内容body
	    body.setDataType("HCM-OUT_ORG");
        body.setFilePath("/VOL_sftp1/SAP_out/20140731/HR_ORG");
        body.setFileName("HR_ORG_ECD_20140731093806_020.xml.zip");
        body.setIsZip("0");
	    port.bigFileService(head, body, esbSoapHeader15, shead1, sbody1, esbSoapHeader2);
	     
  		//业务内容body
/*        body.setDataType("HCM-OUT_EMP");
        body.setFilePath("/VOL_sftp1/SAP_out/20140812/HR_EMP");
        body.setFileName("HR_EMP_ECD_20140812112400_103.xml.zip");
        body.setIsZip("0");
	    port.bigFileService(head, body, esbSoapHeader15, shead1, sbody1, esbSoapHeader2);*/
	  
	    try {
	    	System.out.println("over");
	    	Thread.sleep(30000L);
		} catch (Exception e) {
			// TODO: handle exception
		}
	    
	}

}
