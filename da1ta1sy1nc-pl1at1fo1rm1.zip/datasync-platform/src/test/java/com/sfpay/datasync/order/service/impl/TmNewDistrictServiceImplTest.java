/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.testcase.ClassTransactionalTestCase;

import com.sfpay.datasync.order.service.ITmNewDistrictService;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288 易振强
 * 2014-12-2
 */
public class TmNewDistrictServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private ITmNewDistrictService tmNewDistrictService;
	
	@Test
	public void queryDistByDistTypeTest() {
		System.out.println(tmNewDistrictService.queryDistByDistType(""));
		System.out.println(tmNewDistrictService.queryDistByDistType("1"));
		System.out.println(tmNewDistrictService.queryDistByDistType("2"));
		System.out.println(tmNewDistrictService.queryDistByDistType("3"));
	}
	
	@Test
	public void queryAllChildrenDistTest() {
		System.out.println(tmNewDistrictService.queryAllChildrenDist(""));
		System.out.println(tmNewDistrictService.queryAllChildrenDist("A440000000"));
	}
	
	@Test
	public void queryTmNewDistrictByDistCodeTest() {
		System.out.println(tmNewDistrictService.queryTmNewDistrictByDistCode(""));
	}
	
	@Test
	public void queryTmNewDistrictByIdTest() {
		System.out.println(tmNewDistrictService.queryTmNewDistrictById(null));
		System.out.println(tmNewDistrictService.queryTmNewDistrictById(new Long(32116)));
	}
	
	
	
	
}
