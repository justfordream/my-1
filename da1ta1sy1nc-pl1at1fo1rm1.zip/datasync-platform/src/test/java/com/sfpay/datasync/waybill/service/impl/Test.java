package com.sfpay.datasync.waybill.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.Holder;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

import com.sf.module.esb.util.SftpTools;
import com.sf.sftp.core.GetSftpServerInfoService;
import com.sf.sftp.core.infoBean.SftpServerInfoBean;
import com.sf.sftp.core.util.SftpServerInfoAnalyzeUtil;
import com.sfpay.datasync.sap.service.bigfileservice.BigFileServicePortType;
import com.sfpay.datasync.sap.service.bigfileservice.EsbSoapHeaderType;
import com.sfpay.datasync.sap.service.bigfileservice.SBODYType2;


public class Test {
	private Test() {
	}

	public static void main(String args[]) throws Exception {
		 @SuppressWarnings("unused")
		SftpServerInfoBean sftpServerInfo = GetSftpServerInfoService.getSftpServerInfoByTcp("10.0.44.31","10001", "requestSftpInfo");
		
		JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
		factory.setServiceClass(BigFileServicePortType.class);
		factory.setAddress("http://10.79.11.156:9097/datasync-platform/ws/BigFileService");

		BigFileServicePortType hw = (BigFileServicePortType) factory.create(); 

		com.sfpay.datasync.sap.service.bigfileservice.SHEADType1 shead = new com.sfpay.datasync.sap.service.bigfileservice.SHEADType1();
		com.sfpay.datasync.sap.service.bigfileservice.SBODYType2 sbody = new SBODYType2();
		com.sfpay.datasync.sap.service.bigfileservice.EsbSoapHeaderType esbSoapHeader1 = new EsbSoapHeaderType();
		shead.setTRANMODE("0");
		sbody.setDataType("PMP_EPIEMP_ONE");
		sbody.setFilePath("20150120/PMP/PMP_EPIEMP_ONE");
		sbody.setFileName("1421745394170_PMP_EPIEMP_ONE.zip");
		sbody.setIsZip("true");
		
		javax.xml.ws.Holder<com.sfpay.datasync.sap.service.bigfileservice.SHEADType3> shead1 = new Holder<com.sfpay.datasync.sap.service.bigfileservice.SHEADType3>();
		javax.xml.ws.Holder<com.sfpay.datasync.sap.service.bigfileservice.SBODYType5> sbody1 = new Holder<com.sfpay.datasync.sap.service.bigfileservice.SBODYType5>();
		javax.xml.ws.Holder<com.sfpay.datasync.sap.service.bigfileservice.EsbSoapHeaderType> esbSoapHeader2 = new Holder<com.sfpay.datasync.sap.service.bigfileservice.EsbSoapHeaderType>();
	
		hw.bigFileService(shead, sbody, esbSoapHeader1, shead1, sbody1, esbSoapHeader2);
		System.out.println("over");
	
	}
}
