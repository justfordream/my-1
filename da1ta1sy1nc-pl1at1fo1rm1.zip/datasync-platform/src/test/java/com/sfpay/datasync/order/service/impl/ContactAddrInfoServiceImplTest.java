/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.datasync.order.dao.IContactAddrInfoDao;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.enums.AddressType;
import com.sfpay.datasync.order.enums.DefaultFlag;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 * 
 * 类描述：
 * 
 * @author 625288 易振强 2014-11-24
 */
public class ContactAddrInfoServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IContactAddrInfoService contactAddrInfoService;

	@Test
	public void addContactAddrInfoTest() {
		try {
			ContactAddrInfo contactAddrInfo = null;
			contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
		} catch (Exception e) {
		}

		ContactAddrInfo contactAddrInfo = new ContactAddrInfo();
		contactAddrInfo.setMemberNo(20799989991969L);
		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.SENDER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		try {
			contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
			ContactAddrInfo info = contactAddrInfoService.queryContactAddrInfoById(contactAddrInfo.getId());
			System.out.println("创建日期:" + info.getCreateTime());
			System.out.println("更新日期:" + info.getUpdateTime());
		} catch (ServiceException e) {
			e.printStackTrace();
		}

		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.NOTDEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.SENDER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		try {
			contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
		} catch (ServiceException e) {
			e.printStackTrace();
		}

		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.RECEIVER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		try {
			contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
		} catch (ServiceException e) {
			e.printStackTrace();
		}

		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.NOTDEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.RECEIVER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		try {
			contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
		} catch (ServiceException e) {
			e.printStackTrace();
		}

		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A43000000011");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.NOTDEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.RECEIVER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		try {
			contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void delContactAddrInfoTest() {
		ContactAddrInfo contactAddrInfo = new ContactAddrInfo();
		contactAddrInfo.setMemberNo(20799989991969L);
		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.SENDER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		Long id = null;
		try {
			id = contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
		} catch (ServiceException e) {
			e.printStackTrace();
		}

		try {
			if (id != null)
				contactAddrInfoService.delContactAddrInfo(id);
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.delContactAddrInfo(123l);
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.delContactAddrInfo(null);
		} catch (ServiceException e) {
		}
		
		try {
			contactAddrInfoService.delContactAddrInfo(null, null);
		} catch (ServiceException e) {
		}
		
		try {
			contactAddrInfoService.delContactAddrInfo(123l, null);
		} catch (ServiceException e) {
		}
		
		
		ContactAddrInfo info = new ContactAddrInfo();
		info.setMemberNo(20799989991969L);
		info.setCustTag("13012312312");
		info.setDistCityCode("020");
		info.setProvinceCode("A430000000");
		info.setCityCode("A430200000");
		info.setCountyCode("A430204000");
		info.setAddress("响石四村15棟701号");
		info.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		info.setAddressType(AddressType.SENDER.toString());
		info.setContacts("美女");
		info.setTelphoneNo("13012312312");
		info.setCompany("sdf");
		info.setCustTag("sdfsdf");
		info.setTeamId("123123");
		
		try {
			contactAddrInfoService.addContactAddrInfo(info);
			contactAddrInfoService.delContactAddrInfo(info.getId(), null);
		} catch (ServiceException e) {
		}
		
		long id1, id2;
		try {
			contactAddrInfoService.addContactAddrInfo(info);
			id1 = info.getId();
			contactAddrInfoService.delContactAddrInfo(id1, 123l);
		} catch (ServiceException e) {
		}
		
		try {
			contactAddrInfoService.addContactAddrInfo(info);
			id1 = info.getId();
			info.setDefaultFlag("0");
			contactAddrInfoService.addContactAddrInfo(info);
			id2 = info.getId();
			contactAddrInfoService.delContactAddrInfo(id1, id2);
		} catch (ServiceException e) {
		}
	}

	@Test
	public void updateAddressInfoTest() {
		try {
			ContactAddrInfo contactAddrInfo = null;
			contactAddrInfoService.updateAddressInfo(contactAddrInfo);
		} catch (Exception e) {
			System.out.println(e.toString());
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("2234");
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("2234");
			test1.setId(183);
			test1.setMemberNo(new Long(123323));
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("2234");
			test1.setId(183);
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("A610700F09");
			test1.setId(183);
			test1.setProvinceCode("A610700F09");
			test1.setCountyCode("2234");
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("2234");
			test1.setId(183);
			test1.setProvinceCode("A610000000");
			test1.setCountyCode("2234");
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("A000820000");
			test1.setId(183);
			test1.setProvinceCode("A000820000");
			test1.setCountyCode("2234");
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("A61070000Q");
			test1.setId(183);
			test1.setProvinceCode("A610702018");
			test1.setCountyCode("2234");
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo test1 = new ContactAddrInfo();
			test1.setCityCode("A61070000Q");
			test1.setId(183);
			test1.setProvinceCode("A610702018");
			test1.setCountyCode("A000086000");
			contactAddrInfoService.updateAddressInfo(test1);
		} catch (Exception e) {
		}

		ContactAddrInfo contactAddrInfo = new ContactAddrInfo();
		contactAddrInfo.setId(137l);
		contactAddrInfo.setMemberNo(123123l);
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCustTag("汤圆");
		contactAddrInfo.setContacts("ab");
		contactAddrInfo.setTelphoneNo("12312312312");
		contactAddrInfo.setAddress("222222");
		try {
			contactAddrInfoService.updateAddressInfo(contactAddrInfo);
		} catch (ServiceException e) {
			System.out.println(e);
		}
		System.out.println(contactAddrInfoService.queryContactAddrInfoById(22l));
		
		ContactAddrInfo info = new ContactAddrInfo();
		info.setMemberNo(20799989991969L);
		info.setCustTag("13012312312");
		info.setDistCityCode("020");
		info.setProvinceCode("A430000000");
		info.setCityCode("A430200000");
		info.setCountyCode("A430204000");
		info.setAddress("响石四村15棟701号");
		info.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		info.setAddressType(AddressType.SENDER.toString());
		info.setContacts("美女");
		info.setTelphoneNo("13012312312");
		info.setCompany("sdf");
		info.setCustTag("sdfsdf");
		info.setTeamId("123123");
		
		try {
			long id = contactAddrInfoService.addContactAddrInfo(info);
			info.setId(id);
			
			ContactAddrInfo queryInfo = contactAddrInfoService.queryContactAddrInfoById(id);
			info.setTeamId(null);
			
			contactAddrInfoService.updateAddressInfo(info);
			
			queryInfo = contactAddrInfoService.queryContactAddrInfoById(id);
			System.out.println(queryInfo);
		} catch(ServiceException e) {
			System.out.println(e);
		}

	}

	@Test
	public void queryAddressInfoTest() {
		contactAddrInfoService.queryAddressInfo(20799989991969l, AddressType.RECEIVER.toString());
		contactAddrInfoService.queryAddressInfo(20799989991969l, AddressType.SENDER.toString());
		try {
			contactAddrInfoService.queryAddressInfo(null, AddressType.SENDER.toString());
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.queryAddressInfo(123l, "");
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.queryAddressInfo(123l, "123");
		} catch (ServiceException e) {
		}
	}

	@Test
	public void setDefaultAddressInfoTest() {
		ContactAddrInfo contactAddrInfo = new ContactAddrInfo();
		contactAddrInfo.setMemberNo(20799989991969L);
		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.SENDER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		Long id = null;
		try {
			id = contactAddrInfoService.addContactAddrInfo(contactAddrInfo);
		} catch (ServiceException e) {
			e.printStackTrace();
		}

		try {
			contactAddrInfoService.setDefaultAddressInfo(id);
		} catch (ServiceException e) {
		}

		contactAddrInfo.setDefaultFlag("0");
		try {
			contactAddrInfoService.setDefaultAddressInfo(id);
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.setDefaultAddressInfo(null);
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.setDefaultAddressInfo(0l);
		} catch (ServiceException e) {
		}
		
		try {
			contactAddrInfoService.setDefaultAddressInfo(new Long(182));
		} catch (ServiceException e) {
		}
	}

	@Test
	public void queryDefaultAddressTest() {
		contactAddrInfoService.queryDefaultAddress(20799989991969l, AddressType.RECEIVER.toString());

		try {
			contactAddrInfoService.queryDefaultAddress(null, AddressType.RECEIVER.toString());
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.queryDefaultAddress(123l, null);
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.queryDefaultAddress(123l, "REC");
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.queryDefaultAddress(123l, AddressType.RECEIVER.toString());
		} catch (ServiceException e) {
		}

		try {
			contactAddrInfoService.queryDefaultAddress(123l, AddressType.SENDER.toString());
		} catch (ServiceException e) {
		}
		
		List<ContactAddrInfo> conInfoList = new ArrayList<ContactAddrInfo>();
		MockCurrentResult.setMockValue(IContactAddrInfoDao.class, "queryAddressInfoByParam",conInfoList);
		contactAddrInfoService.queryDefaultAddress(123l, AddressType.SENDER.toString());
		MockCurrentResult.removeMockValue(IContactAddrInfoDao.class, "queryAddressInfoByParam");
		conInfoList.add(new ContactAddrInfo());
		conInfoList.add(new ContactAddrInfo());
		MockCurrentResult.setMockValue(IContactAddrInfoDao.class, "queryAddressInfoByParam",conInfoList);
		contactAddrInfoService.queryDefaultAddress(123l, AddressType.SENDER.toString());
		

	}

	@Test
	public void queryContactAddrInfoByIdTest() {
		try {
			contactAddrInfoService.queryContactAddrInfoById(null);
		} catch (Exception e) {
		}
		contactAddrInfoService.queryContactAddrInfoById(23l);
	}

	@Test
	public void queryAddressInfoByParamTest() {
		try {
			ContactAddrInfo contactAddrInfo = null;
			contactAddrInfoService.queryAddressInfoByParam(contactAddrInfo);
		} catch (Exception e) {
		}

		try {
			ContactAddrInfo contactAddrInfo = new ContactAddrInfo();
			contactAddrInfo.setMemberNo(20799989991969l);
			contactAddrInfo.setAddressType(AddressType.RECEIVER.toString());
			contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
			contactAddrInfoService.queryAddressInfoByParam(contactAddrInfo);
		} catch (Exception e) {
		}
		
		try {
			ContactAddrInfo info = new ContactAddrInfo();
			info.setAddress("哦啦都看了结局");
			info.setDistCityCode("010");
			contactAddrInfoService.queryAddressInfoByParam(info);
		} catch (Exception e) {
		}

	}

}
