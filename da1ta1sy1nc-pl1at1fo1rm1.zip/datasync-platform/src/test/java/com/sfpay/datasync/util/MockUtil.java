package com.sfpay.datasync.util;

import org.springframework.test.mock.MockCurrentResult;
import org.springframework.test.mock.MockKey;
import org.springframework.test.mock.MockValue;


public class MockUtil {
	
	public static void mock(String serviceInterface,String methodName,Object valueObject,Throwable throwable){
		MockValue value = new MockValue();
		MockKey key = new MockKey();
		key.setServiceInterface(serviceInterface);
		key.setMethodName(methodName);
		value.setValue(valueObject);
		value.setThrowable(throwable);
		MockCurrentResult.setValue(key, value);
	}

}
