/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.caucho.hessian.client.HessianProxyFactory;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.domain.ExpressOrder;
import com.sfpay.datasync.order.enums.AddressType;
import com.sfpay.datasync.order.enums.DefaultFlag;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.datasync.order.service.IExpressOrderService;
import com.sfpay.datasync.util.MockUtil;
import com.sfpay.datasync.waybill.domain.WayBillRoute;
import com.sfpay.datasync.waybill.domain.WaybillBarInfo;
import com.sfpay.datasync.waybill.service.IWayBillRouteService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.mock.MockKey;
import com.sfpay.framework.test.mock.MockValue;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：
 *
 * 类描述：
 * @author 625288 易振强
 * 2014-12-1
 */
public class ExpressOrderServiceImplTest extends ClassTransactionalTestCase {
	@Autowired
	private IExpressOrderService expressOrderService;
	@Autowired
	private IContactAddrInfoService contactAddrInfoService;
	
	@Test
	public void addExpressOrderTest() {
		try {
			expressOrderService.addExpressOrder(null);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		ExpressOrder expressOrder = new ExpressOrder();
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		expressOrder.setMemberNo(20197949991999l);
		
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		expressOrder.setSenderAddrId(32l);
		
		MockValue value = new MockValue();
		value.setValue("1");
		MockKey key = new MockKey();
		key.setServiceInterface("com.sfpay.datasync.order.webservice.IOrderService");
		key.setMethodName("orderNew2");
		MockCurrentResult.setValue(key, value);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		expressOrder.setSenderAddrId(131l);
		MockUtil.mock("com.sfpay.datasync.order.webservice.IOrderService", "orderNew2", "1", null);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		expressOrder.setSenderAddrId(132l);
		MockUtil.mock("com.sfpay.datasync.order.webservice.IOrderService", "orderNew2", "1", null);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		expressOrder.setSenderAddrId(133l);
		MockUtil.mock("com.sfpay.datasync.order.webservice.IOrderService", "orderNew2", "1", null);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		expressOrder.setSenderAddrId(134l);
		MockUtil.mock("com.sfpay.datasync.order.webservice.IOrderService", "orderNew2", "1", null);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e2) {
			e2.printStackTrace();
		}
		
		expressOrder.setRecAddrId(205l);
		expressOrder.setSenderAddrId(105l);
		MockValue value1 = new MockValue();
		value1.setValue("1");
		MockKey key1 = new MockKey();
		key1.setServiceInterface("com.sfpay.datasync.order.webservice.IOrderService");
		key1.setMethodName("orderNew2");
		MockCurrentResult.setValue(key1, value1);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e1) {
			e1.printStackTrace();
		}
		
		expressOrder.setRecAddrId(151l);
		expressOrder.setSenderAddrId(105l);
		MockUtil.mock("com.sfpay.datasync.order.webservice.IOrderService", "orderNew2", "1", null);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e1) {
			e1.printStackTrace();
		}
		
		expressOrder.setRecAddrId(152l);
		expressOrder.setSenderAddrId(105l);
		MockUtil.mock("com.sfpay.datasync.order.webservice.IOrderService", "orderNew2", "1", null);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e1) {
			e1.printStackTrace();
		}
		
		expressOrder.setRecAddrId(153l);
		expressOrder.setSenderAddrId(105l);
		MockUtil.mock("com.sfpay.datasync.order.webservice.IOrderService", "orderNew2", "1", null);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e1) {
			e1.printStackTrace();
		}
		
		expressOrder.setRecAddrId(141l);
		expressOrder.setSenderAddrId(-1l);
		MockValue value12 = new MockValue();
		value12.setValue("1");
		MockKey key12 = new MockKey();
		key12.setServiceInterface("com.sfpay.datasync.order.webservice.IOrderService");
		key12.setMethodName("orderNew2");
		MockCurrentResult.setValue(key12, value12);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e1) {
			e1.printStackTrace();
		}
		
		ContactAddrInfo contactAddrInfo = new ContactAddrInfo();
		contactAddrInfo.setMemberNo(20799989991969L);
		contactAddrInfo.setCustTag("13012312312");
		contactAddrInfo.setDistCityCode("020");
		contactAddrInfo.setProvinceCode("A430000000");
		contactAddrInfo.setCityCode("A430200000");
		contactAddrInfo.setCountyCode("A430204000");
		contactAddrInfo.setAddress("响石四村15棟701号");
		contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		contactAddrInfo.setAddressType(AddressType.SENDER.toString());
		contactAddrInfo.setContacts("美女");
		contactAddrInfo.setTelphoneNo("13012312312");
		contactAddrInfo.setCompany("sdf");
		contactAddrInfo.setCustTag("sdfsdf");
		contactAddrInfo.setTeamId("123123");
		try {
			expressOrder.setSenderAddrId(contactAddrInfoService.addContactAddrInfo(contactAddrInfo));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		MockValue value123 = new MockValue();
		value12.setValue("1");
		MockKey key123 = new MockKey();
		key123.setServiceInterface("com.sfpay.datasync.order.webservice.IOrderService");
		key123.setMethodName("orderNew2");
		MockCurrentResult.setValue(key123, value123);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e1) {
			e1.printStackTrace();
		}
		
		expressOrder.setAreaNo("111");
		expressOrder.setDeptId("111");
		expressOrder.setTeamId("111");
		expressOrder.setCustId("111");
		expressOrder.setCustType("111");
		expressOrder.setCustType("111");
		expressOrder.setContact("111");
		expressOrder.setCompAbb("111");
		expressOrder.setProvinceName("111");
		expressOrder.setCityName("111");
		expressOrder.setCountyName("111");
		expressOrder.setAddrAbb("111");
		expressOrder.setCustTel("111");
		expressOrder.setWeight(123d);
		expressOrder.setLength(123d);
		expressOrder.setCargoType("111");
		expressOrder.setCargoName("111");
		expressOrder.setBookTime("1201");
		expressOrder.setOrderType("52");
		expressOrder.setMakeup("111");
		expressOrder.setMemo("111");
		expressOrder.setOperator("111");
		expressOrder.setAddressNo("111");
		expressOrder.setCustTag("111");
		expressOrder.setSenderType("111");
		expressOrder.setDcontanct("111");
		expressOrder.setDtel("111");
		expressOrder.setDcompany("111");
		expressOrder.setDaddress("111");
		expressOrder.setCargoNumber(111l);
		expressOrder.setCargoPiece(111l);
		expressOrder.setInsuranceAmount(111d);
		expressOrder.setPayMethod("111");
		expressOrder.setDestinationCode("111");
		expressOrder.setMonthPayCustId("1");
		expressOrder.setIsHhtWayBill("111");
		expressOrder.setIsClaims("Y");
		expressOrder.setBlackType("0");
		expressOrder.setCurrencyValue("RMB");
		expressOrder.setDestination("111");
		expressOrder.setCouponsVerificationCode("111");
		expressOrder.setCouponsNo("111");
		expressOrder.setCouponsAmount(111d);
		
		MockValue value2 = new MockValue();
		value2.setValue("1");
		MockKey key2 = new MockKey();
		key2.setServiceInterface("com.sfpay.datasync.order.webservice.IOrderService");
		key2.setMethodName("orderNew2");
		MockCurrentResult.setValue(key2, value2);
		try {
			expressOrderService.addExpressOrder(expressOrder);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryExpressRecordByWayBillNoTest() {
		try {
			System.out.println(expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" )));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			expressOrderService.queryExpressRecordByWayBillNo(null);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		MockUtil.mock("com.sfpay.datasync.waybill.service.IWayBillRouteService", "queryBillStandard", "1", new Exception());
		try {
			expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" ));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			System.out.println(expressOrderService.queryExpressRecordByWayBillNo(new ArrayList<String>()));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			MockValue value2 = new MockValue();
			value2.setThrowable(new Exception());
			MockKey key2 = new MockKey();
			key2.setServiceInterface("com.sfpay.datasync.waybill.service.IWayBillRouteService");
			key2.setMethodName("queryBillStandard");
			MockCurrentResult.setValue(key2, value2);
			expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" ));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			MockCurrentResult.setMockValue(IWayBillRouteService.class, "queryBillStandard", new ArrayList<WayBillRoute>());
			expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" ));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			MockCurrentResult.removeMockValue(IWayBillRouteService.class, "queryBillStandard");
			MockCurrentResult.setMockValue(IWayBillRouteService.class, "queryBillStandard", null);
			expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" ));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			MockCurrentResult.removeMockValue(IWayBillRouteService.class, "queryBillStandard");
			List<WayBillRoute> result = new ArrayList<WayBillRoute>();
			WayBillRoute route = new WayBillRoute();
			route.setSendTm("0845");
			WaybillBarInfo waybillBarInfo = new WaybillBarInfo();
			waybillBarInfo.setBarScanDt("2014-05-05");
			waybillBarInfo.setBarScanTm("14:45:12");
			waybillBarInfo.setOpCode("80");
			route.setBarList(Arrays.asList(waybillBarInfo));
			result.add(route);
			MockCurrentResult.setMockValue(IWayBillRouteService.class, "queryBillStandard", result);
			expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" ));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			MockCurrentResult.removeMockValue(IWayBillRouteService.class, "queryBillStandard");
			List<WayBillRoute> result = new ArrayList<WayBillRoute>();
			WayBillRoute route = new WayBillRoute();
			route.setSendTm("0845");
			WaybillBarInfo waybillBarInfo = new WaybillBarInfo();
			waybillBarInfo.setBarScanDt("2014-05-05");
			waybillBarInfo.setBarScanTm("14:45:12");
			waybillBarInfo.setOpCode("8000");
			route.setBarList(Arrays.asList(waybillBarInfo));
			result.add(route);
			MockCurrentResult.setMockValue(IWayBillRouteService.class, "queryBillStandard", result);
			expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" ));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		try {
			MockCurrentResult.removeMockValue(IWayBillRouteService.class, "queryBillStandard");
			List<WayBillRoute> result = new ArrayList<WayBillRoute>();
			WayBillRoute route = new WayBillRoute();
			route.setSendTm("0845");
			WaybillBarInfo waybillBarInfo = new WaybillBarInfo();
			waybillBarInfo.setOpCode("8000");
			route.setBarList(Arrays.asList(waybillBarInfo));
			result.add(route);
			MockCurrentResult.setMockValue(IWayBillRouteService.class, "queryBillStandard", result);
			expressOrderService.queryExpressRecordByWayBillNo(Arrays.asList("555242497028" ));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void queryExpressOrderByIdTest() {
		System.out.println(expressOrderService.queryExpressOrderById(null));
		System.out.println(expressOrderService.queryExpressOrderById(180l));
	}
	
	@Test
	public void queryExpressOrderByOrderIdTest() {
		System.out.println(expressOrderService.queryExpressOrderByOrderId(null));
		System.out.println(expressOrderService.queryExpressOrderByOrderId("DATASYNC2014120516110700000007"));
	}
	
	@Test
	public void expressOrderTest() {
		HessianProxyFactory factory = new HessianProxyFactory();
		try {
			IExpressOrderService service = (IExpressOrderService) factory.create(IExpressOrderService.class, 
					"http://10.79.11.156:9097/datasync-platform/hessian/mobile/expressOrderService");
			
			ExpressOrder expressOrder = new ExpressOrder();
			expressOrder.setMemberNo(20197949991999l);
			expressOrder.setSenderAddrId(139l);
			expressOrder.setAreaNo("111");
			expressOrder.setDeptId("111");
			expressOrder.setTeamId("111");
			expressOrder.setCustId("111");
			expressOrder.setCustType("111");
			expressOrder.setCustType("111");
			expressOrder.setContact("111");
			expressOrder.setCompAbb("111");
			expressOrder.setProvinceName("111");
			expressOrder.setCityName("111");
			expressOrder.setCountyName("111");
			expressOrder.setAddrAbb("111");
			expressOrder.setCustTel("111");
			expressOrder.setWeight(123d);
			expressOrder.setLength(123d);
			expressOrder.setCargoType("111");
			expressOrder.setCargoName("111");
			expressOrder.setBookTime("1201");
			expressOrder.setOrderType("52");
			expressOrder.setMakeup("111");
			expressOrder.setMemo("111");
			expressOrder.setOperator("111");
			expressOrder.setAddressNo("111");
			expressOrder.setCustTag("111");
			expressOrder.setSenderType("111");
			expressOrder.setDcontanct("111");
			expressOrder.setDtel("111");
			expressOrder.setDcompany("111");
			expressOrder.setDaddress("111");
			expressOrder.setCargoNumber(111l);
			expressOrder.setCargoPiece(111l);
			expressOrder.setInsuranceAmount(111d);
			expressOrder.setPayMethod("111");
			expressOrder.setDestinationCode("111");
			expressOrder.setMonthPayCustId("1");
			expressOrder.setIsHhtWayBill("111");
			expressOrder.setIsClaims("Y");
			expressOrder.setBlackType("0");
			expressOrder.setCurrencyValue("RMB");
			expressOrder.setDestination("111");
			expressOrder.setCouponsVerificationCode("111");
			expressOrder.setCouponsNo("111");
			expressOrder.setCouponsAmount(111d);
			service.addExpressOrder(expressOrder);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	
	
	
}
