/**
 * 包名：com.sf.webservice.esb.server.biz
 * 文件名：Notify.java
 * 版本信息：
 * 日期：2014-8-27-下午4:19:08
 * 
 */
package com.sfpay.datasync.sap.service.impl;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sf.module.esb.biz.INotify;
//import com.sfpay.datasync.sap.enums.Subject;
//import com.sfpay.datasync.sap.service.ISapEmpSyncDataAppService;
//import com.sfpay.organ.service.IOrgAccountService;

/**
 * 类名称：Notify
 * 类描述：
 * 创建人：313920 熊伟
 * 修改人：313920 熊伟
 * 修改时间：2014-8-27 下午4:19:08
 * 修改备注：
 * @version 2.0.1
 * 
 */
public class NotifyServiceImpl implements INotify {
	// 主题类型
	private String subject;
	
//	private IOrgAccountService orgAccountService;
//	private ISapEmpSyncDataAppService sapEmpSyncDataAppService;
	
	private static final Logger logger = LoggerFactory.getLogger(NotifyServiceImpl.class);
	
	public NotifyServiceImpl(String subject){
		this.subject = subject;
	}

	@Override
	public void success() {
		logger.info(String.format("success start 主题:%s ... ...", subject));
	/*	try {
			if(Subject.SAPFICORP.toString().equals(subject)) {
				logger.info(String.format("success 牌照主题，开始准备进行牌照数据同步:%s", subject));
				orgAccountService.synOrgAccountInfoFromSapfiCorp();
				logger.info(String.format("success 牌照主题，end:%s", subject));
				
			} else if(Subject.HCMOUTEMPSEC.toString().equals(subject)) {
				logger.info(String.format("success 人资主题，开始准备进行人资数据同步:%s", subject));
				sapEmpSyncDataAppService.appSapEmpSyncData();
				logger.info(String.format("success 人资主题，end:%s", subject));
			} else {
				logger.info(String.format("success 除了牌照和人资主题，其他主题占不用做处理:%s", subject));
			}
		} catch (Exception e) {
			logger.error("success 通知调用处理异常！", e);
		}*/
		
		logger.info(String.format("success end:%s", subject));
	}

	@Override
	public void warnning(String arg0) {
		logger.warn(String.format("warnning:%s ... ...", arg0));
	}

/*	public void setOrgAccountService(IOrgAccountService orgAccountService) {
		this.orgAccountService = orgAccountService;
	}

	public void setSapEmpSyncDataAppService(
			ISapEmpSyncDataAppService sapEmpSyncDataAppService) {
		this.sapEmpSyncDataAppService = sapEmpSyncDataAppService;
	}*/
}
