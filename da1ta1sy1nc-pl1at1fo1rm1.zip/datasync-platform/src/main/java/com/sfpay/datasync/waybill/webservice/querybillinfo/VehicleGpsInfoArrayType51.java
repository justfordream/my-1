
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>vehicleGpsInfoArrayType_51 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="vehicleGpsInfoArrayType_51">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}arriveTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}conveyanceType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}departTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}destZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}planArriveZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}srcZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}vehicleId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}vehicleNo" minOccurs="0"/>
 *         &lt;element name="descZoneCodeGps" type="{http://www.sf-express.com/esb/service/QueryBillInfo}descZoneCodeGpsArrayType_50" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="srcZoneCodeGps" type="{http://www.sf-express.com/esb/service/QueryBillInfo}srcZoneCodeArrayType_53" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="gps" type="{http://www.sf-express.com/esb/service/QueryBillInfo}gpsArrayType_54" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "vehicleGpsInfoArrayType_51", propOrder = {
    "arriveTm",
    "conveyanceType",
    "departTm",
    "destZoneCode",
    "planArriveZoneCode",
    "srcZoneCode",
    "vehicleId",
    "vehicleNo",
    "descZoneCodeGps",
    "srcZoneCodeGps",
    "gps"
})
public class VehicleGpsInfoArrayType51 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar arriveTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String conveyanceType;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar departTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String destZoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String planArriveZoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String srcZoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String vehicleId;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String vehicleNo;
    @XmlElement(nillable = true)
    protected List<DescZoneCodeGpsArrayType50> descZoneCodeGps;
    @XmlElement(nillable = true)
    protected List<SrcZoneCodeArrayType53> srcZoneCodeGps;
    @XmlElement(nillable = true)
    protected List<GpsArrayType54> gps;

    /**
     * ��ȡarriveTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getArriveTm() {
        return arriveTm;
    }

    /**
     * ����arriveTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setArriveTm(XMLGregorianCalendar value) {
        this.arriveTm = value;
    }

    /**
     * ��ȡconveyanceType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConveyanceType() {
        return conveyanceType;
    }

    /**
     * ����conveyanceType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConveyanceType(String value) {
        this.conveyanceType = value;
    }

    /**
     * ��ȡdepartTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDepartTm() {
        return departTm;
    }

    /**
     * ����departTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setDepartTm(XMLGregorianCalendar value) {
        this.departTm = value;
    }

    /**
     * ��ȡdestZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestZoneCode() {
        return destZoneCode;
    }

    /**
     * ����destZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestZoneCode(String value) {
        this.destZoneCode = value;
    }

    /**
     * ��ȡplanArriveZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlanArriveZoneCode() {
        return planArriveZoneCode;
    }

    /**
     * ����planArriveZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlanArriveZoneCode(String value) {
        this.planArriveZoneCode = value;
    }

    /**
     * ��ȡsrcZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcZoneCode() {
        return srcZoneCode;
    }

    /**
     * ����srcZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcZoneCode(String value) {
        this.srcZoneCode = value;
    }

    /**
     * ��ȡvehicleId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleId() {
        return vehicleId;
    }

    /**
     * ����vehicleId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleId(String value) {
        this.vehicleId = value;
    }

    /**
     * ��ȡvehicleNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleNo() {
        return vehicleNo;
    }

    /**
     * ����vehicleNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleNo(String value) {
        this.vehicleNo = value;
    }

    /**
     * Gets the value of the descZoneCodeGps property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the descZoneCodeGps property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDescZoneCodeGps().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DescZoneCodeGpsArrayType50 }
     * 
     * 
     */
    public List<DescZoneCodeGpsArrayType50> getDescZoneCodeGps() {
        if (descZoneCodeGps == null) {
            descZoneCodeGps = new ArrayList<DescZoneCodeGpsArrayType50>();
        }
        return this.descZoneCodeGps;
    }

    /**
     * Gets the value of the srcZoneCodeGps property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the srcZoneCodeGps property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSrcZoneCodeGps().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SrcZoneCodeArrayType53 }
     * 
     * 
     */
    public List<SrcZoneCodeArrayType53> getSrcZoneCodeGps() {
        if (srcZoneCodeGps == null) {
            srcZoneCodeGps = new ArrayList<SrcZoneCodeArrayType53>();
        }
        return this.srcZoneCodeGps;
    }

    /**
     * Gets the value of the gps property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the gps property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGps().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GpsArrayType54 }
     * 
     * 
     */
    public List<GpsArrayType54> getGps() {
        if (gps == null) {
            gps = new ArrayList<GpsArrayType54>();
        }
        return this.gps;
    }

}
