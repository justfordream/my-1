
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>waybillListArrayType_17 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="waybillListArrayType_17">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}desCity" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}desCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}srcCity" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}srcCityName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}srcCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}telNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}desCityName" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "waybillListArrayType_17", propOrder = {
    "desCity",
    "desCode",
    "receDt",
    "receTm",
    "srcCity",
    "srcCityName",
    "srcCode",
    "telNo",
    "waybillNo",
    "desCityName"
})
public class WaybillListArrayType17 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String desCity;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String desCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receDt;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String srcCity;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String srcCityName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String srcCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String telNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String waybillNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String desCityName;

    /**
     * ��ȡdesCity���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesCity() {
        return desCity;
    }

    /**
     * ����desCity���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesCity(String value) {
        this.desCity = value;
    }

    /**
     * ��ȡdesCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesCode() {
        return desCode;
    }

    /**
     * ����desCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesCode(String value) {
        this.desCode = value;
    }

    /**
     * ��ȡreceDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceDt() {
        return receDt;
    }

    /**
     * ����receDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceDt(String value) {
        this.receDt = value;
    }

    /**
     * ��ȡreceTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceTm() {
        return receTm;
    }

    /**
     * ����receTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceTm(XMLGregorianCalendar value) {
        this.receTm = value;
    }

    /**
     * ��ȡsrcCity���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcCity() {
        return srcCity;
    }

    /**
     * ����srcCity���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcCity(String value) {
        this.srcCity = value;
    }

    /**
     * ��ȡsrcCityName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcCityName() {
        return srcCityName;
    }

    /**
     * ����srcCityName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcCityName(String value) {
        this.srcCityName = value;
    }

    /**
     * ��ȡsrcCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcCode() {
        return srcCode;
    }

    /**
     * ����srcCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcCode(String value) {
        this.srcCode = value;
    }

    /**
     * ��ȡtelNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelNo() {
        return telNo;
    }

    /**
     * ����telNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelNo(String value) {
        this.telNo = value;
    }

    /**
     * ��ȡwaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaybillNo() {
        return waybillNo;
    }

    /**
     * ����waybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaybillNo(String value) {
        this.waybillNo = value;
    }

    /**
     * ��ȡdesCityName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesCityName() {
        return desCityName;
    }

    /**
     * ����desCityName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesCityName(String value) {
        this.desCityName = value;
    }

}
