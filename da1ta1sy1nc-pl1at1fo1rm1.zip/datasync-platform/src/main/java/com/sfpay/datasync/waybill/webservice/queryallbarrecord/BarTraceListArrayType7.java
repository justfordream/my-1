
package com.sfpay.datasync.waybill.webservice.queryallbarrecord;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>barTraceListArrayType_7 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="barTraceListArrayType_7">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}oprCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}outsideName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}payFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}phoneZone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}planTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}routeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sapDestZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sapDestZoneName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sourceScanTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}stayWhyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}stayWhyName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}stayWhyNameEn" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}uploadTypeInputty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}vehiclePlate" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}weightQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneGmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}accountantCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}autoloading" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barScanTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barScanTmStd" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barUploadTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barUploadTmStd" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}cityName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}contnrCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}convienienceCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}convienienceStore" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}courierCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}deliverConfirm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}deliverDateStr" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}destZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}destZoneName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}distName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}distScanTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}empMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}exceptionCause" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}exceptionState" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}extendAttach1" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}extendAttach2" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}extendAttach3" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}extendAttach4" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}note" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}objTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}opAttachInfo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}opCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}opName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}extendAttach5" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}fromOmpflg" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "barTraceListArrayType_7", propOrder = {
    "oprCode",
    "outsideName",
    "payFlg",
    "phoneZone",
    "planTime",
    "routeCode",
    "sapDestZoneCode",
    "sapDestZoneName",
    "sourceScanTm",
    "stayWhyCode",
    "stayWhyName",
    "stayWhyNameEn",
    "uploadTypeInputty",
    "vehiclePlate",
    "waybillNo",
    "weightQty",
    "zoneCode",
    "zoneGmt",
    "zoneName",
    "accountantCode",
    "autoloading",
    "barScanTm",
    "barScanTmStd",
    "barUploadTm",
    "barUploadTmStd",
    "cityName",
    "contnrCode",
    "convienienceCode",
    "convienienceStore",
    "courierCode",
    "deliverConfirm",
    "deliverDateStr",
    "destZoneCode",
    "destZoneName",
    "distName",
    "distScanTm",
    "empMobile",
    "exceptionCause",
    "exceptionState",
    "extendAttach1",
    "extendAttach2",
    "extendAttach3",
    "extendAttach4",
    "note",
    "objTypeCode",
    "opAttachInfo",
    "opCode",
    "opName",
    "extendAttach5",
    "fromOmpflg"
})
public class BarTraceListArrayType7 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String oprCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String outsideName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String payFlg;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String phoneZone;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar planTime;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String routeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sapDestZoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sapDestZoneName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar sourceScanTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String stayWhyCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String stayWhyName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String stayWhyNameEn;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String uploadTypeInputty;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String vehiclePlate;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String waybillNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double weightQty;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneGmt;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String accountantCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String autoloading;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar barScanTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar barScanTmStd;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar barUploadTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar barUploadTmStd;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String cityName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String contnrCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String convienienceCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String convienienceStore;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String courierCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String deliverConfirm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar deliverDateStr;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String destZoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String destZoneName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String distName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar distScanTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String empMobile;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String exceptionCause;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String exceptionState;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String extendAttach1;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String extendAttach2;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String extendAttach3;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String extendAttach4;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String note;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String objTypeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String opAttachInfo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String opCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String opName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String extendAttach5;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String fromOmpflg;

    /**
     * ��ȡoprCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOprCode() {
        return oprCode;
    }

    /**
     * ����oprCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOprCode(String value) {
        this.oprCode = value;
    }

    /**
     * ��ȡoutsideName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutsideName() {
        return outsideName;
    }

    /**
     * ����outsideName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutsideName(String value) {
        this.outsideName = value;
    }

    /**
     * ��ȡpayFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayFlg() {
        return payFlg;
    }

    /**
     * ����payFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayFlg(String value) {
        this.payFlg = value;
    }

    /**
     * ��ȡphoneZone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneZone() {
        return phoneZone;
    }

    /**
     * ����phoneZone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneZone(String value) {
        this.phoneZone = value;
    }

    /**
     * ��ȡplanTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPlanTime() {
        return planTime;
    }

    /**
     * ����planTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPlanTime(XMLGregorianCalendar value) {
        this.planTime = value;
    }

    /**
     * ��ȡrouteCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRouteCode() {
        return routeCode;
    }

    /**
     * ����routeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRouteCode(String value) {
        this.routeCode = value;
    }

    /**
     * ��ȡsapDestZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSapDestZoneCode() {
        return sapDestZoneCode;
    }

    /**
     * ����sapDestZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSapDestZoneCode(String value) {
        this.sapDestZoneCode = value;
    }

    /**
     * ��ȡsapDestZoneName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSapDestZoneName() {
        return sapDestZoneName;
    }

    /**
     * ����sapDestZoneName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSapDestZoneName(String value) {
        this.sapDestZoneName = value;
    }

    /**
     * ��ȡsourceScanTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSourceScanTm() {
        return sourceScanTm;
    }

    /**
     * ����sourceScanTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSourceScanTm(XMLGregorianCalendar value) {
        this.sourceScanTm = value;
    }

    /**
     * ��ȡstayWhyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStayWhyCode() {
        return stayWhyCode;
    }

    /**
     * ����stayWhyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStayWhyCode(String value) {
        this.stayWhyCode = value;
    }

    /**
     * ��ȡstayWhyName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStayWhyName() {
        return stayWhyName;
    }

    /**
     * ����stayWhyName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStayWhyName(String value) {
        this.stayWhyName = value;
    }

    /**
     * ��ȡstayWhyNameEn���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStayWhyNameEn() {
        return stayWhyNameEn;
    }

    /**
     * ����stayWhyNameEn���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStayWhyNameEn(String value) {
        this.stayWhyNameEn = value;
    }

    /**
     * ��ȡuploadTypeInputty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUploadTypeInputty() {
        return uploadTypeInputty;
    }

    /**
     * ����uploadTypeInputty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUploadTypeInputty(String value) {
        this.uploadTypeInputty = value;
    }

    /**
     * ��ȡvehiclePlate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehiclePlate() {
        return vehiclePlate;
    }

    /**
     * ����vehiclePlate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehiclePlate(String value) {
        this.vehiclePlate = value;
    }

    /**
     * ��ȡwaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaybillNo() {
        return waybillNo;
    }

    /**
     * ����waybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaybillNo(String value) {
        this.waybillNo = value;
    }

    /**
     * ��ȡweightQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getWeightQty() {
        return weightQty;
    }

    /**
     * ����weightQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setWeightQty(Double value) {
        this.weightQty = value;
    }

    /**
     * ��ȡzoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneCode() {
        return zoneCode;
    }

    /**
     * ����zoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneCode(String value) {
        this.zoneCode = value;
    }

    /**
     * ��ȡzoneGmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneGmt() {
        return zoneGmt;
    }

    /**
     * ����zoneGmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneGmt(String value) {
        this.zoneGmt = value;
    }

    /**
     * ��ȡzoneName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneName() {
        return zoneName;
    }

    /**
     * ����zoneName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneName(String value) {
        this.zoneName = value;
    }

    /**
     * ��ȡaccountantCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountantCode() {
        return accountantCode;
    }

    /**
     * ����accountantCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountantCode(String value) {
        this.accountantCode = value;
    }

    /**
     * ��ȡautoloading���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoloading() {
        return autoloading;
    }

    /**
     * ����autoloading���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoloading(String value) {
        this.autoloading = value;
    }

    /**
     * ��ȡbarScanTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBarScanTm() {
        return barScanTm;
    }

    /**
     * ����barScanTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBarScanTm(XMLGregorianCalendar value) {
        this.barScanTm = value;
    }

    /**
     * ��ȡbarScanTmStd���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBarScanTmStd() {
        return barScanTmStd;
    }

    /**
     * ����barScanTmStd���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBarScanTmStd(XMLGregorianCalendar value) {
        this.barScanTmStd = value;
    }

    /**
     * ��ȡbarUploadTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBarUploadTm() {
        return barUploadTm;
    }

    /**
     * ����barUploadTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBarUploadTm(XMLGregorianCalendar value) {
        this.barUploadTm = value;
    }

    /**
     * ��ȡbarUploadTmStd���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBarUploadTmStd() {
        return barUploadTmStd;
    }

    /**
     * ����barUploadTmStd���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBarUploadTmStd(XMLGregorianCalendar value) {
        this.barUploadTmStd = value;
    }

    /**
     * ��ȡcityName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * ����cityName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    /**
     * ��ȡcontnrCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContnrCode() {
        return contnrCode;
    }

    /**
     * ����contnrCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContnrCode(String value) {
        this.contnrCode = value;
    }

    /**
     * ��ȡconvienienceCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvienienceCode() {
        return convienienceCode;
    }

    /**
     * ����convienienceCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvienienceCode(String value) {
        this.convienienceCode = value;
    }

    /**
     * ��ȡconvienienceStore���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvienienceStore() {
        return convienienceStore;
    }

    /**
     * ����convienienceStore���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvienienceStore(String value) {
        this.convienienceStore = value;
    }

    /**
     * ��ȡcourierCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCourierCode() {
        return courierCode;
    }

    /**
     * ����courierCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCourierCode(String value) {
        this.courierCode = value;
    }

    /**
     * ��ȡdeliverConfirm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliverConfirm() {
        return deliverConfirm;
    }

    /**
     * ����deliverConfirm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliverConfirm(String value) {
        this.deliverConfirm = value;
    }

    /**
     * ��ȡdeliverDateStr���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDeliverDateStr() {
        return deliverDateStr;
    }

    /**
     * ����deliverDateStr���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDeliverDateStr(XMLGregorianCalendar value) {
        this.deliverDateStr = value;
    }

    /**
     * ��ȡdestZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestZoneCode() {
        return destZoneCode;
    }

    /**
     * ����destZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestZoneCode(String value) {
        this.destZoneCode = value;
    }

    /**
     * ��ȡdestZoneName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestZoneName() {
        return destZoneName;
    }

    /**
     * ����destZoneName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestZoneName(String value) {
        this.destZoneName = value;
    }

    /**
     * ��ȡdistName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistName() {
        return distName;
    }

    /**
     * ����distName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistName(String value) {
        this.distName = value;
    }

    /**
     * ��ȡdistScanTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDistScanTm() {
        return distScanTm;
    }

    /**
     * ����distScanTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDistScanTm(XMLGregorianCalendar value) {
        this.distScanTm = value;
    }

    /**
     * ��ȡempMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmpMobile() {
        return empMobile;
    }

    /**
     * ����empMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmpMobile(String value) {
        this.empMobile = value;
    }

    /**
     * ��ȡexceptionCause���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionCause() {
        return exceptionCause;
    }

    /**
     * ����exceptionCause���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionCause(String value) {
        this.exceptionCause = value;
    }

    /**
     * ��ȡexceptionState���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionState() {
        return exceptionState;
    }

    /**
     * ����exceptionState���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionState(String value) {
        this.exceptionState = value;
    }

    /**
     * ��ȡextendAttach1���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtendAttach1() {
        return extendAttach1;
    }

    /**
     * ����extendAttach1���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtendAttach1(String value) {
        this.extendAttach1 = value;
    }

    /**
     * ��ȡextendAttach2���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtendAttach2() {
        return extendAttach2;
    }

    /**
     * ����extendAttach2���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtendAttach2(String value) {
        this.extendAttach2 = value;
    }

    /**
     * ��ȡextendAttach3���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtendAttach3() {
        return extendAttach3;
    }

    /**
     * ����extendAttach3���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtendAttach3(String value) {
        this.extendAttach3 = value;
    }

    /**
     * ��ȡextendAttach4���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtendAttach4() {
        return extendAttach4;
    }

    /**
     * ����extendAttach4���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtendAttach4(String value) {
        this.extendAttach4 = value;
    }

    /**
     * ��ȡnote���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * ����note���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

    /**
     * ��ȡobjTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjTypeCode() {
        return objTypeCode;
    }

    /**
     * ����objTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjTypeCode(String value) {
        this.objTypeCode = value;
    }

    /**
     * ��ȡopAttachInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpAttachInfo() {
        return opAttachInfo;
    }

    /**
     * ����opAttachInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpAttachInfo(String value) {
        this.opAttachInfo = value;
    }

    /**
     * ��ȡopCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpCode() {
        return opCode;
    }

    /**
     * ����opCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpCode(String value) {
        this.opCode = value;
    }

    /**
     * ��ȡopName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpName() {
        return opName;
    }

    /**
     * ����opName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpName(String value) {
        this.opName = value;
    }

    /**
     * ��ȡextendAttach5���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtendAttach5() {
        return extendAttach5;
    }

    /**
     * ����extendAttach5���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtendAttach5(String value) {
        this.extendAttach5 = value;
    }

    /**
     * ��ȡfromOmpflg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromOmpflg() {
        return fromOmpflg;
    }

    /**
     * ����fromOmpflg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromOmpflg(String value) {
        this.fromOmpflg = value;
    }

}
