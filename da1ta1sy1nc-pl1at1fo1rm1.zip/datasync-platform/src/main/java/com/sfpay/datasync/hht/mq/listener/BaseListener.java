/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.datasync.hht.mq.listener;

import javax.jms.BytesMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.datasync.hht.enums.DataVariety;
import com.sfpay.datasync.hht.enums.SystemCode;
import com.sfpay.datasync.mq.UnknownMQMessageException;


/**
 * 
 * 类说明： IBM MQ 监听基础类
 * 
 * <p>
 * 详细描述：
 * 
 * @author 321302 程俊杰
 * @author 325336 梁亚保
 * 
 *         CreateDate: 2012-6-7
 */
public abstract class BaseListener implements MessageListener
{
	private static Logger logger = LoggerFactory.getLogger(BaseListener.class);
	
	/**
	 * 方法说明：MQ信息处理
	 * 
	 * @param content
	 */
	abstract protected void execute(Object msg) throws Exception;

	/**
	 * 方法说明：待解析的XML对象
	 * 
	 * @return
	 */
	abstract protected SystemCode getSystemCode();

	abstract protected DataVariety getDataVariety();

	@Override
	public void onMessage(Message message)
	{
		if (message == null)
		{
			return;
		}

		Object msg = null;

		try
		{
			if (message instanceof TextMessage)
			{
				// 文本消息
				TextMessage txtMsg = (TextMessage) message;
				msg = txtMsg.getText();
			} else if (message instanceof BytesMessage)
			{
				// 字节数组消息
				BytesMessage bytes = (BytesMessage) message;
				msg = bytes.readUTF();
			} else if (message instanceof ObjectMessage)
			{
				// 对象消息
				ObjectMessage obj = (ObjectMessage)message;
				msg = obj.getObject();
			}
			else
			{
				// 其它形式的消息暂时无法处理
				throw new UnknownMQMessageException(message.toString());
			}

			if (msg == null)
			{
				return;
			}

			execute(msg);
			logger.info("消息处理成功!");
		}
		catch (Exception e)
		{
			// 当失败或者异常时，需要记录至数据库中，以便于人工处理。
			logger.error("消息处理异常!",e);
		}
	}
}
