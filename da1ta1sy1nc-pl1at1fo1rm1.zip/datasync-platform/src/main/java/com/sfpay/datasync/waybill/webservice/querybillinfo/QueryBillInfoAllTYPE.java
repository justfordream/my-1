
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>QueryBillInfoAll_TYPE complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="QueryBillInfoAll_TYPE">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SHEAD" type="{http://www.sf-express.com/esb/service/QueryBillInfo}SHEADType_34" minOccurs="0"/>
 *         &lt;element name="SBODY" type="{http://www.sf-express.com/esb/service/QueryBillInfo}SBODYType_35" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryBillInfoAll_TYPE", propOrder = {
    "shead",
    "sbody"
})
public class QueryBillInfoAllTYPE {

    @XmlElementRef(name = "SHEAD", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<SHEADType34> shead;
    @XmlElementRef(name = "SBODY", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<SBODYType35> sbody;

    /**
     * ��ȡshead���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SHEADType34 }{@code >}
     *     
     */
    public JAXBElement<SHEADType34> getSHEAD() {
        return shead;
    }

    /**
     * ����shead���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SHEADType34 }{@code >}
     *     
     */
    public void setSHEAD(JAXBElement<SHEADType34> value) {
        this.shead = value;
    }

    /**
     * ��ȡsbody���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SBODYType35 }{@code >}
     *     
     */
    public JAXBElement<SBODYType35> getSBODY() {
        return sbody;
    }

    /**
     * ����sbody���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SBODYType35 }{@code >}
     *     
     */
    public void setSBODY(JAXBElement<SBODYType35> value) {
        this.sbody = value;
    }

}
