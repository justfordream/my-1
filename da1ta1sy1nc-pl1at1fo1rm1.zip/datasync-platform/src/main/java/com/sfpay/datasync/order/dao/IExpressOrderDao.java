/**
 * 
 */
package com.sfpay.datasync.order.dao;

import com.sfpay.datasync.order.domain.ExpressOrder;

/**
 * 类说明：下单DAO
 *
 * 类描述：下单DAO
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IExpressOrderDao {
	
	/**
	 * 新增下单数据
	 * @param expressOrder
	 */
	public void addExpressOrder(ExpressOrder expressOrder);
	
	/**
	 * 通过ID查询下单信息
	 * @return
	 */
	public ExpressOrder queryExpressOrderById(Long id);
	
	/**
	 * 通过订单号查询下单信息
	 * @return
	 */
	public ExpressOrder queryExpressOrderByOrderId(String orderId);
	
	/**
	 * 获得下一个订单号中的序列号
	 * @return
	 */
	public Long getNextOrderId();

}
