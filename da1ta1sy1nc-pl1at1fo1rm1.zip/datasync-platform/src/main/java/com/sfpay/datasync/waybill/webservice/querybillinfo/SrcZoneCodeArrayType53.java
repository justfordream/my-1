
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>srcZoneCodeArrayType_53 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="srcZoneCodeArrayType_53">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}latitude" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}longitude" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}specialLevel" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "srcZoneCodeArrayType_53", propOrder = {
    "latitude",
    "longitude",
    "specialLevel",
    "zoneCode"
})
public class SrcZoneCodeArrayType53 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double latitude;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double longitude;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String specialLevel;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneCode;

    /**
     * ��ȡlatitude���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLatitude() {
        return latitude;
    }

    /**
     * ����latitude���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLatitude(Double value) {
        this.latitude = value;
    }

    /**
     * ��ȡlongitude���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLongitude() {
        return longitude;
    }

    /**
     * ����longitude���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLongitude(Double value) {
        this.longitude = value;
    }

    /**
     * ��ȡspecialLevel���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialLevel() {
        return specialLevel;
    }

    /**
     * ����specialLevel���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialLevel(String value) {
        this.specialLevel = value;
    }

    /**
     * ��ȡzoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneCode() {
        return zoneCode;
    }

    /**
     * ����zoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneCode(String value) {
        this.zoneCode = value;
    }

}
