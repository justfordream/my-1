/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.datasync.constant.MsgCode;
import com.sfpay.datasync.order.dao.IAddressTeamDao;
import com.sfpay.datasync.order.domain.AddressTeam;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.service.IAddressTeamService;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：地址单元区域管理接口实现类
 *
 * 类描述：地址单元区域管理接口实现类
 * @author 625288 易振强
 * 2014-11-12
 */
@Service("addressTeamService")
public class AddressTeamServiceImpl implements IAddressTeamService {
	@Autowired
	private IAddressTeamDao addressTeamDao;
	@Autowired
	private IContactAddrInfoService contactAddrInfoService;
	
	private static final Logger logger = LoggerFactory.getLogger(AddressTeamServiceImpl.class);

	/**
	 * 新增地址单元区域
	 * 
	 * @param addressTeam
	 * @throws ServiceException 20036-AddressTeam不能为空  20037-AddressTeam数据校验失败
	 */
	@Override
	public void addAddressTeam(AddressTeam addressTeam) throws ServiceException {
		logger.info(String.format("addAddressTeam start:%s ... ...", addressTeam));
		if(addressTeam == null) {
			throw new ServiceException(MsgCode.ADDRESS_TEAM_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.ADDRESS_TEAM_CAN_NOT_EMPTY));
		}
		
		// 校验数据完整性
		if(StringUtils.isBlank(addressTeam.getCityId()) || StringUtils.isBlank(addressTeam.getAddress()) || 
				StringUtils.isBlank(addressTeam.getTeamId())) {
			logger.error(String.format("addAddressTeam 数据校验失败:%s", addressTeam));
			throw new ServiceException(MsgCode.ADDRESS_TEAM_CHECK_FAIL, 
					MsgCode.getValue(MsgCode.ADDRESS_TEAM_CHECK_FAIL));
		}
		
		addressTeamDao.addAddressTeam(addressTeam);
		logger.info(String.format("addAddressTeam 地址单元区域插入数据库完毕:%s", addressTeam.getCityId()));
		
		// 如果地址、城市代码和单元区域都不为空，则区更新联系人地址信息中的单元区域
		ContactAddrInfo queryContactAddrInfo = new ContactAddrInfo();
		queryContactAddrInfo.setAddress(addressTeam.getAddress());
		queryContactAddrInfo.setTelphoneNo(addressTeam.getCustId());
		queryContactAddrInfo.setDistCityCode(addressTeam.getCityId());
		List<ContactAddrInfo> contactAddrInfoList = contactAddrInfoService.queryAddressInfoByParam(queryContactAddrInfo);
		if(contactAddrInfoList != null && !contactAddrInfoList.isEmpty()) {
			for(ContactAddrInfo contactAddrInfo : contactAddrInfoList) {
				contactAddrInfo.setTeamId(addressTeam.getTeamId());
				try {
					// 更新操作是否成功不应该影响地址单元区域的保存
					contactAddrInfoService.updateAddressInfo(contactAddrInfo);
//					logger.info(String.format("addAddressTeam 更新的联系人地址信息的单元区域成功:%s", contactAddrInfo));
				} catch (Exception e) {
					logger.warn(String.format("addAddressTeam 更新的联系人地址信息的单元区域失败:%s", contactAddrInfo), e);
				}
			}
		}
		
		
		logger.info(String.format("addAddressTeam end:%s", addressTeam));
	}

}
