/**
 * 包名：com.sfpay.datasync.util
 * 文件名：EsbInterfaceUtil.java
 * 版本信息：
 * 日期：2014-8-12-下午5:24:35
 * 
 */
package com.sfpay.datasync.waybill.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sf.esb.app.dispatcher.AccessManager;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.QueryAllBarRecordPortType;
import com.sfpay.datasync.waybill.webservice.querybillinfo.QueryBillInfoPortType;


/**
 * 类名称：EsbInterfaceUtil 类描述： 创建人：313920 熊伟 修改人：313920 熊伟 修改时间：2014-8-12
 * 下午5:24:35 修改备注：
 * 
 * @version 2.0.1
 * 
 */
public class EsbInterfaceUtil {

	private final Logger logger = LoggerFactory.getLogger(EsbInterfaceUtil.class);
	private String switchPath;
	
	private QueryBillInfoPortType queryBillInfoPortTypeNew;
	private QueryBillInfoPortType queryBillInfoPortTypeOld;
	private QueryAllBarRecordPortType queryAllBarRecordPortTypeNew;
	private QueryAllBarRecordPortType queryAllBarRecordPortTypeOld;

	public void setSwitchPath(String switchPath) {
		this.switchPath = switchPath;
	}

	/**
	 * 方法说明：getQueryBillInfo 获取WQS运单查询接口
	 * 
	 * @return
	 * @exception
	 * @since 2.0.1
	 */
	public QueryBillInfoPortType getQueryBillInfo() {

		// 新旧开关比例
		if (isNewWay("queryBillStandard")) {
			logger.info("isQueryBillStandardNewWay:[getEsbQueryBillInfo]");
			return queryBillInfoPortTypeNew;
		} else {
			logger.info("isQueryBillStandardNewWay:[getWqsQueryBillInfo]");
			return queryBillInfoPortTypeOld;
		}

	}
	
	/**
	 * 方法说明：getQueryBillInfo 获取WQS运单查询接口
	 * 
	 * @return
	 * @exception
	 * @since 2.0.1
	 */
	public QueryAllBarRecordPortType getQueryAllBarRecord() {
		// 新旧开关比例
		if (isNewWay("queryAllBarRecordList")) {
			logger.info("isQueryBillStandardNewWay:[getEsbQueryAllBarRecordPortType]");
			return queryAllBarRecordPortTypeNew;
			
		} else {
			logger.info("isQueryBillStandardNewWay:[getWqsQueryAllBarRecordPortType]");
			return queryAllBarRecordPortTypeOld;
		}
	}

	public boolean isNewWay(String methodName) {
		AccessManager.setConfig(EsbInterfaceUtil.class.getResource("/" + switchPath + "/").getPath(), "esbswitch", 10);
		logger.info(EsbInterfaceUtil.class.getResource("/" + switchPath).getPath() + "/");
		return AccessManager.getInstance().isNewWay(methodName);
	}

	public void setQueryBillInfoPortTypeNew(
			QueryBillInfoPortType queryBillInfoPortTypeNew) {
		this.queryBillInfoPortTypeNew = queryBillInfoPortTypeNew;
	}

	public void setQueryBillInfoPortTypeOld(
			QueryBillInfoPortType queryBillInfoPortTypeOld) {
		this.queryBillInfoPortTypeOld = queryBillInfoPortTypeOld;
	}

	public void setQueryAllBarRecordPortTypeNew(
			QueryAllBarRecordPortType queryAllBarRecordPortTypeNew) {
		this.queryAllBarRecordPortTypeNew = queryAllBarRecordPortTypeNew;
	}

	public void setQueryAllBarRecordPortTypeOld(
			QueryAllBarRecordPortType queryAllBarRecordPortTypeOld) {
		this.queryAllBarRecordPortTypeOld = queryAllBarRecordPortTypeOld;
	}

}
