/**
 * 
 */
package com.sfpay.datasync.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.datasync.order.domain.ContactAddrInfo;

/**
 * 类说明：联系人（寄件/收件）地址信息DAO
 *
 * 类描述：联系人（寄件/收件）地址信息DAO
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IContactAddrInfoDao {
	/**
	 *	新增联系人（寄件/收件）地址信息
	 * @param contactAddrInfo
	 */
	public void addContactAddrInfo(ContactAddrInfo contactAddrInfo);
	
	/**
	 * 更新联系人（寄件/收件）地址信息
	 * @param contactAddrInfo
	 */
	public void updateAddressInfo(ContactAddrInfo contactAddrInfo);
	
	/**
	 * 通过ID来查询联系人（寄件/收件）地址信息
	 * @param id
	 * @return
	 */
	public ContactAddrInfo queryAddressInfoById(@Param("id")Long id);
	
	/**
	 * 通过参数来查询联系人（寄件/收件）地址信息
	 * 目前可用参数有：memberNo、addressType、defaultFlag
	 * @param contactAddrInfo
	 * @return
	 */
	public List<ContactAddrInfo> queryAddressInfoByParam(ContactAddrInfo contactAddrInfo);
}
