/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.datasync.hht.domain;

import com.sfpay.framework.common.xml.dom4j.base.XElement;
import com.sfpay.framework.common.xml.dom4j.base.XmlBaseModel;
import com.sfpay.framework.common.xml.dom4j.base.XmlType;

/**
 * 
 * 类说明：
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 321302 程俊杰
 *   
 * CreateDate: 2012-7-13
 */
@XElement(name="MQEnvironment", clazz=MQEnvironmentX.class)
public class MQEnvironmentX implements XmlBaseModel
{
	@XElement(name="MQName", type=XmlType.ATTRIBUTE)
	private String MQName;
	
	@XElement(name="HostName", type=XmlType.ELEMENT)
	private String hostName;
	
	@XElement(name="Port", type=XmlType.ELEMENT, clazz=Integer.class)
	private int port;
	
	@XElement(name="Ccsid", type=XmlType.ELEMENT, clazz=Integer.class)
	private int ccsid;
	
	@XElement(name="Channel", type=XmlType.ELEMENT)
	private String channel;
	
	@XElement(name="QueueManager", type=XmlType.ELEMENT)
	private String queueManager;
	
	@XElement(name="Queue", type=XmlType.ELEMENT)
	private String queue;
	
	@XElement(name="Opt", type=XmlType.ELEMENT, clazz=Integer.class)
	private int opt;
	
	public boolean hasChildren()
	{
		return true;
	}

	public String getMQName()
	{
		return MQName;
	}

	public void setMQName(String mQName)
	{
		MQName = mQName;
	}

	public String getHostName()
	{
		return hostName;
	}

	public void setHostName(String hostName)
	{
		this.hostName = hostName;
	}

	public int getPort()
	{
		return port;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public int getCcsid()
	{
		return ccsid;
	}

	public void setCcsid(int ccsid)
	{
		this.ccsid = ccsid;
	}

	public String getChannel()
	{
		return channel;
	}

	public void setChannel(String channel)
	{
		this.channel = channel;
	}

	public String getQueueManager()
	{
		return queueManager;
	}

	public void setQueueManager(String queueManager)
	{
		this.queueManager = queueManager;
	}

	public String getQueue()
	{
		return queue;
	}

	public void setQueue(String queue)
	{
		this.queue = queue;
	}

	public int getOpt()
	{
		return opt;
	}

	public void setOpt(int opt)
	{
		this.opt = opt;
	}
}
