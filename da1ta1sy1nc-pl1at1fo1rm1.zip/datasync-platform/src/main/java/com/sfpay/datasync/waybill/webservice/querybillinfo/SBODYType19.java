
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>SBODYType_19 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="SBODYType_19">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNoList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addHTML" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addBar" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}visitInfo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}isNohtm" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SBODYType_19", propOrder = {
    "waybillNoList",
    "addHTML",
    "addBar",
    "visitInfo",
    "isNohtm"
})
public class SBODYType19 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected List<String> waybillNoList;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addHTML;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addBar;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String visitInfo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String isNohtm;

    /**
     * Gets the value of the waybillNoList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the waybillNoList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWaybillNoList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getWaybillNoList() {
        if (waybillNoList == null) {
            waybillNoList = new ArrayList<String>();
        }
        return this.waybillNoList;
    }

    /**
     * ��ȡaddHTML���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddHTML() {
        return addHTML;
    }

    /**
     * ����addHTML���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddHTML(String value) {
        this.addHTML = value;
    }

    /**
     * ��ȡaddBar���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddBar() {
        return addBar;
    }

    /**
     * ����addBar���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddBar(String value) {
        this.addBar = value;
    }

    /**
     * ��ȡvisitInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVisitInfo() {
        return visitInfo;
    }

    /**
     * ����visitInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVisitInfo(String value) {
        this.visitInfo = value;
    }

    /**
     * ��ȡisNohtm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsNohtm() {
        return isNohtm;
    }

    /**
     * ����isNohtm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsNohtm(String value) {
        this.isNohtm = value;
    }

}
