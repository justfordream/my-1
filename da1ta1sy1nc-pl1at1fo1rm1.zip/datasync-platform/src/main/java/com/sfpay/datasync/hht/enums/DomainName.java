package com.sfpay.datasync.hht.enums;

public enum DomainName {

	departmentForReport,
	
	department,
	
	duty,
	
	employee,
	
	position,
	
}
