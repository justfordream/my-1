
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>barListArrayType_32 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="barListArrayType_32">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barScanDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barScanTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}cvsCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}cvsName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}distName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}nextDestZone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}opCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}opName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}remark" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}routeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}stayWhyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneTypeCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "barListArrayType_32", propOrder = {
    "barScanDt",
    "barScanTm",
    "cvsCode",
    "cvsName",
    "distName",
    "nextDestZone",
    "opCode",
    "opName",
    "remark",
    "routeCode",
    "stayWhyCode",
    "zoneCode",
    "zoneTypeCode"
})
public class BarListArrayType32 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String barScanDt;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String barScanTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String cvsCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String cvsName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String distName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String nextDestZone;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String opCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String opName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String remark;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String routeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String stayWhyCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneTypeCode;

    /**
     * ��ȡbarScanDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarScanDt() {
        return barScanDt;
    }

    /**
     * ����barScanDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarScanDt(String value) {
        this.barScanDt = value;
    }

    /**
     * ��ȡbarScanTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarScanTm() {
        return barScanTm;
    }

    /**
     * ����barScanTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarScanTm(String value) {
        this.barScanTm = value;
    }

    /**
     * ��ȡcvsCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCvsCode() {
        return cvsCode;
    }

    /**
     * ����cvsCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCvsCode(String value) {
        this.cvsCode = value;
    }

    /**
     * ��ȡcvsName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCvsName() {
        return cvsName;
    }

    /**
     * ����cvsName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCvsName(String value) {
        this.cvsName = value;
    }

    /**
     * ��ȡdistName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistName() {
        return distName;
    }

    /**
     * ����distName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistName(String value) {
        this.distName = value;
    }

    /**
     * ��ȡnextDestZone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextDestZone() {
        return nextDestZone;
    }

    /**
     * ����nextDestZone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextDestZone(String value) {
        this.nextDestZone = value;
    }

    /**
     * ��ȡopCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpCode() {
        return opCode;
    }

    /**
     * ����opCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpCode(String value) {
        this.opCode = value;
    }

    /**
     * ��ȡopName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpName() {
        return opName;
    }

    /**
     * ����opName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpName(String value) {
        this.opName = value;
    }

    /**
     * ��ȡremark���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemark() {
        return remark;
    }

    /**
     * ����remark���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemark(String value) {
        this.remark = value;
    }

    /**
     * ��ȡrouteCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRouteCode() {
        return routeCode;
    }

    /**
     * ����routeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRouteCode(String value) {
        this.routeCode = value;
    }

    /**
     * ��ȡstayWhyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStayWhyCode() {
        return stayWhyCode;
    }

    /**
     * ����stayWhyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStayWhyCode(String value) {
        this.stayWhyCode = value;
    }

    /**
     * ��ȡzoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneCode() {
        return zoneCode;
    }

    /**
     * ����zoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneCode(String value) {
        this.zoneCode = value;
    }

    /**
     * ��ȡzoneTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneTypeCode() {
        return zoneTypeCode;
    }

    /**
     * ����zoneTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneTypeCode(String value) {
        this.zoneTypeCode = value;
    }

}
