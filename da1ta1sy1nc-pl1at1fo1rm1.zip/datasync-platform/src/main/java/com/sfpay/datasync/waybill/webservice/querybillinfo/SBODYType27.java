
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>SBODYType_27 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="SBODYType_27">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}vipCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}visitInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SBODYType_27", propOrder = {
    "waybillNo",
    "vipCode",
    "visitInfo"
})
public class SBODYType27 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String waybillNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String vipCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String visitInfo;

    /**
     * ��ȡwaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaybillNo() {
        return waybillNo;
    }

    /**
     * ����waybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaybillNo(String value) {
        this.waybillNo = value;
    }

    /**
     * ��ȡvipCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVipCode() {
        return vipCode;
    }

    /**
     * ����vipCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVipCode(String value) {
        this.vipCode = value;
    }

    /**
     * ��ȡvisitInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVisitInfo() {
        return visitInfo;
    }

    /**
     * ����visitInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVisitInfo(String value) {
        this.visitInfo = value;
    }

}
