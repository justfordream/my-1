
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>sendServiceArrayType_40 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="sendServiceArrayType_40">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_serviceId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_attribute1" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_attribute2" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_Attribute3" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_Attribute4" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_Attribute5" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_waybillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_inputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_versionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_serviceProdCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendService_newInputTm" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sendServiceArrayType_40", propOrder = {
    "sendServiceServiceId",
    "sendServiceAttribute1",
    "sendServiceAttribute2",
    "sendServiceAttribute3",
    "sendServiceAttribute4",
    "sendServiceAttribute5",
    "sendServiceWaybillId",
    "sendServiceWaybillNo",
    "sendServiceInputTm",
    "sendServiceVersionNo",
    "sendServiceServiceProdCode",
    "sendServiceNewInputTm"
})
public class SendServiceArrayType40 {

    @XmlElement(name = "sendService_serviceId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceServiceId;
    @XmlElement(name = "sendService_attribute1", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceAttribute1;
    @XmlElement(name = "sendService_attribute2", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceAttribute2;
    @XmlElement(name = "sendService_Attribute3", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceAttribute3;
    @XmlElement(name = "sendService_Attribute4", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceAttribute4;
    @XmlElement(name = "sendService_Attribute5", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceAttribute5;
    @XmlElement(name = "sendService_waybillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceWaybillId;
    @XmlElement(name = "sendService_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceWaybillNo;
    @XmlElement(name = "sendService_inputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendServiceInputTm;
    @XmlElement(name = "sendService_versionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendServiceVersionNo;
    @XmlElement(name = "sendService_serviceProdCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendServiceServiceProdCode;
    @XmlElement(name = "sendService_newInputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendServiceNewInputTm;

    /**
     * ��ȡsendServiceServiceId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceServiceId() {
        return sendServiceServiceId;
    }

    /**
     * ����sendServiceServiceId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceServiceId(String value) {
        this.sendServiceServiceId = value;
    }

    /**
     * ��ȡsendServiceAttribute1���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceAttribute1() {
        return sendServiceAttribute1;
    }

    /**
     * ����sendServiceAttribute1���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceAttribute1(String value) {
        this.sendServiceAttribute1 = value;
    }

    /**
     * ��ȡsendServiceAttribute2���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceAttribute2() {
        return sendServiceAttribute2;
    }

    /**
     * ����sendServiceAttribute2���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceAttribute2(String value) {
        this.sendServiceAttribute2 = value;
    }

    /**
     * ��ȡsendServiceAttribute3���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceAttribute3() {
        return sendServiceAttribute3;
    }

    /**
     * ����sendServiceAttribute3���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceAttribute3(String value) {
        this.sendServiceAttribute3 = value;
    }

    /**
     * ��ȡsendServiceAttribute4���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceAttribute4() {
        return sendServiceAttribute4;
    }

    /**
     * ����sendServiceAttribute4���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceAttribute4(String value) {
        this.sendServiceAttribute4 = value;
    }

    /**
     * ��ȡsendServiceAttribute5���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceAttribute5() {
        return sendServiceAttribute5;
    }

    /**
     * ����sendServiceAttribute5���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceAttribute5(String value) {
        this.sendServiceAttribute5 = value;
    }

    /**
     * ��ȡsendServiceWaybillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceWaybillId() {
        return sendServiceWaybillId;
    }

    /**
     * ����sendServiceWaybillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceWaybillId(String value) {
        this.sendServiceWaybillId = value;
    }

    /**
     * ��ȡsendServiceWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceWaybillNo() {
        return sendServiceWaybillNo;
    }

    /**
     * ����sendServiceWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceWaybillNo(String value) {
        this.sendServiceWaybillNo = value;
    }

    /**
     * ��ȡsendServiceInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendServiceInputTm() {
        return sendServiceInputTm;
    }

    /**
     * ����sendServiceInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendServiceInputTm(XMLGregorianCalendar value) {
        this.sendServiceInputTm = value;
    }

    /**
     * ��ȡsendServiceVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendServiceVersionNo() {
        return sendServiceVersionNo;
    }

    /**
     * ����sendServiceVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendServiceVersionNo(Integer value) {
        this.sendServiceVersionNo = value;
    }

    /**
     * ��ȡsendServiceServiceProdCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendServiceServiceProdCode() {
        return sendServiceServiceProdCode;
    }

    /**
     * ����sendServiceServiceProdCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendServiceServiceProdCode(String value) {
        this.sendServiceServiceProdCode = value;
    }

    /**
     * ��ȡsendServiceNewInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendServiceNewInputTm() {
        return sendServiceNewInputTm;
    }

    /**
     * ����sendServiceNewInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendServiceNewInputTm(XMLGregorianCalendar value) {
        this.sendServiceNewInputTm = value;
    }

}
