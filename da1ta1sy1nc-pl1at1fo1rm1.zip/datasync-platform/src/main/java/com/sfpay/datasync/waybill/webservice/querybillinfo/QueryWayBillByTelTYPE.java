
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>QueryWayBillByTel_TYPE complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="QueryWayBillByTel_TYPE">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SHEAD" type="{http://www.sf-express.com/esb/service/QueryBillInfo}SHEADType_12" minOccurs="0"/>
 *         &lt;element name="SBODY" type="{http://www.sf-express.com/esb/service/QueryBillInfo}SBODYType_13" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryWayBillByTel_TYPE", propOrder = {
    "shead",
    "sbody"
})
public class QueryWayBillByTelTYPE {

    @XmlElementRef(name = "SHEAD", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<SHEADType12> shead;
    @XmlElementRef(name = "SBODY", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<SBODYType13> sbody;

    /**
     * ��ȡshead���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SHEADType12 }{@code >}
     *     
     */
    public JAXBElement<SHEADType12> getSHEAD() {
        return shead;
    }

    /**
     * ����shead���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SHEADType12 }{@code >}
     *     
     */
    public void setSHEAD(JAXBElement<SHEADType12> value) {
        this.shead = value;
    }

    /**
     * ��ȡsbody���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SBODYType13 }{@code >}
     *     
     */
    public JAXBElement<SBODYType13> getSBODY() {
        return sbody;
    }

    /**
     * ����sbody���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SBODYType13 }{@code >}
     *     
     */
    public void setSBODY(JAXBElement<SBODYType13> value) {
        this.sbody = value;
    }

}
