
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>barNewListArrayType_33 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="barNewListArrayType_33">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barScanDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}barScanTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}cvsCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}cvsName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}distName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}nextDestZone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}opCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}opName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}remark" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}routeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}stayWhyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}abnormalReason" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}countryName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}extendAttach3" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}extendAttach4" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}hqCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}provinceName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}scanDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}scanTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}stayCodeName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}stayWhyName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}zoneName" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "barNewListArrayType_33", propOrder = {
    "barScanDt",
    "barScanTm",
    "cvsCode",
    "cvsName",
    "distName",
    "nextDestZone",
    "opCode",
    "opName",
    "remark",
    "routeCode",
    "stayWhyCode",
    "zoneCode",
    "zoneTypeCode",
    "abnormalReason",
    "countryName",
    "extendAttach3",
    "extendAttach4",
    "hqCode",
    "provinceName",
    "scanDate",
    "scanTime",
    "stayCodeName",
    "stayWhyName",
    "zoneName"
})
public class BarNewListArrayType33 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String barScanDt;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String barScanTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String cvsCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String cvsName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String distName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String nextDestZone;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String opCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String opName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String remark;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String routeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String stayWhyCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneTypeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String abnormalReason;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String countryName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String extendAttach3;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String extendAttach4;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String hqCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String provinceName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String scanDate;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String scanTime;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String stayCodeName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String stayWhyName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String zoneName;

    /**
     * ��ȡbarScanDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarScanDt() {
        return barScanDt;
    }

    /**
     * ����barScanDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarScanDt(String value) {
        this.barScanDt = value;
    }

    /**
     * ��ȡbarScanTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarScanTm() {
        return barScanTm;
    }

    /**
     * ����barScanTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarScanTm(String value) {
        this.barScanTm = value;
    }

    /**
     * ��ȡcvsCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCvsCode() {
        return cvsCode;
    }

    /**
     * ����cvsCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCvsCode(String value) {
        this.cvsCode = value;
    }

    /**
     * ��ȡcvsName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCvsName() {
        return cvsName;
    }

    /**
     * ����cvsName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCvsName(String value) {
        this.cvsName = value;
    }

    /**
     * ��ȡdistName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistName() {
        return distName;
    }

    /**
     * ����distName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistName(String value) {
        this.distName = value;
    }

    /**
     * ��ȡnextDestZone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextDestZone() {
        return nextDestZone;
    }

    /**
     * ����nextDestZone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextDestZone(String value) {
        this.nextDestZone = value;
    }

    /**
     * ��ȡopCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpCode() {
        return opCode;
    }

    /**
     * ����opCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpCode(String value) {
        this.opCode = value;
    }

    /**
     * ��ȡopName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpName() {
        return opName;
    }

    /**
     * ����opName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpName(String value) {
        this.opName = value;
    }

    /**
     * ��ȡremark���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemark() {
        return remark;
    }

    /**
     * ����remark���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemark(String value) {
        this.remark = value;
    }

    /**
     * ��ȡrouteCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRouteCode() {
        return routeCode;
    }

    /**
     * ����routeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRouteCode(String value) {
        this.routeCode = value;
    }

    /**
     * ��ȡstayWhyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStayWhyCode() {
        return stayWhyCode;
    }

    /**
     * ����stayWhyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStayWhyCode(String value) {
        this.stayWhyCode = value;
    }

    /**
     * ��ȡzoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneCode() {
        return zoneCode;
    }

    /**
     * ����zoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneCode(String value) {
        this.zoneCode = value;
    }

    /**
     * ��ȡzoneTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneTypeCode() {
        return zoneTypeCode;
    }

    /**
     * ����zoneTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneTypeCode(String value) {
        this.zoneTypeCode = value;
    }

    /**
     * ��ȡabnormalReason���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAbnormalReason() {
        return abnormalReason;
    }

    /**
     * ����abnormalReason���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAbnormalReason(String value) {
        this.abnormalReason = value;
    }

    /**
     * ��ȡcountryName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * ����countryName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryName(String value) {
        this.countryName = value;
    }

    /**
     * ��ȡextendAttach3���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtendAttach3() {
        return extendAttach3;
    }

    /**
     * ����extendAttach3���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtendAttach3(String value) {
        this.extendAttach3 = value;
    }

    /**
     * ��ȡextendAttach4���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtendAttach4() {
        return extendAttach4;
    }

    /**
     * ����extendAttach4���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtendAttach4(String value) {
        this.extendAttach4 = value;
    }

    /**
     * ��ȡhqCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHqCode() {
        return hqCode;
    }

    /**
     * ����hqCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHqCode(String value) {
        this.hqCode = value;
    }

    /**
     * ��ȡprovinceName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvinceName() {
        return provinceName;
    }

    /**
     * ����provinceName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvinceName(String value) {
        this.provinceName = value;
    }

    /**
     * ��ȡscanDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScanDate() {
        return scanDate;
    }

    /**
     * ����scanDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScanDate(String value) {
        this.scanDate = value;
    }

    /**
     * ��ȡscanTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScanTime() {
        return scanTime;
    }

    /**
     * ����scanTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScanTime(String value) {
        this.scanTime = value;
    }

    /**
     * ��ȡstayCodeName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStayCodeName() {
        return stayCodeName;
    }

    /**
     * ����stayCodeName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStayCodeName(String value) {
        this.stayCodeName = value;
    }

    /**
     * ��ȡstayWhyName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStayWhyName() {
        return stayWhyName;
    }

    /**
     * ����stayWhyName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStayWhyName(String value) {
        this.stayWhyName = value;
    }

    /**
     * ��ȡzoneName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZoneName() {
        return zoneName;
    }

    /**
     * ����zoneName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZoneName(String value) {
        this.zoneName = value;
    }

}
