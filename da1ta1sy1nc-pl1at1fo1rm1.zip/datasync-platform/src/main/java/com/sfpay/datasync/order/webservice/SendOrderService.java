
package com.sfpay.datasync.order.webservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="sendOrderService">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arg0" type="{http://biz.nos.schinterface.module.sf.com/}schOrderDto" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sendOrderService", propOrder = {
    "arg0"
})
public class SendOrderService {

    protected SchOrderDto arg0;

    /**
     * 
     * @return
     *     possible object is
     *     {@link SchOrderDto }
     *     
     */
    public SchOrderDto getArg0() {
        return arg0;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link SchOrderDto }
     *     
     */
    public void setArg0(SchOrderDto value) {
        this.arg0 = value;
    }

}
