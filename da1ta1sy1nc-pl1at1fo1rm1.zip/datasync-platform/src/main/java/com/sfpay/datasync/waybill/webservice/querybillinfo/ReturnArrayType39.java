
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>returnArrayType_39 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="returnArrayType_39">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sendService" type="{http://www.sf-express.com/esb/service/QueryBillInfo}sendServiceArrayType_40" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="receiveService" type="{http://www.sf-express.com/esb/service/QueryBillInfo}receiveServiceArrayType_41" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}tbOrderNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}b2c" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}childNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}childNos" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="sendBill" type="{http://www.sf-express.com/esb/service/QueryBillInfo}sendBillType_42" minOccurs="0"/>
 *         &lt;element name="taxbillInfo" type="{http://www.sf-express.com/esb/service/QueryBillInfo}taxbillInfoType_43" minOccurs="0"/>
 *         &lt;element name="consignList" type="{http://www.sf-express.com/esb/service/QueryBillInfo}consignListArrayType_44" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="receiveBill" type="{http://www.sf-express.com/esb/service/QueryBillInfo}receiveBillType_45" minOccurs="0"/>
 *         &lt;element name="sendFee" type="{http://www.sf-express.com/esb/service/QueryBillInfo}sendFeeArrayType_46" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="receiveFee" type="{http://www.sf-express.com/esb/service/QueryBillInfo}receiveFeeArrayType_47" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "returnArrayType_39", propOrder = {
    "sendService",
    "receiveService",
    "waybillNo",
    "tbOrderNo",
    "b2C",
    "childNo",
    "childNos",
    "sendBill",
    "taxbillInfo",
    "consignList",
    "receiveBill",
    "sendFee",
    "receiveFee"
})
public class ReturnArrayType39 {

    @XmlElement(nillable = true)
    protected List<SendServiceArrayType40> sendService;
    @XmlElement(nillable = true)
    protected List<ReceiveServiceArrayType41> receiveService;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String waybillNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String tbOrderNo;
    @XmlElement(name = "b2c", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String b2C;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String childNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected List<String> childNos;
    @XmlElementRef(name = "sendBill", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<SendBillType42> sendBill;
    @XmlElementRef(name = "taxbillInfo", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<TaxbillInfoType43> taxbillInfo;
    @XmlElement(nillable = true)
    protected List<ConsignListArrayType44> consignList;
    @XmlElementRef(name = "receiveBill", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<ReceiveBillType45> receiveBill;
    @XmlElement(nillable = true)
    protected List<SendFeeArrayType46> sendFee;
    @XmlElement(nillable = true)
    protected List<ReceiveFeeArrayType47> receiveFee;

    /**
     * Gets the value of the sendService property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sendService property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSendService().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SendServiceArrayType40 }
     * 
     * 
     */
    public List<SendServiceArrayType40> getSendService() {
        if (sendService == null) {
            sendService = new ArrayList<SendServiceArrayType40>();
        }
        return this.sendService;
    }

    /**
     * Gets the value of the receiveService property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the receiveService property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReceiveService().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReceiveServiceArrayType41 }
     * 
     * 
     */
    public List<ReceiveServiceArrayType41> getReceiveService() {
        if (receiveService == null) {
            receiveService = new ArrayList<ReceiveServiceArrayType41>();
        }
        return this.receiveService;
    }

    /**
     * ��ȡwaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaybillNo() {
        return waybillNo;
    }

    /**
     * ����waybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaybillNo(String value) {
        this.waybillNo = value;
    }

    /**
     * ��ȡtbOrderNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTbOrderNo() {
        return tbOrderNo;
    }

    /**
     * ����tbOrderNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTbOrderNo(String value) {
        this.tbOrderNo = value;
    }

    /**
     * ��ȡb2C���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getB2C() {
        return b2C;
    }

    /**
     * ����b2C���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setB2C(String value) {
        this.b2C = value;
    }

    /**
     * ��ȡchildNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChildNo() {
        return childNo;
    }

    /**
     * ����childNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChildNo(String value) {
        this.childNo = value;
    }

    /**
     * Gets the value of the childNos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the childNos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChildNos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getChildNos() {
        if (childNos == null) {
            childNos = new ArrayList<String>();
        }
        return this.childNos;
    }

    /**
     * ��ȡsendBill���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SendBillType42 }{@code >}
     *     
     */
    public JAXBElement<SendBillType42> getSendBill() {
        return sendBill;
    }

    /**
     * ����sendBill���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SendBillType42 }{@code >}
     *     
     */
    public void setSendBill(JAXBElement<SendBillType42> value) {
        this.sendBill = value;
    }

    /**
     * ��ȡtaxbillInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link TaxbillInfoType43 }{@code >}
     *     
     */
    public JAXBElement<TaxbillInfoType43> getTaxbillInfo() {
        return taxbillInfo;
    }

    /**
     * ����taxbillInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link TaxbillInfoType43 }{@code >}
     *     
     */
    public void setTaxbillInfo(JAXBElement<TaxbillInfoType43> value) {
        this.taxbillInfo = value;
    }

    /**
     * Gets the value of the consignList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the consignList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConsignList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConsignListArrayType44 }
     * 
     * 
     */
    public List<ConsignListArrayType44> getConsignList() {
        if (consignList == null) {
            consignList = new ArrayList<ConsignListArrayType44>();
        }
        return this.consignList;
    }

    /**
     * ��ȡreceiveBill���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link ReceiveBillType45 }{@code >}
     *     
     */
    public JAXBElement<ReceiveBillType45> getReceiveBill() {
        return receiveBill;
    }

    /**
     * ����receiveBill���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link ReceiveBillType45 }{@code >}
     *     
     */
    public void setReceiveBill(JAXBElement<ReceiveBillType45> value) {
        this.receiveBill = value;
    }

    /**
     * Gets the value of the sendFee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sendFee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSendFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SendFeeArrayType46 }
     * 
     * 
     */
    public List<SendFeeArrayType46> getSendFee() {
        if (sendFee == null) {
            sendFee = new ArrayList<SendFeeArrayType46>();
        }
        return this.sendFee;
    }

    /**
     * Gets the value of the receiveFee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the receiveFee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReceiveFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReceiveFeeArrayType47 }
     * 
     * 
     */
    public List<ReceiveFeeArrayType47> getReceiveFee() {
        if (receiveFee == null) {
            receiveFee = new ArrayList<ReceiveFeeArrayType47>();
        }
        return this.receiveFee;
    }

}
