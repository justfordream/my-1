
package com.sfpay.datasync.order.webservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <pre>
 * &lt;complexType name="schAgentordersTemp">
 *   &lt;complexContent>
 *     &lt;extension base="{http://biz.nos.schinterface.module.sf.com/}baseEntity">
 *       &lt;sequence>
 *         &lt;element name="agentorderid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cargoHigh" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="cargoLength" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="cargoName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cargoValue" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="cargoVol" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="cargoWeight" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="cargoWide" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="cargopcs" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="daddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dcityid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dcompany" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dcontact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dcusttag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dphone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dtaxno" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="handled" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/>
 *         &lt;element name="handledtime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="inserttime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="insurance" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isbooking" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jaddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jcityid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jcompany" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jcontact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jcustid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jcusttag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jphone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loadtime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="nccomment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="operator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paycompany" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paycontact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paycustid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payphone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="schcomment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="secret" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="serverid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shipType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="syncFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="waddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wcityid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wcompany" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wcontact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wcustid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wcusttag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wemail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wfax" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wphone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wtelephone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wtime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "schAgentordersTemp", propOrder = {
    "agentorderid",
    "cargoHigh",
    "cargoLength",
    "cargoName",
    "cargoValue",
    "cargoVol",
    "cargoWeight",
    "cargoWide",
    "cargopcs",
    "daddress",
    "dcityid",
    "dcompany",
    "dcontact",
    "dcusttag",
    "dphone",
    "dtaxno",
    "handled",
    "handledtime",
    "inserttime",
    "insurance",
    "isbooking",
    "jaddress",
    "jcityid",
    "jcompany",
    "jcontact",
    "jcustid",
    "jcusttag",
    "jphone",
    "loadtime",
    "nccomment",
    "operator",
    "payMethod",
    "paycompany",
    "paycontact",
    "paycustid",
    "payphone",
    "schcomment",
    "secret",
    "serverid",
    "shipType",
    "syncFlag",
    "waddress",
    "wcityid",
    "wcompany",
    "wcontact",
    "wcustid",
    "wcusttag",
    "wemail",
    "wfax",
    "wphone",
    "wtelephone",
    "wtime"
})
public class SchAgentordersTemp
    extends BaseEntity
{

    protected String agentorderid;
    protected Double cargoHigh;
    protected Double cargoLength;
    protected String cargoName;
    protected Double cargoValue;
    protected Double cargoVol;
    protected Double cargoWeight;
    protected Double cargoWide;
    protected Integer cargopcs;
    protected String daddress;
    protected String dcityid;
    protected String dcompany;
    protected String dcontact;
    protected String dcusttag;
    protected String dphone;
    protected String dtaxno;
    protected Short handled;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar handledtime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar inserttime;
    protected String insurance;
    protected String isbooking;
    protected String jaddress;
    protected String jcityid;
    protected String jcompany;
    protected String jcontact;
    protected String jcustid;
    protected String jcusttag;
    protected String jphone;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar loadtime;
    protected String nccomment;
    protected String operator;
    protected String payMethod;
    protected String paycompany;
    protected String paycontact;
    protected String paycustid;
    protected String payphone;
    protected String schcomment;
    protected String secret;
    protected String serverid;
    protected String shipType;
    protected String syncFlag;
    protected String waddress;
    protected String wcityid;
    protected String wcompany;
    protected String wcontact;
    protected String wcustid;
    protected String wcusttag;
    protected String wemail;
    protected String wfax;
    protected String wphone;
    protected String wtelephone;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar wtime;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentorderid() {
        return agentorderid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentorderid(String value) {
        this.agentorderid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCargoHigh() {
        return cargoHigh;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCargoHigh(Double value) {
        this.cargoHigh = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCargoLength() {
        return cargoLength;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCargoLength(Double value) {
        this.cargoLength = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCargoName() {
        return cargoName;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCargoName(String value) {
        this.cargoName = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCargoValue() {
        return cargoValue;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCargoValue(Double value) {
        this.cargoValue = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCargoVol() {
        return cargoVol;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCargoVol(Double value) {
        this.cargoVol = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCargoWeight() {
        return cargoWeight;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCargoWeight(Double value) {
        this.cargoWeight = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCargoWide() {
        return cargoWide;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCargoWide(Double value) {
        this.cargoWide = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCargopcs() {
        return cargopcs;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCargopcs(Integer value) {
        this.cargopcs = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaddress() {
        return daddress;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaddress(String value) {
        this.daddress = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDcityid() {
        return dcityid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDcityid(String value) {
        this.dcityid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDcompany() {
        return dcompany;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDcompany(String value) {
        this.dcompany = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDcontact() {
        return dcontact;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDcontact(String value) {
        this.dcontact = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDcusttag() {
        return dcusttag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDcusttag(String value) {
        this.dcusttag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDphone() {
        return dphone;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDphone(String value) {
        this.dphone = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtaxno() {
        return dtaxno;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtaxno(String value) {
        this.dtaxno = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getHandled() {
        return handled;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setHandled(Short value) {
        this.handled = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getHandledtime() {
        return handledtime;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setHandledtime(XMLGregorianCalendar value) {
        this.handledtime = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getInserttime() {
        return inserttime;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setInserttime(XMLGregorianCalendar value) {
        this.inserttime = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsurance() {
        return insurance;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsurance(String value) {
        this.insurance = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsbooking() {
        return isbooking;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsbooking(String value) {
        this.isbooking = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJaddress() {
        return jaddress;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJaddress(String value) {
        this.jaddress = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJcityid() {
        return jcityid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJcityid(String value) {
        this.jcityid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJcompany() {
        return jcompany;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJcompany(String value) {
        this.jcompany = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJcontact() {
        return jcontact;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJcontact(String value) {
        this.jcontact = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJcustid() {
        return jcustid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJcustid(String value) {
        this.jcustid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJcusttag() {
        return jcusttag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJcusttag(String value) {
        this.jcusttag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJphone() {
        return jphone;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJphone(String value) {
        this.jphone = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLoadtime() {
        return loadtime;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLoadtime(XMLGregorianCalendar value) {
        this.loadtime = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNccomment() {
        return nccomment;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNccomment(String value) {
        this.nccomment = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperator() {
        return operator;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperator(String value) {
        this.operator = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayMethod() {
        return payMethod;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayMethod(String value) {
        this.payMethod = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaycompany() {
        return paycompany;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaycompany(String value) {
        this.paycompany = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaycontact() {
        return paycontact;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaycontact(String value) {
        this.paycontact = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaycustid() {
        return paycustid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaycustid(String value) {
        this.paycustid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayphone() {
        return payphone;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayphone(String value) {
        this.payphone = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSchcomment() {
        return schcomment;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSchcomment(String value) {
        this.schcomment = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecret() {
        return secret;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecret(String value) {
        this.secret = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServerid() {
        return serverid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServerid(String value) {
        this.serverid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipType() {
        return shipType;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipType(String value) {
        this.shipType = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSyncFlag() {
        return syncFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSyncFlag(String value) {
        this.syncFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaddress() {
        return waddress;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaddress(String value) {
        this.waddress = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWcityid() {
        return wcityid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWcityid(String value) {
        this.wcityid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWcompany() {
        return wcompany;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWcompany(String value) {
        this.wcompany = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWcontact() {
        return wcontact;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWcontact(String value) {
        this.wcontact = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWcustid() {
        return wcustid;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWcustid(String value) {
        this.wcustid = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWcusttag() {
        return wcusttag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWcusttag(String value) {
        this.wcusttag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWemail() {
        return wemail;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWemail(String value) {
        this.wemail = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWfax() {
        return wfax;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWfax(String value) {
        this.wfax = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWphone() {
        return wphone;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWphone(String value) {
        this.wphone = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWtelephone() {
        return wtelephone;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWtelephone(String value) {
        this.wtelephone = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getWtime() {
        return wtime;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setWtime(XMLGregorianCalendar value) {
        this.wtime = value;
    }

}
