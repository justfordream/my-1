/**
 * 
 */
package com.sfpay.datasync.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.datasync.order.domain.TmNewDistrict;

/**
 * 类说明：区域表DAO
 *
 * 类描述：区域表DAO
 * @author 625288 易振强
 * 2014-11-12
 */
public interface ITmNewDistrictDao {
	/**
	 * 通过区域代码来查询区域对象
	 * @param distCode
	 * @return
	 */
	public TmNewDistrict queryTmNewDistrictByDistCode(@Param("distCode")String distCode);
	
	/**
	 * 通过区域ID来查询区域对象
	 * @param distId
	 * @return
	 */
	public TmNewDistrict queryTmNewDistrictById(@Param("distId")Long distId);
	
	/**
	 * 通过区域ID来查询区域对象
	 * @param tmNewDistrict
	 * @return
	 */
	public List<TmNewDistrict> queryTmNewDistrictByParam(TmNewDistrict tmNewDistrict);
	
}
