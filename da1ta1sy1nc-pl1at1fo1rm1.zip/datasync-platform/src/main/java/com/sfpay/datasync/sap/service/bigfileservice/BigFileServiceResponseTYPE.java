
package com.sfpay.datasync.sap.service.bigfileservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BigFileServiceResponse_TYPE complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BigFileServiceResponse_TYPE">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SHEAD" type="{http://www.sf-express.com/esb/service/BigFileService}SHEADType_3" minOccurs="0"/>
 *         &lt;element name="SBODY" type="{http://www.sf-express.com/esb/service/BigFileService}SBODYType_5" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BigFileServiceResponse_TYPE", propOrder = {
    "shead",
    "sbody"
})
public class BigFileServiceResponseTYPE {

    @XmlElementRef(name = "SHEAD", namespace = "http://www.sf-express.com/esb/service/BigFileService", type = JAXBElement.class)
    protected JAXBElement<SHEADType3> shead;
    @XmlElementRef(name = "SBODY", namespace = "http://www.sf-express.com/esb/service/BigFileService", type = JAXBElement.class)
    protected JAXBElement<SBODYType5> sbody;

    /**
     * Gets the value of the shead property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SHEADType3 }{@code >}
     *     
     */
    public JAXBElement<SHEADType3> getSHEAD() {
        return shead;
    }

    /**
     * Sets the value of the shead property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SHEADType3 }{@code >}
     *     
     */
    public void setSHEAD(JAXBElement<SHEADType3> value) {
        this.shead = ((JAXBElement<SHEADType3> ) value);
    }

    /**
     * Gets the value of the sbody property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SBODYType5 }{@code >}
     *     
     */
    public JAXBElement<SBODYType5> getSBODY() {
        return sbody;
    }

    /**
     * Sets the value of the sbody property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SBODYType5 }{@code >}
     *     
     */
    public void setSBODY(JAXBElement<SBODYType5> value) {
        this.sbody = ((JAXBElement<SBODYType5> ) value);
    }

}
