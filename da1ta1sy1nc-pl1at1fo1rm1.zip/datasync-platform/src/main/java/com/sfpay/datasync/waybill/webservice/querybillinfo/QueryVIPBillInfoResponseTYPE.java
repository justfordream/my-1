
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>QueryVIPBillInfoResponse_TYPE complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="QueryVIPBillInfoResponse_TYPE">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SHEAD" type="{http://www.sf-express.com/esb/service/QueryBillInfo}SHEADType_28" minOccurs="0"/>
 *         &lt;element name="SBODY" type="{http://www.sf-express.com/esb/service/QueryBillInfo}SBODYType_30" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryVIPBillInfoResponse_TYPE", propOrder = {
    "shead",
    "sbody"
})
public class QueryVIPBillInfoResponseTYPE {

    @XmlElementRef(name = "SHEAD", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<SHEADType28> shead;
    @XmlElementRef(name = "SBODY", namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", type = JAXBElement.class)
    protected JAXBElement<SBODYType30> sbody;

    /**
     * ��ȡshead���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SHEADType28 }{@code >}
     *     
     */
    public JAXBElement<SHEADType28> getSHEAD() {
        return shead;
    }

    /**
     * ����shead���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SHEADType28 }{@code >}
     *     
     */
    public void setSHEAD(JAXBElement<SHEADType28> value) {
        this.shead = value;
    }

    /**
     * ��ȡsbody���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SBODYType30 }{@code >}
     *     
     */
    public JAXBElement<SBODYType30> getSBODY() {
        return sbody;
    }

    /**
     * ����sbody���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.bind.JAXBElement }{@code <}{@link SBODYType30 }{@code >}
     *     
     */
    public void setSBODY(JAXBElement<SBODYType30> value) {
        this.sbody = value;
    }

}
