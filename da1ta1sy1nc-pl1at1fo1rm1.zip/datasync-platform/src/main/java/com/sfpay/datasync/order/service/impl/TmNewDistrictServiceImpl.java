/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.datasync.order.dao.ITmNewDistrictDao;
import com.sfpay.datasync.order.domain.TmNewDistrict;
import com.sfpay.datasync.order.service.ITmNewDistrictService;

/**
 * 类说明：区域查询接口实现类
 *
 * 类描述：
 * @author 625288 易振强
 * 2014-11-12
 */
@Service("tmNewDistrictService")
public class TmNewDistrictServiceImpl implements ITmNewDistrictService {
	@Autowired
	private ITmNewDistrictDao tmNewDistrictDao;
	
	private static final Logger logger = LoggerFactory.getLogger(TmNewDistrictServiceImpl.class);
	
	private static final String CHINA_CODE = "A000086000";

	/**
	 * 通过区域类型来获取中国的区域列表
	 * 
	 * @param distType 区域类型  Province-省 City-市 County-县区
	 * @return
	 */
	@Override
	public List<TmNewDistrict> queryDistByDistType(String typeCode) {
		logger.info(String.format("queryDistByDistType start:%s ... ...", typeCode));
		List<TmNewDistrict> resultList = new ArrayList<TmNewDistrict>();
		if(StringUtils.isBlank(typeCode)) {
			return resultList;
		}
		
		TmNewDistrict queryTmNewDistrict = new TmNewDistrict();
		queryTmNewDistrict.setCountryCode(CHINA_CODE);	// 设置国家为中国
		queryTmNewDistrict.setTypeCode(typeCode);
		resultList = tmNewDistrictDao.queryTmNewDistrictByParam(queryTmNewDistrict);
		
		logger.info(String.format("queryDistByDistType end:%s", typeCode));

		return resultList;
	}

	/**
	 * 通过区域代码获取所有直接下级区域
	 * 
	 * @param parentCode 父区域代码
	 * @return
	 */
	@Override
	public List<TmNewDistrict> queryAllChildrenDist(String parentCode) {
		logger.info(String.format("queryAllChildrenDist start:%s ... ...", parentCode));
		List<TmNewDistrict> resultList = new ArrayList<TmNewDistrict>();
		if(StringUtils.isBlank(parentCode)) {
			return resultList;
		}
		
		TmNewDistrict queryTmNewDistrict = new TmNewDistrict();
		queryTmNewDistrict.setCountryCode(CHINA_CODE);	// 设置国家为中国
		queryTmNewDistrict.setParentDistCode(parentCode);
		resultList = tmNewDistrictDao.queryTmNewDistrictByParam(queryTmNewDistrict);
		
		logger.info(String.format("queryAllChildrenDist end:%s", parentCode));

		return resultList;
	}

	/**
	 * 通过区域代码来获取区域对象
	 * 
	 * @param distCode 区域代码
	 * @return
	 */
	@Override
	public TmNewDistrict queryTmNewDistrictByDistCode(String distCode) {
		logger.info(String.format("queryTmNewDistrictByDistCode start:%s ... ...", distCode));
		if(StringUtils.isBlank(distCode)) {
			return null;
		}
		
		TmNewDistrict queryTmNewDistrict = tmNewDistrictDao.queryTmNewDistrictByDistCode(distCode);
		
		logger.info(String.format("queryTmNewDistrictByDistCode end:%s", distCode));

		return queryTmNewDistrict;
	}

	/**
	 * 通过区域ID来获取区域对象
	 * 
	 * @param distId 区域ID
	 * @return
	 */
	@Override
	public TmNewDistrict queryTmNewDistrictById(Long distId) {
		logger.info(String.format("queryTmNewDistrictById start:%s ... ...", distId));
		if(distId == null) {
			return null;
		}
		
		TmNewDistrict queryTmNewDistrict = tmNewDistrictDao.queryTmNewDistrictById(distId);
		
		logger.info(String.format("queryTmNewDistrictById end:%s", distId));

		return queryTmNewDistrict;
	}

}
