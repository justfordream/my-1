/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sfpay.datasync.constant.MsgCode;
import com.sfpay.datasync.order.dao.IExpressOrderDao;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.domain.ExpressOrder;
import com.sfpay.datasync.order.domain.ExpressRecord;
import com.sfpay.datasync.order.domain.TmNewDistrict;
import com.sfpay.datasync.order.domain.WayBillRecord;
import com.sfpay.datasync.order.enums.ExpressStatus;
import com.sfpay.datasync.order.enums.NumEmum;
import com.sfpay.datasync.order.enums.OrderType;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.datasync.order.service.IExpressOrderService;
import com.sfpay.datasync.order.service.ITmNewDistrictService;
import com.sfpay.datasync.order.webservice.IOrderService;
import com.sfpay.datasync.util.DateUtils;
import com.sfpay.datasync.waybill.domain.WayBillRoute;
import com.sfpay.datasync.waybill.domain.WaybillBarInfo;
import com.sfpay.datasync.waybill.service.IWayBillRouteService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：下单服务接口实现类
 *
 * 类描述：下单服务接口实现类
 * @author 625288 易振强
 * 2014-11-12
 */
@HessianExporter
@Service("expressOrderService")
public class ExpressOrderServiceImpl implements IExpressOrderService {
	@Autowired
	private IExpressOrderDao expressOrderDao;
	@Autowired
	private IContactAddrInfoService contactAddrInfoService;
	@Autowired
	private ITmNewDistrictService tmNewDistrictService;
	@Resource
	private IOrderService orderServiceClient;
	@Autowired
	private IWayBillRouteService wayBillRouteService;
	
	// 如果用户已签收，巴枪操作码为80或8000
	private final static String signBarCode80 ="80";
	private final static String signBarCode8000 ="8000";
	
	public static final String ORDER_ID_PREFIX = "DATASYNC";
	
	private static final Logger logger = LoggerFactory.getLogger(ExpressOrderServiceImpl.class);
	
	@Value("${CAN_NOT_ORDER_TIME}")
	private String canNotOrderTime; 
	
	// 不可寄快递时间段Map，key为开始时间（HH:mm）,value为结束时间（HH:mm），结束时间必须要大于等于开始时间
	private Map<String, String> canNotOrderTimeMap;
	
	@PostConstruct
	public void init() {
		if(StringUtils.isBlank(canNotOrderTime)) {
			logger.error("快递不可下单时间范围为空，将采用【18:00-23:59,00:00-08:00】");
			canNotOrderTime = "18:00-23:59,00:00-08:00";
		}
		
		String[] timeStrs = canNotOrderTime.split(",");
		canNotOrderTimeMap = new HashMap<String, String>();
		for(String timeStr : timeStrs) {
			if(StringUtils.isNotBlank(timeStr)) {
				timeStr = timeStr.replaceAll("\\s", "");
				String[] times = timeStr.split("-");
				if(times.length == 2 && StringUtils.isNotBlank(times[0]) && StringUtils.isNotBlank(times[1])) {
					canNotOrderTimeMap.put(times[0], times[1]);
					logger.info("插入快递下单不可用时间段：【{}-{}】", times[0], times[1]);
				}
			}
		}
	}
	
	
	/**
	 * 新增手机APP运单，由手机代理调用
	 * @throws ServiceException 20001-下单数据校验失败 20002-下单数据不能为空 20024-寄件人联系地址信息ID不存在 20023-收件人联系地址信息ID不存在
	 * 20040-省代码不存在 20041-市代码不存在 20042-区/县代码不存在 20038-资科下单调度系统异常
	 * @return
	 */
	@Override
	public String addExpressOrder(ExpressOrder expressOrder)
			throws ServiceException {
		logger.info("addExpressOrder start:{} ... ...");
		if(expressOrder == null) {
			throw new ServiceException(MsgCode.EXPRESSORDER_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.EXPRESSORDER_CAN_NOT_EMPTY));
		}
		
		// 检查是否在快递下单时间范围内
		String curTime = new SimpleDateFormat("HH:mm").format(new Date());
		for(Entry<String, String> entry : canNotOrderTimeMap.entrySet()) {
			if(curTime.compareTo(entry.getKey()) >= 0 && curTime.compareTo(entry.getValue()) <= 0 ) {
				logger.error("快递不可下单时间段：【{}-{}】", entry.getKey(), entry.getValue());
				throw new ServiceException(MsgCode.CAN_NOT_ORDER_EXCEPTION, 
						String.format(MsgCode.getValue(MsgCode.CAN_NOT_ORDER_EXCEPTION), 
								new Object[]{entry.getKey(), entry.getValue()}));
			}
		}
		
		String logLabel = "ExpressOrder@" + Integer.toHexString(System.identityHashCode(expressOrder));
		logger.info(logLabel + " " + expressOrder);
		
		// 校验手机APP代理传过来的数据是否完整
		if(expressOrder.getMemberNo() == null || expressOrder.getSenderAddrId() == null)  {
			logger.error(String.format("addExpressOrder 校验失败，数据字段不完整:%s", logLabel));
			throw new ServiceException(MsgCode.EXPRESSORDER_DATA_CHECK_FAIL, 
					MsgCode.getValue(MsgCode.EXPRESSORDER_DATA_CHECK_FAIL));
		}
		
		// 检查寄件人地址是否都存在
		ContactAddrInfo senderAddr = contactAddrInfoService.queryContactAddrInfoById(expressOrder.getSenderAddrId());
		if(senderAddr == null) {
			logger.error(String.format("addExpressOrder 寄件人地址信息不存在:%s", 
					expressOrder.getSenderAddrId()));
			throw new ServiceException(MsgCode.SENDER_CONTACT_ADDR_INFO_ID_NOT_EXIST, 
					MsgCode.getValue(MsgCode.SENDER_CONTACT_ADDR_INFO_ID_NOT_EXIST) + String.format("【%s】", expressOrder.getSenderAddrId()));
		}
		expressOrder.setContact(senderAddr.getContacts());
		expressOrder.setCompAbb(senderAddr.getCompany());
		expressOrder.setAddrAbb(senderAddr.getAddress());
		expressOrder.setCustTel(senderAddr.getTelphoneNo());
		expressOrder.setTeamId(senderAddr.getTeamId());
		// 设置客户卡号（可填手机号）
		expressOrder.setCustId(senderAddr.getTelphoneNo());
		// 设置客户编码（填手机号）
		expressOrder.setCustTag(senderAddr.getTelphoneNo());
		
		ContactAddrInfo recAddr = null;
		if(expressOrder.getRecAddrId() == null) {
			logger.info(String.format("addExpressOrder 收件人地址信息ID为空:%s", 
					logLabel));
			
			// 不是三合一电子运单
			expressOrder.setIsHhtWayBill(NumEmum.NO.toString());
		} else {
			logger.info(String.format("addExpressOrder 收件人地址信息ID不为空:%s", logLabel));
			recAddr = contactAddrInfoService.queryContactAddrInfoById(expressOrder.getRecAddrId());
			if(recAddr == null) {
				logger.error(String.format("addExpressOrder 收件人地址信息不存在:%s", expressOrder.getRecAddrId()));
				throw new ServiceException(MsgCode.REC_CONTACT_ADDR_INFO_ID_NOT_EXIST, 
						MsgCode.getValue(MsgCode.REC_CONTACT_ADDR_INFO_ID_NOT_EXIST) + String.format("【%s】", expressOrder.getRecAddrId()));
			}
			expressOrder.setDcontanct(recAddr.getContacts());
			expressOrder.setDcompany(recAddr.getCompany());
			expressOrder.setDtel(recAddr.getTelphoneNo());
			
			// 是三合一电子运单
			expressOrder.setIsHhtWayBill(NumEmum.YES.toString());
		}
		
		// 设置订单类型
		expressOrder.setOrderType(OrderType.DEFAULT_ORDER_TYPE.toString());
		// 设置客户类型,如果不传,则设置成非月结（0-非月结，1-月结）
		if(!NumEmum.NO.toString().equals(expressOrder.getCustType()) && !NumEmum.YES.toString().equals(expressOrder.getCustType())) {
			expressOrder.setCustType(NumEmum.NO.toString());
		} else {
			expressOrder.setCustType(expressOrder.getCustType());
		}
		
		logger.info(String.format("addExpressOrder 寄件人地址和收件人地址ID检查成功，开始检查地址中的区域ID是否都存在:%s", 
				logLabel));
		// 检查寄件人地址和收件人地址信息中的区域ID是否都存在
		TmNewDistrict senderProvince = tmNewDistrictService.queryTmNewDistrictByDistCode(senderAddr.getProvinceCode());
		if(senderProvince == null) {
			logger.error(String.format("addExpressOrder 寄件人地址省代码不存在:%s", senderAddr.getProvinceCode()));
			throw new ServiceException(MsgCode.PROVINCE_CODE_NOT_EXIST, "寄件人地址" + MsgCode.getValue(MsgCode.PROVINCE_CODE_NOT_EXIST));
		}
		expressOrder.setProvinceName(senderProvince.getDistCnName());
		TmNewDistrict senderCity = senderAddr.getProvinceCode().equals(senderAddr.getCityCode()) ? 
				senderProvince : tmNewDistrictService.queryTmNewDistrictByDistCode(senderAddr.getCityCode());
		if(senderCity == null) {
			logger.error(String.format("addExpressOrder 寄件人地址城市代码不存在:%s", senderAddr.getCityCode()));
			throw new ServiceException(MsgCode.CITY_CODE_NOT_EXIST, "寄件人地址" + MsgCode.getValue(MsgCode.CITY_CODE_NOT_EXIST));
		}
		// 设置寄件城市代码
		expressOrder.setAreaNo(senderCity.getDistCityCode() == null ? null : String.format("%1$3s", senderCity.getDistCityCode()).replaceAll(" ", "0"));
		expressOrder.setCityName(senderCity.getDistCnName());
		
		if(StringUtils.isNotBlank(senderAddr.getCountyCode())) {
			TmNewDistrict senderCounty = senderAddr.getCityCode().equals(senderAddr.getCountyCode()) ? 
					senderCity : tmNewDistrictService.queryTmNewDistrictByDistCode(senderAddr.getCountyCode());
			if(senderCounty == null) {
				logger.error(String.format("addExpressOrder 寄件人地址区/县代码不存在:%s %s", new Object[]{senderAddr.getCountyCode(), logLabel}));
				throw new ServiceException(MsgCode.COUNTY_CODE_NOT_EXIST, "寄件人地址" + MsgCode.getValue(MsgCode.COUNTY_CODE_NOT_EXIST));
			}
			expressOrder.setCountyName(senderCounty.getDistCnName());
		}
		
		// 收件人地址信息处理
		StringBuilder dAddress = null;
		TmNewDistrict recProvince = null, recCity = null, recCounty = null;
		if(recAddr != null) {
			dAddress = new StringBuilder();
			recProvince = tmNewDistrictService.queryTmNewDistrictByDistCode(recAddr.getProvinceCode());
			if(recProvince == null) {
				logger.error(String.format("addExpressOrder 收件人地址省代码不存在:%s %s", new Object[]{recAddr.getProvinceCode(), logLabel}));
				throw new ServiceException(MsgCode.PROVINCE_CODE_NOT_EXIST, "收件人地址" + MsgCode.getValue(MsgCode.PROVINCE_CODE_NOT_EXIST));
			}
			dAddress.append(recProvince.getDistCnName());
			recCity = recAddr.getProvinceCode().equals(recAddr.getCityCode()) ? 
					recProvince : tmNewDistrictService.queryTmNewDistrictByDistCode(recAddr.getCityCode());
			if(recCity == null) {
				logger.info(String.format("addExpressOrder 收件人地址城市代码不存在:%s %s", new Object[]{recAddr.getCityCode(), logLabel}));
				throw new ServiceException(MsgCode.CITY_CODE_NOT_EXIST, "收件人地址" + MsgCode.getValue(MsgCode.CITY_CODE_NOT_EXIST));
			}
			// 设置到件城市编码
			expressOrder.setDestinationCode(recCity.getDistCityCode() == null ? null : String.format("%1$3s", recCity.getDistCityCode()).replaceAll(" ", "0"));
			expressOrder.setDestination(recCity.getDistCnName());
			dAddress.append(recCity.getDistCnName());
			
			if(StringUtils.isNotBlank(recAddr.getCountyCode())) {
				recCounty = recAddr.getCityCode().equals(recAddr.getCountyCode()) ? 
						recCity : tmNewDistrictService.queryTmNewDistrictByDistCode(recAddr.getCountyCode());
				if(recCounty == null) {
					logger.info(String.format("addExpressOrder 收件人地址区县代码不存在:%s %s", new Object[]{recAddr.getCountyCode(), logLabel}));
					throw new ServiceException(MsgCode.COUNTY_CODE_NOT_EXIST, "收件人地址" + MsgCode.getValue(MsgCode.COUNTY_CODE_NOT_EXIST));
				}
				dAddress.append(recCounty.getDistCnName());
			}
			
			expressOrder.setDaddress(dAddress.append(recAddr.getAddress()).toString());
		}
		
		// 生成订单号
		logger.info(String.format("addExpressOrder 开始生成订单号:%s", logLabel));
		String orderId = getNewOrderNo();
		expressOrder.setOrderId(orderId);
		logger.info(String.format("addExpressOrder 订单号生成完毕:%s %s", new Object[]{orderId, logLabel}));
		
		// 将数据保存到数据库
		logger.info(String.format("addExpressOrder 开始将下单数据保存到数据库:%s", logLabel));
		expressOrderDao.addExpressOrder(expressOrder);
		logger.info(String.format("addExpressOrder 下单数据保存到数据库成功:%s", logLabel));
		
		logger.info(String.format("addExpressOrder 开始调用资科系统的下单调度任务:%s", logLabel));
		String result = null;
		try {
			result = orderServiceClient.orderNew2(expressOrder.getOrderId(), expressOrder.getAreaNo(), expressOrder.getDeptId(), 
				expressOrder.getTeamId(), expressOrder.getCustId(), expressOrder.getCustType(), 
				expressOrder.getContact(), expressOrder.getCompAbb(),  expressOrder.getProvinceName(), 
				expressOrder.getCityName(), expressOrder.getCountyName(), expressOrder.getAddrAbb(), expressOrder.getCustTel(), 
				expressOrder.getWeight() == null ? null : expressOrder.getWeight().toString(), 
				expressOrder.getLength() == null ? null : expressOrder.getLength().toString(), 
				expressOrder.getCargoType(), expressOrder.getCargoName(), expressOrder.getBookTime(), 
				expressOrder.getOrderType(), expressOrder.getMakeup(), expressOrder.getMemo(), expressOrder.getOperator(), 
				expressOrder.getAddressNo()/*地址编号已经不使用*/, expressOrder.getCustTag(), expressOrder.getSenderType(), 
				expressOrder.getDcontanct(), expressOrder.getDtel(), expressOrder.getDcompany(), expressOrder.getDaddress(), 
				expressOrder.getCargoNumber() == null ? null : expressOrder.getCargoNumber().toString(), 
				expressOrder.getCargoPiece() == null ? null : expressOrder.getCargoPiece().toString(), 
				expressOrder.getInsuranceAmount() == null ? null : expressOrder.getInsuranceAmount().toString(), 
				expressOrder.getPayMethod(), expressOrder.getDestinationCode(), 
				expressOrder.getMonthPayCustId(), expressOrder.getIsHhtWayBill(), expressOrder.getIsClaims(), 
				/*expressOrder.getBlackType()*/ "0", expressOrder.getCurrencyValue(), 
				expressOrder.getDestination(), expressOrder.getCouponsVerificationCode(), expressOrder.getCouponsNo(), 
				expressOrder.getCouponsAmount() == null ? null : expressOrder.getCouponsAmount().toString(), 
				Arrays.asList(expressOrder.getOrderArgs()));
		} catch (Exception e) {
			logger.error(String.format("addExpressOrder 资科系统的下单调度任务异常:%s {}", logLabel), e);
			throw new ServiceException(MsgCode.ORDER_SERVICE_EXCEPTION, MsgCode.getValue(MsgCode.ORDER_SERVICE_EXCEPTION));
		}
		
		logger.info(String.format("addExpressOrder 资科系统的下单调度任务返回结果:%s %s", new Object[]{result, logLabel}));
		
		return result;
	}

	/**
	 * 通过运单号来获取快件记录
	 * ExpressRecord 对象包含 快递状态、运单号、始发城市及目的城市、下单时间 等信息
	 * 
	 * @param wayBillNo 运单号
	 * @return
	 * @throws ServiceException 20014-ESB运单路由查询失败
	 */
	@Override
	public List<ExpressRecord> queryExpressRecordByWayBillNo(List<String> wayBillNo) throws ServiceException {
		logger.info(String.format("queryExpressRecordByWayBillNo start:%s ... ...", wayBillNo));
		List<ExpressRecord> expressRecordList = new ArrayList<ExpressRecord>();
		if(wayBillNo == null || wayBillNo.isEmpty()) {
			logger.info("queryExpressRecordByWayBillNo 需要查询的运单为空，直接返回");
			return expressRecordList;
		}
		
		List<WayBillRoute> wayBillRouteList = null;
		try {
			wayBillRouteList = wayBillRouteService.queryBillStandard(wayBillNo);
		} catch (Exception e) {
			logger.error(String.format("ESB运单路由【%s】查询异常：{}", wayBillNo), e);
			throw new ServiceException(MsgCode.ESB_ROUTE_QUERY_FAIL, MsgCode.getValue(MsgCode.ESB_ROUTE_QUERY_FAIL));
		}
		
		logger.info(String.format("queryExpressRecordByWayBillNo 【%s】的运单路由查询结果:【%s】", new Object[]{wayBillNo, wayBillRouteList}));
		if(wayBillRouteList == null || wayBillRouteList.isEmpty()) {
			logger.info(String.format("queryExpressRecordByWayBillNo 【%s】的运单路由查询结果为空，直接返回", wayBillNo));
			return expressRecordList;
		}
		
		for(WayBillRoute wayBillRoute : wayBillRouteList) {
			if(wayBillRoute.getBarList() == null || wayBillRoute.getBarList().isEmpty()) {
				logger.info(String.format("queryExpressRecordByWayBillNo 【%s】的运单路由barList为空，跳过该数据", wayBillRoute));
				continue ;
			}
			
			ExpressRecord expressRecord = new ExpressRecord();
			// 设置运单号
			expressRecord.setWaybillNo(wayBillRoute.getWaybillNo());
	
			// 设置寄件日期
			try {
				if(wayBillRoute.getSendTm() != null) {
					expressRecord.setOrderTime(DateUtils.formatDate(wayBillRoute.getSendTm(), DateUtils.DATE_FORMAT_TYPE2));
				}
			} catch (ParseException e) {
				logger.error(String.format("queryExpressRecordByWayBillNo 【%s】的运单路由格式化寄件日期错误：{}", wayBillRoute), e);
			}
			// 设置收件城市
			expressRecord.setRecCityName(wayBillRoute.getDestCityName());
			// 设置寄件城市
			expressRecord.setSenderCityName(wayBillRoute.getSourceCityName());
			
			// 将新增的运单记录放入List中
			expressRecordList.add(expressRecord);
			
			List<WaybillBarInfo> wayBillBarInfoList = wayBillRoute.getBarList();
			if(wayBillBarInfoList == null || wayBillBarInfoList.isEmpty()) {
				logger.info(String.format("queryExpressRecordByWayBillNo 运单路由信息【%s】中WaybillBarInfo信息为空", 
						wayBillRoute));
				continue ;
			}
			
			StringBuilder time = null;
			// 是否已签收
			boolean isSign = false;
			for(WaybillBarInfo waybillBarInfo : wayBillBarInfoList) {
				time = new StringBuilder();
				time.append(waybillBarInfo.getBarScanDt()).append(" ").append(waybillBarInfo.getBarScanTm());
				
				WayBillRecord wayBillRecord = new WayBillRecord();
				try {
					// 设置操作时间
					wayBillRecord.setDate(DateUtils.formatDate(time.toString(), DateUtils.DATE_FORMAT_TYPE2));
				} catch (ParseException e) {
					logger.info(String.format("queryExpressRecordByWayBillNo 【%s】的运单号中WaybillBarInfo【%s】日期格式化失败", 
							new Object[]{wayBillRoute.getWaybillNo(), waybillBarInfo}));
					continue ;
				}
				
				// 设置当前地址
				wayBillRecord.setAddress(waybillBarInfo.getDistName());
				// 设置当前操作
				wayBillRecord.setOperation(waybillBarInfo.getRemark());
				
				expressRecord.getWayBillRecordList().add(wayBillRecord);
				
				// 设置是否已签收
				if(!isSign && (signBarCode80.equals(waybillBarInfo.getOpCode()) || signBarCode8000.equals(waybillBarInfo.getOpCode()))) {
					isSign = true;
				}
			}
			
			// 设置运单状态
			if(isSign) {
				// 客户已签收
				expressRecord.setExpressStatus(ExpressStatus.SIGN.toString());
			} else {
				// 派件中
				expressRecord.setExpressStatus(ExpressStatus.TRANSIT.toString());
			}
			
		}
		
		logger.info(String.format("queryExpressRecordByWayBillNo end:【%s】【%s】", new Object[]{wayBillNo, expressRecordList}));
		return expressRecordList;
	}

	/**
	 * 通过ID来查询下单信息
	 * 
	 * @param id
	 * @return
	 */
	@Override
	public ExpressOrder queryExpressOrderById(Long id) {
		logger.info(String.format("queryExpressOrderById start:%s ... ...", id));
		if(id == null) {
			return null;
		}
		
		ExpressOrder expressOrder = expressOrderDao.queryExpressOrderById(id);
		
		logger.info(String.format("queryExpressOrderById end:%s", id));
		
		return expressOrder;
	}

	/**
	 * 通过订单号来查询下单信息
	 * 
	 * @param orderId
	 * @return
	 */
	@Override
	public ExpressOrder queryExpressOrderByOrderId(String orderId) {
		logger.info(String.format("queryExpressOrderByOrderId start:%s ... ...", orderId));
		if(orderId == null) {
			return null;
		}
		
		ExpressOrder expressOrder = expressOrderDao.queryExpressOrderByOrderId(orderId);
		
		logger.info(String.format("queryExpressOrderByOrderId end:%s", orderId));
		
		return expressOrder;
	}
	
	/**
	 * 生成一个新的订单号
	 * 订单号位30位，由我们自己生成，生成规则为：8位系统编码+14位日期+8位自增编号(这8位由数据库序列生成)
	 * @param memberNo
	 * @return
	 * @throws ServiceException 20016-生成订单号失败
	 */
	private String getNewOrderNo() throws ServiceException {
		logger.info("getNewOrderNo start:%s ... ...");
		
		Long seq = expressOrderDao.getNextOrderId();
		if(seq == null) {
			throw new ServiceException(MsgCode.ORDER_ID_GENERATION_FAIL, 
					MsgCode.getValue(MsgCode.ORDER_ID_GENERATION_FAIL));
		}
		
		logger.info(String.format("getNewOrderNo 生成的订单号的序列号为：:%s", seq));
		
		StringBuilder orderNo = new StringBuilder(ORDER_ID_PREFIX);
		orderNo.append(DateUtils.formatDate(DateUtils.DATE_FORMAT_TYPE1));
		orderNo.append(String.format("%1$08d", seq));
		
		logger.info(String.format("getNewOrderNo end 生成的订单号为:%s", orderNo.toString()));
		
		return orderNo.toString();
	}
	
}
