
package com.sfpay.datasync.order.webservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.sfpay.datasync.order.webservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DispAgentOrderResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "dispAgentOrderResponse");
    private final static QName _CssForOrderNew2Response_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "cssForOrderNew2Response");
    private final static QName _DispNewOrder_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "dispNewOrder");
    private final static QName _CssForOrderNewResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "cssForOrderNewResponse");
    private final static QName _SendOrderService_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "sendOrderService");
    private final static QName _OrderNew2_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "orderNew2");
    private final static QName _DispAgentOrder_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "dispAgentOrder");
    private final static QName _OrderNewResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "orderNewResponse");
    private final static QName _CssForOrderNew_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "cssForOrderNew");
    private final static QName _TransferOrderForHHT_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "transferOrderForHHT");
    private final static QName _HastenBillResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "hastenBillResponse");
    private final static QName _OrderNew_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "orderNew");
    private final static QName _SendOrderServiceResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "sendOrderServiceResponse");
    private final static QName _CssForOrderNew2_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "cssForOrderNew2");
    private final static QName _ChangeOrder_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "changeOrder");
    private final static QName _OrderNew2Response_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "orderNew2Response");
    private final static QName _AcceptOrder4HHTResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "acceptOrder4HHTResponse");
    private final static QName _CssForOrder_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "cssForOrder");
    private final static QName _DispNewOrderResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "dispNewOrderResponse");
    private final static QName _TransferOrderForHHTResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "transferOrderForHHTResponse");
    private final static QName _ChangeOrderResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "changeOrderResponse");
    private final static QName _AcceptOrder4HHT_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "acceptOrder4HHT");
    private final static QName _CssForOrderResponse_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "cssForOrderResponse");
    private final static QName _HastenBill_QNAME = new QName("http://biz.nos.schinterface.module.sf.com/", "hastenBill");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.sfpay.datasync.order.webservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link OrderNew2 }
     * 
     */
    public OrderNew2 createOrderNew2() {
        return new OrderNew2();
    }

    /**
     * Create an instance of {@link DispAgentOrder }
     * 
     */
    public DispAgentOrder createDispAgentOrder() {
        return new DispAgentOrder();
    }

    /**
     * Create an instance of {@link OrderNewResponse }
     * 
     */
    public OrderNewResponse createOrderNewResponse() {
        return new OrderNewResponse();
    }

    /**
     * Create an instance of {@link CssForOrderNew }
     * 
     */
    public CssForOrderNew createCssForOrderNew() {
        return new CssForOrderNew();
    }

    /**
     * Create an instance of {@link SendOrderService }
     * 
     */
    public SendOrderService createSendOrderService() {
        return new SendOrderService();
    }

    /**
     * Create an instance of {@link TransferOrderForHHT }
     * 
     */
    public TransferOrderForHHT createTransferOrderForHHT() {
        return new TransferOrderForHHT();
    }

    /**
     * Create an instance of {@link HastenBillResponse }
     * 
     */
    public HastenBillResponse createHastenBillResponse() {
        return new HastenBillResponse();
    }

    /**
     * Create an instance of {@link DispAgentOrderResponse }
     * 
     */
    public DispAgentOrderResponse createDispAgentOrderResponse() {
        return new DispAgentOrderResponse();
    }

    /**
     * Create an instance of {@link CssForOrderNew2Response }
     * 
     */
    public CssForOrderNew2Response createCssForOrderNew2Response() {
        return new CssForOrderNew2Response();
    }

    /**
     * Create an instance of {@link DispNewOrder }
     * 
     */
    public DispNewOrder createDispNewOrder() {
        return new DispNewOrder();
    }

    /**
     * Create an instance of {@link CssForOrderNewResponse }
     * 
     */
    public CssForOrderNewResponse createCssForOrderNewResponse() {
        return new CssForOrderNewResponse();
    }

    /**
     * Create an instance of {@link DispNewOrderResponse }
     * 
     */
    public DispNewOrderResponse createDispNewOrderResponse() {
        return new DispNewOrderResponse();
    }

    /**
     * Create an instance of {@link ChangeOrderResponse }
     * 
     */
    public ChangeOrderResponse createChangeOrderResponse() {
        return new ChangeOrderResponse();
    }

    /**
     * Create an instance of {@link TransferOrderForHHTResponse }
     * 
     */
    public TransferOrderForHHTResponse createTransferOrderForHHTResponse() {
        return new TransferOrderForHHTResponse();
    }

    /**
     * Create an instance of {@link HastenBill }
     * 
     */
    public HastenBill createHastenBill() {
        return new HastenBill();
    }

    /**
     * Create an instance of {@link AcceptOrder4HHT }
     * 
     */
    public AcceptOrder4HHT createAcceptOrder4HHT() {
        return new AcceptOrder4HHT();
    }

    /**
     * Create an instance of {@link CssForOrderResponse }
     * 
     */
    public CssForOrderResponse createCssForOrderResponse() {
        return new CssForOrderResponse();
    }

    /**
     * Create an instance of {@link ChangeOrder }
     * 
     */
    public ChangeOrder createChangeOrder() {
        return new ChangeOrder();
    }

    /**
     * Create an instance of {@link CssForOrderNew2 }
     * 
     */
    public CssForOrderNew2 createCssForOrderNew2() {
        return new CssForOrderNew2();
    }

    /**
     * Create an instance of {@link OrderNew }
     * 
     */
    public OrderNew createOrderNew() {
        return new OrderNew();
    }

    /**
     * Create an instance of {@link SendOrderServiceResponse }
     * 
     */
    public SendOrderServiceResponse createSendOrderServiceResponse() {
        return new SendOrderServiceResponse();
    }

    /**
     * Create an instance of {@link CssForOrder }
     * 
     */
    public CssForOrder createCssForOrder() {
        return new CssForOrder();
    }

    /**
     * Create an instance of {@link AcceptOrder4HHTResponse }
     * 
     */
    public AcceptOrder4HHTResponse createAcceptOrder4HHTResponse() {
        return new AcceptOrder4HHTResponse();
    }

    /**
     * Create an instance of {@link OrderNew2Response }
     * 
     */
    public OrderNew2Response createOrderNew2Response() {
        return new OrderNew2Response();
    }

    /**
     * Create an instance of {@link SchAgentordersTemp }
     * 
     */
    public SchAgentordersTemp createSchAgentordersTemp() {
        return new SchAgentordersTemp();
    }

    /**
     * Create an instance of {@link SchOrderDto }
     * 
     */
    public SchOrderDto createSchOrderDto() {
        return new SchOrderDto();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DispAgentOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "dispAgentOrderResponse")
    public JAXBElement<DispAgentOrderResponse> createDispAgentOrderResponse(DispAgentOrderResponse value) {
        return new JAXBElement<DispAgentOrderResponse>(_DispAgentOrderResponse_QNAME, DispAgentOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CssForOrderNew2Response }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "cssForOrderNew2Response")
    public JAXBElement<CssForOrderNew2Response> createCssForOrderNew2Response(CssForOrderNew2Response value) {
        return new JAXBElement<CssForOrderNew2Response>(_CssForOrderNew2Response_QNAME, CssForOrderNew2Response.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DispNewOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "dispNewOrder")
    public JAXBElement<DispNewOrder> createDispNewOrder(DispNewOrder value) {
        return new JAXBElement<DispNewOrder>(_DispNewOrder_QNAME, DispNewOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CssForOrderNewResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "cssForOrderNewResponse")
    public JAXBElement<CssForOrderNewResponse> createCssForOrderNewResponse(CssForOrderNewResponse value) {
        return new JAXBElement<CssForOrderNewResponse>(_CssForOrderNewResponse_QNAME, CssForOrderNewResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendOrderService }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "sendOrderService")
    public JAXBElement<SendOrderService> createSendOrderService(SendOrderService value) {
        return new JAXBElement<SendOrderService>(_SendOrderService_QNAME, SendOrderService.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderNew2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "orderNew2")
    public JAXBElement<OrderNew2> createOrderNew2(OrderNew2 value) {
        return new JAXBElement<OrderNew2>(_OrderNew2_QNAME, OrderNew2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DispAgentOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "dispAgentOrder")
    public JAXBElement<DispAgentOrder> createDispAgentOrder(DispAgentOrder value) {
        return new JAXBElement<DispAgentOrder>(_DispAgentOrder_QNAME, DispAgentOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderNewResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "orderNewResponse")
    public JAXBElement<OrderNewResponse> createOrderNewResponse(OrderNewResponse value) {
        return new JAXBElement<OrderNewResponse>(_OrderNewResponse_QNAME, OrderNewResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CssForOrderNew }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "cssForOrderNew")
    public JAXBElement<CssForOrderNew> createCssForOrderNew(CssForOrderNew value) {
        return new JAXBElement<CssForOrderNew>(_CssForOrderNew_QNAME, CssForOrderNew.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransferOrderForHHT }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "transferOrderForHHT")
    public JAXBElement<TransferOrderForHHT> createTransferOrderForHHT(TransferOrderForHHT value) {
        return new JAXBElement<TransferOrderForHHT>(_TransferOrderForHHT_QNAME, TransferOrderForHHT.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HastenBillResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "hastenBillResponse")
    public JAXBElement<HastenBillResponse> createHastenBillResponse(HastenBillResponse value) {
        return new JAXBElement<HastenBillResponse>(_HastenBillResponse_QNAME, HastenBillResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderNew }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "orderNew")
    public JAXBElement<OrderNew> createOrderNew(OrderNew value) {
        return new JAXBElement<OrderNew>(_OrderNew_QNAME, OrderNew.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendOrderServiceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "sendOrderServiceResponse")
    public JAXBElement<SendOrderServiceResponse> createSendOrderServiceResponse(SendOrderServiceResponse value) {
        return new JAXBElement<SendOrderServiceResponse>(_SendOrderServiceResponse_QNAME, SendOrderServiceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CssForOrderNew2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "cssForOrderNew2")
    public JAXBElement<CssForOrderNew2> createCssForOrderNew2(CssForOrderNew2 value) {
        return new JAXBElement<CssForOrderNew2>(_CssForOrderNew2_QNAME, CssForOrderNew2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangeOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "changeOrder")
    public JAXBElement<ChangeOrder> createChangeOrder(ChangeOrder value) {
        return new JAXBElement<ChangeOrder>(_ChangeOrder_QNAME, ChangeOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderNew2Response }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "orderNew2Response")
    public JAXBElement<OrderNew2Response> createOrderNew2Response(OrderNew2Response value) {
        return new JAXBElement<OrderNew2Response>(_OrderNew2Response_QNAME, OrderNew2Response.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AcceptOrder4HHTResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "acceptOrder4HHTResponse")
    public JAXBElement<AcceptOrder4HHTResponse> createAcceptOrder4HHTResponse(AcceptOrder4HHTResponse value) {
        return new JAXBElement<AcceptOrder4HHTResponse>(_AcceptOrder4HHTResponse_QNAME, AcceptOrder4HHTResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CssForOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "cssForOrder")
    public JAXBElement<CssForOrder> createCssForOrder(CssForOrder value) {
        return new JAXBElement<CssForOrder>(_CssForOrder_QNAME, CssForOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DispNewOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "dispNewOrderResponse")
    public JAXBElement<DispNewOrderResponse> createDispNewOrderResponse(DispNewOrderResponse value) {
        return new JAXBElement<DispNewOrderResponse>(_DispNewOrderResponse_QNAME, DispNewOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransferOrderForHHTResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "transferOrderForHHTResponse")
    public JAXBElement<TransferOrderForHHTResponse> createTransferOrderForHHTResponse(TransferOrderForHHTResponse value) {
        return new JAXBElement<TransferOrderForHHTResponse>(_TransferOrderForHHTResponse_QNAME, TransferOrderForHHTResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangeOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "changeOrderResponse")
    public JAXBElement<ChangeOrderResponse> createChangeOrderResponse(ChangeOrderResponse value) {
        return new JAXBElement<ChangeOrderResponse>(_ChangeOrderResponse_QNAME, ChangeOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AcceptOrder4HHT }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "acceptOrder4HHT")
    public JAXBElement<AcceptOrder4HHT> createAcceptOrder4HHT(AcceptOrder4HHT value) {
        return new JAXBElement<AcceptOrder4HHT>(_AcceptOrder4HHT_QNAME, AcceptOrder4HHT.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CssForOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "cssForOrderResponse")
    public JAXBElement<CssForOrderResponse> createCssForOrderResponse(CssForOrderResponse value) {
        return new JAXBElement<CssForOrderResponse>(_CssForOrderResponse_QNAME, CssForOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HastenBill }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://biz.nos.schinterface.module.sf.com/", name = "hastenBill")
    public JAXBElement<HastenBill> createHastenBill(HastenBill value) {
        return new JAXBElement<HastenBill>(_HastenBill_QNAME, HastenBill.class, null, value);
    }

}
