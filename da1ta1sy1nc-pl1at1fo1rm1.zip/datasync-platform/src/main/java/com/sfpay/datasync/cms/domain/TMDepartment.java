/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.datasync.cms.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;
import com.sfpay.framework.common.xml.dom4j.base.XElement;
import com.sfpay.framework.common.xml.dom4j.base.XmlBaseModel;
import com.sfpay.framework.common.xml.dom4j.base.XmlType;

/**
 * 
 * 类说明：
 * 
 * 
 * <p>
 * 详细描述：
 * 
 * 
 * @author 321302 程俊杰
 * 
 *         CreateDate: 2012-7-18
 */
@XElement(name = "department_to", clazz = TMDepartment.class)
public class TMDepartment extends BaseEntity implements XmlBaseModel {
	private static final long serialVersionUID = -4133957168572428318L;

	/**
	 * 机构ID
	 */
	@XElement(name = "dept_id", type = XmlType.ELEMENT, clazz = Long.class)
	private Long deptId;

	/**
	 * 所属分部编码
	 */
	@XElement(name = "division_code", type = XmlType.ELEMENT)
	private String divisionCode;

	/**
	 * 所属区部编码
	 */
	@XElement(name = "area_code", type = XmlType.ELEMENT)
	private String areaCode;

	/**
	 * 所属经营本部编码
	 */
	@XElement(name = "hq_code", type = XmlType.ELEMENT)
	private String hqCode;

	/**
	 * 机构类型ID
	 */
	@XElement(name = "type_code", type = XmlType.ELEMENT)
	private String typeCode;

	/**
	 * 机构名称
	 */
	@XElement(name = "dept_name", type = XmlType.ELEMENT)
	private String deptName;

	/**
	 * 机构编码-网络网点编号，例如：755A
	 */
	@XElement(name = "dept_code", type = XmlType.ELEMENT)
	private String deptCode;

	/**
	 * 描述
	 */
	@XElement(name = "dept_desc", type = XmlType.ELEMENT)
	private String deptDesc;

	/**
	 * 创建人
	 */
	@XElement(name = "created_emp_code", type = XmlType.ELEMENT)
	private String createEmpCode;

	/**
	 * 创建时间
	 */
	@XElement(name = "created_tm", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date createTm;

	/**
	 * 修改人
	 */
	@XElement(name = "modified_emp_code", type = XmlType.ELEMENT)
	private String modifiedEmpCode;

	/**
	 * 修改时间
	 */
	@XElement(name = "modified_tm", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedTm;

	/**
	 * 启用日期
	 */
	@XElement(name = "valid_dt", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date vaidDt;

	/**
	 * 币别编码
	 */
	@XElement(name = "currency_code", type = XmlType.ELEMENT)
	private String currencyCode;

	/**
	 * 行政区部编码
	 */
	@XElement(name = "dist_code", type = XmlType.ELEMENT)
	private String distCode;

	/**
	 * 电话
	 */
	@XElement(name = "tel_no", type = XmlType.ELEMENT)
	private String phoneNo;

	/**
	 * 传真
	 */
	@XElement(name = "fax_no", type = XmlType.ELEMENT)
	private String faxNo;

	/**
	 * 联系人名称
	 */
	@XElement(name = "contactor_name", type = XmlType.ELEMENT)
	private String contactorName;

	/**
	 * 是否已删除
	 */
	@XElement(name = "delete_flg", type = XmlType.ELEMENT, clazz = Boolean.class)
	private Boolean deleteFlag;

	/**
	 * 失效日期
	 */
	@XElement(name = "invalid_tm", type = XmlType.ELEMENT, clazz = Date.class, patten = "yyyy-MM-dd HH:mm:ss")
	private Date invalidTm;

	/**
	 * 是否配置服务器
	 */
	@XElement(name = "server_flg", type = XmlType.ELEMENT, clazz = Long.class)
	private Long serverFlg;

	/**
	 * 上级部门编码
	 */
	@XElement(name = "parent_dept_code", type = XmlType.ELEMENT)
	private String parentDeptCode;

	/**
	 * 类型层次
	 */
	@XElement(name = "type_level", type = XmlType.ELEMENT, clazz = Long.class)
	private Long typeLevel;

	/**
	 * 所属账套编号
	 */
	@XElement(name = "account_code", type = XmlType.ELEMENT)
	private String accountCode;

	/**
	 * 官网名称（对外名称）
	 */
	private String outsideName;

	/**
	 * 删除日期
	 */
	private Date delDate;

	/**
	 * 城市代码
	 */
	private String cityCode;

	/**
	 * 机构地址
	 */
	private String deptAddr;

	/**
	 * 邮编
	 */
	private String postalCode;

	/**
	 * 对外英文名称
	 */
	private String outsideNameEn;

	/**
	 * 对账邮箱地址
	 */
	private String emailAddr;

	/**
	 * 所属区/县/镇
	 */
	private String belongCounty;

	/**
	 * 所属乡/镇
	 */
	private String belongVillage;

	/**
	 * 时区:GMT+-12
	 */
	@XElement(name = "dept_gmt", type = XmlType.ELEMENT, clazz = Long.class)
	private Long deptGmt;

	/**
	 * 顺丰店序列号
	 */
	private Long shopCode;

	/**
	 * 数据版本号
	 */
	private Long versionId;

	@Override
	public boolean hasChildren() {
		return true;
	}

	public Long getDeptId() {
		return deptId;
	}

	public void setDeptId(Long deptId) {
		this.deptId = deptId;
	}

	public String getDivisionCode() {
		return divisionCode;
	}

	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getHqCode() {
		return hqCode;
	}

	public void setHqCode(String hqCode) {
		this.hqCode = hqCode;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getDeptDesc() {
		return deptDesc;
	}

	public void setDeptDesc(String deptDesc) {
		this.deptDesc = deptDesc;
	}

	public String getCreateEmpCode() {
		return createEmpCode;
	}

	public void setCreateEmpCode(String createEmpCode) {
		this.createEmpCode = createEmpCode;
	}

	public Date getCreateTm() {
		return createTm!=null?(Date) createTm.clone():null;
	}

	public void setCreateTm(Date createTm) {
		this.createTm = createTm!=null?(Date) createTm.clone():null;
	}

	public String getModifiedEmpCode() {
		return modifiedEmpCode;
	}

	public void setModifiedEmpCode(String modifiedEmpCode) {
		this.modifiedEmpCode = modifiedEmpCode;
	}

	public Date getModifiedTm() {
		return modifiedTm != null ? (Date) modifiedTm.clone() : null;
	}

	public void setModifiedTm(Date modifiedTm) {
		this.modifiedTm = modifiedTm != null ? (Date) modifiedTm.clone() : null;
	}

	public Date getVaidDt() {
		return vaidDt != null ? (Date) vaidDt.clone() : null;
	}

	public void setVaidDt(Date vaidDt) {
		this.vaidDt =vaidDt!=null?(Date)vaidDt.clone():null;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getDistCode() {
		return distCode;
	}

	public void setDistCode(String distCode) {
		this.distCode = distCode;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getContactorName() {
		return contactorName;
	}

	public void setContactorName(String contactorName) {
		this.contactorName = contactorName;
	}

	public Boolean getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(Boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public Date getInvalidTm() {
		return invalidTm!=null?(Date)invalidTm.clone():null;
	}

	public void setInvalidTm(Date invalidTm) {
		this.invalidTm = invalidTm!=null?(Date)invalidTm.clone():null;
	}

	public Long getServerFlg() {
		return serverFlg;
	}

	public void setServerFlg(Long serverFlg) {
		this.serverFlg = serverFlg;
	}

	public String getParentDeptCode() {
		return parentDeptCode;
	}

	public void setParentDeptCode(String parentDeptCode) {
		this.parentDeptCode = parentDeptCode;
	}

	public Long getTypeLevel() {
		return typeLevel;
	}

	public void setTypeLevel(Long typeLevel) {
		this.typeLevel = typeLevel;
	}

	public String getAccountCode() {
		return accountCode;
	}

	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	public String getOutsideName() {
		return outsideName;
	}

	public void setOutsideName(String outsideName) {
		this.outsideName = outsideName;
	}

	public Date getDelDate() {
		return delDate!=null?(Date)delDate.clone():null;
	}

	public void setDelDate(Date delDate) {
		this.delDate = delDate!=null?(Date)delDate.clone():null;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getDeptAddr() {
		return deptAddr;
	}

	public void setDeptAddr(String deptAddr) {
		this.deptAddr = deptAddr;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getOutsideNameEn() {
		return outsideNameEn;
	}

	public void setOutsideNameEn(String outsideNameEn) {
		this.outsideNameEn = outsideNameEn;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getBelongCounty() {
		return belongCounty;
	}

	public void setBelongCounty(String belongCounty) {
		this.belongCounty = belongCounty;
	}

	public String getBelongVillage() {
		return belongVillage;
	}

	public void setBelongVillage(String belongVillage) {
		this.belongVillage = belongVillage;
	}

	public Long getDeptGmt() {
		return deptGmt;
	}

	public void setDeptGmt(Long deptGmt) {
		this.deptGmt = deptGmt;
	}

	public Long getShopCode() {
		return shopCode;
	}

	public void setShopCode(Long shopCode) {
		this.shopCode = shopCode;
	}

	public Long getVersionId() {
		return versionId;
	}

	public void setVersionId(Long versionId) {
		this.versionId = versionId;
	}
}
