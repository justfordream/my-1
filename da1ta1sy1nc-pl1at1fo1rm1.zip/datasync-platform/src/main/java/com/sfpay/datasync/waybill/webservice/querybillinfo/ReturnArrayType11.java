
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>returnArrayType_11 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="returnArrayType_11">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeAddr" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeContName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseePhone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}cageCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}currencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}feeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}storeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "returnArrayType_11", propOrder = {
    "addresseeAddr",
    "addresseeContName",
    "addresseePhone",
    "cageCode",
    "currencyCode",
    "feeAmt",
    "storeCode",
    "waybillNo"
})
public class ReturnArrayType11 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeAddr;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeContName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseePhone;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String cageCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String currencyCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double feeAmt;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String storeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String waybillNo;

    /**
     * ��ȡaddresseeAddr���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeAddr() {
        return addresseeAddr;
    }

    /**
     * ����addresseeAddr���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeAddr(String value) {
        this.addresseeAddr = value;
    }

    /**
     * ��ȡaddresseeContName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeContName() {
        return addresseeContName;
    }

    /**
     * ����addresseeContName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeContName(String value) {
        this.addresseeContName = value;
    }

    /**
     * ��ȡaddresseePhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseePhone() {
        return addresseePhone;
    }

    /**
     * ����addresseePhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseePhone(String value) {
        this.addresseePhone = value;
    }

    /**
     * ��ȡcageCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCageCode() {
        return cageCode;
    }

    /**
     * ����cageCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCageCode(String value) {
        this.cageCode = value;
    }

    /**
     * ��ȡcurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * ����currencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * ��ȡfeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getFeeAmt() {
        return feeAmt;
    }

    /**
     * ����feeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setFeeAmt(Double value) {
        this.feeAmt = value;
    }

    /**
     * ��ȡstoreCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoreCode() {
        return storeCode;
    }

    /**
     * ����storeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoreCode(String value) {
        this.storeCode = value;
    }

    /**
     * ��ȡwaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaybillNo() {
        return waybillNo;
    }

    /**
     * ����waybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaybillNo(String value) {
        this.waybillNo = value;
    }

}
