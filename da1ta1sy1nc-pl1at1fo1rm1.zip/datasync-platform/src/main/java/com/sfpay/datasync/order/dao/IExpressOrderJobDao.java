/**
 * 
 */
package com.sfpay.datasync.order.dao;

import java.util.List;

import com.sfpay.datasync.order.domain.ExpressOrderJob;

/**
 * 类说明：全网订单作业DAO
 *
 * 类描述：全网订单作业DAO
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IExpressOrderJobDao {
	/**
	 * 新增全网订单作业
	 * @param expressOrderJob
	 */
	public void addExpressOrderJob(ExpressOrderJob expressOrderJob);
	
	/**
	 * 通过参数来查询全网订单作业
	 * 目前可用参数为jobId、orderId、bno
	 * @param expressOrderJob
	 * @return
	 */
	public List<ExpressOrderJob> queryExpressOrderJobByParam(ExpressOrderJob expressOrderJob);
	
	/**
	 * 通过ID来查询全网订单作业
	 * @param id
	 * @return
	 */
	public ExpressOrderJob queryExpressOrderJobById(Long id);
	
	/**
	 * 通过运单号来查询全网订单作业
	 * @param wayBillNo
	 * @return
	 */
	public List<ExpressOrderJob> queryExpressOrderJobByWayBillNo(String wayBillNo);
	
	
}
