/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.datasync.constant.MsgCode;
import com.sfpay.datasync.order.dao.IContactAddrInfoDao;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.domain.TmNewDistrict;
import com.sfpay.datasync.order.enums.AddressType;
import com.sfpay.datasync.order.enums.DefaultFlag;
import com.sfpay.datasync.order.enums.Used;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.datasync.order.service.ITmNewDistrictService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：联系人（寄件/收件）地址信息服务接口实现类
 *
 * 类描述：如果会员的第一个（寄件或收件）地址需要自动设置成默认地址
 * @author 625288 易振强
 * 2014-11-12
 */
@HessianExporter
@Service("contactAddrInfoService")
public class ContactAddrInfoServiceImpl implements IContactAddrInfoService {
	@Autowired
	private IContactAddrInfoDao contactAddrInfoDao;
	@Autowired
	private ITmNewDistrictService tmNewDistrictService;
	
	private static final Logger logger = LoggerFactory.getLogger(ContactAddrInfoServiceImpl.class);
	
	/**
	 * 新增联系人（寄件人/收件人）地址信息
	 * 注意，如果会员的第一个（寄件或收件）地址需要自动设置成默认地址
	 * @param contactAddrInfo
	 * @return	id主键
	 * @throws ServiceException 20027-联系人地址信息不能为空 20020-联系人地址信息数据校验失败 20040-省代码不存在 20041-市代码不存在 20042-区/县代码不存在
	 * 20021-区域代码不存在  20027-ContactAddrInfo不能为空
	 */
	@Override
	public Long addContactAddrInfo(ContactAddrInfo contactAddrInfo)
			throws ServiceException {
		logger.info(String.format("addContactAddrInfo start:%s ... ...", contactAddrInfo));
		
		// 数据检查
		String checkResult = dataCheck(contactAddrInfo);
		if(StringUtils.isNotBlank(checkResult)) {
			logger.error(String.format("addContactAddrInfo 数据校验失败:%s", contactAddrInfo));
			throw new ServiceException(checkResult, MsgCode.getValue(checkResult));
		}
		
		logger.info(String.format("addContactAddrInfo 数据校验通过:%s", contactAddrInfo));
		
		List<ContactAddrInfo> contactAddrInfoList = queryAddressInfo(contactAddrInfo.getMemberNo(), contactAddrInfo.getAddressType());
		// 如果该会员该地址类型还没有地址数据，则把新增的这个作为默认地址
//		if(contactAddrInfoList == null || contactAddrInfoList.isEmpty()) {
//			logger.info(String.format("addContactAddrInfo 会员该地址类型中没有地址，自动将新增的该地址设置成默认地址:%s", contactAddrInfo));
//			contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
		
		// 如果新增的这个地址是默认地址，且该会员该地址类型还有其他默认地址，把其他默认地址设置成非默认地址
//		} else 
		
		if(DefaultFlag.DEFAULT.toString().equals(contactAddrInfo.getDefaultFlag())) {
			for(ContactAddrInfo contactAddrInfoTemp : contactAddrInfoList) {
				if(DefaultFlag.DEFAULT.toString().equals(contactAddrInfoTemp.getDefaultFlag())) {
					contactAddrInfoTemp.setDefaultFlag(DefaultFlag.NOTDEFAULT.toString());
					contactAddrInfoDao.updateAddressInfo(contactAddrInfoTemp);
					logger.info(String.format("addContactAddrInfo 会员设置了新的默认地址，该地址自动设置成非默认地址:%s %s", 
							new Object[]{contactAddrInfo, contactAddrInfoTemp}));
				}
			}
		}
		
		contactAddrInfoDao.addContactAddrInfo(contactAddrInfo);
		
		logger.info(String.format("addContactAddrInfo end:%s", contactAddrInfo));
		return contactAddrInfo.getId();
	}

	/**
	 * 删除联系人（寄件人/收件人）地址信息
	 * 这里只做假删除，将isUsed设置为0，即使它是默认地址，也可以假删除
	 * @param contactAddrInfoId		联系人（寄件人/收件人）地址信息ID
	 * @throws ServiceException 20029-联系人地址信息ID不能为空 20022-联系地址信息ID不存在
	 */
	@Override
	public void delContactAddrInfo(Long contactAddrInfoId)
			throws ServiceException {
		logger.info(String.format("delContactAddrInfo start:%s ... ...", contactAddrInfoId));
		
		unusedContactAddrInfo(contactAddrInfoId);
		
		logger.info(String.format("delContactAddrInfo end:%s", contactAddrInfoId));
	}
	
	/**
	 * 删除联系人（寄件人/收件人）地址信息
	 * 这里只做假删除，将IS_USED设置为0
	 * @param contactAddrInfoId		联系人（寄件人/收件人）地址信息ID
	 * @param newDefaultAddrId 		如果删除的是默认寄件人地址，则该参数表示新的默认寄件人地址
	 * @throws ServiceException 20029-联系人地址信息ID不能为空 20022-联系地址信息ID不存在
	 */
	@Override
	public void delContactAddrInfo(Long contactAddrInfoId, Long newDefaultAddrId) throws ServiceException {
		logger.info(String.format("delContactAddrInfo start:%s %s... ...", 
				new Object[]{contactAddrInfoId, newDefaultAddrId}));
		// 先删除该联系人地址信息
		ContactAddrInfo contactAddrInfo = unusedContactAddrInfo(contactAddrInfoId);
		
		// 如果是默认的寄件人地址，则需要设置新的默认寄件人地址
		if(AddressType.SENDER.getValue().equals(contactAddrInfo.getAddressType()) && 
				DefaultFlag.DEFAULT.getValue().equals(contactAddrInfo.getDefaultFlag()) && newDefaultAddrId != null) {
			ContactAddrInfo newDefaultContactAddr = contactAddrInfoDao.queryAddressInfoById(newDefaultAddrId);
			if(newDefaultContactAddr == null) {
				logger.error("delContactAddrInfo 设置新的默认地址失败，联系人地址ID【{}】不存在！", newDefaultAddrId);
				return ;
			}
			
			// 如果新的默认地址不是寄件人地址，则设置失败
			if(!AddressType.SENDER.getValue().equals(contactAddrInfo.getAddressType())) {
				logger.error("delContactAddrInfo 设置新的默认地址失败，联系人地址【{}】的地址类型不是寄件人地址！", newDefaultAddrId);
			} else {
				try {
					newDefaultContactAddr.setDefaultFlag(DefaultFlag.DEFAULT.getValue());
					contactAddrInfoDao.updateAddressInfo(newDefaultContactAddr);
					logger.info("delContactAddrInfo 设置新的默认寄件人地址【{}】成功！", newDefaultAddrId);
				} catch (Exception e) {
					logger.error("delContactAddrInfo 设置新的默认寄件人地址【{}】异常：", newDefaultAddrId, e);
				}
				
			}
			
		}
		
		logger.info(String.format("delContactAddrInfo end:%s %s... ...", 
				new Object[]{contactAddrInfoId, newDefaultAddrId}));
		
	}
	
	private ContactAddrInfo unusedContactAddrInfo(Long contactAddrInfoId) {
		if(contactAddrInfoId == null) {
			throw new ServiceException(MsgCode.CONTACT_ADDR_INFO_ID_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.CONTACT_ADDR_INFO_ID_CAN_NOT_EMPTY));
		}
		
		ContactAddrInfo contactAddrInfo = contactAddrInfoDao.queryAddressInfoById(contactAddrInfoId);
		if(contactAddrInfo == null) {
			logger.error(String.format("delContactAddrInfo 联系人地址信息ID不存在:%s", contactAddrInfoId));
			throw new ServiceException(MsgCode.CONTACT_ADDR_INFO_ID_NOT_EXIST, 
					MsgCode.getValue(MsgCode.CONTACT_ADDR_INFO_ID_NOT_EXIST));
		}
		
		// 设置状态为不可用
		contactAddrInfo.setIsUsed(Used.UNUSED.getValue());
		contactAddrInfoDao.updateAddressInfo(contactAddrInfo);
		
		return contactAddrInfo;
	}

	/**
	 * 更新联系人（寄件人/收件人）地址信息
	 * 
	 * @param contactAddrInfo
	 * @throws ServiceException
	 * 20021-区域代码不存在 20024-联系人地址信息ID不存在 20027-联系人地址信息不能为空 20027-联系人地址信息不能为空 
	 * 20020-联系人地址信息数据校验失败 20040-省代码不存在 20041-市代码不存在 20042-区/县代码不存在
	 */
	@Override
	public void updateAddressInfo(ContactAddrInfo contactAddrInfo)
			throws ServiceException {
		logger.info(String.format("updateAddressInfo start:%s ... ...", contactAddrInfo));
		if(contactAddrInfo == null) {
			logger.error("updateAddressInfo ContactAddrInfo为空");
			throw new ServiceException(MsgCode.CONTACT_ADDR_INFO_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.CONTACT_ADDR_INFO_CAN_NOT_EMPTY));
		}
		
		ContactAddrInfo oldContactAddrInfo = contactAddrInfoDao.queryAddressInfoById(contactAddrInfo.getId());
		if(oldContactAddrInfo == null) {
			logger.error(String.format("updateAddressInfo 联系人地址信息ID不存在:%s", contactAddrInfo));
			throw new ServiceException(MsgCode.CONTACT_ADDR_INFO_ID_NOT_EXIST, 
					MsgCode.getValue(MsgCode.CONTACT_ADDR_INFO_ID_NOT_EXIST));
		}
		
		// 校验数据是否完整
		String checkResult = dataCheck(contactAddrInfo);
		if(StringUtils.isNotBlank(checkResult)) {
			logger.error(String.format("updateAddressInfo 校验数据失败:%s", contactAddrInfo));
			throw new ServiceException(checkResult, MsgCode.getValue(checkResult));
		}
		
		// 如果是要设置成默认地址，则需要取消其他的默认地址
		if(DefaultFlag.DEFAULT.toString().equals(contactAddrInfo.getDefaultFlag())) {
			cancelOtherDefaultAddr(contactAddrInfo.getMemberNo(), contactAddrInfo.getAddressType(), contactAddrInfo.getId());
		}
		
		// 如果是寄件人且修改了地址信息,则把单元区域置空
		if(AddressType.SENDER.toString().equals(contactAddrInfo.getAddressType()) 
				&& (!StringUtils.equals(contactAddrInfo.getAddress(), oldContactAddrInfo.getAddress()) || 
						!StringUtils.equals(contactAddrInfo.getProvinceCode(), oldContactAddrInfo.getProvinceCode()) ||
						!StringUtils.equals(contactAddrInfo.getCityCode(), oldContactAddrInfo.getCityCode()) ||
						!StringUtils.equals(contactAddrInfo.getCountyCode(), oldContactAddrInfo.getCountyCode()))) {
			contactAddrInfo.setTeamId(null);
		}
		
		contactAddrInfoDao.updateAddressInfo(contactAddrInfo);
		
		logger.info(String.format("updateAddressInfo end 更新数据成功:%s", contactAddrInfo));
	}

	/**
	 * 通过会员号和类型（寄件/收件）来查询联系人地址信息列表
	 * 
	 * @param memberNo
	 * @param addressType 	SENDER-寄件人地址，RECEIVER-收件人地址
	 * @throws ServiceException 20011-会员号不能为空 20025-地址类型不能为空 20026-地址类型不正确
	 */
	@Override
	public List<ContactAddrInfo> queryAddressInfo(Long memberNo,
			String addressType) throws ServiceException {
		logger.info(String.format("queryAddressInfo start:%s %s... ...", new Object[]{memberNo, addressType}));
		if(memberNo == null) {
			logger.error("queryAddressInfo 会员号不能为空");
			throw new ServiceException(MsgCode.MEMBER_NO_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.MEMBER_NO_CAN_NOT_EMPTY));
		}
		
		if(StringUtils.isBlank(addressType)) {
			logger.error("queryAddressInfo 地址类型不能为空");
			throw new ServiceException(MsgCode.ADDRESS_TYPE_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.ADDRESS_TYPE_CAN_NOT_EMPTY));
		}
		
		if(!AddressType.RECEIVER.getValue().equals(addressType) && !AddressType.SENDER.getValue().equals(addressType)) {
			logger.error(String.format("queryAddressInfo 地址类型不正确:%s %s", new Object[]{memberNo, addressType}));
			throw new ServiceException(MsgCode.ADDRESS_TYPE_ERROR, 
					MsgCode.getValue(MsgCode.ADDRESS_TYPE_ERROR));
		}
		
		ContactAddrInfo queryContactAddrInfo = new ContactAddrInfo();
		queryContactAddrInfo.setMemberNo(memberNo);
		queryContactAddrInfo.setAddressType(addressType);
		List<ContactAddrInfo> contactAddrInfoList = contactAddrInfoDao.queryAddressInfoByParam(queryContactAddrInfo);
			
		logger.info(String.format("queryAddressInfo end:%s %s", new Object[]{memberNo, addressType}));	
		return contactAddrInfoList;
	}

	/**
	 * 将该ID的联系人地址信息设置成默认的（寄件或收件）地址
	 * 
	 * @throws ServiceException 20029-联系人地址信息ID不能为空 20022-联系地址信息ID不存在
	 * @param defaultContactAddrInfoId 
	 */
	@Override
	public void setDefaultAddressInfo(Long defaultContactAddrInfoId)
			throws ServiceException {
		logger.info(String.format("setDefaultAddressInfo start:%s ... ...", defaultContactAddrInfoId));
		if(defaultContactAddrInfoId == null) {
			logger.error("setDefaultAddressInfo 联系人地址信息ID不能为空");
			throw new ServiceException(MsgCode.CONTACT_ADDR_INFO_ID_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.CONTACT_ADDR_INFO_ID_CAN_NOT_EMPTY));
		}
		
		ContactAddrInfo contactAddrInfo = contactAddrInfoDao.queryAddressInfoById(defaultContactAddrInfoId);
		if(contactAddrInfo == null) {
			logger.error(String.format("setDefaultAddressInfo 联系人地址信息ID不存在:%s", defaultContactAddrInfoId));
			throw new ServiceException(MsgCode.CONTACT_ADDR_INFO_ID_NOT_EXIST, 
					MsgCode.getValue(MsgCode.CONTACT_ADDR_INFO_ID_NOT_EXIST));
		}
		
		// 先查找是否有其他地址已经被设置成默认地址,如果有，则取消这些地址的默认状态
		cancelOtherDefaultAddr(contactAddrInfo.getMemberNo(), contactAddrInfo.getAddressType(), defaultContactAddrInfoId);
		
		// 开始设置新的默认地址
		if(DefaultFlag.DEFAULT.toString().equals(contactAddrInfo.getDefaultFlag())) {
			logger.info(String.format("setDefaultAddressInfo end 该地址已经是默认地址，返回:%s", contactAddrInfo));
		} else {
			contactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.toString());
			contactAddrInfoDao.updateAddressInfo(contactAddrInfo);
			logger.info(String.format("setDefaultAddressInfo 设置新的默认地址成功:%s", contactAddrInfo));
		}
		
		logger.info(String.format("setDefaultAddressInfo end:%s", defaultContactAddrInfoId));
	}

	/**
	 * 获取某会员的（收件/寄件）默认地址
	 * 
	 * @param memberNo	会员号
	 * @param addressType	默认地址类型  SENDER-寄件人地址，RECEIVER-收件人地址
	 * @return
	 * @throws ServiceException 20011-会员号不能为空 20025-地址类型不能为空 20026-地址类型不正确
	 */
	@Override
	public ContactAddrInfo queryDefaultAddress(Long memberNo, String addressType)
			throws ServiceException {
		logger.info(String.format("getDefaultAddress start:%s %s... ...", new Object[]{memberNo, addressType}));
		if(memberNo == null) {
			throw new ServiceException(MsgCode.MEMBER_NO_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.MEMBER_NO_CAN_NOT_EMPTY));
		}
		
		if(StringUtils.isBlank(addressType)) {
			throw new ServiceException(MsgCode.ADDRESS_TYPE_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.ADDRESS_TYPE_CAN_NOT_EMPTY));
		}
		
		if(!AddressType.RECEIVER.getValue().equals(addressType) && !AddressType.SENDER.getValue().equals(addressType)) {
			logger.info(String.format("getDefaultAddress 地址类型不正确:%s %s", new Object[]{memberNo, addressType}));
			throw new ServiceException(MsgCode.ADDRESS_TYPE_ERROR, 
					MsgCode.getValue(MsgCode.ADDRESS_TYPE_ERROR));
		}
		
		ContactAddrInfo queryContactAddrInfo = new ContactAddrInfo();
		queryContactAddrInfo.setMemberNo(memberNo);
		queryContactAddrInfo.setAddressType(addressType);
		queryContactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.getValue());
		List<ContactAddrInfo> resultList = contactAddrInfoDao.queryAddressInfoByParam(queryContactAddrInfo);
		
		if(resultList == null || resultList.isEmpty()) {
			logger.info(String.format("getDefaultAddress 找不到默认地址数据:%s %s", new Object[]{memberNo, addressType}));
			return null;
		} else if(resultList.size() > 1) {
			logger.warn(String.format("getDefaultAddress 找到的默认地址数据不止一条:%s %s %s", 
					new Object[]{memberNo, addressType, resultList}));
		}
		
		logger.info(String.format("getDefaultAddress end:%s %s", new Object[]{memberNo, addressType}));
		return resultList.get(0);
	}
	
	/**
	 * 数据检查
	 * @param contactAddrInfo
	 * @return 20027-联系人地址信息不能为空 20020-联系人地址信息数据校验失败 20040-省代码不存在 20041-市代码不存在 20042-区/县代码不存在
	 */
	private String dataCheck(ContactAddrInfo contactAddrInfo) {
		logger.info(String.format("dataCheck start:%s... ...", contactAddrInfo));
		
		if(contactAddrInfo == null) {
			logger.error("dataCheck ContactAddrInfo为空");
			return MsgCode.CONTACT_ADDR_INFO_CAN_NOT_EMPTY;
		}
		
		// 校验数据是否完整
		if(contactAddrInfo.getMemberNo() == null || StringUtils.isBlank(contactAddrInfo.getProvinceCode()) ||
				StringUtils.isBlank(contactAddrInfo.getCityCode()) || StringUtils.isBlank(contactAddrInfo.getAddress()) || 
				StringUtils.isBlank(contactAddrInfo.getTelphoneNo()) || StringUtils.isBlank(contactAddrInfo.getContacts())) {
			logger.error(String.format("ContactAddrInfo数据不完整，校验失败:%s", contactAddrInfo));
			return MsgCode.CONTACT_ADDR_INFO_CHECK_FAIL;
		}
		
		// 省代码是否存在
		TmNewDistrict provinceDistrict = tmNewDistrictService.queryTmNewDistrictByDistCode(contactAddrInfo.getProvinceCode());
		if(provinceDistrict == null) {
			logger.error(String.format("dataCheck 省代码不存在:%s", contactAddrInfo));
			return MsgCode.PROVINCE_CODE_NOT_EXIST;
		}
		
		// 市代码是否存在
		TmNewDistrict cityDistrict = contactAddrInfo.getProvinceCode().equals(contactAddrInfo.getCityCode()) ?
				provinceDistrict : tmNewDistrictService.queryTmNewDistrictByDistCode(contactAddrInfo.getCityCode());
		if(cityDistrict == null) {
			logger.error(String.format("dataCheck 市代码不存在:%s", contactAddrInfo));
			return MsgCode.CITY_CODE_NOT_EXIST;
		} else {
			// 设置城市编码
			contactAddrInfo.setDistCityCode(cityDistrict.getDistCityCode() == null ? null : 
				String.format("%1$3s", cityDistrict.getDistCityCode()).replaceAll(" ", "0"));
		}
		
		// 区县代码如果不为空,则必须存在
		if(StringUtils.isNotBlank(contactAddrInfo.getCountyCode())) {
			if(!contactAddrInfo.getCountyCode().equals(contactAddrInfo.getCityCode()) && 
					tmNewDistrictService.queryTmNewDistrictByDistCode(contactAddrInfo.getCountyCode()) == null) {
				logger.error(String.format("dataCheck 区/县代码不存在:%s", contactAddrInfo));
				return MsgCode.COUNTY_CODE_NOT_EXIST;
			}
		}
		
		logger.info(String.format("dataCheck 数据校验成功:%s", contactAddrInfo));
		
		return null;
	}

	/**
	 * 通过ID来查询联系人（收件/寄件）地址信息
	 * 
	 * @param id
	 * @return
	 */
	@Override
	public ContactAddrInfo queryContactAddrInfoById(Long id) {
		logger.info(String.format("queryContactAddrInfoById start:%s ... ...", id));
		if(id == null) {
			return null;
		}
		
		ContactAddrInfo contactAddrInfo = contactAddrInfoDao.queryAddressInfoById(id);
		
		logger.info(String.format("queryContactAddrInfoById start:%s ... ...", id));
		return contactAddrInfo;
	}

	/**
	 * 通过参数来查询联系人地址信息列表
	 * 目前只支持memberNo、addressType、defaultFlag、cityId和address来查询
	 * 
	 * @param contactAddrInfo
	 */
	@Override
	public List<ContactAddrInfo> queryAddressInfoByParam(
			ContactAddrInfo contactAddrInfo) {
		logger.info(String.format("queryAddressInfoByParam start:%s ... ...", contactAddrInfo));
		if(contactAddrInfo == null) {
			return null;
		}
		
		List<ContactAddrInfo> result = contactAddrInfoDao.queryAddressInfoByParam(contactAddrInfo);
		
		logger.info(String.format("queryAddressInfoByParam end:%s", contactAddrInfo));
		return result;
	}
	
	/**
	 * 取消某会员某地址类型的其他默认地址
	 * @param memberNo 会员号
	 * @param addressType 地址类型
	 * @param newDefaultAddrId 新的默认地址ID
	 */
	private void cancelOtherDefaultAddr(Long memberNo, String addressType, Long newDefaultAddrId) {
		logger.info(String.format("cancelOtherDefaultAddr start:%s %s %s ... ...", 
				new Object[]{memberNo, addressType, newDefaultAddrId}));
		// 先查找是否有其他地址已经被设置成默认地址
		ContactAddrInfo queryContactAddrInfo = new ContactAddrInfo();
		queryContactAddrInfo.setMemberNo(memberNo);
		queryContactAddrInfo.setAddressType(addressType);
		queryContactAddrInfo.setDefaultFlag(DefaultFlag.DEFAULT.getValue());
		List<ContactAddrInfo> resultList = contactAddrInfoDao.queryAddressInfoByParam(queryContactAddrInfo);
		
		// 虽然默认地址一般只有一个，但也不排除多个的情况
		if(resultList != null && !resultList.isEmpty()) {
			// 如果有其他地址被设置成默认地址，则先取消其他地址的默认地址状态
			logger.info(String.format("cancelOtherDefaultAddr 有其它地址被设置成默认地址，先取消这些地址的默认状态:%s %s %s", 
					new Object[]{memberNo, addressType, newDefaultAddrId}));
			for(ContactAddrInfo contactAddrInfo : resultList) {
				if(!newDefaultAddrId.equals(contactAddrInfo.getId())) {
					contactAddrInfo.setDefaultFlag(DefaultFlag.NOTDEFAULT.getValue());
					contactAddrInfoDao.updateAddressInfo(contactAddrInfo);
					logger.info(String.format("cancelOtherDefaultAddr 取消该地址的默认状态:%s %s", 
							new Object[]{newDefaultAddrId, contactAddrInfo}));
				} 
			}
		}
		
		logger.info(String.format("cancelOtherDefaultAddr end:%s %s %s", 
				new Object[]{memberNo, addressType, newDefaultAddrId}));
	}
}
