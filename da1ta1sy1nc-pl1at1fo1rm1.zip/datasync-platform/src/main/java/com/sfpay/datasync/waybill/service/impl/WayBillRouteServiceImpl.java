/**
 * 包名：com.sfpay.datasync.service.impl
 * 文件名：EsbService.java
 * 版本信息：
 * 日期：2014-8-12-下午1:43:36
 * 
 */
package com.sfpay.datasync.waybill.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.Holder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sfpay.datasync.waybill.domain.BarTraceInfo;
import com.sfpay.datasync.waybill.domain.WayBillRoute;
import com.sfpay.datasync.waybill.domain.WaybillBarInfo;
import com.sfpay.datasync.waybill.service.IWayBillRouteService;
import com.sfpay.datasync.waybill.util.EsbInterfaceUtil;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.BarTraceListArrayType7;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.QueryAllBarRecordPortType;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.ReturnArrayType6;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.SBODYType2;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.SBODYType5;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.SHEADType1;
import com.sfpay.datasync.waybill.webservice.queryallbarrecord.SHEADType3;
import com.sfpay.datasync.waybill.webservice.querybillinfo.BarNewListArrayType25;
import com.sfpay.datasync.waybill.webservice.querybillinfo.EsbSoapHeaderType;
import com.sfpay.datasync.waybill.webservice.querybillinfo.ObjectFactory;
import com.sfpay.datasync.waybill.webservice.querybillinfo.QueryBillInfoPortType;
import com.sfpay.datasync.waybill.webservice.querybillinfo.ReturnArrayType23;
import com.sfpay.datasync.waybill.webservice.querybillinfo.SBODYType19;
import com.sfpay.datasync.waybill.webservice.querybillinfo.SBODYType22;
import com.sfpay.datasync.waybill.webservice.querybillinfo.SHEADType18;
import com.sfpay.datasync.waybill.webservice.querybillinfo.SHEADType20;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类名称：EsbService 类描述： 创建人：313920 熊伟 修改人：313920 熊伟 修改时间：2014-8-12 下午1:43:36
 * 修改备注：
 * 
 * @version 2.0.1
 * 
 */
@HessianExporter
@Service("wayBillRouteService")
public class WayBillRouteServiceImpl implements IWayBillRouteService {

	private static final Logger logger = LoggerFactory.getLogger(WayBillRouteServiceImpl.class);
	
	private static final String FROM = "DATASYNC-EXP";
	private static final String TO = "WQS";
	private static final String USERLANG = "1";
	private static final String COUNTRY = "CN";
	
	@Autowired
	private EsbInterfaceUtil esbInterfaceUtil;
	
	@Value("${WAY_BILL_NUM}")
	private int wayBillNum;

	@Override
	public List<WayBillRoute> queryBillStandard(List<String> waybillNos) {
		logger.info("官网路由接口---查询运单号:【{}】,运单数量:{}",waybillNos,waybillNos.size());
		SHEADType18 shead = new SHEADType18();
		EsbSoapHeaderType esbSoapHeader7 = new EsbSoapHeaderType();
		javax.xml.ws.Holder<SHEADType20> shead1 = new javax.xml.ws.Holder<SHEADType20>();
		 javax.xml.ws.Holder<SBODYType22> sbody1 = new javax.xml.ws.Holder<SBODYType22>();
		javax.xml.ws.Holder<EsbSoapHeaderType> esbSoapHeader8 = new javax.xml.ws.Holder<EsbSoapHeaderType>();
		ObjectFactory objectFactory = new ObjectFactory();

		esbSoapHeader7.setFrom(objectFactory.createEsbSoapHeaderTypeFrom(FROM));
		esbSoapHeader7.setTo(objectFactory.createEsbSoapHeaderTypeFrom(TO));

		// 传参
		shead.setUSERLANG(USERLANG); // 语言
		shead.setCOUNTRY(COUNTRY); // 国家代码
		shead.setSYSTEMID(FROM); // 调用者系统编码
		
		QueryBillInfoPortType queryBillInfoPortType = esbInterfaceUtil.getQueryBillInfo();
		
		List<WayBillRoute> routes = new ArrayList<WayBillRoute>();
		
		if(queryBillInfoPortType == null){
			logger.warn("QueryBillInfo服务创建异常");
			return routes;
		}
		int len = waybillNos.size();
		for(int i=0;i<(len%wayBillNum==0?(len/wayBillNum):(len/wayBillNum)+1);i++){
			int start = i*wayBillNum;
			int end = (i+1)*wayBillNum<len?(i+1)*wayBillNum:len;
			SBODYType19 sbody = new SBODYType19();
			sbody.getWaybillNoList().addAll(waybillNos.subList(start, end));
			try {
				//查询路由接口调用
				queryBillInfoPortType.queryBillStandard(shead, sbody, esbSoapHeader7, shead1,sbody1, esbSoapHeader8);
			} catch (Exception e) {
				logger.error("queryBillStandard接口调用异常", e);
				return routes;
			}

			List<ReturnArrayType23> array = sbody1.value.getReturn();
			if(array!=null && array.size()>0){
				for(ReturnArrayType23 ret:array){
					WayBillRoute route = new WayBillRoute();
					List<WaybillBarInfo> barList = new ArrayList<WaybillBarInfo>();
					route.setBarList(barList);
					route.setChildSet(ret.getChildSet());
					route.setChildWaybillNo(ret.getChildWaybillNo());
					route.setDistName(ret.getDistName());
					route.setReceiveBillFlg(ret.getReceiveBillFlg());
					route.setSigninTm(ret.getSigninTm());
					route.setSubscriberName(ret.getSubscriberName());
					route.setWaybillNo(ret.getWaybillNo());
					
					route.setSendTm(ret.getConsignedTm());
					route.setSourceCityName(ret.getSourceCityName());
					route.setSourceZoneCode(ret.getSourceZoneCode());
					route.setSourceZoneName(ret.getSourceZoneName());
					route.setSenderName(ret.getConsignorContName());
					route.setSenderMobile(ret.getConsignorMobile());
					route.setSenderPhone(ret.getConsignorPhone());
					route.setDestCityName(ret.getDestCityName());
					route.setDestZoneCode(ret.getDestZoneCode());
					route.setDestZoneName(ret.getDestZoneName());
					route.setSubscriberName(ret.getSubscriberName());
					route.setReceiverMobile(ret.getAddresseeMobile());
					route.setReceiverPhone(ret.getAddresseePhone());
					
					for(BarNewListArrayType25 barNew: ret.getBarNewList()){
						WaybillBarInfo waybillBarInfo = new WaybillBarInfo();
						waybillBarInfo.setBarScanDt(barNew.getBarScanDt());
						waybillBarInfo.setBarScanTm(barNew.getBarScanTm());
						waybillBarInfo.setDistName(barNew.getDistName());
						waybillBarInfo.setNextDestZone(barNew.getNextDestZone());
						waybillBarInfo.setOpCode(barNew.getOpCode());
						waybillBarInfo.setOpName(barNew.getOpName());
						waybillBarInfo.setRemark(barNew.getRemark());
						barList.add(waybillBarInfo);
					}
					route.setBarList(barList);
					routes.add(route);
				}
			}
		}
		logger.info("返回路由信息:【{}】",routes);
		return routes;
	}

	@Override
	public List<BarTraceInfo> queryAllBarRecordList(List<String> waybillNos) {
		logger.info("全量路由接口---查询运单号:【{}】,运单数量:{}",waybillNos,waybillNos.size());
		SHEADType1 shead = new SHEADType1();
		com.sfpay.datasync.waybill.webservice.queryallbarrecord.EsbSoapHeaderType esbSoapHeaderType3 = new com.sfpay.datasync.waybill.webservice.queryallbarrecord.EsbSoapHeaderType();
		javax.xml.ws.Holder<SHEADType3> shead1 = new javax.xml.ws.Holder<SHEADType3>();
		javax.xml.ws.Holder<SBODYType5> sbody1 = new javax.xml.ws.Holder<SBODYType5>();
		javax.xml.ws.Holder<com.sfpay.datasync.waybill.webservice.queryallbarrecord.EsbSoapHeaderType> esbSoapHeader4 = new Holder<com.sfpay.datasync.waybill.webservice.queryallbarrecord.EsbSoapHeaderType>();
		
		com.sfpay.datasync.waybill.webservice.queryallbarrecord.ObjectFactory objectFactory = new com.sfpay.datasync.waybill.webservice.queryallbarrecord.ObjectFactory();

		esbSoapHeaderType3.setFrom(objectFactory.createEsbSoapHeaderTypeFrom(FROM));
		esbSoapHeaderType3.setTo(objectFactory.createEsbSoapHeaderTypeFrom(TO));
		
		// 传参
		shead.setUSERLANG(USERLANG); // 语言
		shead.setCOUNTRY(COUNTRY); // 国家代码
		shead.setSYSTEMID(FROM); // 调用者系统编码
		
		QueryAllBarRecordPortType queryAllBarRecordPortType = esbInterfaceUtil.getQueryAllBarRecord();
		
		List<BarTraceInfo> barTraceInfos = new ArrayList<BarTraceInfo>();
		
		if(queryAllBarRecordPortType == null){
			logger.warn("QueryAllBarRecordPortType服务创建异常");
			return barTraceInfos;
		}
		
		int len = waybillNos.size();
		
		for(int i=0;i<(len%wayBillNum==0?(len/wayBillNum):(len/wayBillNum)+1);i++){
			int start = i*wayBillNum;
			int end = (i+1)*wayBillNum<len?(i+1)*wayBillNum:len;
			
			SBODYType2 sbody = new SBODYType2();
			sbody.getWaybillNoList().addAll(waybillNos.subList(start, end));
			try {
				//查询路由接口调用
				queryAllBarRecordPortType.queryAllBarRecordList(shead, sbody, esbSoapHeaderType3, shead1, sbody1, esbSoapHeader4);
			} catch (Exception e) {
				logger.error("queryAllBarRecordList接口调用异常", e);
				return barTraceInfos;
			}
			List<ReturnArrayType6> array = sbody1.value.getReturn();
			for(ReturnArrayType6 ret:array){
				for(BarTraceListArrayType7 barTraceListArrayType7:ret.getBarTraceList()){
					BarTraceInfo barTraceInfo = new BarTraceInfo();
					barTraceInfo.setAccountantCode(barTraceListArrayType7.getAccountantCode());
					barTraceInfo.setAutoloading(barTraceListArrayType7.getAutoloading());
					barTraceInfo.setBarScanTm(barTraceListArrayType7.getBarScanTm()!=null?barTraceListArrayType7.getBarScanTm().toGregorianCalendar().getTime():null);
					barTraceInfo.setBarScanTmStd(barTraceListArrayType7.getBarScanTmStd()!=null?barTraceListArrayType7.getBarScanTmStd().toGregorianCalendar().getTime():null);
					barTraceInfo.setBarUploadTm(barTraceListArrayType7.getBarUploadTm()!=null?barTraceListArrayType7.getBarUploadTm().toGregorianCalendar().getTime():null);
					barTraceInfo.setBarUploadTmStd(barTraceListArrayType7.getBarUploadTmStd()!=null?barTraceListArrayType7.getBarUploadTmStd().toGregorianCalendar().getTime():null);
					barTraceInfo.setCityName(barTraceListArrayType7.getCityName());
					barTraceInfo.setContnrCode(barTraceListArrayType7.getContnrCode());
					barTraceInfo.setConvienienceCode(barTraceListArrayType7.getConvienienceCode());
					barTraceInfo.setConvienienceStore(barTraceListArrayType7.getConvienienceStore());
					barTraceInfo.setCourierCode(barTraceListArrayType7.getCourierCode());
					barTraceInfo.setDeliverConfirm(barTraceListArrayType7.getDeliverConfirm());
					barTraceInfo.setDeliverDateStr(barTraceListArrayType7.getDeliverDateStr()!=null?barTraceListArrayType7.getDeliverDateStr().toGregorianCalendar().getTime():null);
					barTraceInfo.setDestZoneCode(barTraceListArrayType7.getDestZoneCode());
					barTraceInfo.setDestZoneName(barTraceListArrayType7.getDestZoneName());
					barTraceInfo.setDistName(barTraceListArrayType7.getDistName());
					barTraceInfo.setDistScanTm(barTraceListArrayType7.getDistScanTm()!=null?barTraceListArrayType7.getDistScanTm().toGregorianCalendar().getTime():null);
					barTraceInfo.setEmpMobile(barTraceListArrayType7.getEmpMobile());
					barTraceInfo.setExceptionCause(barTraceListArrayType7.getExceptionCause());
					barTraceInfo.setExceptionState(barTraceListArrayType7.getExceptionState());
					barTraceInfo.setExtendAttach1(barTraceListArrayType7.getExtendAttach1());
					barTraceInfo.setExtendAttach2(barTraceListArrayType7.getExtendAttach2());
					barTraceInfo.setExtendAttach3(barTraceListArrayType7.getExtendAttach3());
					barTraceInfo.setExtendAttach4(barTraceListArrayType7.getExtendAttach4());
					barTraceInfo.setExtendAttach5(barTraceListArrayType7.getExtendAttach5());
					barTraceInfo.setFromOmpflg(barTraceListArrayType7.getFromOmpflg());
					barTraceInfo.setNote(barTraceListArrayType7.getNote());
					barTraceInfo.setObjTypeCode(barTraceListArrayType7.getObjTypeCode());
					barTraceInfo.setOpAttachInfo(barTraceListArrayType7.getOpAttachInfo());
					barTraceInfo.setOpCode(barTraceListArrayType7.getOpCode());
					barTraceInfo.setOpName(barTraceListArrayType7.getOpName());
					barTraceInfo.setOprCode(barTraceListArrayType7.getOprCode());
					barTraceInfo.setOutsideName(barTraceListArrayType7.getOutsideName());
					barTraceInfo.setPayFlg(barTraceListArrayType7.getPayFlg());
					barTraceInfo.setPhoneZone(barTraceListArrayType7.getPhoneZone());
					barTraceInfo.setPlanTime(barTraceListArrayType7.getPlanTime()!=null?barTraceListArrayType7.getPlanTime().toGregorianCalendar().getTime():null);
					barTraceInfo.setRouteCode(barTraceListArrayType7.getRouteCode());
					barTraceInfo.setSapDestZoneName(barTraceListArrayType7.getSapDestZoneName());
					barTraceInfo.setSapDestZoneCode(barTraceListArrayType7.getSapDestZoneCode());
					barTraceInfo.setSourceScanTm(barTraceListArrayType7.getSourceScanTm()!=null?barTraceListArrayType7.getSourceScanTm().toGregorianCalendar().getTime():null);
					barTraceInfo.setStayWhyCode(barTraceListArrayType7.getStayWhyCode());
					barTraceInfo.setStayWhyName(barTraceListArrayType7.getStayWhyName());
					barTraceInfo.setStayWhyNameEn(barTraceListArrayType7.getStayWhyNameEn());
					barTraceInfo.setUploadTypeInputty(barTraceListArrayType7.getUploadTypeInputty());
					barTraceInfo.setVehiclePlate(barTraceListArrayType7.getVehiclePlate());
					barTraceInfo.setWaybillNo(barTraceListArrayType7.getWaybillNo());
					barTraceInfo.setWeightQty(barTraceListArrayType7.getWeightQty());
					barTraceInfo.setZoneCode(barTraceListArrayType7.getZoneCode());
					barTraceInfo.setZoneGmt(barTraceListArrayType7.getZoneGmt());
					barTraceInfo.setZoneName(barTraceListArrayType7.getZoneName());
					barTraceInfos.add(barTraceInfo);
				}
			}
		}
		logger.info("返回路由信息:【{}】",barTraceInfos);
		return barTraceInfos;
	}
	
}
