/**
 * 
 */
package com.sfpay.datasync.sap.enums;

/**
 * 类说明：订阅的主题的常量
 *
 * 类描述：订阅的主题的常量
 * @author 625288 易振强
 * 2014-11-18
 */
public enum Subject {
	SAPFICORP("SAPFI_CORP"),
	HCMOUTEMPSEC("HCM-OUT_EMP-SEC");
	
	private String value;
	
	private Subject(String value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return value;
	}

}