
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>SBODYType_35 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="SBODYType_35">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNoList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}inputTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}dataType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}feeTypeCodeList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}serviceTypeCodeList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}visitInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SBODYType_35", propOrder = {
    "waybillNoList",
    "inputTypeCode",
    "dataType",
    "feeTypeCodeList",
    "serviceTypeCodeList",
    "visitInfo"
})
public class SBODYType35 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected List<String> waybillNoList;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String inputTypeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String dataType;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected List<String> feeTypeCodeList;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected List<String> serviceTypeCodeList;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String visitInfo;

    /**
     * Gets the value of the waybillNoList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the waybillNoList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWaybillNoList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getWaybillNoList() {
        if (waybillNoList == null) {
            waybillNoList = new ArrayList<String>();
        }
        return this.waybillNoList;
    }

    public void setWaybillNoList(List<String> waybillNoList) {
        this.waybillNoList = waybillNoList;
    }

    /**
     * ��ȡinputTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInputTypeCode() {
        return inputTypeCode;
    }

    /**
     * ����inputTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputTypeCode(String value) {
        this.inputTypeCode = value;
    }

    /**
     * ��ȡdataType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataType() {
        return dataType;
    }

    /**
     * ����dataType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataType(String value) {
        this.dataType = value;
    }

    /**
     * Gets the value of the feeTypeCodeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the feeTypeCodeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFeeTypeCodeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFeeTypeCodeList() {
        if (feeTypeCodeList == null) {
            feeTypeCodeList = new ArrayList<String>();
        }
        return this.feeTypeCodeList;
    }

    /**
     * Gets the value of the serviceTypeCodeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the serviceTypeCodeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getServiceTypeCodeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getServiceTypeCodeList() {
        if (serviceTypeCodeList == null) {
            serviceTypeCodeList = new ArrayList<String>();
        }
        return this.serviceTypeCodeList;
    }

    /**
     * ��ȡvisitInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVisitInfo() {
        return visitInfo;
    }

    /**
     * ����visitInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVisitInfo(String value) {
        this.visitInfo = value;
    }

}
