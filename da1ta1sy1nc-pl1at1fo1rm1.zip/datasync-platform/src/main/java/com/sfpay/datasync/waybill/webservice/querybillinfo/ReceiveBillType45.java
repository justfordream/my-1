
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>receiveBillType_45 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="receiveBillType_45">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignorCompName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignorAdd" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignorPhone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignorContName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignorMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_addresseeCompName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_addresseeAddr" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_addresseePhone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_addresseeContName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_addresseeMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_meterageWeightQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_realWeightQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_quantity" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_freeParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_innerParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_frangibleParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_trustParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_preCustomsDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consigneeEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignedTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_deliverEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_subscriberName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_signinTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_waybillRemk" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_customsBatchs" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_auditedFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_inputerEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_inputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_auditerEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_auditedTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_suppTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_customsTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_boxTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_versionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_cargoTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_limitTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_distanceTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_transportTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_expressTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_lockVersionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_inputedZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_inputTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_needSignedBackFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_signedBackWaybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_addresseeAddrNative" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_unifiedCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_modifiedEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_modifiedTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_hasServiceProdFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_ackbillTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consValue" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_otherNodeFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_tbOrderNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_tbOrderType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_freeTicketNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_twinvoiceTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_selfSendFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_selfSendDiscount" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_hvalueBoxType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_volume" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_sourcearea" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consultCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignorPostalCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_addresseePostalCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_countryCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_invoiceNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_isCredit" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consValueCurrencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_mawb" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_airportCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_consignorTaxNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_transferParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_codBillFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_cvsCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_destZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_oneselfPickupFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_waybillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_sourceZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_codType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_inputTmGmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_modifydateGmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_auditerTmGmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_unitWeight" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_refundFreeParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBill_newInputTm" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "receiveBillType_45", propOrder = {
    "receiveBillConsignorCompName",
    "receiveBillConsignorAdd",
    "receiveBillConsignorPhone",
    "receiveBillConsignorContName",
    "receiveBillConsignorMobile",
    "receiveBillAddresseeCompName",
    "receiveBillAddresseeAddr",
    "receiveBillAddresseePhone",
    "receiveBillAddresseeContName",
    "receiveBillAddresseeMobile",
    "receiveBillMeterageWeightQty",
    "receiveBillRealWeightQty",
    "receiveBillQuantity",
    "receiveBillFreeParcelFlg",
    "receiveBillInnerParcelFlg",
    "receiveBillFrangibleParcelFlg",
    "receiveBillTrustParcelFlg",
    "receiveBillPreCustomsDt",
    "receiveBillConsigneeEmpCode",
    "receiveBillConsignedTm",
    "receiveBillDeliverEmpCode",
    "receiveBillSubscriberName",
    "receiveBillSigninTm",
    "receiveBillWaybillRemk",
    "receiveBillCustomsBatchs",
    "receiveBillAuditedFlg",
    "receiveBillInputerEmpCode",
    "receiveBillInputTm",
    "receiveBillAuditerEmpCode",
    "receiveBillAuditedTm",
    "receiveBillSuppTypeCode",
    "receiveBillCustomsTypeCode",
    "receiveBillBoxTypeCode",
    "receiveBillVersionNo",
    "receiveBillCargoTypeCode",
    "receiveBillLimitTypeCode",
    "receiveBillDistanceTypeCode",
    "receiveBillTransportTypeCode",
    "receiveBillExpressTypeCode",
    "receiveBillLockVersionNo",
    "receiveBillInputedZoneCode",
    "receiveBillInputTypeCode",
    "receiveBillNeedSignedBackFlg",
    "receiveBillSignedBackWaybillNo",
    "receiveBillAddresseeAddrNative",
    "receiveBillUnifiedCode",
    "receiveBillModifiedEmpCode",
    "receiveBillModifiedTm",
    "receiveBillHasServiceProdFlg",
    "receiveBillAckbillTypeCode",
    "receiveBillConsValue",
    "receiveBillOtherNodeFlg",
    "receiveBillTbOrderNo",
    "receiveBillTbOrderType",
    "receiveBillFreeTicketNo",
    "receiveBillTwinvoiceTypeCode",
    "receiveBillSelfSendFlg",
    "receiveBillSelfSendDiscount",
    "receiveBillHvalueBoxType",
    "receiveBillVolume",
    "receiveBillSourcearea",
    "receiveBillConsultCode",
    "receiveBillConsignorPostalCode",
    "receiveBillAddresseePostalCode",
    "receiveBillCountryCode",
    "receiveBillInvoiceNo",
    "receiveBillIsCredit",
    "receiveBillConsValueCurrencyCode",
    "receiveBillMawb",
    "receiveBillAirportCode",
    "receiveBillConsignorTaxNo",
    "receiveBillTransferParcelFlg",
    "receiveBillCodBillFlg",
    "receiveBillCvsCode",
    "receiveBillDestZoneCode",
    "receiveBillOneselfPickupFlg",
    "receiveBillWaybillId",
    "receiveBillWaybillNo",
    "receiveBillSourceZoneCode",
    "receiveBillCodType",
    "receiveBillInputTmGmt",
    "receiveBillModifydateGmt",
    "receiveBillAuditerTmGmt",
    "receiveBillUnitWeight",
    "receiveBillRefundFreeParcelFlg",
    "receiveBillNewInputTm"
})
public class ReceiveBillType45 {

    @XmlElement(name = "receiveBill_consignorCompName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignorCompName;
    @XmlElement(name = "receiveBill_consignorAdd", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignorAdd;
    @XmlElement(name = "receiveBill_consignorPhone", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignorPhone;
    @XmlElement(name = "receiveBill_consignorContName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignorContName;
    @XmlElement(name = "receiveBill_consignorMobile", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignorMobile;
    @XmlElement(name = "receiveBill_addresseeCompName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAddresseeCompName;
    @XmlElement(name = "receiveBill_addresseeAddr", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAddresseeAddr;
    @XmlElement(name = "receiveBill_addresseePhone", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAddresseePhone;
    @XmlElement(name = "receiveBill_addresseeContName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAddresseeContName;
    @XmlElement(name = "receiveBill_addresseeMobile", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAddresseeMobile;
    @XmlElement(name = "receiveBill_meterageWeightQty", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveBillMeterageWeightQty;
    @XmlElement(name = "receiveBill_realWeightQty", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveBillRealWeightQty;
    @XmlElement(name = "receiveBill_quantity", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveBillQuantity;
    @XmlElement(name = "receiveBill_freeParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillFreeParcelFlg;
    @XmlElement(name = "receiveBill_innerParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillInnerParcelFlg;
    @XmlElement(name = "receiveBill_frangibleParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillFrangibleParcelFlg;
    @XmlElement(name = "receiveBill_trustParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillTrustParcelFlg;
    @XmlElement(name = "receiveBill_preCustomsDt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillPreCustomsDt;
    @XmlElement(name = "receiveBill_consigneeEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsigneeEmpCode;
    @XmlElement(name = "receiveBill_consignedTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignedTm;
    @XmlElement(name = "receiveBill_deliverEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillDeliverEmpCode;
    @XmlElement(name = "receiveBill_subscriberName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillSubscriberName;
    @XmlElement(name = "receiveBill_signinTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillSigninTm;
    @XmlElement(name = "receiveBill_waybillRemk", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillWaybillRemk;
    @XmlElement(name = "receiveBill_customsBatchs", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillCustomsBatchs;
    @XmlElement(name = "receiveBill_auditedFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillAuditedFlg;
    @XmlElement(name = "receiveBill_inputerEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillInputerEmpCode;
    @XmlElement(name = "receiveBill_inputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillInputTm;
    @XmlElement(name = "receiveBill_auditerEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAuditerEmpCode;
    @XmlElement(name = "receiveBill_auditedTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillAuditedTm;
    @XmlElement(name = "receiveBill_suppTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillSuppTypeCode;
    @XmlElement(name = "receiveBill_customsTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillCustomsTypeCode;
    @XmlElement(name = "receiveBill_boxTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillBoxTypeCode;
    @XmlElement(name = "receiveBill_versionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillVersionNo;
    @XmlElement(name = "receiveBill_cargoTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillCargoTypeCode;
    @XmlElement(name = "receiveBill_limitTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillLimitTypeCode;
    @XmlElement(name = "receiveBill_distanceTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillDistanceTypeCode;
    @XmlElement(name = "receiveBill_transportTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillTransportTypeCode;
    @XmlElement(name = "receiveBill_expressTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillExpressTypeCode;
    @XmlElement(name = "receiveBill_lockVersionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillLockVersionNo;
    @XmlElement(name = "receiveBill_inputedZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillInputedZoneCode;
    @XmlElement(name = "receiveBill_inputTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillInputTypeCode;
    @XmlElement(name = "receiveBill_needSignedBackFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillNeedSignedBackFlg;
    @XmlElement(name = "receiveBill_signedBackWaybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillSignedBackWaybillNo;
    @XmlElement(name = "receiveBill_addresseeAddrNative", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAddresseeAddrNative;
    @XmlElement(name = "receiveBill_unifiedCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillUnifiedCode;
    @XmlElement(name = "receiveBill_modifiedEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillModifiedEmpCode;
    @XmlElement(name = "receiveBill_modifiedTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillModifiedTm;
    @XmlElement(name = "receiveBill_hasServiceProdFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillHasServiceProdFlg;
    @XmlElement(name = "receiveBill_ackbillTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAckbillTypeCode;
    @XmlElement(name = "receiveBill_consValue", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveBillConsValue;
    @XmlElement(name = "receiveBill_otherNodeFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillOtherNodeFlg;
    @XmlElement(name = "receiveBill_tbOrderNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillTbOrderNo;
    @XmlElement(name = "receiveBill_tbOrderType", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillTbOrderType;
    @XmlElement(name = "receiveBill_freeTicketNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillFreeTicketNo;
    @XmlElement(name = "receiveBill_twinvoiceTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillTwinvoiceTypeCode;
    @XmlElement(name = "receiveBill_selfSendFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillSelfSendFlg;
    @XmlElement(name = "receiveBill_selfSendDiscount", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveBillSelfSendDiscount;
    @XmlElement(name = "receiveBill_hvalueBoxType", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillHvalueBoxType;
    @XmlElement(name = "receiveBill_volume", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveBillVolume;
    @XmlElement(name = "receiveBill_sourcearea", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillSourcearea;
    @XmlElement(name = "receiveBill_consultCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsultCode;
    @XmlElement(name = "receiveBill_consignorPostalCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignorPostalCode;
    @XmlElement(name = "receiveBill_addresseePostalCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAddresseePostalCode;
    @XmlElement(name = "receiveBill_countryCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillCountryCode;
    @XmlElement(name = "receiveBill_invoiceNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillInvoiceNo;
    @XmlElement(name = "receiveBill_isCredit", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillIsCredit;
    @XmlElement(name = "receiveBill_consValueCurrencyCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsValueCurrencyCode;
    @XmlElement(name = "receiveBill_mawb", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillMawb;
    @XmlElement(name = "receiveBill_airportCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillAirportCode;
    @XmlElement(name = "receiveBill_consignorTaxNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillConsignorTaxNo;
    @XmlElement(name = "receiveBill_transferParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillTransferParcelFlg;
    @XmlElement(name = "receiveBill_codBillFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillCodBillFlg;
    @XmlElement(name = "receiveBill_cvsCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillCvsCode;
    @XmlElement(name = "receiveBill_destZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillDestZoneCode;
    @XmlElement(name = "receiveBill_oneselfPickupFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillOneselfPickupFlg;
    @XmlElement(name = "receiveBill_waybillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillWaybillId;
    @XmlElement(name = "receiveBill_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillWaybillNo;
    @XmlElement(name = "receiveBill_sourceZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillSourceZoneCode;
    @XmlElement(name = "receiveBill_codType", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillCodType;
    @XmlElement(name = "receiveBill_inputTmGmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillInputTmGmt;
    @XmlElement(name = "receiveBill_modifydateGmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillModifydateGmt;
    @XmlElement(name = "receiveBill_auditerTmGmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillAuditerTmGmt;
    @XmlElement(name = "receiveBill_unitWeight", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillUnitWeight;
    @XmlElement(name = "receiveBill_refundFreeParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveBillRefundFreeParcelFlg;
    @XmlElement(name = "receiveBill_newInputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveBillNewInputTm;

    /**
     * ��ȡreceiveBillConsignorCompName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignorCompName() {
        return receiveBillConsignorCompName;
    }

    /**
     * ����receiveBillConsignorCompName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignorCompName(String value) {
        this.receiveBillConsignorCompName = value;
    }

    /**
     * ��ȡreceiveBillConsignorAdd���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignorAdd() {
        return receiveBillConsignorAdd;
    }

    /**
     * ����receiveBillConsignorAdd���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignorAdd(String value) {
        this.receiveBillConsignorAdd = value;
    }

    /**
     * ��ȡreceiveBillConsignorPhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignorPhone() {
        return receiveBillConsignorPhone;
    }

    /**
     * ����receiveBillConsignorPhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignorPhone(String value) {
        this.receiveBillConsignorPhone = value;
    }

    /**
     * ��ȡreceiveBillConsignorContName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignorContName() {
        return receiveBillConsignorContName;
    }

    /**
     * ����receiveBillConsignorContName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignorContName(String value) {
        this.receiveBillConsignorContName = value;
    }

    /**
     * ��ȡreceiveBillConsignorMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignorMobile() {
        return receiveBillConsignorMobile;
    }

    /**
     * ����receiveBillConsignorMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignorMobile(String value) {
        this.receiveBillConsignorMobile = value;
    }

    /**
     * ��ȡreceiveBillAddresseeCompName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAddresseeCompName() {
        return receiveBillAddresseeCompName;
    }

    /**
     * ����receiveBillAddresseeCompName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAddresseeCompName(String value) {
        this.receiveBillAddresseeCompName = value;
    }

    /**
     * ��ȡreceiveBillAddresseeAddr���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAddresseeAddr() {
        return receiveBillAddresseeAddr;
    }

    /**
     * ����receiveBillAddresseeAddr���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAddresseeAddr(String value) {
        this.receiveBillAddresseeAddr = value;
    }

    /**
     * ��ȡreceiveBillAddresseePhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAddresseePhone() {
        return receiveBillAddresseePhone;
    }

    /**
     * ����receiveBillAddresseePhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAddresseePhone(String value) {
        this.receiveBillAddresseePhone = value;
    }

    /**
     * ��ȡreceiveBillAddresseeContName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAddresseeContName() {
        return receiveBillAddresseeContName;
    }

    /**
     * ����receiveBillAddresseeContName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAddresseeContName(String value) {
        this.receiveBillAddresseeContName = value;
    }

    /**
     * ��ȡreceiveBillAddresseeMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAddresseeMobile() {
        return receiveBillAddresseeMobile;
    }

    /**
     * ����receiveBillAddresseeMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAddresseeMobile(String value) {
        this.receiveBillAddresseeMobile = value;
    }

    /**
     * ��ȡreceiveBillMeterageWeightQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveBillMeterageWeightQty() {
        return receiveBillMeterageWeightQty;
    }

    /**
     * ����receiveBillMeterageWeightQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveBillMeterageWeightQty(Double value) {
        this.receiveBillMeterageWeightQty = value;
    }

    /**
     * ��ȡreceiveBillRealWeightQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveBillRealWeightQty() {
        return receiveBillRealWeightQty;
    }

    /**
     * ����receiveBillRealWeightQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveBillRealWeightQty(Double value) {
        this.receiveBillRealWeightQty = value;
    }

    /**
     * ��ȡreceiveBillQuantity���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveBillQuantity() {
        return receiveBillQuantity;
    }

    /**
     * ����receiveBillQuantity���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveBillQuantity(Double value) {
        this.receiveBillQuantity = value;
    }

    /**
     * ��ȡreceiveBillFreeParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillFreeParcelFlg() {
        return receiveBillFreeParcelFlg;
    }

    /**
     * ����receiveBillFreeParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillFreeParcelFlg(Integer value) {
        this.receiveBillFreeParcelFlg = value;
    }

    /**
     * ��ȡreceiveBillInnerParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillInnerParcelFlg() {
        return receiveBillInnerParcelFlg;
    }

    /**
     * ����receiveBillInnerParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillInnerParcelFlg(Integer value) {
        this.receiveBillInnerParcelFlg = value;
    }

    /**
     * ��ȡreceiveBillFrangibleParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillFrangibleParcelFlg() {
        return receiveBillFrangibleParcelFlg;
    }

    /**
     * ����receiveBillFrangibleParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillFrangibleParcelFlg(Integer value) {
        this.receiveBillFrangibleParcelFlg = value;
    }

    /**
     * ��ȡreceiveBillTrustParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillTrustParcelFlg() {
        return receiveBillTrustParcelFlg;
    }

    /**
     * ����receiveBillTrustParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillTrustParcelFlg(Integer value) {
        this.receiveBillTrustParcelFlg = value;
    }

    /**
     * ��ȡreceiveBillPreCustomsDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillPreCustomsDt() {
        return receiveBillPreCustomsDt;
    }

    /**
     * ����receiveBillPreCustomsDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillPreCustomsDt(XMLGregorianCalendar value) {
        this.receiveBillPreCustomsDt = value;
    }

    /**
     * ��ȡreceiveBillConsigneeEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsigneeEmpCode() {
        return receiveBillConsigneeEmpCode;
    }

    /**
     * ����receiveBillConsigneeEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsigneeEmpCode(String value) {
        this.receiveBillConsigneeEmpCode = value;
    }

    /**
     * ��ȡreceiveBillConsignedTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignedTm() {
        return receiveBillConsignedTm;
    }

    /**
     * ����receiveBillConsignedTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignedTm(String value) {
        this.receiveBillConsignedTm = value;
    }

    /**
     * ��ȡreceiveBillDeliverEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillDeliverEmpCode() {
        return receiveBillDeliverEmpCode;
    }

    /**
     * ����receiveBillDeliverEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillDeliverEmpCode(String value) {
        this.receiveBillDeliverEmpCode = value;
    }

    /**
     * ��ȡreceiveBillSubscriberName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillSubscriberName() {
        return receiveBillSubscriberName;
    }

    /**
     * ����receiveBillSubscriberName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillSubscriberName(String value) {
        this.receiveBillSubscriberName = value;
    }

    /**
     * ��ȡreceiveBillSigninTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillSigninTm() {
        return receiveBillSigninTm;
    }

    /**
     * ����receiveBillSigninTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillSigninTm(String value) {
        this.receiveBillSigninTm = value;
    }

    /**
     * ��ȡreceiveBillWaybillRemk���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillWaybillRemk() {
        return receiveBillWaybillRemk;
    }

    /**
     * ����receiveBillWaybillRemk���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillWaybillRemk(String value) {
        this.receiveBillWaybillRemk = value;
    }

    /**
     * ��ȡreceiveBillCustomsBatchs���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillCustomsBatchs() {
        return receiveBillCustomsBatchs;
    }

    /**
     * ����receiveBillCustomsBatchs���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillCustomsBatchs(String value) {
        this.receiveBillCustomsBatchs = value;
    }

    /**
     * ��ȡreceiveBillAuditedFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillAuditedFlg() {
        return receiveBillAuditedFlg;
    }

    /**
     * ����receiveBillAuditedFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillAuditedFlg(Integer value) {
        this.receiveBillAuditedFlg = value;
    }

    /**
     * ��ȡreceiveBillInputerEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillInputerEmpCode() {
        return receiveBillInputerEmpCode;
    }

    /**
     * ����receiveBillInputerEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillInputerEmpCode(String value) {
        this.receiveBillInputerEmpCode = value;
    }

    /**
     * ��ȡreceiveBillInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillInputTm() {
        return receiveBillInputTm;
    }

    /**
     * ����receiveBillInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillInputTm(XMLGregorianCalendar value) {
        this.receiveBillInputTm = value;
    }

    /**
     * ��ȡreceiveBillAuditerEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAuditerEmpCode() {
        return receiveBillAuditerEmpCode;
    }

    /**
     * ����receiveBillAuditerEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAuditerEmpCode(String value) {
        this.receiveBillAuditerEmpCode = value;
    }

    /**
     * ��ȡreceiveBillAuditedTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillAuditedTm() {
        return receiveBillAuditedTm;
    }

    /**
     * ����receiveBillAuditedTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillAuditedTm(XMLGregorianCalendar value) {
        this.receiveBillAuditedTm = value;
    }

    /**
     * ��ȡreceiveBillSuppTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillSuppTypeCode() {
        return receiveBillSuppTypeCode;
    }

    /**
     * ����receiveBillSuppTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillSuppTypeCode(String value) {
        this.receiveBillSuppTypeCode = value;
    }

    /**
     * ��ȡreceiveBillCustomsTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillCustomsTypeCode() {
        return receiveBillCustomsTypeCode;
    }

    /**
     * ����receiveBillCustomsTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillCustomsTypeCode(String value) {
        this.receiveBillCustomsTypeCode = value;
    }

    /**
     * ��ȡreceiveBillBoxTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillBoxTypeCode() {
        return receiveBillBoxTypeCode;
    }

    /**
     * ����receiveBillBoxTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillBoxTypeCode(String value) {
        this.receiveBillBoxTypeCode = value;
    }

    /**
     * ��ȡreceiveBillVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillVersionNo() {
        return receiveBillVersionNo;
    }

    /**
     * ����receiveBillVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillVersionNo(Integer value) {
        this.receiveBillVersionNo = value;
    }

    /**
     * ��ȡreceiveBillCargoTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillCargoTypeCode() {
        return receiveBillCargoTypeCode;
    }

    /**
     * ����receiveBillCargoTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillCargoTypeCode(String value) {
        this.receiveBillCargoTypeCode = value;
    }

    /**
     * ��ȡreceiveBillLimitTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillLimitTypeCode() {
        return receiveBillLimitTypeCode;
    }

    /**
     * ����receiveBillLimitTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillLimitTypeCode(String value) {
        this.receiveBillLimitTypeCode = value;
    }

    /**
     * ��ȡreceiveBillDistanceTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillDistanceTypeCode() {
        return receiveBillDistanceTypeCode;
    }

    /**
     * ����receiveBillDistanceTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillDistanceTypeCode(String value) {
        this.receiveBillDistanceTypeCode = value;
    }

    /**
     * ��ȡreceiveBillTransportTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillTransportTypeCode() {
        return receiveBillTransportTypeCode;
    }

    /**
     * ����receiveBillTransportTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillTransportTypeCode(String value) {
        this.receiveBillTransportTypeCode = value;
    }

    /**
     * ��ȡreceiveBillExpressTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillExpressTypeCode() {
        return receiveBillExpressTypeCode;
    }

    /**
     * ����receiveBillExpressTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillExpressTypeCode(String value) {
        this.receiveBillExpressTypeCode = value;
    }

    /**
     * ��ȡreceiveBillLockVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillLockVersionNo() {
        return receiveBillLockVersionNo;
    }

    /**
     * ����receiveBillLockVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillLockVersionNo(Integer value) {
        this.receiveBillLockVersionNo = value;
    }

    /**
     * ��ȡreceiveBillInputedZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillInputedZoneCode() {
        return receiveBillInputedZoneCode;
    }

    /**
     * ����receiveBillInputedZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillInputedZoneCode(String value) {
        this.receiveBillInputedZoneCode = value;
    }

    /**
     * ��ȡreceiveBillInputTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillInputTypeCode() {
        return receiveBillInputTypeCode;
    }

    /**
     * ����receiveBillInputTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillInputTypeCode(String value) {
        this.receiveBillInputTypeCode = value;
    }

    /**
     * ��ȡreceiveBillNeedSignedBackFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillNeedSignedBackFlg() {
        return receiveBillNeedSignedBackFlg;
    }

    /**
     * ����receiveBillNeedSignedBackFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillNeedSignedBackFlg(Integer value) {
        this.receiveBillNeedSignedBackFlg = value;
    }

    /**
     * ��ȡreceiveBillSignedBackWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillSignedBackWaybillNo() {
        return receiveBillSignedBackWaybillNo;
    }

    /**
     * ����receiveBillSignedBackWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillSignedBackWaybillNo(String value) {
        this.receiveBillSignedBackWaybillNo = value;
    }

    /**
     * ��ȡreceiveBillAddresseeAddrNative���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAddresseeAddrNative() {
        return receiveBillAddresseeAddrNative;
    }

    /**
     * ����receiveBillAddresseeAddrNative���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAddresseeAddrNative(String value) {
        this.receiveBillAddresseeAddrNative = value;
    }

    /**
     * ��ȡreceiveBillUnifiedCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillUnifiedCode() {
        return receiveBillUnifiedCode;
    }

    /**
     * ����receiveBillUnifiedCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillUnifiedCode(String value) {
        this.receiveBillUnifiedCode = value;
    }

    /**
     * ��ȡreceiveBillModifiedEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillModifiedEmpCode() {
        return receiveBillModifiedEmpCode;
    }

    /**
     * ����receiveBillModifiedEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillModifiedEmpCode(String value) {
        this.receiveBillModifiedEmpCode = value;
    }

    /**
     * ��ȡreceiveBillModifiedTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillModifiedTm() {
        return receiveBillModifiedTm;
    }

    /**
     * ����receiveBillModifiedTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillModifiedTm(XMLGregorianCalendar value) {
        this.receiveBillModifiedTm = value;
    }

    /**
     * ��ȡreceiveBillHasServiceProdFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillHasServiceProdFlg() {
        return receiveBillHasServiceProdFlg;
    }

    /**
     * ����receiveBillHasServiceProdFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillHasServiceProdFlg(Integer value) {
        this.receiveBillHasServiceProdFlg = value;
    }

    /**
     * ��ȡreceiveBillAckbillTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAckbillTypeCode() {
        return receiveBillAckbillTypeCode;
    }

    /**
     * ����receiveBillAckbillTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAckbillTypeCode(String value) {
        this.receiveBillAckbillTypeCode = value;
    }

    /**
     * ��ȡreceiveBillConsValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveBillConsValue() {
        return receiveBillConsValue;
    }

    /**
     * ����receiveBillConsValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveBillConsValue(Double value) {
        this.receiveBillConsValue = value;
    }

    /**
     * ��ȡreceiveBillOtherNodeFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillOtherNodeFlg() {
        return receiveBillOtherNodeFlg;
    }

    /**
     * ����receiveBillOtherNodeFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillOtherNodeFlg(Integer value) {
        this.receiveBillOtherNodeFlg = value;
    }

    /**
     * ��ȡreceiveBillTbOrderNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillTbOrderNo() {
        return receiveBillTbOrderNo;
    }

    /**
     * ����receiveBillTbOrderNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillTbOrderNo(String value) {
        this.receiveBillTbOrderNo = value;
    }

    /**
     * ��ȡreceiveBillTbOrderType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillTbOrderType() {
        return receiveBillTbOrderType;
    }

    /**
     * ����receiveBillTbOrderType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillTbOrderType(String value) {
        this.receiveBillTbOrderType = value;
    }

    /**
     * ��ȡreceiveBillFreeTicketNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillFreeTicketNo() {
        return receiveBillFreeTicketNo;
    }

    /**
     * ����receiveBillFreeTicketNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillFreeTicketNo(String value) {
        this.receiveBillFreeTicketNo = value;
    }

    /**
     * ��ȡreceiveBillTwinvoiceTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillTwinvoiceTypeCode() {
        return receiveBillTwinvoiceTypeCode;
    }

    /**
     * ����receiveBillTwinvoiceTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillTwinvoiceTypeCode(Integer value) {
        this.receiveBillTwinvoiceTypeCode = value;
    }

    /**
     * ��ȡreceiveBillSelfSendFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillSelfSendFlg() {
        return receiveBillSelfSendFlg;
    }

    /**
     * ����receiveBillSelfSendFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillSelfSendFlg(Integer value) {
        this.receiveBillSelfSendFlg = value;
    }

    /**
     * ��ȡreceiveBillSelfSendDiscount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveBillSelfSendDiscount() {
        return receiveBillSelfSendDiscount;
    }

    /**
     * ����receiveBillSelfSendDiscount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveBillSelfSendDiscount(Double value) {
        this.receiveBillSelfSendDiscount = value;
    }

    /**
     * ��ȡreceiveBillHvalueBoxType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillHvalueBoxType() {
        return receiveBillHvalueBoxType;
    }

    /**
     * ����receiveBillHvalueBoxType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillHvalueBoxType(String value) {
        this.receiveBillHvalueBoxType = value;
    }

    /**
     * ��ȡreceiveBillVolume���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveBillVolume() {
        return receiveBillVolume;
    }

    /**
     * ����receiveBillVolume���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveBillVolume(Double value) {
        this.receiveBillVolume = value;
    }

    /**
     * ��ȡreceiveBillSourcearea���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillSourcearea() {
        return receiveBillSourcearea;
    }

    /**
     * ����receiveBillSourcearea���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillSourcearea(String value) {
        this.receiveBillSourcearea = value;
    }

    /**
     * ��ȡreceiveBillConsultCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsultCode() {
        return receiveBillConsultCode;
    }

    /**
     * ����receiveBillConsultCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsultCode(String value) {
        this.receiveBillConsultCode = value;
    }

    /**
     * ��ȡreceiveBillConsignorPostalCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignorPostalCode() {
        return receiveBillConsignorPostalCode;
    }

    /**
     * ����receiveBillConsignorPostalCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignorPostalCode(String value) {
        this.receiveBillConsignorPostalCode = value;
    }

    /**
     * ��ȡreceiveBillAddresseePostalCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAddresseePostalCode() {
        return receiveBillAddresseePostalCode;
    }

    /**
     * ����receiveBillAddresseePostalCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAddresseePostalCode(String value) {
        this.receiveBillAddresseePostalCode = value;
    }

    /**
     * ��ȡreceiveBillCountryCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillCountryCode() {
        return receiveBillCountryCode;
    }

    /**
     * ����receiveBillCountryCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillCountryCode(String value) {
        this.receiveBillCountryCode = value;
    }

    /**
     * ��ȡreceiveBillInvoiceNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillInvoiceNo() {
        return receiveBillInvoiceNo;
    }

    /**
     * ����receiveBillInvoiceNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillInvoiceNo(String value) {
        this.receiveBillInvoiceNo = value;
    }

    /**
     * ��ȡreceiveBillIsCredit���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillIsCredit() {
        return receiveBillIsCredit;
    }

    /**
     * ����receiveBillIsCredit���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillIsCredit(Integer value) {
        this.receiveBillIsCredit = value;
    }

    /**
     * ��ȡreceiveBillConsValueCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsValueCurrencyCode() {
        return receiveBillConsValueCurrencyCode;
    }

    /**
     * ����receiveBillConsValueCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsValueCurrencyCode(String value) {
        this.receiveBillConsValueCurrencyCode = value;
    }

    /**
     * ��ȡreceiveBillMawb���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillMawb() {
        return receiveBillMawb;
    }

    /**
     * ����receiveBillMawb���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillMawb(String value) {
        this.receiveBillMawb = value;
    }

    /**
     * ��ȡreceiveBillAirportCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillAirportCode() {
        return receiveBillAirportCode;
    }

    /**
     * ����receiveBillAirportCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillAirportCode(String value) {
        this.receiveBillAirportCode = value;
    }

    /**
     * ��ȡreceiveBillConsignorTaxNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillConsignorTaxNo() {
        return receiveBillConsignorTaxNo;
    }

    /**
     * ����receiveBillConsignorTaxNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillConsignorTaxNo(String value) {
        this.receiveBillConsignorTaxNo = value;
    }

    /**
     * ��ȡreceiveBillTransferParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillTransferParcelFlg() {
        return receiveBillTransferParcelFlg;
    }

    /**
     * ����receiveBillTransferParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillTransferParcelFlg(Integer value) {
        this.receiveBillTransferParcelFlg = value;
    }

    /**
     * ��ȡreceiveBillCodBillFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillCodBillFlg() {
        return receiveBillCodBillFlg;
    }

    /**
     * ����receiveBillCodBillFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillCodBillFlg(Integer value) {
        this.receiveBillCodBillFlg = value;
    }

    /**
     * ��ȡreceiveBillCvsCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillCvsCode() {
        return receiveBillCvsCode;
    }

    /**
     * ����receiveBillCvsCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillCvsCode(String value) {
        this.receiveBillCvsCode = value;
    }

    /**
     * ��ȡreceiveBillDestZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillDestZoneCode() {
        return receiveBillDestZoneCode;
    }

    /**
     * ����receiveBillDestZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillDestZoneCode(String value) {
        this.receiveBillDestZoneCode = value;
    }

    /**
     * ��ȡreceiveBillOneselfPickupFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillOneselfPickupFlg() {
        return receiveBillOneselfPickupFlg;
    }

    /**
     * ����receiveBillOneselfPickupFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillOneselfPickupFlg(Integer value) {
        this.receiveBillOneselfPickupFlg = value;
    }

    /**
     * ��ȡreceiveBillWaybillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillWaybillId() {
        return receiveBillWaybillId;
    }

    /**
     * ����receiveBillWaybillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillWaybillId(String value) {
        this.receiveBillWaybillId = value;
    }

    /**
     * ��ȡreceiveBillWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillWaybillNo() {
        return receiveBillWaybillNo;
    }

    /**
     * ����receiveBillWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillWaybillNo(String value) {
        this.receiveBillWaybillNo = value;
    }

    /**
     * ��ȡreceiveBillSourceZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillSourceZoneCode() {
        return receiveBillSourceZoneCode;
    }

    /**
     * ����receiveBillSourceZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillSourceZoneCode(String value) {
        this.receiveBillSourceZoneCode = value;
    }

    /**
     * ��ȡreceiveBillCodType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillCodType() {
        return receiveBillCodType;
    }

    /**
     * ����receiveBillCodType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillCodType(Integer value) {
        this.receiveBillCodType = value;
    }

    /**
     * ��ȡreceiveBillInputTmGmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillInputTmGmt() {
        return receiveBillInputTmGmt;
    }

    /**
     * ����receiveBillInputTmGmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillInputTmGmt(XMLGregorianCalendar value) {
        this.receiveBillInputTmGmt = value;
    }

    /**
     * ��ȡreceiveBillModifydateGmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillModifydateGmt() {
        return receiveBillModifydateGmt;
    }

    /**
     * ����receiveBillModifydateGmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillModifydateGmt(XMLGregorianCalendar value) {
        this.receiveBillModifydateGmt = value;
    }

    /**
     * ��ȡreceiveBillAuditerTmGmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillAuditerTmGmt() {
        return receiveBillAuditerTmGmt;
    }

    /**
     * ����receiveBillAuditerTmGmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillAuditerTmGmt(XMLGregorianCalendar value) {
        this.receiveBillAuditerTmGmt = value;
    }

    /**
     * ��ȡreceiveBillUnitWeight���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillUnitWeight() {
        return receiveBillUnitWeight;
    }

    /**
     * ����receiveBillUnitWeight���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillUnitWeight(String value) {
        this.receiveBillUnitWeight = value;
    }

    /**
     * ��ȡreceiveBillRefundFreeParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveBillRefundFreeParcelFlg() {
        return receiveBillRefundFreeParcelFlg;
    }

    /**
     * ����receiveBillRefundFreeParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveBillRefundFreeParcelFlg(Integer value) {
        this.receiveBillRefundFreeParcelFlg = value;
    }

    /**
     * ��ȡreceiveBillNewInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveBillNewInputTm() {
        return receiveBillNewInputTm;
    }

    /**
     * ����receiveBillNewInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveBillNewInputTm(XMLGregorianCalendar value) {
        this.receiveBillNewInputTm = value;
    }

}
