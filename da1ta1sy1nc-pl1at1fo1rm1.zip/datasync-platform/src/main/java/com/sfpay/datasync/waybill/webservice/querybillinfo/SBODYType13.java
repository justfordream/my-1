
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>SBODYType_13 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="SBODYType_13">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}telNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}startDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}endDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}visitInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SBODYType_13", propOrder = {
    "telNo",
    "startDt",
    "endDt",
    "visitInfo"
})
public class SBODYType13 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String telNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String startDt;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String endDt;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String visitInfo;

    /**
     * ��ȡtelNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelNo() {
        return telNo;
    }

    /**
     * ����telNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelNo(String value) {
        this.telNo = value;
    }

    /**
     * ��ȡstartDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDt() {
        return startDt;
    }

    /**
     * ����startDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDt(String value) {
        this.startDt = value;
    }

    /**
     * ��ȡendDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDt() {
        return endDt;
    }

    /**
     * ����endDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDt(String value) {
        this.endDt = value;
    }

    /**
     * ��ȡvisitInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVisitInfo() {
        return visitInfo;
    }

    /**
     * ����visitInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVisitInfo(String value) {
        this.visitInfo = value;
    }

}
