
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>receiveFeeArrayType_47 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="receiveFeeArrayType_47">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_paymentChangeTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_serviceId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_customerAcctCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_waybillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_inputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_versionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_currencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_gatherEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_inputTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_bizOwnerZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_gstFee" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_sourceCodeFeeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_exchangeRate" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_destCurrencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_refundFeeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_newInputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_feeId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_feeTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_feeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_gatherZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_paymentTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveFee_settlementTypeCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "receiveFeeArrayType_47", propOrder = {
    "receiveFeePaymentChangeTypeCode",
    "receiveFeeServiceId",
    "receiveFeeCustomerAcctCode",
    "receiveFeeWaybillId",
    "receiveFeeWaybillNo",
    "receiveFeeInputTm",
    "receiveFeeVersionNo",
    "receiveFeeCurrencyCode",
    "receiveFeeGatherEmpCode",
    "receiveFeeInputTypeCode",
    "receiveFeeBizOwnerZoneCode",
    "receiveFeeGstFee",
    "receiveFeeSourceCodeFeeAmt",
    "receiveFeeExchangeRate",
    "receiveFeeDestCurrencyCode",
    "receiveFeeRefundFeeAmt",
    "receiveFeeNewInputTm",
    "receiveFeeFeeId",
    "receiveFeeFeeTypeCode",
    "receiveFeeFeeAmt",
    "receiveFeeGatherZoneCode",
    "receiveFeePaymentTypeCode",
    "receiveFeeSettlementTypeCode"
})
public class ReceiveFeeArrayType47 {

    @XmlElement(name = "receiveFee_paymentChangeTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeePaymentChangeTypeCode;
    @XmlElement(name = "receiveFee_serviceId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeServiceId;
    @XmlElement(name = "receiveFee_customerAcctCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeCustomerAcctCode;
    @XmlElement(name = "receiveFee_waybillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeWaybillId;
    @XmlElement(name = "receiveFee_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeWaybillNo;
    @XmlElement(name = "receiveFee_inputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveFeeInputTm;
    @XmlElement(name = "receiveFee_versionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveFeeVersionNo;
    @XmlElement(name = "receiveFee_currencyCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeCurrencyCode;
    @XmlElement(name = "receiveFee_gatherEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeGatherEmpCode;
    @XmlElement(name = "receiveFee_inputTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeInputTypeCode;
    @XmlElement(name = "receiveFee_bizOwnerZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeBizOwnerZoneCode;
    @XmlElement(name = "receiveFee_gstFee", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveFeeGstFee;
    @XmlElement(name = "receiveFee_sourceCodeFeeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveFeeSourceCodeFeeAmt;
    @XmlElement(name = "receiveFee_exchangeRate", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveFeeExchangeRate;
    @XmlElement(name = "receiveFee_destCurrencyCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeDestCurrencyCode;
    @XmlElement(name = "receiveFee_refundFeeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveFeeRefundFeeAmt;
    @XmlElement(name = "receiveFee_newInputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveFeeNewInputTm;
    @XmlElement(name = "receiveFee_feeId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeFeeId;
    @XmlElement(name = "receiveFee_feeTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeFeeTypeCode;
    @XmlElement(name = "receiveFee_feeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double receiveFeeFeeAmt;
    @XmlElement(name = "receiveFee_gatherZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeGatherZoneCode;
    @XmlElement(name = "receiveFee_paymentTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeePaymentTypeCode;
    @XmlElement(name = "receiveFee_settlementTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveFeeSettlementTypeCode;

    /**
     * ��ȡreceiveFeePaymentChangeTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeePaymentChangeTypeCode() {
        return receiveFeePaymentChangeTypeCode;
    }

    /**
     * ����receiveFeePaymentChangeTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeePaymentChangeTypeCode(String value) {
        this.receiveFeePaymentChangeTypeCode = value;
    }

    /**
     * ��ȡreceiveFeeServiceId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeServiceId() {
        return receiveFeeServiceId;
    }

    /**
     * ����receiveFeeServiceId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeServiceId(String value) {
        this.receiveFeeServiceId = value;
    }

    /**
     * ��ȡreceiveFeeCustomerAcctCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeCustomerAcctCode() {
        return receiveFeeCustomerAcctCode;
    }

    /**
     * ����receiveFeeCustomerAcctCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeCustomerAcctCode(String value) {
        this.receiveFeeCustomerAcctCode = value;
    }

    /**
     * ��ȡreceiveFeeWaybillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeWaybillId() {
        return receiveFeeWaybillId;
    }

    /**
     * ����receiveFeeWaybillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeWaybillId(String value) {
        this.receiveFeeWaybillId = value;
    }

    /**
     * ��ȡreceiveFeeWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeWaybillNo() {
        return receiveFeeWaybillNo;
    }

    /**
     * ����receiveFeeWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeWaybillNo(String value) {
        this.receiveFeeWaybillNo = value;
    }

    /**
     * ��ȡreceiveFeeInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveFeeInputTm() {
        return receiveFeeInputTm;
    }

    /**
     * ����receiveFeeInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveFeeInputTm(XMLGregorianCalendar value) {
        this.receiveFeeInputTm = value;
    }

    /**
     * ��ȡreceiveFeeVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveFeeVersionNo() {
        return receiveFeeVersionNo;
    }

    /**
     * ����receiveFeeVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveFeeVersionNo(Integer value) {
        this.receiveFeeVersionNo = value;
    }

    /**
     * ��ȡreceiveFeeCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeCurrencyCode() {
        return receiveFeeCurrencyCode;
    }

    /**
     * ����receiveFeeCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeCurrencyCode(String value) {
        this.receiveFeeCurrencyCode = value;
    }

    /**
     * ��ȡreceiveFeeGatherEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeGatherEmpCode() {
        return receiveFeeGatherEmpCode;
    }

    /**
     * ����receiveFeeGatherEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeGatherEmpCode(String value) {
        this.receiveFeeGatherEmpCode = value;
    }

    /**
     * ��ȡreceiveFeeInputTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeInputTypeCode() {
        return receiveFeeInputTypeCode;
    }

    /**
     * ����receiveFeeInputTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeInputTypeCode(String value) {
        this.receiveFeeInputTypeCode = value;
    }

    /**
     * ��ȡreceiveFeeBizOwnerZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeBizOwnerZoneCode() {
        return receiveFeeBizOwnerZoneCode;
    }

    /**
     * ����receiveFeeBizOwnerZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeBizOwnerZoneCode(String value) {
        this.receiveFeeBizOwnerZoneCode = value;
    }

    /**
     * ��ȡreceiveFeeGstFee���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveFeeGstFee() {
        return receiveFeeGstFee;
    }

    /**
     * ����receiveFeeGstFee���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveFeeGstFee(Double value) {
        this.receiveFeeGstFee = value;
    }

    /**
     * ��ȡreceiveFeeSourceCodeFeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveFeeSourceCodeFeeAmt() {
        return receiveFeeSourceCodeFeeAmt;
    }

    /**
     * ����receiveFeeSourceCodeFeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveFeeSourceCodeFeeAmt(Double value) {
        this.receiveFeeSourceCodeFeeAmt = value;
    }

    /**
     * ��ȡreceiveFeeExchangeRate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveFeeExchangeRate() {
        return receiveFeeExchangeRate;
    }

    /**
     * ����receiveFeeExchangeRate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveFeeExchangeRate(Double value) {
        this.receiveFeeExchangeRate = value;
    }

    /**
     * ��ȡreceiveFeeDestCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeDestCurrencyCode() {
        return receiveFeeDestCurrencyCode;
    }

    /**
     * ����receiveFeeDestCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeDestCurrencyCode(String value) {
        this.receiveFeeDestCurrencyCode = value;
    }

    /**
     * ��ȡreceiveFeeRefundFeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveFeeRefundFeeAmt() {
        return receiveFeeRefundFeeAmt;
    }

    /**
     * ����receiveFeeRefundFeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveFeeRefundFeeAmt(Double value) {
        this.receiveFeeRefundFeeAmt = value;
    }

    /**
     * ��ȡreceiveFeeNewInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveFeeNewInputTm() {
        return receiveFeeNewInputTm;
    }

    /**
     * ����receiveFeeNewInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveFeeNewInputTm(XMLGregorianCalendar value) {
        this.receiveFeeNewInputTm = value;
    }

    /**
     * ��ȡreceiveFeeFeeId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeFeeId() {
        return receiveFeeFeeId;
    }

    /**
     * ����receiveFeeFeeId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeFeeId(String value) {
        this.receiveFeeFeeId = value;
    }

    /**
     * ��ȡreceiveFeeFeeTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeFeeTypeCode() {
        return receiveFeeFeeTypeCode;
    }

    /**
     * ����receiveFeeFeeTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeFeeTypeCode(String value) {
        this.receiveFeeFeeTypeCode = value;
    }

    /**
     * ��ȡreceiveFeeFeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getReceiveFeeFeeAmt() {
        return receiveFeeFeeAmt;
    }

    /**
     * ����receiveFeeFeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setReceiveFeeFeeAmt(Double value) {
        this.receiveFeeFeeAmt = value;
    }

    /**
     * ��ȡreceiveFeeGatherZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeGatherZoneCode() {
        return receiveFeeGatherZoneCode;
    }

    /**
     * ����receiveFeeGatherZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeGatherZoneCode(String value) {
        this.receiveFeeGatherZoneCode = value;
    }

    /**
     * ��ȡreceiveFeePaymentTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeePaymentTypeCode() {
        return receiveFeePaymentTypeCode;
    }

    /**
     * ����receiveFeePaymentTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeePaymentTypeCode(String value) {
        this.receiveFeePaymentTypeCode = value;
    }

    /**
     * ��ȡreceiveFeeSettlementTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveFeeSettlementTypeCode() {
        return receiveFeeSettlementTypeCode;
    }

    /**
     * ����receiveFeeSettlementTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveFeeSettlementTypeCode(String value) {
        this.receiveFeeSettlementTypeCode = value;
    }

}
