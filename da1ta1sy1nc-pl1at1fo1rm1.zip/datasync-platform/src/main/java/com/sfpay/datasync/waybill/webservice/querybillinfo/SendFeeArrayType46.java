
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>sendFeeArrayType_46 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="sendFeeArrayType_46">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_feeId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_feeTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_feeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_gatherZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_paymentTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_settlementTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_paymentChangeTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_serviceId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_customerAcctCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_waybillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_inputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_versionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_currencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_gatherEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_inputTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_bizOwnerZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_gstFee" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_sourceCodeFeeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_exchangeRate" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_destCurrencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_refundFeeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendFee_newInputTm" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sendFeeArrayType_46", propOrder = {
    "sendFeeFeeId",
    "sendFeeFeeTypeCode",
    "sendFeeFeeAmt",
    "sendFeeGatherZoneCode",
    "sendFeePaymentTypeCode",
    "sendFeeSettlementTypeCode",
    "sendFeePaymentChangeTypeCode",
    "sendFeeServiceId",
    "sendFeeCustomerAcctCode",
    "sendFeeWaybillId",
    "sendFeeWaybillNo",
    "sendFeeInputTm",
    "sendFeeVersionNo",
    "sendFeeCurrencyCode",
    "sendFeeGatherEmpCode",
    "sendFeeInputTypeCode",
    "sendFeeBizOwnerZoneCode",
    "sendFeeGstFee",
    "sendFeeSourceCodeFeeAmt",
    "sendFeeExchangeRate",
    "sendFeeDestCurrencyCode",
    "sendFeeRefundFeeAmt",
    "sendFeeNewInputTm"
})
public class SendFeeArrayType46 {

    @XmlElement(name = "sendFee_feeId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeFeeId;
    @XmlElement(name = "sendFee_feeTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeFeeTypeCode;
    @XmlElement(name = "sendFee_feeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendFeeFeeAmt;
    @XmlElement(name = "sendFee_gatherZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeGatherZoneCode;
    @XmlElement(name = "sendFee_paymentTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeePaymentTypeCode;
    @XmlElement(name = "sendFee_settlementTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeSettlementTypeCode;
    @XmlElement(name = "sendFee_paymentChangeTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeePaymentChangeTypeCode;
    @XmlElement(name = "sendFee_serviceId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeServiceId;
    @XmlElement(name = "sendFee_customerAcctCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeCustomerAcctCode;
    @XmlElement(name = "sendFee_waybillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeWaybillId;
    @XmlElement(name = "sendFee_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeWaybillNo;
    @XmlElement(name = "sendFee_inputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendFeeInputTm;
    @XmlElement(name = "sendFee_versionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendFeeVersionNo;
    @XmlElement(name = "sendFee_currencyCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeCurrencyCode;
    @XmlElement(name = "sendFee_gatherEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeGatherEmpCode;
    @XmlElement(name = "sendFee_inputTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeInputTypeCode;
    @XmlElement(name = "sendFee_bizOwnerZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeBizOwnerZoneCode;
    @XmlElement(name = "sendFee_gstFee", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendFeeGstFee;
    @XmlElement(name = "sendFee_sourceCodeFeeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendFeeSourceCodeFeeAmt;
    @XmlElement(name = "sendFee_exchangeRate", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendFeeExchangeRate;
    @XmlElement(name = "sendFee_destCurrencyCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendFeeDestCurrencyCode;
    @XmlElement(name = "sendFee_refundFeeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendFeeRefundFeeAmt;
    @XmlElement(name = "sendFee_newInputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendFeeNewInputTm;

    /**
     * ��ȡsendFeeFeeId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeFeeId() {
        return sendFeeFeeId;
    }

    /**
     * ����sendFeeFeeId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeFeeId(String value) {
        this.sendFeeFeeId = value;
    }

    /**
     * ��ȡsendFeeFeeTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeFeeTypeCode() {
        return sendFeeFeeTypeCode;
    }

    /**
     * ����sendFeeFeeTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeFeeTypeCode(String value) {
        this.sendFeeFeeTypeCode = value;
    }

    /**
     * ��ȡsendFeeFeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendFeeFeeAmt() {
        return sendFeeFeeAmt;
    }

    /**
     * ����sendFeeFeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendFeeFeeAmt(Double value) {
        this.sendFeeFeeAmt = value;
    }

    /**
     * ��ȡsendFeeGatherZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeGatherZoneCode() {
        return sendFeeGatherZoneCode;
    }

    /**
     * ����sendFeeGatherZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeGatherZoneCode(String value) {
        this.sendFeeGatherZoneCode = value;
    }

    /**
     * ��ȡsendFeePaymentTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeePaymentTypeCode() {
        return sendFeePaymentTypeCode;
    }

    /**
     * ����sendFeePaymentTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeePaymentTypeCode(String value) {
        this.sendFeePaymentTypeCode = value;
    }

    /**
     * ��ȡsendFeeSettlementTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeSettlementTypeCode() {
        return sendFeeSettlementTypeCode;
    }

    /**
     * ����sendFeeSettlementTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeSettlementTypeCode(String value) {
        this.sendFeeSettlementTypeCode = value;
    }

    /**
     * ��ȡsendFeePaymentChangeTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeePaymentChangeTypeCode() {
        return sendFeePaymentChangeTypeCode;
    }

    /**
     * ����sendFeePaymentChangeTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeePaymentChangeTypeCode(String value) {
        this.sendFeePaymentChangeTypeCode = value;
    }

    /**
     * ��ȡsendFeeServiceId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeServiceId() {
        return sendFeeServiceId;
    }

    /**
     * ����sendFeeServiceId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeServiceId(String value) {
        this.sendFeeServiceId = value;
    }

    /**
     * ��ȡsendFeeCustomerAcctCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeCustomerAcctCode() {
        return sendFeeCustomerAcctCode;
    }

    /**
     * ����sendFeeCustomerAcctCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeCustomerAcctCode(String value) {
        this.sendFeeCustomerAcctCode = value;
    }

    /**
     * ��ȡsendFeeWaybillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeWaybillId() {
        return sendFeeWaybillId;
    }

    /**
     * ����sendFeeWaybillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeWaybillId(String value) {
        this.sendFeeWaybillId = value;
    }

    /**
     * ��ȡsendFeeWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeWaybillNo() {
        return sendFeeWaybillNo;
    }

    /**
     * ����sendFeeWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeWaybillNo(String value) {
        this.sendFeeWaybillNo = value;
    }

    /**
     * ��ȡsendFeeInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendFeeInputTm() {
        return sendFeeInputTm;
    }

    /**
     * ����sendFeeInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendFeeInputTm(XMLGregorianCalendar value) {
        this.sendFeeInputTm = value;
    }

    /**
     * ��ȡsendFeeVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendFeeVersionNo() {
        return sendFeeVersionNo;
    }

    /**
     * ����sendFeeVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendFeeVersionNo(Integer value) {
        this.sendFeeVersionNo = value;
    }

    /**
     * ��ȡsendFeeCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeCurrencyCode() {
        return sendFeeCurrencyCode;
    }

    /**
     * ����sendFeeCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeCurrencyCode(String value) {
        this.sendFeeCurrencyCode = value;
    }

    /**
     * ��ȡsendFeeGatherEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeGatherEmpCode() {
        return sendFeeGatherEmpCode;
    }

    /**
     * ����sendFeeGatherEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeGatherEmpCode(String value) {
        this.sendFeeGatherEmpCode = value;
    }

    /**
     * ��ȡsendFeeInputTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeInputTypeCode() {
        return sendFeeInputTypeCode;
    }

    /**
     * ����sendFeeInputTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeInputTypeCode(String value) {
        this.sendFeeInputTypeCode = value;
    }

    /**
     * ��ȡsendFeeBizOwnerZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeBizOwnerZoneCode() {
        return sendFeeBizOwnerZoneCode;
    }

    /**
     * ����sendFeeBizOwnerZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeBizOwnerZoneCode(String value) {
        this.sendFeeBizOwnerZoneCode = value;
    }

    /**
     * ��ȡsendFeeGstFee���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendFeeGstFee() {
        return sendFeeGstFee;
    }

    /**
     * ����sendFeeGstFee���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendFeeGstFee(Double value) {
        this.sendFeeGstFee = value;
    }

    /**
     * ��ȡsendFeeSourceCodeFeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendFeeSourceCodeFeeAmt() {
        return sendFeeSourceCodeFeeAmt;
    }

    /**
     * ����sendFeeSourceCodeFeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendFeeSourceCodeFeeAmt(Double value) {
        this.sendFeeSourceCodeFeeAmt = value;
    }

    /**
     * ��ȡsendFeeExchangeRate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendFeeExchangeRate() {
        return sendFeeExchangeRate;
    }

    /**
     * ����sendFeeExchangeRate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendFeeExchangeRate(Double value) {
        this.sendFeeExchangeRate = value;
    }

    /**
     * ��ȡsendFeeDestCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendFeeDestCurrencyCode() {
        return sendFeeDestCurrencyCode;
    }

    /**
     * ����sendFeeDestCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendFeeDestCurrencyCode(String value) {
        this.sendFeeDestCurrencyCode = value;
    }

    /**
     * ��ȡsendFeeRefundFeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendFeeRefundFeeAmt() {
        return sendFeeRefundFeeAmt;
    }

    /**
     * ����sendFeeRefundFeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendFeeRefundFeeAmt(Double value) {
        this.sendFeeRefundFeeAmt = value;
    }

    /**
     * ��ȡsendFeeNewInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendFeeNewInputTm() {
        return sendFeeNewInputTm;
    }

    /**
     * ����sendFeeNewInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendFeeNewInputTm(XMLGregorianCalendar value) {
        this.sendFeeNewInputTm = value;
    }

}
