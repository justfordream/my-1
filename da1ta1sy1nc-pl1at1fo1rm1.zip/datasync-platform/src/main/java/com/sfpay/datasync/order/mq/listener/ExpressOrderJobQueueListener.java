/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.datasync.order.mq.listener;

import java.io.ByteArrayInputStream;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.sfpay.datasync.hht.enums.DataVariety;
import com.sfpay.datasync.hht.enums.SystemCode;
import com.sfpay.datasync.hht.mq.listener.BaseListener;
import com.sfpay.datasync.order.domain.ExpressOrderJob;
import com.sfpay.datasync.order.service.IExpressOrderJobService;
import com.sfpay.framework.common.xml.dom4j.core.XmlParser;

/**
 * 类说明：资科调度系统订单作业回调监听器
 *
 * 类描述：资科调度系统订单作业回调监听器
 * @author 625288 易振强
 * 2014-11-12
 */
public class ExpressOrderJobQueueListener extends BaseListener
{
	@Autowired
	private IExpressOrderJobService expressOrderJobService;
	
	private static final Logger logger = LoggerFactory.getLogger(ExpressOrderJobQueueListener.class);
	
	@Override
	protected void execute(Object msg) throws Exception {
		if(msg == null) {
			logger.info("ExpressOrderJobQueueListener execute 数据为空,直接返回");
			return ;
		}
		
		ExpressOrderJob expressOrderJob = null;
		try {
			expressOrderJob = XmlParser.parserXml(ExpressOrderJob.class, new ByteArrayInputStream(msg.toString().getBytes("UTF-8")));
		} catch (Exception e) {
			logger.info(String.format("ExpressOrderJobQueueListener execute 将msg【%s】转化成ExpressOrderJob对象错误:【%s】", new Object[]{msg, e}));
			return ;
		}
		
		if(expressOrderJob == null) {
			logger.error(String.format("ExpressOrderJobQueueListener execute 将消息解析成ExpressOrderJob对象为空！:%s", msg));
			return ;
		}
		
//		logger.info(String.format("ExpressOrderJobQueueListener execute 将消息解析成ExpressOrderJob对象成功:%s %s", 
//					new Object[]{expressOrderJob.getJobId(), expressOrderJob.getOrderId()}));
		
		try {
			expressOrderJobService.addExpressOrderJob(expressOrderJob);
//			logger.info(String.format("ExpressOrderJobQueueListener execute end:%s %s", 
//					new Object[]{expressOrderJob.getJobId(), expressOrderJob.getOrderId()}));
		} catch (Exception e) {
			logger.error("ExpressOrderJobQueueListener execute end:{} {}", expressOrderJob.getJobId(), e);
		}
	}

	@Override
	protected SystemCode getSystemCode()
	{
		return SystemCode.EXPRESSORDERJOB;
	}

	@Override
	protected DataVariety getDataVariety()
	{
		return DataVariety.expressorderjob;
	}

}
