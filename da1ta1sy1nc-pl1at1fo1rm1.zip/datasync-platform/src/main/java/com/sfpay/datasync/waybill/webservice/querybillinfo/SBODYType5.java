
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>SBODYType_5 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="SBODYType_5">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeAddr" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeCompName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeContName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseePhone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}isValid" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}message" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SBODYType_5", propOrder = {
    "addresseeAddr",
    "addresseeCompName",
    "addresseeContName",
    "addresseeMobile",
    "addresseePhone",
    "isValid",
    "message"
})
public class SBODYType5 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeAddr;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeCompName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeContName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeMobile;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseePhone;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String isValid;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String message;

    /**
     * ��ȡaddresseeAddr���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeAddr() {
        return addresseeAddr;
    }

    /**
     * ����addresseeAddr���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeAddr(String value) {
        this.addresseeAddr = value;
    }

    /**
     * ��ȡaddresseeCompName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeCompName() {
        return addresseeCompName;
    }

    /**
     * ����addresseeCompName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeCompName(String value) {
        this.addresseeCompName = value;
    }

    /**
     * ��ȡaddresseeContName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeContName() {
        return addresseeContName;
    }

    /**
     * ����addresseeContName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeContName(String value) {
        this.addresseeContName = value;
    }

    /**
     * ��ȡaddresseeMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeMobile() {
        return addresseeMobile;
    }

    /**
     * ����addresseeMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeMobile(String value) {
        this.addresseeMobile = value;
    }

    /**
     * ��ȡaddresseePhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseePhone() {
        return addresseePhone;
    }

    /**
     * ����addresseePhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseePhone(String value) {
        this.addresseePhone = value;
    }

    /**
     * ��ȡisValid���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsValid() {
        return isValid;
    }

    /**
     * ����isValid���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsValid(String value) {
        this.isValid = value;
    }

    /**
     * ��ȡmessage���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * ����message���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

}
