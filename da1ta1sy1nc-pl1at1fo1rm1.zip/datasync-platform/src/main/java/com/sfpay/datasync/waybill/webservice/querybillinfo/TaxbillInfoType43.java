
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>taxbillInfoType_43 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="taxbillInfoType_43">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_taxbillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_taxbillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_importTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_customsDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_customsDutiesAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_salesTaxAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_exciseAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_totalTaxfeeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_currencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_importedDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_handlingFeeAmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}taxbillInfo_othertaxAmt" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "taxbillInfoType_43", propOrder = {
    "taxbillInfoTaxbillId",
    "taxbillInfoWaybillNo",
    "taxbillInfoTaxbillNo",
    "taxbillInfoImportTm",
    "taxbillInfoCustomsDate",
    "taxbillInfoCustomsDutiesAmt",
    "taxbillInfoSalesTaxAmt",
    "taxbillInfoExciseAmt",
    "taxbillInfoTotalTaxfeeAmt",
    "taxbillInfoCurrencyCode",
    "taxbillInfoImportedDt",
    "taxbillInfoHandlingFeeAmt",
    "taxbillInfoOthertaxAmt"
})
public class TaxbillInfoType43 {

    @XmlElement(name = "taxbillInfo_taxbillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String taxbillInfoTaxbillId;
    @XmlElement(name = "taxbillInfo_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String taxbillInfoWaybillNo;
    @XmlElement(name = "taxbillInfo_taxbillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String taxbillInfoTaxbillNo;
    @XmlElement(name = "taxbillInfo_importTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar taxbillInfoImportTm;
    @XmlElement(name = "taxbillInfo_customsDate", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar taxbillInfoCustomsDate;
    @XmlElement(name = "taxbillInfo_customsDutiesAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double taxbillInfoCustomsDutiesAmt;
    @XmlElement(name = "taxbillInfo_salesTaxAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double taxbillInfoSalesTaxAmt;
    @XmlElement(name = "taxbillInfo_exciseAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double taxbillInfoExciseAmt;
    @XmlElement(name = "taxbillInfo_totalTaxfeeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double taxbillInfoTotalTaxfeeAmt;
    @XmlElement(name = "taxbillInfo_currencyCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String taxbillInfoCurrencyCode;
    @XmlElement(name = "taxbillInfo_importedDt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar taxbillInfoImportedDt;
    @XmlElement(name = "taxbillInfo_handlingFeeAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double taxbillInfoHandlingFeeAmt;
    @XmlElement(name = "taxbillInfo_othertaxAmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double taxbillInfoOthertaxAmt;

    /**
     * ��ȡtaxbillInfoTaxbillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxbillInfoTaxbillId() {
        return taxbillInfoTaxbillId;
    }

    /**
     * ����taxbillInfoTaxbillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxbillInfoTaxbillId(String value) {
        this.taxbillInfoTaxbillId = value;
    }

    /**
     * ��ȡtaxbillInfoWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxbillInfoWaybillNo() {
        return taxbillInfoWaybillNo;
    }

    /**
     * ����taxbillInfoWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxbillInfoWaybillNo(String value) {
        this.taxbillInfoWaybillNo = value;
    }

    /**
     * ��ȡtaxbillInfoTaxbillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxbillInfoTaxbillNo() {
        return taxbillInfoTaxbillNo;
    }

    /**
     * ����taxbillInfoTaxbillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxbillInfoTaxbillNo(String value) {
        this.taxbillInfoTaxbillNo = value;
    }

    /**
     * ��ȡtaxbillInfoImportTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTaxbillInfoImportTm() {
        return taxbillInfoImportTm;
    }

    /**
     * ����taxbillInfoImportTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setTaxbillInfoImportTm(XMLGregorianCalendar value) {
        this.taxbillInfoImportTm = value;
    }

    /**
     * ��ȡtaxbillInfoCustomsDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTaxbillInfoCustomsDate() {
        return taxbillInfoCustomsDate;
    }

    /**
     * ����taxbillInfoCustomsDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setTaxbillInfoCustomsDate(XMLGregorianCalendar value) {
        this.taxbillInfoCustomsDate = value;
    }

    /**
     * ��ȡtaxbillInfoCustomsDutiesAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTaxbillInfoCustomsDutiesAmt() {
        return taxbillInfoCustomsDutiesAmt;
    }

    /**
     * ����taxbillInfoCustomsDutiesAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTaxbillInfoCustomsDutiesAmt(Double value) {
        this.taxbillInfoCustomsDutiesAmt = value;
    }

    /**
     * ��ȡtaxbillInfoSalesTaxAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTaxbillInfoSalesTaxAmt() {
        return taxbillInfoSalesTaxAmt;
    }

    /**
     * ����taxbillInfoSalesTaxAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTaxbillInfoSalesTaxAmt(Double value) {
        this.taxbillInfoSalesTaxAmt = value;
    }

    /**
     * ��ȡtaxbillInfoExciseAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTaxbillInfoExciseAmt() {
        return taxbillInfoExciseAmt;
    }

    /**
     * ����taxbillInfoExciseAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTaxbillInfoExciseAmt(Double value) {
        this.taxbillInfoExciseAmt = value;
    }

    /**
     * ��ȡtaxbillInfoTotalTaxfeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTaxbillInfoTotalTaxfeeAmt() {
        return taxbillInfoTotalTaxfeeAmt;
    }

    /**
     * ����taxbillInfoTotalTaxfeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTaxbillInfoTotalTaxfeeAmt(Double value) {
        this.taxbillInfoTotalTaxfeeAmt = value;
    }

    /**
     * ��ȡtaxbillInfoCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxbillInfoCurrencyCode() {
        return taxbillInfoCurrencyCode;
    }

    /**
     * ����taxbillInfoCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxbillInfoCurrencyCode(String value) {
        this.taxbillInfoCurrencyCode = value;
    }

    /**
     * ��ȡtaxbillInfoImportedDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTaxbillInfoImportedDt() {
        return taxbillInfoImportedDt;
    }

    /**
     * ����taxbillInfoImportedDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setTaxbillInfoImportedDt(XMLGregorianCalendar value) {
        this.taxbillInfoImportedDt = value;
    }

    /**
     * ��ȡtaxbillInfoHandlingFeeAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTaxbillInfoHandlingFeeAmt() {
        return taxbillInfoHandlingFeeAmt;
    }

    /**
     * ����taxbillInfoHandlingFeeAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTaxbillInfoHandlingFeeAmt(Double value) {
        this.taxbillInfoHandlingFeeAmt = value;
    }

    /**
     * ��ȡtaxbillInfoOthertaxAmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTaxbillInfoOthertaxAmt() {
        return taxbillInfoOthertaxAmt;
    }

    /**
     * ����taxbillInfoOthertaxAmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTaxbillInfoOthertaxAmt(Double value) {
        this.taxbillInfoOthertaxAmt = value;
    }

}
