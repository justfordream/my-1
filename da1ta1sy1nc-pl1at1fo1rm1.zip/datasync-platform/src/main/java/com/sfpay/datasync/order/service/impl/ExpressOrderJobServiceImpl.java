/**
 * 
 */
package com.sfpay.datasync.order.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfpay.datasync.constant.MsgCode;
import com.sfpay.datasync.order.dao.IExpressOrderJobDao;
import com.sfpay.datasync.order.domain.ContactAddrInfo;
import com.sfpay.datasync.order.domain.ExpressOrder;
import com.sfpay.datasync.order.domain.ExpressOrderJob;
import com.sfpay.datasync.order.service.IContactAddrInfoService;
import com.sfpay.datasync.order.service.IExpressOrderJobService;
import com.sfpay.datasync.order.service.IExpressOrderService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：全网订单作业管理接口实现类
 *
 * 类描述：全网订单作业管理接口实现类
 * @author 625288 易振强
 * 2014-11-12
 */
@Service
public class ExpressOrderJobServiceImpl implements IExpressOrderJobService{
	@Autowired
	private IExpressOrderJobDao expressOrderJobDao;
	@Autowired
	private IExpressOrderService expressOrderService;
	@Autowired
	private IContactAddrInfoService contactAddrInfoService;
	 
	private static final Logger logger = LoggerFactory.getLogger(ExpressOrderJobServiceImpl.class);
	
	/**
	 * 新增全网订单作业
	 * 
	 * @param expressOrderJob
	 * @throws ServiceException 20031-订单作业数据不能为空 20032-订单作业数据校验失败
	 */
	@Override
	public void addExpressOrderJob(ExpressOrderJob expressOrderJob)
			throws ServiceException {
		if(expressOrderJob == null) {
			throw new ServiceException(MsgCode.EXPRESSORDERJOB_CAN_NOT_EMPTY, 
					MsgCode.getValue(MsgCode.EXPRESSORDERJOB_CAN_NOT_EMPTY));
		}
		
		logger.info(String.format("addExpressOrderJob start:%s %s... ...", new Object[]{expressOrderJob.getJobId(), 
				expressOrderJob.getOrderId()}));
		
		// 检查数据完整性
		if(StringUtils.isBlank(expressOrderJob.getJobId()) || StringUtils.isBlank(expressOrderJob.getOrderId())) {
			logger.info("addExpressOrderJob jobId 或 orderId为空！");
			throw new ServiceException(MsgCode.EXPRESSORDERJOB_CHECK_FAIL, 
					MsgCode.getValue(MsgCode.EXPRESSORDERJOB_CHECK_FAIL));
		}
		
		// 通过订单号前缀和长度来判断是否是属于我们的订单号
		if(!expressOrderJob.getOrderId().startsWith(ExpressOrderServiceImpl.ORDER_ID_PREFIX) || expressOrderJob.getOrderId().length() != 30) {
//			logger.info(String.format("addExpressOrderJob 的订单号【%s】不是以DATASYNC开头或者长度不是30位，不添加到数据库", 
//					expressOrderJob.getOrderId()));
			return ;
		}
		
		// 检查看我们有没有该订单号
		ExpressOrder expressOrder = expressOrderService.queryExpressOrderByOrderId(expressOrderJob.getOrderId());
		if(expressOrder == null) {
			logger.info(String.format("addExpressOrderJob 找不到对应的订单号%s数据，不添加到数据库:%s", 
					new Object[]{expressOrderJob.getOrderId(), expressOrderJob.getJobId()}));
			return ;
		}
		
		
		// 插入到数据库
		logger.info(String.format("addExpressOrderJob 准备将订单作业信息插入到数据库:%s", expressOrderJob));
		expressOrderJobDao.addExpressOrderJob(expressOrderJob);
		
		// 开始更新原订单中联系人地址信息中的单元区域
//		logger.info(String.format("addExpressOrderJob 开始更新原订单的寄件联系人地址信息中的单元区域:%s %s", 
//				new Object[]{expressOrderJob.getJobId(), expressOrderJob.getOrderId()}));
		
		// 如果地址、城市代码和单元区域都不为空，则区更新联系人地址信息中的单元区域
		if(StringUtils.isNotBlank(expressOrder.getAddrAbb()) && StringUtils.isNotBlank(expressOrder.getAreaNo()) 
				&& StringUtils.isNotBlank(expressOrderJob.getTeamId())) {
			ContactAddrInfo contactAddrInfo = contactAddrInfoService.queryContactAddrInfoById(expressOrder.
					getSenderAddrId());
			if(contactAddrInfo != null) {
				ContactAddrInfo queryContactAddrInfo = new ContactAddrInfo();
				queryContactAddrInfo.setAddress(expressOrder.getAddrAbb());
				queryContactAddrInfo.setDistCityCode(expressOrder.getAreaNo());
				List<ContactAddrInfo> contactAddrInfoList = contactAddrInfoService.queryAddressInfoByParam(queryContactAddrInfo);
				if(contactAddrInfoList != null && !contactAddrInfoList.isEmpty()) {
					contactAddrInfo.setTeamId(expressOrderJob.getTeamId());
					try {
						// 更新操作是否成功不应该影响Job的保存
						contactAddrInfoService.updateAddressInfo(contactAddrInfo);
					} catch (Exception e) {
						logger.warn(String.format("addExpressOrderJob 更新的联系人地址信息的单元区域失败:%s", contactAddrInfo), e);
					}
				}
				
			} else {
				logger.info(String.format("addExpressOrderJob 原订单的寄件联系人地址信息ID已不存在:%s %s", 
						new Object[]{expressOrderJob.getJobId(), expressOrderJob.getOrderId()}));
			}
			
		}
		
		logger.info(String.format("addExpressOrderJob end:%s %s", new Object[]{expressOrderJob.getJobId(), expressOrderJob.getOrderId()}));
	}

	/**
	 * 通过ID查询全网订单作业
	 * 
	 * @param expressOrderJob
	 */
	@Override
	public ExpressOrderJob queryExpressOrderJobById(Long id) {
		logger.info(String.format("queryExpressOrderJobById start:%s ... ...", id));
		if(id == null) {
			return null;
		}
		
		ExpressOrderJob expressOrderJob = expressOrderJobDao.queryExpressOrderJobById(id);
		
		logger.info(String.format("queryExpressOrderJobById end:%s", id));
		
		return expressOrderJob;
	}
	
	/**
	 * 通过运单号查询全网订单作业
	 * 
	 * @param expressOrderJob
	 */
	@Override
	public List<ExpressOrderJob> queryExpressOrderJobByWayBillNo(String wayBillNo) {
		logger.info(String.format("queryExpressOrderJobByWayBillNo start:%s ... ...", wayBillNo));
		if(StringUtils.isBlank(wayBillNo)) {
			return null;
		}
		
		List<ExpressOrderJob> expressOrderJobList = expressOrderJobDao.queryExpressOrderJobByWayBillNo(wayBillNo);
		
		logger.info(String.format("queryExpressOrderJobByWayBillNo end:%s", wayBillNo));
		
		return expressOrderJobList;
	}

	/**
	 * 通过参数查询全网订单作业
	 * 
	 * @param expressOrderJob
	 */
	@Override
	public List<ExpressOrderJob> queryExpressOrderJobByParam(
			ExpressOrderJob expressOrderJob) {
		logger.info(String.format("queryExpressOrderJobByParam start:%s ... ...", expressOrderJob));
		List<ExpressOrderJob> resultList = new ArrayList<ExpressOrderJob>();
		if(expressOrderJob == null) {
			return resultList;
		}
		
		resultList = expressOrderJobDao.queryExpressOrderJobByParam(expressOrderJob);
		
		logger.info(String.format("queryExpressOrderJobByParam end:%s", expressOrderJob));
		
		return resultList;
	}
}
