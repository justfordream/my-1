
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>consignListArrayType_44 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="consignListArrayType_44">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_consId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_qtyUnit" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_consName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_consQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_weightQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_consValue" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_waybillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_inputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_versionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_newInputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignList_waybillNo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "consignListArrayType_44", propOrder = {
    "consignListConsId",
    "consignListQtyUnit",
    "consignListConsName",
    "consignListConsQty",
    "consignListWeightQty",
    "consignListConsValue",
    "consignListWaybillId",
    "consignListInputTm",
    "consignListVersionNo",
    "consignListNewInputTm",
    "consignListWaybillNo"
})
public class ConsignListArrayType44 {

    @XmlElement(name = "consignList_consId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignListConsId;
    @XmlElement(name = "consignList_qtyUnit", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignListQtyUnit;
    @XmlElement(name = "consignList_consName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignListConsName;
    @XmlElement(name = "consignList_consQty", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignListConsQty;
    @XmlElement(name = "consignList_weightQty", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double consignListWeightQty;
    @XmlElement(name = "consignList_consValue", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double consignListConsValue;
    @XmlElement(name = "consignList_waybillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignListWaybillId;
    @XmlElement(name = "consignList_inputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar consignListInputTm;
    @XmlElement(name = "consignList_versionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer consignListVersionNo;
    @XmlElement(name = "consignList_newInputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar consignListNewInputTm;
    @XmlElement(name = "consignList_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignListWaybillNo;

    /**
     * ��ȡconsignListConsId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignListConsId() {
        return consignListConsId;
    }

    /**
     * ����consignListConsId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignListConsId(String value) {
        this.consignListConsId = value;
    }

    /**
     * ��ȡconsignListQtyUnit���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignListQtyUnit() {
        return consignListQtyUnit;
    }

    /**
     * ����consignListQtyUnit���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignListQtyUnit(String value) {
        this.consignListQtyUnit = value;
    }

    /**
     * ��ȡconsignListConsName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignListConsName() {
        return consignListConsName;
    }

    /**
     * ����consignListConsName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignListConsName(String value) {
        this.consignListConsName = value;
    }

    /**
     * ��ȡconsignListConsQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignListConsQty() {
        return consignListConsQty;
    }

    /**
     * ����consignListConsQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignListConsQty(String value) {
        this.consignListConsQty = value;
    }

    /**
     * ��ȡconsignListWeightQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getConsignListWeightQty() {
        return consignListWeightQty;
    }

    /**
     * ����consignListWeightQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setConsignListWeightQty(Double value) {
        this.consignListWeightQty = value;
    }

    /**
     * ��ȡconsignListConsValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getConsignListConsValue() {
        return consignListConsValue;
    }

    /**
     * ����consignListConsValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setConsignListConsValue(Double value) {
        this.consignListConsValue = value;
    }

    /**
     * ��ȡconsignListWaybillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignListWaybillId() {
        return consignListWaybillId;
    }

    /**
     * ����consignListWaybillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignListWaybillId(String value) {
        this.consignListWaybillId = value;
    }

    /**
     * ��ȡconsignListInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getConsignListInputTm() {
        return consignListInputTm;
    }

    /**
     * ����consignListInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setConsignListInputTm(XMLGregorianCalendar value) {
        this.consignListInputTm = value;
    }

    /**
     * ��ȡconsignListVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getConsignListVersionNo() {
        return consignListVersionNo;
    }

    /**
     * ����consignListVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setConsignListVersionNo(Integer value) {
        this.consignListVersionNo = value;
    }

    /**
     * ��ȡconsignListNewInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getConsignListNewInputTm() {
        return consignListNewInputTm;
    }

    /**
     * ����consignListNewInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setConsignListNewInputTm(XMLGregorianCalendar value) {
        this.consignListNewInputTm = value;
    }

    /**
     * ��ȡconsignListWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignListWaybillNo() {
        return consignListWaybillNo;
    }

    /**
     * ����consignListWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignListWaybillNo(String value) {
        this.consignListWaybillNo = value;
    }

}
