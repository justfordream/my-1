/**
 * 
 */
package com.sfpay.datasync.mq;

public class UnknownMQMessageException extends Exception {

	private static final long serialVersionUID = -5552523251857441973L;

	public UnknownMQMessageException() {
	}

	public UnknownMQMessageException(String message) {
		super(message);
	}

	public UnknownMQMessageException(String message, Throwable cause) {
		super(message, cause);
	}

	public UnknownMQMessageException(Throwable cause) {
		super(cause);
	}
}