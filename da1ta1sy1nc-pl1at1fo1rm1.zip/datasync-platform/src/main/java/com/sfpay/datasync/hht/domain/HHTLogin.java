/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.datasync.hht.domain;

import com.sfpay.framework.base.entity.BaseEntity;
import com.sfpay.framework.common.xml.dom4j.base.XElement;
import com.sfpay.framework.common.xml.dom4j.base.XmlBaseModel;
import com.sfpay.framework.common.xml.dom4j.base.XmlType;

/**
 * 
 * 类说明：
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 321302 程俊杰
 *   
 * CreateDate: 2012-6-14
 */
@XElement(name = "empLogin_to", clazz = HHTLogin.class)
public class HHTLogin extends BaseEntity implements XmlBaseModel
{
	private static final long serialVersionUID = -2007520993978832291L;

	/**
	 * 巴枪Id
	 */
	@XElement(name = "sn", type = XmlType.ELEMENT)
	private String sn;
	
	/**
	 * 网点Id
	 */
	@XElement(name = "dept_Id", type = XmlType.ELEMENT)
	private String departmentId;
	
	/**
	 * 收派员Id
	 */
	@XElement(name = "emp_Id", type = XmlType.ELEMENT)
	private String employeeId;

	@Override
	public boolean hasChildren()
	{
		return false;
	}

	public String getSn()
	{
		return sn;
	}

	public void setSn(String sn)
	{
		this.sn = sn;
	}

	public String getDepartmentId()
	{
		return departmentId;
	}

	public void setDepartmentId(String departmentId)
	{
		this.departmentId = departmentId;
	}

	public String getEmployeeId()
	{
		return employeeId;
	}

	public void setEmployeeId(String employeeId)
	{
		this.employeeId = employeeId;
	}
}
