/**
 * 
 */
package com.sfpay.datasync.order.dao;

import com.sfpay.datasync.order.domain.AddressTeam;

/**
 * 类说明：地址单元区域DAO
 *
 * 类描述：地址单元区域DAO
 * @author 625288 易振强
 * 2014-11-12
 */
public interface IAddressTeamDao {
	/**
	 * 新增一个地址单元区域
	 * @param addressTeam
	 */
	public void addAddressTeam(AddressTeam addressTeam);
}
