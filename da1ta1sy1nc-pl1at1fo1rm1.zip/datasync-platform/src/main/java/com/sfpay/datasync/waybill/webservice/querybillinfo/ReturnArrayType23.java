
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>returnArrayType_23 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="returnArrayType_23">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addService" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeCompName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consNames" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consQtys" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignorContName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}distName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}expressTypeName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}initExpectedDeliveryTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}lastExpectedDeliveryTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}meterageWeightQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}paymentTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}scanDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}scanTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}waiteServiceFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}childSet" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}childWaybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignedTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignorMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}consignorPhone" minOccurs="0"/>
 *         &lt;element name="descZoneCodeGps" type="{http://www.sf-express.com/esb/service/QueryBillInfo}descZoneCodeGpsArrayType_50" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}destCityName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}destZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}destZoneName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}isdeDeliveryPreparation" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}mainLandToMainLand" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveBillFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}signinTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sourceCityName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sourceZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sourceZoneName" minOccurs="0"/>
 *         &lt;element name="srcZoneCodeGps" type="{http://www.sf-express.com/esb/service/QueryBillInfo}srcZoneCodeArrayType_53" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}subscriberName" minOccurs="0"/>
 *         &lt;element name="vehicleGpsInfo" type="{http://www.sf-express.com/esb/service/QueryBillInfo}vehicleGpsInfoArrayType_51" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeAddrNative" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseeMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}addresseePhone" minOccurs="0"/>
 *         &lt;element name="barList" type="{http://www.sf-express.com/esb/service/QueryBillInfo}barListArrayType_24" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="barNewList" type="{http://www.sf-express.com/esb/service/QueryBillInfo}barNewListArrayType_25" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "returnArrayType_23", propOrder = {
    "waybillNo",
    "addService",
    "addresseeCompName",
    "consNames",
    "consQtys",
    "consignorContName",
    "distName",
    "expressTypeName",
    "initExpectedDeliveryTm",
    "lastExpectedDeliveryTm",
    "meterageWeightQty",
    "paymentTypeCode",
    "scanDate",
    "scanTime",
    "waiteServiceFlg",
    "childSet",
    "childWaybillNo",
    "consignedTm",
    "consignorMobile",
    "consignorPhone",
    "descZoneCodeGps",
    "destCityName",
    "destZoneCode",
    "destZoneName",
    "isdeDeliveryPreparation",
    "mainLandToMainLand",
    "receiveBillFlg",
    "signinTm",
    "sourceCityName",
    "sourceZoneCode",
    "sourceZoneName",
    "srcZoneCodeGps",
    "subscriberName",
    "vehicleGpsInfo",
    "addresseeAddrNative",
    "addresseeMobile",
    "addresseePhone",
    "barList",
    "barNewList"
})
public class ReturnArrayType23 {

    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String waybillNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addService;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeCompName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consNames;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consQtys;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignorContName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String distName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String expressTypeName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar initExpectedDeliveryTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastExpectedDeliveryTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double meterageWeightQty;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String paymentTypeCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String scanDate;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String scanTime;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String waiteServiceFlg;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String childSet;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String childWaybillNo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignedTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignorMobile;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String consignorPhone;
    @XmlElement(nillable = true)
    protected List<DescZoneCodeGpsArrayType50> descZoneCodeGps;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String destCityName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String destZoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String destZoneName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String isdeDeliveryPreparation;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String mainLandToMainLand;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveBillFlg;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String signinTm;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sourceCityName;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sourceZoneCode;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sourceZoneName;
    @XmlElement(nillable = true)
    protected List<SrcZoneCodeArrayType53> srcZoneCodeGps;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String subscriberName;
    @XmlElement(nillable = true)
    protected List<VehicleGpsInfoArrayType51> vehicleGpsInfo;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeAddrNative;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseeMobile;
    @XmlElement(namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String addresseePhone;
    @XmlElement(nillable = true)
    protected List<BarListArrayType24> barList;
    @XmlElement(nillable = true)
    protected List<BarNewListArrayType25> barNewList;

    /**
     * ��ȡwaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaybillNo() {
        return waybillNo;
    }

    /**
     * ����waybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaybillNo(String value) {
        this.waybillNo = value;
    }

    /**
     * ��ȡaddService���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddService() {
        return addService;
    }

    /**
     * ����addService���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddService(String value) {
        this.addService = value;
    }

    /**
     * ��ȡaddresseeCompName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeCompName() {
        return addresseeCompName;
    }

    /**
     * ����addresseeCompName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeCompName(String value) {
        this.addresseeCompName = value;
    }

    /**
     * ��ȡconsNames���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsNames() {
        return consNames;
    }

    /**
     * ����consNames���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsNames(String value) {
        this.consNames = value;
    }

    /**
     * ��ȡconsQtys���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsQtys() {
        return consQtys;
    }

    /**
     * ����consQtys���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsQtys(String value) {
        this.consQtys = value;
    }

    /**
     * ��ȡconsignorContName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignorContName() {
        return consignorContName;
    }

    /**
     * ����consignorContName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignorContName(String value) {
        this.consignorContName = value;
    }

    /**
     * ��ȡdistName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistName() {
        return distName;
    }

    /**
     * ����distName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistName(String value) {
        this.distName = value;
    }

    /**
     * ��ȡexpressTypeName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpressTypeName() {
        return expressTypeName;
    }

    /**
     * ����expressTypeName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpressTypeName(String value) {
        this.expressTypeName = value;
    }

    /**
     * ��ȡinitExpectedDeliveryTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getInitExpectedDeliveryTm() {
        return initExpectedDeliveryTm;
    }

    /**
     * ����initExpectedDeliveryTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setInitExpectedDeliveryTm(XMLGregorianCalendar value) {
        this.initExpectedDeliveryTm = value;
    }

    /**
     * ��ȡlastExpectedDeliveryTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastExpectedDeliveryTm() {
        return lastExpectedDeliveryTm;
    }

    /**
     * ����lastExpectedDeliveryTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setLastExpectedDeliveryTm(XMLGregorianCalendar value) {
        this.lastExpectedDeliveryTm = value;
    }

    /**
     * ��ȡmeterageWeightQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterageWeightQty() {
        return meterageWeightQty;
    }

    /**
     * ����meterageWeightQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterageWeightQty(Double value) {
        this.meterageWeightQty = value;
    }

    /**
     * ��ȡpaymentTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentTypeCode() {
        return paymentTypeCode;
    }

    /**
     * ����paymentTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentTypeCode(String value) {
        this.paymentTypeCode = value;
    }

    /**
     * ��ȡscanDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScanDate() {
        return scanDate;
    }

    /**
     * ����scanDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScanDate(String value) {
        this.scanDate = value;
    }

    /**
     * ��ȡscanTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScanTime() {
        return scanTime;
    }

    /**
     * ����scanTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScanTime(String value) {
        this.scanTime = value;
    }

    /**
     * ��ȡwaiteServiceFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaiteServiceFlg() {
        return waiteServiceFlg;
    }

    /**
     * ����waiteServiceFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaiteServiceFlg(String value) {
        this.waiteServiceFlg = value;
    }

    /**
     * ��ȡchildSet���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChildSet() {
        return childSet;
    }

    /**
     * ����childSet���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChildSet(String value) {
        this.childSet = value;
    }

    /**
     * ��ȡchildWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChildWaybillNo() {
        return childWaybillNo;
    }

    /**
     * ����childWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChildWaybillNo(String value) {
        this.childWaybillNo = value;
    }

    /**
     * ��ȡconsignedTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignedTm() {
        return consignedTm;
    }

    /**
     * ����consignedTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignedTm(String value) {
        this.consignedTm = value;
    }

    /**
     * ��ȡconsignorMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignorMobile() {
        return consignorMobile;
    }

    /**
     * ����consignorMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignorMobile(String value) {
        this.consignorMobile = value;
    }

    /**
     * ��ȡconsignorPhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignorPhone() {
        return consignorPhone;
    }

    /**
     * ����consignorPhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignorPhone(String value) {
        this.consignorPhone = value;
    }

    /**
     * Gets the value of the descZoneCodeGps property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the descZoneCodeGps property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDescZoneCodeGps().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DescZoneCodeGpsArrayType50 }
     * 
     * 
     */
    public List<DescZoneCodeGpsArrayType50> getDescZoneCodeGps() {
        if (descZoneCodeGps == null) {
            descZoneCodeGps = new ArrayList<DescZoneCodeGpsArrayType50>();
        }
        return this.descZoneCodeGps;
    }

    /**
     * ��ȡdestCityName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestCityName() {
        return destCityName;
    }

    /**
     * ����destCityName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestCityName(String value) {
        this.destCityName = value;
    }

    /**
     * ��ȡdestZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestZoneCode() {
        return destZoneCode;
    }

    /**
     * ����destZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestZoneCode(String value) {
        this.destZoneCode = value;
    }

    /**
     * ��ȡdestZoneName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestZoneName() {
        return destZoneName;
    }

    /**
     * ����destZoneName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestZoneName(String value) {
        this.destZoneName = value;
    }

    /**
     * ��ȡisdeDeliveryPreparation���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsdeDeliveryPreparation() {
        return isdeDeliveryPreparation;
    }

    /**
     * ����isdeDeliveryPreparation���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsdeDeliveryPreparation(String value) {
        this.isdeDeliveryPreparation = value;
    }

    /**
     * ��ȡmainLandToMainLand���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMainLandToMainLand() {
        return mainLandToMainLand;
    }

    /**
     * ����mainLandToMainLand���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMainLandToMainLand(String value) {
        this.mainLandToMainLand = value;
    }

    /**
     * ��ȡreceiveBillFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveBillFlg() {
        return receiveBillFlg;
    }

    /**
     * ����receiveBillFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveBillFlg(String value) {
        this.receiveBillFlg = value;
    }

    /**
     * ��ȡsigninTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSigninTm() {
        return signinTm;
    }

    /**
     * ����signinTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSigninTm(String value) {
        this.signinTm = value;
    }

    /**
     * ��ȡsourceCityName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCityName() {
        return sourceCityName;
    }

    /**
     * ����sourceCityName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCityName(String value) {
        this.sourceCityName = value;
    }

    /**
     * ��ȡsourceZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceZoneCode() {
        return sourceZoneCode;
    }

    /**
     * ����sourceZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceZoneCode(String value) {
        this.sourceZoneCode = value;
    }

    /**
     * ��ȡsourceZoneName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceZoneName() {
        return sourceZoneName;
    }

    /**
     * ����sourceZoneName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceZoneName(String value) {
        this.sourceZoneName = value;
    }

    /**
     * Gets the value of the srcZoneCodeGps property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the srcZoneCodeGps property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSrcZoneCodeGps().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SrcZoneCodeArrayType53 }
     * 
     * 
     */
    public List<SrcZoneCodeArrayType53> getSrcZoneCodeGps() {
        if (srcZoneCodeGps == null) {
            srcZoneCodeGps = new ArrayList<SrcZoneCodeArrayType53>();
        }
        return this.srcZoneCodeGps;
    }

    /**
     * ��ȡsubscriberName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberName() {
        return subscriberName;
    }

    /**
     * ����subscriberName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberName(String value) {
        this.subscriberName = value;
    }

    /**
     * Gets the value of the vehicleGpsInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the vehicleGpsInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVehicleGpsInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VehicleGpsInfoArrayType51 }
     * 
     * 
     */
    public List<VehicleGpsInfoArrayType51> getVehicleGpsInfo() {
        if (vehicleGpsInfo == null) {
            vehicleGpsInfo = new ArrayList<VehicleGpsInfoArrayType51>();
        }
        return this.vehicleGpsInfo;
    }

    /**
     * ��ȡaddresseeAddrNative���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeAddrNative() {
        return addresseeAddrNative;
    }

    /**
     * ����addresseeAddrNative���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeAddrNative(String value) {
        this.addresseeAddrNative = value;
    }

    /**
     * ��ȡaddresseeMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseeMobile() {
        return addresseeMobile;
    }

    /**
     * ����addresseeMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseeMobile(String value) {
        this.addresseeMobile = value;
    }

    /**
     * ��ȡaddresseePhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddresseePhone() {
        return addresseePhone;
    }

    /**
     * ����addresseePhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddresseePhone(String value) {
        this.addresseePhone = value;
    }

    /**
     * Gets the value of the barList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the barList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBarList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BarListArrayType24 }
     * 
     * 
     */
    public List<BarListArrayType24> getBarList() {
        if (barList == null) {
            barList = new ArrayList<BarListArrayType24>();
        }
        return this.barList;
    }

    /**
     * Gets the value of the barNewList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the barNewList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBarNewList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BarNewListArrayType25 }
     * 
     * 
     */
    public List<BarNewListArrayType25> getBarNewList() {
        if (barNewList == null) {
            barNewList = new ArrayList<BarNewListArrayType25>();
        }
        return this.barNewList;
    }

}
