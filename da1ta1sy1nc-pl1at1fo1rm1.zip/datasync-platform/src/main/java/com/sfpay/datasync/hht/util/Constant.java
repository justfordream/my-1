/**
 * 
 */
package com.sfpay.datasync.hht.util;

import com.sfpay.framework.base.AbstractConstant;

/**
 * 类说明：静态变量
 * 
 * 
 * <p>
 * 详细描述：加载自classpath:properties/constants.properties
 * 
 * </p>
 * 
 * @author 313172 Kucha
 * 
 *         CreateDate: 2012-3-27
 */
public class Constant extends AbstractConstant {

	public static final String IBM_MQ_HOSTNAME = getProperty("hht.ibm.mq.hostname"); // 主机名
	public static final String IBM_MQ_PORT = getProperty("hht.ibm.mq.port"); // 端口号
	public static final String IBM_MQ_CCSID = getProperty("hht.ibm.mq.ccsid"); // CCSID号
	public static final String IBM_MQ_CHANNEL = getProperty("hht.ibm.mq.channel"); // channel名
	public static final String IBM_MQ_QUEUE_MANAGER = getProperty("hht.ibm.mq.queue.manager"); // 队列管理器名 
	public static final String IBM_MQ_QUEUE_NAME = getProperty("hht.ibm.mq.queue.name"); // 队列名
}