@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sf-express.com/esb/service/QueryBillInfo", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.sfpay.datasync.waybill.webservice.querybillinfo;
