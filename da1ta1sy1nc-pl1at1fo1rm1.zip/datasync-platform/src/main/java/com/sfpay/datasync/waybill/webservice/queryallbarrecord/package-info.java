@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sf-express.com/esb/service/QueryAllBarRecord", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.sfpay.datasync.waybill.webservice.queryallbarrecord;
