@javax.xml.bind.annotation.XmlSchema(namespace = "http://biz.nos.schinterface.module.sf.com/")
package com.sfpay.datasync.order.webservice;
