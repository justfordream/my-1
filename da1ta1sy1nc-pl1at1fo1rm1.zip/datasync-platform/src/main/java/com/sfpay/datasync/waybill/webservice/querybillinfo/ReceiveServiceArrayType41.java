
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>receiveServiceArrayType_41 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="receiveServiceArrayType_41">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_serviceId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_attribute1" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_attribute2" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_Attribute3" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_Attribute4" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_Attribute5" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_waybillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_inputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_versionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_serviceProdCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}receiveService_newInputTm" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "receiveServiceArrayType_41", propOrder = {
    "receiveServiceServiceId",
    "receiveServiceAttribute1",
    "receiveServiceAttribute2",
    "receiveServiceAttribute3",
    "receiveServiceAttribute4",
    "receiveServiceAttribute5",
    "receiveServiceWaybillId",
    "receiveServiceWaybillNo",
    "receiveServiceInputTm",
    "receiveServiceVersionNo",
    "receiveServiceServiceProdCode",
    "receiveServiceNewInputTm"
})
public class ReceiveServiceArrayType41 {

    @XmlElement(name = "receiveService_serviceId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceServiceId;
    @XmlElement(name = "receiveService_attribute1", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceAttribute1;
    @XmlElement(name = "receiveService_attribute2", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceAttribute2;
    @XmlElement(name = "receiveService_Attribute3", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceAttribute3;
    @XmlElement(name = "receiveService_Attribute4", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceAttribute4;
    @XmlElement(name = "receiveService_Attribute5", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceAttribute5;
    @XmlElement(name = "receiveService_waybillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceWaybillId;
    @XmlElement(name = "receiveService_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceWaybillNo;
    @XmlElement(name = "receiveService_inputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveServiceInputTm;
    @XmlElement(name = "receiveService_versionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer receiveServiceVersionNo;
    @XmlElement(name = "receiveService_serviceProdCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String receiveServiceServiceProdCode;
    @XmlElement(name = "receiveService_newInputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiveServiceNewInputTm;

    /**
     * ��ȡreceiveServiceServiceId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceServiceId() {
        return receiveServiceServiceId;
    }

    /**
     * ����receiveServiceServiceId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceServiceId(String value) {
        this.receiveServiceServiceId = value;
    }

    /**
     * ��ȡreceiveServiceAttribute1���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceAttribute1() {
        return receiveServiceAttribute1;
    }

    /**
     * ����receiveServiceAttribute1���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceAttribute1(String value) {
        this.receiveServiceAttribute1 = value;
    }

    /**
     * ��ȡreceiveServiceAttribute2���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceAttribute2() {
        return receiveServiceAttribute2;
    }

    /**
     * ����receiveServiceAttribute2���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceAttribute2(String value) {
        this.receiveServiceAttribute2 = value;
    }

    /**
     * ��ȡreceiveServiceAttribute3���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceAttribute3() {
        return receiveServiceAttribute3;
    }

    /**
     * ����receiveServiceAttribute3���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceAttribute3(String value) {
        this.receiveServiceAttribute3 = value;
    }

    /**
     * ��ȡreceiveServiceAttribute4���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceAttribute4() {
        return receiveServiceAttribute4;
    }

    /**
     * ����receiveServiceAttribute4���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceAttribute4(String value) {
        this.receiveServiceAttribute4 = value;
    }

    /**
     * ��ȡreceiveServiceAttribute5���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceAttribute5() {
        return receiveServiceAttribute5;
    }

    /**
     * ����receiveServiceAttribute5���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceAttribute5(String value) {
        this.receiveServiceAttribute5 = value;
    }

    /**
     * ��ȡreceiveServiceWaybillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceWaybillId() {
        return receiveServiceWaybillId;
    }

    /**
     * ����receiveServiceWaybillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceWaybillId(String value) {
        this.receiveServiceWaybillId = value;
    }

    /**
     * ��ȡreceiveServiceWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceWaybillNo() {
        return receiveServiceWaybillNo;
    }

    /**
     * ����receiveServiceWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceWaybillNo(String value) {
        this.receiveServiceWaybillNo = value;
    }

    /**
     * ��ȡreceiveServiceInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveServiceInputTm() {
        return receiveServiceInputTm;
    }

    /**
     * ����receiveServiceInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveServiceInputTm(XMLGregorianCalendar value) {
        this.receiveServiceInputTm = value;
    }

    /**
     * ��ȡreceiveServiceVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReceiveServiceVersionNo() {
        return receiveServiceVersionNo;
    }

    /**
     * ����receiveServiceVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReceiveServiceVersionNo(Integer value) {
        this.receiveServiceVersionNo = value;
    }

    /**
     * ��ȡreceiveServiceServiceProdCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiveServiceServiceProdCode() {
        return receiveServiceServiceProdCode;
    }

    /**
     * ����receiveServiceServiceProdCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiveServiceServiceProdCode(String value) {
        this.receiveServiceServiceProdCode = value;
    }

    /**
     * ��ȡreceiveServiceNewInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiveServiceNewInputTm() {
        return receiveServiceNewInputTm;
    }

    /**
     * ����receiveServiceNewInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setReceiveServiceNewInputTm(XMLGregorianCalendar value) {
        this.receiveServiceNewInputTm = value;
    }

}
