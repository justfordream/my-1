/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.datasync.hht.enums;

/**
 * 
 * 类说明：
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 321302 程俊杰
 *   
 * CreateDate: 2012-6-7
 */
public enum SystemCode
{
	HHT("hht"),
	
	SCH("sch"),
	
	HRS("hrs"),
	
	PAY("pay"),
	
	CMS("cms"),
	
	EXPRESSORDERJOB("expressOrderJob"),
	
	ADDRESSTEAM("addressTeam");
	
	private String code;
	
	SystemCode(String code){
		this.code = code;
	}
	
	SystemCode()
	{
		
	}
	
	public String getCode() {
		return code;
	}
}
