
package com.sfpay.datasync.waybill.webservice.querybillinfo;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>sendBillType_42 complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="sendBillType_42">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_waybillId" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_waybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_sourceZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_destZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_oneselfPickupFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignorCompName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignorAdd" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignorPhone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignorContName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignorMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_addresseeCompName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_addresseeAddr" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_addresseePhone" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_addresseeContName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_addresseeMobile" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_meterageWeightQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consValue" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_otherNodeFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_tbOrderNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_tbOrderType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_freeTicketNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_twinvoiceTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_selfSendFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_selfSendDiscount" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_hvalueBoxType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_volume" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_sourcearea" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consultCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignorPostalCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_addresseePostalCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_countryCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_invoiceNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_isCredit" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consValueCurrencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_mawb" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_airportCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignorTaxNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_transferParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_codBillFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_cvsCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_codType" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_inputTmGmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_modifydateGmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_auditerTmGmt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_unitWeight" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_refundFreeParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_newInputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_realWeightQty" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_quantity" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_freeParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_innerParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_frangibleParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_trustParcelFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_preCustomsDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consigneeEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_consignedTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_deliverEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_subscriberName" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_signinTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_waybillRemk" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_customsBatchs" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_auditedFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_inputerEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_inputTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_auditerEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_auditedTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_suppTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_customsTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_boxTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_versionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_cargoTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_limitTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_distanceTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_transportTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_expressTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_lockVersionNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_inputedZoneCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_inputTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_needSignedBackFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_signedBackWaybillNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_addresseeAddrNative" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_unifiedCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_modifiedEmpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_modifiedTm" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_hasServiceProdFlg" minOccurs="0"/>
 *         &lt;element ref="{http://www.sf-express.com/esb/metadata}sendBill_ackbillTypeCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sendBillType_42", propOrder = {
    "sendBillWaybillId",
    "sendBillWaybillNo",
    "sendBillSourceZoneCode",
    "sendBillDestZoneCode",
    "sendBillOneselfPickupFlg",
    "sendBillConsignorCompName",
    "sendBillConsignorAdd",
    "sendBillConsignorPhone",
    "sendBillConsignorContName",
    "sendBillConsignorMobile",
    "sendBillAddresseeCompName",
    "sendBillAddresseeAddr",
    "sendBillAddresseePhone",
    "sendBillAddresseeContName",
    "sendBillAddresseeMobile",
    "sendBillMeterageWeightQty",
    "sendBillConsValue",
    "sendBillOtherNodeFlg",
    "sendBillTbOrderNo",
    "sendBillTbOrderType",
    "sendBillFreeTicketNo",
    "sendBillTwinvoiceTypeCode",
    "sendBillSelfSendFlg",
    "sendBillSelfSendDiscount",
    "sendBillHvalueBoxType",
    "sendBillVolume",
    "sendBillSourcearea",
    "sendBillConsultCode",
    "sendBillConsignorPostalCode",
    "sendBillAddresseePostalCode",
    "sendBillCountryCode",
    "sendBillInvoiceNo",
    "sendBillIsCredit",
    "sendBillConsValueCurrencyCode",
    "sendBillMawb",
    "sendBillAirportCode",
    "sendBillConsignorTaxNo",
    "sendBillTransferParcelFlg",
    "sendBillCodBillFlg",
    "sendBillCvsCode",
    "sendBillCodType",
    "sendBillInputTmGmt",
    "sendBillModifydateGmt",
    "sendBillAuditerTmGmt",
    "sendBillUnitWeight",
    "sendBillRefundFreeParcelFlg",
    "sendBillNewInputTm",
    "sendBillRealWeightQty",
    "sendBillQuantity",
    "sendBillFreeParcelFlg",
    "sendBillInnerParcelFlg",
    "sendBillFrangibleParcelFlg",
    "sendBillTrustParcelFlg",
    "sendBillPreCustomsDt",
    "sendBillConsigneeEmpCode",
    "sendBillConsignedTm",
    "sendBillDeliverEmpCode",
    "sendBillSubscriberName",
    "sendBillSigninTm",
    "sendBillWaybillRemk",
    "sendBillCustomsBatchs",
    "sendBillAuditedFlg",
    "sendBillInputerEmpCode",
    "sendBillInputTm",
    "sendBillAuditerEmpCode",
    "sendBillAuditedTm",
    "sendBillSuppTypeCode",
    "sendBillCustomsTypeCode",
    "sendBillBoxTypeCode",
    "sendBillVersionNo",
    "sendBillCargoTypeCode",
    "sendBillLimitTypeCode",
    "sendBillDistanceTypeCode",
    "sendBillTransportTypeCode",
    "sendBillExpressTypeCode",
    "sendBillLockVersionNo",
    "sendBillInputedZoneCode",
    "sendBillInputTypeCode",
    "sendBillNeedSignedBackFlg",
    "sendBillSignedBackWaybillNo",
    "sendBillAddresseeAddrNative",
    "sendBillUnifiedCode",
    "sendBillModifiedEmpCode",
    "sendBillModifiedTm",
    "sendBillHasServiceProdFlg",
    "sendBillAckbillTypeCode"
})
public class SendBillType42 {

    @XmlElement(name = "sendBill_waybillId", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillWaybillId;
    @XmlElement(name = "sendBill_waybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillWaybillNo;
    @XmlElement(name = "sendBill_sourceZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillSourceZoneCode;
    @XmlElement(name = "sendBill_destZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillDestZoneCode;
    @XmlElement(name = "sendBill_oneselfPickupFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillOneselfPickupFlg;
    @XmlElement(name = "sendBill_consignorCompName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignorCompName;
    @XmlElement(name = "sendBill_consignorAdd", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignorAdd;
    @XmlElement(name = "sendBill_consignorPhone", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignorPhone;
    @XmlElement(name = "sendBill_consignorContName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignorContName;
    @XmlElement(name = "sendBill_consignorMobile", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignorMobile;
    @XmlElement(name = "sendBill_addresseeCompName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAddresseeCompName;
    @XmlElement(name = "sendBill_addresseeAddr", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAddresseeAddr;
    @XmlElement(name = "sendBill_addresseePhone", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAddresseePhone;
    @XmlElement(name = "sendBill_addresseeContName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAddresseeContName;
    @XmlElement(name = "sendBill_addresseeMobile", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAddresseeMobile;
    @XmlElement(name = "sendBill_meterageWeightQty", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendBillMeterageWeightQty;
    @XmlElement(name = "sendBill_consValue", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendBillConsValue;
    @XmlElement(name = "sendBill_otherNodeFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillOtherNodeFlg;
    @XmlElement(name = "sendBill_tbOrderNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillTbOrderNo;
    @XmlElement(name = "sendBill_tbOrderType", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillTbOrderType;
    @XmlElement(name = "sendBill_freeTicketNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillFreeTicketNo;
    @XmlElement(name = "sendBill_twinvoiceTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillTwinvoiceTypeCode;
    @XmlElement(name = "sendBill_selfSendFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillSelfSendFlg;
    @XmlElement(name = "sendBill_selfSendDiscount", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendBillSelfSendDiscount;
    @XmlElement(name = "sendBill_hvalueBoxType", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillHvalueBoxType;
    @XmlElement(name = "sendBill_volume", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendBillVolume;
    @XmlElement(name = "sendBill_sourcearea", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillSourcearea;
    @XmlElement(name = "sendBill_consultCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsultCode;
    @XmlElement(name = "sendBill_consignorPostalCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignorPostalCode;
    @XmlElement(name = "sendBill_addresseePostalCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAddresseePostalCode;
    @XmlElement(name = "sendBill_countryCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillCountryCode;
    @XmlElement(name = "sendBill_invoiceNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillInvoiceNo;
    @XmlElement(name = "sendBill_isCredit", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillIsCredit;
    @XmlElement(name = "sendBill_consValueCurrencyCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsValueCurrencyCode;
    @XmlElement(name = "sendBill_mawb", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillMawb;
    @XmlElement(name = "sendBill_airportCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAirportCode;
    @XmlElement(name = "sendBill_consignorTaxNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignorTaxNo;
    @XmlElement(name = "sendBill_transferParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillTransferParcelFlg;
    @XmlElement(name = "sendBill_codBillFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillCodBillFlg;
    @XmlElement(name = "sendBill_cvsCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillCvsCode;
    @XmlElement(name = "sendBill_codType", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillCodType;
    @XmlElement(name = "sendBill_inputTmGmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillInputTmGmt;
    @XmlElement(name = "sendBill_modifydateGmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillModifydateGmt;
    @XmlElement(name = "sendBill_auditerTmGmt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillAuditerTmGmt;
    @XmlElement(name = "sendBill_unitWeight", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillUnitWeight;
    @XmlElement(name = "sendBill_refundFreeParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillRefundFreeParcelFlg;
    @XmlElement(name = "sendBill_newInputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillNewInputTm;
    @XmlElement(name = "sendBill_realWeightQty", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendBillRealWeightQty;
    @XmlElement(name = "sendBill_quantity", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Double sendBillQuantity;
    @XmlElement(name = "sendBill_freeParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillFreeParcelFlg;
    @XmlElement(name = "sendBill_innerParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillInnerParcelFlg;
    @XmlElement(name = "sendBill_frangibleParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillFrangibleParcelFlg;
    @XmlElement(name = "sendBill_trustParcelFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillTrustParcelFlg;
    @XmlElement(name = "sendBill_preCustomsDt", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillPreCustomsDt;
    @XmlElement(name = "sendBill_consigneeEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsigneeEmpCode;
    @XmlElement(name = "sendBill_consignedTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillConsignedTm;
    @XmlElement(name = "sendBill_deliverEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillDeliverEmpCode;
    @XmlElement(name = "sendBill_subscriberName", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillSubscriberName;
    @XmlElement(name = "sendBill_signinTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillSigninTm;
    @XmlElement(name = "sendBill_waybillRemk", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillWaybillRemk;
    @XmlElement(name = "sendBill_customsBatchs", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillCustomsBatchs;
    @XmlElement(name = "sendBill_auditedFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillAuditedFlg;
    @XmlElement(name = "sendBill_inputerEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillInputerEmpCode;
    @XmlElement(name = "sendBill_inputTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillInputTm;
    @XmlElement(name = "sendBill_auditerEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAuditerEmpCode;
    @XmlElement(name = "sendBill_auditedTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillAuditedTm;
    @XmlElement(name = "sendBill_suppTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillSuppTypeCode;
    @XmlElement(name = "sendBill_customsTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillCustomsTypeCode;
    @XmlElement(name = "sendBill_boxTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillBoxTypeCode;
    @XmlElement(name = "sendBill_versionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillVersionNo;
    @XmlElement(name = "sendBill_cargoTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillCargoTypeCode;
    @XmlElement(name = "sendBill_limitTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillLimitTypeCode;
    @XmlElement(name = "sendBill_distanceTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillDistanceTypeCode;
    @XmlElement(name = "sendBill_transportTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillTransportTypeCode;
    @XmlElement(name = "sendBill_expressTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillExpressTypeCode;
    @XmlElement(name = "sendBill_lockVersionNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillLockVersionNo;
    @XmlElement(name = "sendBill_inputedZoneCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillInputedZoneCode;
    @XmlElement(name = "sendBill_inputTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillInputTypeCode;
    @XmlElement(name = "sendBill_needSignedBackFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillNeedSignedBackFlg;
    @XmlElement(name = "sendBill_signedBackWaybillNo", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillSignedBackWaybillNo;
    @XmlElement(name = "sendBill_addresseeAddrNative", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAddresseeAddrNative;
    @XmlElement(name = "sendBill_unifiedCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillUnifiedCode;
    @XmlElement(name = "sendBill_modifiedEmpCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillModifiedEmpCode;
    @XmlElement(name = "sendBill_modifiedTm", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sendBillModifiedTm;
    @XmlElement(name = "sendBill_hasServiceProdFlg", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected Integer sendBillHasServiceProdFlg;
    @XmlElement(name = "sendBill_ackbillTypeCode", namespace = "http://www.sf-express.com/esb/metadata", nillable = true)
    protected String sendBillAckbillTypeCode;

    /**
     * ��ȡsendBillWaybillId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillWaybillId() {
        return sendBillWaybillId;
    }

    /**
     * ����sendBillWaybillId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillWaybillId(String value) {
        this.sendBillWaybillId = value;
    }

    /**
     * ��ȡsendBillWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillWaybillNo() {
        return sendBillWaybillNo;
    }

    /**
     * ����sendBillWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillWaybillNo(String value) {
        this.sendBillWaybillNo = value;
    }

    /**
     * ��ȡsendBillSourceZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillSourceZoneCode() {
        return sendBillSourceZoneCode;
    }

    /**
     * ����sendBillSourceZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillSourceZoneCode(String value) {
        this.sendBillSourceZoneCode = value;
    }

    /**
     * ��ȡsendBillDestZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillDestZoneCode() {
        return sendBillDestZoneCode;
    }

    /**
     * ����sendBillDestZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillDestZoneCode(String value) {
        this.sendBillDestZoneCode = value;
    }

    /**
     * ��ȡsendBillOneselfPickupFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillOneselfPickupFlg() {
        return sendBillOneselfPickupFlg;
    }

    /**
     * ����sendBillOneselfPickupFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillOneselfPickupFlg(Integer value) {
        this.sendBillOneselfPickupFlg = value;
    }

    /**
     * ��ȡsendBillConsignorCompName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignorCompName() {
        return sendBillConsignorCompName;
    }

    /**
     * ����sendBillConsignorCompName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignorCompName(String value) {
        this.sendBillConsignorCompName = value;
    }

    /**
     * ��ȡsendBillConsignorAdd���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignorAdd() {
        return sendBillConsignorAdd;
    }

    /**
     * ����sendBillConsignorAdd���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignorAdd(String value) {
        this.sendBillConsignorAdd = value;
    }

    /**
     * ��ȡsendBillConsignorPhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignorPhone() {
        return sendBillConsignorPhone;
    }

    /**
     * ����sendBillConsignorPhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignorPhone(String value) {
        this.sendBillConsignorPhone = value;
    }

    /**
     * ��ȡsendBillConsignorContName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignorContName() {
        return sendBillConsignorContName;
    }

    /**
     * ����sendBillConsignorContName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignorContName(String value) {
        this.sendBillConsignorContName = value;
    }

    /**
     * ��ȡsendBillConsignorMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignorMobile() {
        return sendBillConsignorMobile;
    }

    /**
     * ����sendBillConsignorMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignorMobile(String value) {
        this.sendBillConsignorMobile = value;
    }

    /**
     * ��ȡsendBillAddresseeCompName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAddresseeCompName() {
        return sendBillAddresseeCompName;
    }

    /**
     * ����sendBillAddresseeCompName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAddresseeCompName(String value) {
        this.sendBillAddresseeCompName = value;
    }

    /**
     * ��ȡsendBillAddresseeAddr���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAddresseeAddr() {
        return sendBillAddresseeAddr;
    }

    /**
     * ����sendBillAddresseeAddr���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAddresseeAddr(String value) {
        this.sendBillAddresseeAddr = value;
    }

    /**
     * ��ȡsendBillAddresseePhone���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAddresseePhone() {
        return sendBillAddresseePhone;
    }

    /**
     * ����sendBillAddresseePhone���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAddresseePhone(String value) {
        this.sendBillAddresseePhone = value;
    }

    /**
     * ��ȡsendBillAddresseeContName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAddresseeContName() {
        return sendBillAddresseeContName;
    }

    /**
     * ����sendBillAddresseeContName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAddresseeContName(String value) {
        this.sendBillAddresseeContName = value;
    }

    /**
     * ��ȡsendBillAddresseeMobile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAddresseeMobile() {
        return sendBillAddresseeMobile;
    }

    /**
     * ����sendBillAddresseeMobile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAddresseeMobile(String value) {
        this.sendBillAddresseeMobile = value;
    }

    /**
     * ��ȡsendBillMeterageWeightQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendBillMeterageWeightQty() {
        return sendBillMeterageWeightQty;
    }

    /**
     * ����sendBillMeterageWeightQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendBillMeterageWeightQty(Double value) {
        this.sendBillMeterageWeightQty = value;
    }

    /**
     * ��ȡsendBillConsValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendBillConsValue() {
        return sendBillConsValue;
    }

    /**
     * ����sendBillConsValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendBillConsValue(Double value) {
        this.sendBillConsValue = value;
    }

    /**
     * ��ȡsendBillOtherNodeFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillOtherNodeFlg() {
        return sendBillOtherNodeFlg;
    }

    /**
     * ����sendBillOtherNodeFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillOtherNodeFlg(Integer value) {
        this.sendBillOtherNodeFlg = value;
    }

    /**
     * ��ȡsendBillTbOrderNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillTbOrderNo() {
        return sendBillTbOrderNo;
    }

    /**
     * ����sendBillTbOrderNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillTbOrderNo(String value) {
        this.sendBillTbOrderNo = value;
    }

    /**
     * ��ȡsendBillTbOrderType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillTbOrderType() {
        return sendBillTbOrderType;
    }

    /**
     * ����sendBillTbOrderType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillTbOrderType(String value) {
        this.sendBillTbOrderType = value;
    }

    /**
     * ��ȡsendBillFreeTicketNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillFreeTicketNo() {
        return sendBillFreeTicketNo;
    }

    /**
     * ����sendBillFreeTicketNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillFreeTicketNo(String value) {
        this.sendBillFreeTicketNo = value;
    }

    /**
     * ��ȡsendBillTwinvoiceTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillTwinvoiceTypeCode() {
        return sendBillTwinvoiceTypeCode;
    }

    /**
     * ����sendBillTwinvoiceTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillTwinvoiceTypeCode(Integer value) {
        this.sendBillTwinvoiceTypeCode = value;
    }

    /**
     * ��ȡsendBillSelfSendFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillSelfSendFlg() {
        return sendBillSelfSendFlg;
    }

    /**
     * ����sendBillSelfSendFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillSelfSendFlg(Integer value) {
        this.sendBillSelfSendFlg = value;
    }

    /**
     * ��ȡsendBillSelfSendDiscount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendBillSelfSendDiscount() {
        return sendBillSelfSendDiscount;
    }

    /**
     * ����sendBillSelfSendDiscount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendBillSelfSendDiscount(Double value) {
        this.sendBillSelfSendDiscount = value;
    }

    /**
     * ��ȡsendBillHvalueBoxType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillHvalueBoxType() {
        return sendBillHvalueBoxType;
    }

    /**
     * ����sendBillHvalueBoxType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillHvalueBoxType(String value) {
        this.sendBillHvalueBoxType = value;
    }

    /**
     * ��ȡsendBillVolume���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendBillVolume() {
        return sendBillVolume;
    }

    /**
     * ����sendBillVolume���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendBillVolume(Double value) {
        this.sendBillVolume = value;
    }

    /**
     * ��ȡsendBillSourcearea���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillSourcearea() {
        return sendBillSourcearea;
    }

    /**
     * ����sendBillSourcearea���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillSourcearea(String value) {
        this.sendBillSourcearea = value;
    }

    /**
     * ��ȡsendBillConsultCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsultCode() {
        return sendBillConsultCode;
    }

    /**
     * ����sendBillConsultCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsultCode(String value) {
        this.sendBillConsultCode = value;
    }

    /**
     * ��ȡsendBillConsignorPostalCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignorPostalCode() {
        return sendBillConsignorPostalCode;
    }

    /**
     * ����sendBillConsignorPostalCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignorPostalCode(String value) {
        this.sendBillConsignorPostalCode = value;
    }

    /**
     * ��ȡsendBillAddresseePostalCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAddresseePostalCode() {
        return sendBillAddresseePostalCode;
    }

    /**
     * ����sendBillAddresseePostalCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAddresseePostalCode(String value) {
        this.sendBillAddresseePostalCode = value;
    }

    /**
     * ��ȡsendBillCountryCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillCountryCode() {
        return sendBillCountryCode;
    }

    /**
     * ����sendBillCountryCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillCountryCode(String value) {
        this.sendBillCountryCode = value;
    }

    /**
     * ��ȡsendBillInvoiceNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillInvoiceNo() {
        return sendBillInvoiceNo;
    }

    /**
     * ����sendBillInvoiceNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillInvoiceNo(String value) {
        this.sendBillInvoiceNo = value;
    }

    /**
     * ��ȡsendBillIsCredit���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillIsCredit() {
        return sendBillIsCredit;
    }

    /**
     * ����sendBillIsCredit���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillIsCredit(Integer value) {
        this.sendBillIsCredit = value;
    }

    /**
     * ��ȡsendBillConsValueCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsValueCurrencyCode() {
        return sendBillConsValueCurrencyCode;
    }

    /**
     * ����sendBillConsValueCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsValueCurrencyCode(String value) {
        this.sendBillConsValueCurrencyCode = value;
    }

    /**
     * ��ȡsendBillMawb���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillMawb() {
        return sendBillMawb;
    }

    /**
     * ����sendBillMawb���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillMawb(String value) {
        this.sendBillMawb = value;
    }

    /**
     * ��ȡsendBillAirportCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAirportCode() {
        return sendBillAirportCode;
    }

    /**
     * ����sendBillAirportCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAirportCode(String value) {
        this.sendBillAirportCode = value;
    }

    /**
     * ��ȡsendBillConsignorTaxNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignorTaxNo() {
        return sendBillConsignorTaxNo;
    }

    /**
     * ����sendBillConsignorTaxNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignorTaxNo(String value) {
        this.sendBillConsignorTaxNo = value;
    }

    /**
     * ��ȡsendBillTransferParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillTransferParcelFlg() {
        return sendBillTransferParcelFlg;
    }

    /**
     * ����sendBillTransferParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillTransferParcelFlg(Integer value) {
        this.sendBillTransferParcelFlg = value;
    }

    /**
     * ��ȡsendBillCodBillFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillCodBillFlg() {
        return sendBillCodBillFlg;
    }

    /**
     * ����sendBillCodBillFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillCodBillFlg(Integer value) {
        this.sendBillCodBillFlg = value;
    }

    /**
     * ��ȡsendBillCvsCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillCvsCode() {
        return sendBillCvsCode;
    }

    /**
     * ����sendBillCvsCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillCvsCode(String value) {
        this.sendBillCvsCode = value;
    }

    /**
     * ��ȡsendBillCodType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillCodType() {
        return sendBillCodType;
    }

    /**
     * ����sendBillCodType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillCodType(Integer value) {
        this.sendBillCodType = value;
    }

    /**
     * ��ȡsendBillInputTmGmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillInputTmGmt() {
        return sendBillInputTmGmt;
    }

    /**
     * ����sendBillInputTmGmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillInputTmGmt(XMLGregorianCalendar value) {
        this.sendBillInputTmGmt = value;
    }

    /**
     * ��ȡsendBillModifydateGmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillModifydateGmt() {
        return sendBillModifydateGmt;
    }

    /**
     * ����sendBillModifydateGmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillModifydateGmt(XMLGregorianCalendar value) {
        this.sendBillModifydateGmt = value;
    }

    /**
     * ��ȡsendBillAuditerTmGmt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillAuditerTmGmt() {
        return sendBillAuditerTmGmt;
    }

    /**
     * ����sendBillAuditerTmGmt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillAuditerTmGmt(XMLGregorianCalendar value) {
        this.sendBillAuditerTmGmt = value;
    }

    /**
     * ��ȡsendBillUnitWeight���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillUnitWeight() {
        return sendBillUnitWeight;
    }

    /**
     * ����sendBillUnitWeight���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillUnitWeight(String value) {
        this.sendBillUnitWeight = value;
    }

    /**
     * ��ȡsendBillRefundFreeParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillRefundFreeParcelFlg() {
        return sendBillRefundFreeParcelFlg;
    }

    /**
     * ����sendBillRefundFreeParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillRefundFreeParcelFlg(Integer value) {
        this.sendBillRefundFreeParcelFlg = value;
    }

    /**
     * ��ȡsendBillNewInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillNewInputTm() {
        return sendBillNewInputTm;
    }

    /**
     * ����sendBillNewInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillNewInputTm(XMLGregorianCalendar value) {
        this.sendBillNewInputTm = value;
    }

    /**
     * ��ȡsendBillRealWeightQty���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendBillRealWeightQty() {
        return sendBillRealWeightQty;
    }

    /**
     * ����sendBillRealWeightQty���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendBillRealWeightQty(Double value) {
        this.sendBillRealWeightQty = value;
    }

    /**
     * ��ȡsendBillQuantity���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSendBillQuantity() {
        return sendBillQuantity;
    }

    /**
     * ����sendBillQuantity���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSendBillQuantity(Double value) {
        this.sendBillQuantity = value;
    }

    /**
     * ��ȡsendBillFreeParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillFreeParcelFlg() {
        return sendBillFreeParcelFlg;
    }

    /**
     * ����sendBillFreeParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillFreeParcelFlg(Integer value) {
        this.sendBillFreeParcelFlg = value;
    }

    /**
     * ��ȡsendBillInnerParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillInnerParcelFlg() {
        return sendBillInnerParcelFlg;
    }

    /**
     * ����sendBillInnerParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillInnerParcelFlg(Integer value) {
        this.sendBillInnerParcelFlg = value;
    }

    /**
     * ��ȡsendBillFrangibleParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillFrangibleParcelFlg() {
        return sendBillFrangibleParcelFlg;
    }

    /**
     * ����sendBillFrangibleParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillFrangibleParcelFlg(Integer value) {
        this.sendBillFrangibleParcelFlg = value;
    }

    /**
     * ��ȡsendBillTrustParcelFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillTrustParcelFlg() {
        return sendBillTrustParcelFlg;
    }

    /**
     * ����sendBillTrustParcelFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillTrustParcelFlg(Integer value) {
        this.sendBillTrustParcelFlg = value;
    }

    /**
     * ��ȡsendBillPreCustomsDt���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillPreCustomsDt() {
        return sendBillPreCustomsDt;
    }

    /**
     * ����sendBillPreCustomsDt���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillPreCustomsDt(XMLGregorianCalendar value) {
        this.sendBillPreCustomsDt = value;
    }

    /**
     * ��ȡsendBillConsigneeEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsigneeEmpCode() {
        return sendBillConsigneeEmpCode;
    }

    /**
     * ����sendBillConsigneeEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsigneeEmpCode(String value) {
        this.sendBillConsigneeEmpCode = value;
    }

    /**
     * ��ȡsendBillConsignedTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillConsignedTm() {
        return sendBillConsignedTm;
    }

    /**
     * ����sendBillConsignedTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillConsignedTm(String value) {
        this.sendBillConsignedTm = value;
    }

    /**
     * ��ȡsendBillDeliverEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillDeliverEmpCode() {
        return sendBillDeliverEmpCode;
    }

    /**
     * ����sendBillDeliverEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillDeliverEmpCode(String value) {
        this.sendBillDeliverEmpCode = value;
    }

    /**
     * ��ȡsendBillSubscriberName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillSubscriberName() {
        return sendBillSubscriberName;
    }

    /**
     * ����sendBillSubscriberName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillSubscriberName(String value) {
        this.sendBillSubscriberName = value;
    }

    /**
     * ��ȡsendBillSigninTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillSigninTm() {
        return sendBillSigninTm;
    }

    /**
     * ����sendBillSigninTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillSigninTm(String value) {
        this.sendBillSigninTm = value;
    }

    /**
     * ��ȡsendBillWaybillRemk���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillWaybillRemk() {
        return sendBillWaybillRemk;
    }

    /**
     * ����sendBillWaybillRemk���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillWaybillRemk(String value) {
        this.sendBillWaybillRemk = value;
    }

    /**
     * ��ȡsendBillCustomsBatchs���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillCustomsBatchs() {
        return sendBillCustomsBatchs;
    }

    /**
     * ����sendBillCustomsBatchs���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillCustomsBatchs(String value) {
        this.sendBillCustomsBatchs = value;
    }

    /**
     * ��ȡsendBillAuditedFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillAuditedFlg() {
        return sendBillAuditedFlg;
    }

    /**
     * ����sendBillAuditedFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillAuditedFlg(Integer value) {
        this.sendBillAuditedFlg = value;
    }

    /**
     * ��ȡsendBillInputerEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillInputerEmpCode() {
        return sendBillInputerEmpCode;
    }

    /**
     * ����sendBillInputerEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillInputerEmpCode(String value) {
        this.sendBillInputerEmpCode = value;
    }

    /**
     * ��ȡsendBillInputTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillInputTm() {
        return sendBillInputTm;
    }

    /**
     * ����sendBillInputTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillInputTm(XMLGregorianCalendar value) {
        this.sendBillInputTm = value;
    }

    /**
     * ��ȡsendBillAuditerEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAuditerEmpCode() {
        return sendBillAuditerEmpCode;
    }

    /**
     * ����sendBillAuditerEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAuditerEmpCode(String value) {
        this.sendBillAuditerEmpCode = value;
    }

    /**
     * ��ȡsendBillAuditedTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillAuditedTm() {
        return sendBillAuditedTm;
    }

    /**
     * ����sendBillAuditedTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillAuditedTm(XMLGregorianCalendar value) {
        this.sendBillAuditedTm = value;
    }

    /**
     * ��ȡsendBillSuppTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillSuppTypeCode() {
        return sendBillSuppTypeCode;
    }

    /**
     * ����sendBillSuppTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillSuppTypeCode(String value) {
        this.sendBillSuppTypeCode = value;
    }

    /**
     * ��ȡsendBillCustomsTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillCustomsTypeCode() {
        return sendBillCustomsTypeCode;
    }

    /**
     * ����sendBillCustomsTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillCustomsTypeCode(String value) {
        this.sendBillCustomsTypeCode = value;
    }

    /**
     * ��ȡsendBillBoxTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillBoxTypeCode() {
        return sendBillBoxTypeCode;
    }

    /**
     * ����sendBillBoxTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillBoxTypeCode(String value) {
        this.sendBillBoxTypeCode = value;
    }

    /**
     * ��ȡsendBillVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillVersionNo() {
        return sendBillVersionNo;
    }

    /**
     * ����sendBillVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillVersionNo(Integer value) {
        this.sendBillVersionNo = value;
    }

    /**
     * ��ȡsendBillCargoTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillCargoTypeCode() {
        return sendBillCargoTypeCode;
    }

    /**
     * ����sendBillCargoTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillCargoTypeCode(String value) {
        this.sendBillCargoTypeCode = value;
    }

    /**
     * ��ȡsendBillLimitTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillLimitTypeCode() {
        return sendBillLimitTypeCode;
    }

    /**
     * ����sendBillLimitTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillLimitTypeCode(String value) {
        this.sendBillLimitTypeCode = value;
    }

    /**
     * ��ȡsendBillDistanceTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillDistanceTypeCode() {
        return sendBillDistanceTypeCode;
    }

    /**
     * ����sendBillDistanceTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillDistanceTypeCode(String value) {
        this.sendBillDistanceTypeCode = value;
    }

    /**
     * ��ȡsendBillTransportTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillTransportTypeCode() {
        return sendBillTransportTypeCode;
    }

    /**
     * ����sendBillTransportTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillTransportTypeCode(String value) {
        this.sendBillTransportTypeCode = value;
    }

    /**
     * ��ȡsendBillExpressTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillExpressTypeCode() {
        return sendBillExpressTypeCode;
    }

    /**
     * ����sendBillExpressTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillExpressTypeCode(String value) {
        this.sendBillExpressTypeCode = value;
    }

    /**
     * ��ȡsendBillLockVersionNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillLockVersionNo() {
        return sendBillLockVersionNo;
    }

    /**
     * ����sendBillLockVersionNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillLockVersionNo(Integer value) {
        this.sendBillLockVersionNo = value;
    }

    /**
     * ��ȡsendBillInputedZoneCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillInputedZoneCode() {
        return sendBillInputedZoneCode;
    }

    /**
     * ����sendBillInputedZoneCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillInputedZoneCode(String value) {
        this.sendBillInputedZoneCode = value;
    }

    /**
     * ��ȡsendBillInputTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillInputTypeCode() {
        return sendBillInputTypeCode;
    }

    /**
     * ����sendBillInputTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillInputTypeCode(String value) {
        this.sendBillInputTypeCode = value;
    }

    /**
     * ��ȡsendBillNeedSignedBackFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillNeedSignedBackFlg() {
        return sendBillNeedSignedBackFlg;
    }

    /**
     * ����sendBillNeedSignedBackFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillNeedSignedBackFlg(Integer value) {
        this.sendBillNeedSignedBackFlg = value;
    }

    /**
     * ��ȡsendBillSignedBackWaybillNo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillSignedBackWaybillNo() {
        return sendBillSignedBackWaybillNo;
    }

    /**
     * ����sendBillSignedBackWaybillNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillSignedBackWaybillNo(String value) {
        this.sendBillSignedBackWaybillNo = value;
    }

    /**
     * ��ȡsendBillAddresseeAddrNative���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAddresseeAddrNative() {
        return sendBillAddresseeAddrNative;
    }

    /**
     * ����sendBillAddresseeAddrNative���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAddresseeAddrNative(String value) {
        this.sendBillAddresseeAddrNative = value;
    }

    /**
     * ��ȡsendBillUnifiedCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillUnifiedCode() {
        return sendBillUnifiedCode;
    }

    /**
     * ����sendBillUnifiedCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillUnifiedCode(String value) {
        this.sendBillUnifiedCode = value;
    }

    /**
     * ��ȡsendBillModifiedEmpCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillModifiedEmpCode() {
        return sendBillModifiedEmpCode;
    }

    /**
     * ����sendBillModifiedEmpCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillModifiedEmpCode(String value) {
        this.sendBillModifiedEmpCode = value;
    }

    /**
     * ��ȡsendBillModifiedTm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSendBillModifiedTm() {
        return sendBillModifiedTm;
    }

    /**
     * ����sendBillModifiedTm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setSendBillModifiedTm(XMLGregorianCalendar value) {
        this.sendBillModifiedTm = value;
    }

    /**
     * ��ȡsendBillHasServiceProdFlg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSendBillHasServiceProdFlg() {
        return sendBillHasServiceProdFlg;
    }

    /**
     * ����sendBillHasServiceProdFlg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSendBillHasServiceProdFlg(Integer value) {
        this.sendBillHasServiceProdFlg = value;
    }

    /**
     * ��ȡsendBillAckbillTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendBillAckbillTypeCode() {
        return sendBillAckbillTypeCode;
    }

    /**
     * ����sendBillAckbillTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendBillAckbillTypeCode(String value) {
        this.sendBillAckbillTypeCode = value;
    }

}
